// ---- Tutorials: a Quick tour (the essentials, about a minute) and a Full tour (every part, about five) ---------
// Both spotlight the real app. Start from Help → Show me around, Settings → General, or the offer new people get.
const T = {
  status: {sel: '#conn', title: 'One clear status', text: '<b>Running</b>, <b>Watching</b>, <b>Paused</b>, <b>Offline</b> or <b>Needs attention</b>, with a plain reason. Click it to see each coin’s “Why no bet?”.'},
  money: {sel: '#sec-balance', tab: 'home', title: 'Your money', text: 'Your total balance, profit for the period you pick (1D, 1W…), and what’s in bets right now.'},
  pause: {sel: '#pause', title: 'Pause and Kill switch', text: '<b>Pause</b> stops new bets and cancels a waiting bid. The <b>Kill switch</b> blocks new bets until you undo it. Bets that already filled always finish at their 15-minute result.'},
  cats: {sel: '#cat', title: 'Ask the cats', text: 'Click your sidekick to ask anything: “What happened while I was away?”, “Why did trading stop?”, “Why did I lose?”. ' +
    'Answers come from your real data and say whether a number is real money, simulated, a past test or an estimate.'},
  help: {sel: '#helpbtn', title: 'Help', text: 'Ask the cats, see why there’s no bet, get the daily recap, replay a tour, export diagnostics, and choose between closing the window, pausing and turning the bot off.'},
  settings: {sel: '#gear', title: 'Settings', text: 'Your Kalshi account, safety limits, text size, sidekicks, coins, alerts and the update history. Hover anything in the app for a short explanation.'},
};
const TOURS = {
  basic: {name: 'Quick tour', steps: [
    {title: 'The quick tour', text: 'The essentials in about a minute. Leave any time with Esc or Skip.'},
    T.status, T.money, T.pause, T.cats, T.help, T.settings,
    {title: 'That’s the basics!', text: 'Start in practice mode if you’re new and keep bets small. Want every detail? <b>Help → Show me around → Full tour</b>.'},
  ]},
  full: {name: 'Full tour', steps: [
    {title: 'The full tour', text: 'Every part of Odds &amp; Whiskers in about five minutes. Use ← → to move and Esc to leave; you can start again from Help.'},
    {sel: '#tabseg', title: 'Three screens', text: '<b>Cat Corner</b> is your home. <b>Statistics</b> has the charts, the future and Backtrack. <b>Litter Box</b> tests other ideas with fake money.'},
    {sel: '#mode', title: 'Which money', text: '<b>Simulated</b> means practice: fake money on real Kalshi prices. <b>Real money</b> means your Kalshi balance is used, within the limits you chose.'},
    T.status, T.help, T.money,
    {sel: '#sec-sim', tab: 'home', title: 'Real vs Simulated', text: 'Slide between your <b>real</b> bot and <b>Simulated you</b>: the same settings and coins with fake money, on the same live prices. A quick reality check.'},
    {sel: '#sec-preset', tab: 'home', title: 'Recommended preset & Clump', text: 'Ideas only get recommended after they beat the original on <b>new</b> markets. The Clump slider sets how much to risk, never which bets. Nothing changes until you press Apply.'},
    {sel: '#sec-picker', tab: 'home', title: 'Pick a version', text: 'Mix a model, coins and a risk level. Each choice shows how the others did, with fake money and on past data.'},
    {sel: '#sec-cats', tab: 'home', title: 'Cat Chat', text: 'Your sidekicks read your bets and Backtrack. Click a cat (or ⇄) to choose who presents each card, or <b>Ask</b> one a question.'},
    {sel: '#sec-profit', tab: 'stats', title: 'Profit charts', text: 'Every settled bet adds to these charts: total profit over time and each day’s result.'},
    {sel: '#sec-future', tab: 'stats', title: 'The future', text: 'Thousands of simulated futures from your own record. The box is the middle half, the whiskers 90% of outcomes. Estimates, not promises.'},
    {sel: '#sec-backtrack', tab: 'stats', title: 'Backtrack', text: 'Replays the strategy on past prices to see how ideas would have done. Past results are a test, not a guarantee.'},
    {sel: '#sec-trades', tab: 'stats', title: 'Every trade', text: 'Each bet with its price, result and fees. Click one to see the details.'},
    {sel: '#lbboard', tab: 'litter', title: 'The Litter Box', text: 'Fake-money models trade the same live prices side by side, so you can see which ideas hold up. No real money, ever. The small Clump slider on each card tests it at another risk level.'},
    {sel: '#viewseg', tab: 'home', title: 'Make it yours', text: '<b>Classic</b> shows everything, <b>Simple</b> just the essentials, <b>Custom</b> your own pick. ✎ Layout lets you move, resize and hide sections.'},
    T.pause, T.cats,
    {sel: '#gear', title: 'Settings', text: '<b>Kalshi account</b> connects your key (stored encrypted on this computer). <b>Safety limits</b> show the most the bot may use, per bet and per day. ' +
      '<b>Updates</b> lists every version; your data is backed up before each one. Plus text size, sidekicks, coins and alerts.'},
    {title: 'Real money, safely', text: 'Switching to real money is always your choice: you pick the limits and type a confirmation yourself. ' +
      'A daily stop pauses betting after a bad day, and the cats can never place a bet or change real-money settings.'},
    {title: 'That’s everything!', text: 'Keep the computer awake while it trades, start small, and ask the cats whenever something looks odd. (Rumour has it there’s a fourth cat somewhere…)'},
  ]},
};
let tourKind = 'basic', tourFromTab = null;
const tourSteps = () => TOURS[tourKind].steps;
let tourIx = -1, tourBox = null, tourPlace = null, tourRaf = 0;
addEventListener('scroll', () => {                 // the spotlight follows the page while it scrolls
  if (!tourPlace || tourRaf) return;
  tourRaf = requestAnimationFrame(() => { tourRaf = 0; if (tourPlace) tourPlace(); });
}, {passive: true});
function tourEl() {
  if (tourBox) return tourBox;
  tourBox = document.createElement('div');
  tourBox.className = 'tour';
  tourBox.innerHTML = '<div class="tour-spot"></div><div class="tour-card" role="dialog" aria-modal="true" aria-labelledby="tourt">' +
    '<div class="tour-n"></div><h3 id="tourt"></h3><p></p><div class="tour-act"><button data-t="skip">Skip</button>' +
    '<span class="spacer"></span><button data-t="back">Back</button><button class="primary" data-t="next">Next</button></div></div>';
  document.body.appendChild(tourBox);
  tourBox.addEventListener('click', e => { const t = e.target.closest('[data-t]'); if (!t) return;
    if (t.dataset.t === 'next') tourGo(tourIx + 1); else if (t.dataset.t === 'back') tourGo(tourIx - 1); else tourEnd(); });
  return tourBox;
}
function tourTarget(st) {
  if (!st.sel) return null;
  const n = document.querySelector(st.sel);
  if (!n) return null;
  const r = n.getBoundingClientRect();
  return r.width && r.height ? n : null;                    // hidden sections are skipped
}
function tourGo(i) {
  if (i < 0) return;
  const steps = tourSteps();
  if (i >= steps.length) return tourEnd();
  const st = steps[i];
  if (st.tab && prefs.tab !== st.tab) { prefs.tab = st.tab; savePrefs(); applyPrefs(); }
  if (st.sel && !tourTarget(st)) return tourGo(i + (i >= tourIx ? 1 : -1));
  tourIx = i;
  const box = tourEl(), card = box.querySelector('.tour-card'), spot = box.querySelector('.tour-spot');
  box.classList.add('on');
  box.querySelector('.tour-n').textContent = `${TOURS[tourKind].name} · ${i + 1} of ${steps.length}`;
  box.querySelector('h3').textContent = st.title;
  box.querySelector('p').innerHTML = st.text;
  box.querySelector('[data-t="back"]').disabled = i === 0;
  box.querySelector('[data-t="next"]').textContent = i === steps.length - 1 ? 'Done' : 'Next';
  const n = tourTarget(st);
  const place = () => {
    const z = pageScale(card), pad = 8;
    if (!n) { spot.classList.add('none'); card.classList.add('center'); card.style.left = card.style.top = ''; return; }
    spot.classList.remove('none'); card.classList.remove('center');
    const r = n.getBoundingClientRect();
    const R = {l: r.left / z - pad, t: r.top / z - pad, w: r.width / z + pad * 2, h: r.height / z + pad * 2};
    const vh = innerHeight / z, vw = innerWidth / z;
    R.h = Math.min(R.h, vh - 24);
    Object.assign(spot.style, {left: R.l + 'px', top: Math.max(4, R.t) + 'px', width: R.w + 'px', height: R.h + 'px'});
    const cw = card.offsetWidth, ch = card.offsetHeight;
    let top = R.t + R.h + 12; if (top + ch > vh - 12) top = Math.max(12, R.t - ch - 12);
    if (top + ch > vh - 12) top = Math.max(12, vh - ch - 12);
    const left = Math.max(12, Math.min(vw - cw - 12, R.l + R.w / 2 - cw / 2));
    card.style.left = left + 'px'; card.style.top = top + 'px';
  };
  if (n) {
    const r = n.getBoundingClientRect();
    if (r.top < 70 || r.bottom > innerHeight - 20) n.scrollIntoView({block: r.height > innerHeight * 0.6 ? 'start' : 'center', behavior: 'smooth'});
  }
  tourPlace = place; place(); setTimeout(place, 400);                    // and on every scroll, below
  setTimeout(() => {                    // if smooth scrolling didn't get there, jump straight to it
    if (!n || tourIx !== i) return;
    const r = n.getBoundingClientRect();
    if (r.top < 0 || r.top > innerHeight - 80) n.scrollIntoView({block: 'start'});
    place();
  }, 900);
  box.querySelector('[data-t="next"]').focus({preventScroll: true});
}
// "Show me around": pick the quick or the full tour
function tourStart(kind) {
  $('scrim').classList.remove('open'); hideTourOffer();
  if (!TOURS[kind]) return tourPick();
  closeSheet('tourpick');
  tourKind = kind; tourIx = -1; tourFromTab = prefs.tab;
  tourGo(0);
}
function tourPick() {
  const n = sheet('tourpick', `<div class="pre-tag">Tutorials</div><h2 style="margin:4px 0 12px">Show me around</h2>
    <div class="leaveopt"><div><b>Quick tour</b><span>The essentials: status, your money, pausing, asking the cats, help and settings.
      About a minute, ${TOURS.basic.steps.length} stops.</span></div><button class="primary" data-tour="basic">Quick tour</button></div>
    <div class="leaveopt"><div><b>Full tour</b><span>Every part of the app, including Statistics, the Litter Box, layouts and real-money safety.
      About five minutes, ${TOURS.full.steps.length} stops.</span></div><button data-tour="full">Full tour</button></div>
    <div class="pre-act" style="justify-content:flex-end"><button data-close>Not now</button></div>`);
  n.querySelector('[data-tour="basic"]').focus({preventScroll: true});
}
document.addEventListener('click', e => { const b = e.target.closest('[data-tour]'); if (b) tourStart(b.dataset.tour); });
function tourEnd() {
  if (tourBox) tourBox.classList.remove('on');
  if (tourFromTab && prefs.tab !== tourFromTab) { prefs.tab = tourFromTab; savePrefs(); applyPrefs(); }   // back where you were
  tourIx = -1; tourPlace = null; tourFromTab = null;
  postJSON('/api/ui', {key: 'tour_done', value: true}).catch(() => {});
  prefs.tourDone = true; savePrefs();
}
addEventListener('keydown', e => { if (tourIx < 0) return;
  if (e.key === 'Escape') tourEnd(); else if (e.key === 'ArrowRight') tourGo(tourIx + 1); else if (e.key === 'ArrowLeft') tourGo(tourIx - 1); });
addEventListener('resize', () => { if (tourIx >= 0) tourGo(tourIx); });

// offered once: a small card in the corner (never on top of the What's new popup)
let tourOffered = false;
function maybeOfferTour(s) {
  if (tourOffered || prefs.tourDone || (s.ui || {}).tour_done || document.getElementById('wnscrim') || s.whats_new_seen !== (s.release || {}).installed) return;
  tourOffered = true;
  const n = document.createElement('div'); n.className = 'toast offer'; n.id = 'touroffer';
  n.innerHTML = '<b>New here?</b> Take a tour of Odds &amp; Whiskers: the quick one (1 minute) or the full one (5 minutes).' +
    '<div class="tour-act"><button data-o="no">Not now</button><button data-o="full">Full tour</button>' +
    '<button class="primary" data-o="basic">Quick tour</button></div>';
  document.body.appendChild(n);
  n.addEventListener('click', e => { const b = e.target.closest('[data-o]'); if (!b) return;
    if (b.dataset.o !== 'no') tourStart(b.dataset.o); else { hideTourOffer(); prefs.tourDone = true; savePrefs(); postJSON('/api/ui', {key: 'tour_done', value: true}).catch(() => {}); } });
}
function hideTourOffer() { const n = $('touroffer'); if (n) { n.classList.add('out'); setTimeout(() => n.remove(), 400); } }
document.addEventListener('click', e => { if (e.target.id === 'tourstart') tourStart(); });
