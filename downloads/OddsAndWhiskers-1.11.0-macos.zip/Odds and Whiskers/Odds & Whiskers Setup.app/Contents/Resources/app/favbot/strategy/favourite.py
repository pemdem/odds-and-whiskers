"""The favourite rule. No price model, no prediction: the market's own price is the only signal.

Inside the last 300 s (and before the last 60 s) of a 15-minute contract, the outcome whose
best ask is in [0.88, 0.97] is the favourite. If its spread is <= 0.03 and not crossed, rest a
post-only buy at its best bid (never at the ask), expiring after 20 s and never into the last 60 s.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from decimal import Decimal

from ..config import StrategyCfg
from ..models import LEGS, Book, Contract


@dataclass(frozen=True)
class Decision:
    bid: bool
    reason: str
    leg: str | None = None
    outcome: str | None = None
    price: Decimal | None = None
    ask: Decimal | None = None
    expiration_ts: int | None = None
    secs_left: float | None = None


def decide(contract: Contract, book: Book, now: float, p: StrategyCfg) -> Decision:
    secs_left = contract.close_ts - now
    if secs_left > p.window_start_s:
        return Decision(False, f"waiting ({int(secs_left)}s left)", secs_left=secs_left)
    if secs_left <= p.window_end_s:
        return Decision(False, "final 60s: no new bids", secs_left=secs_left)

    in_band = []
    for leg in LEGS:
        ask = book.best_ask(leg)
        if ask is not None and p.ask_min <= ask <= p.ask_max:
            in_band.append((leg, book.best_bid(leg), ask))
    if not in_band:
        return Decision(False, "no favourite in 0.88-0.97", secs_left=secs_left)
    if len(in_band) > 1:
        return Decision(False, "both sides in band (thin book)", secs_left=secs_left)

    leg, bid, ask = in_band[0]
    outcome = contract.outcome_of(leg)
    if p.side != "both" and outcome.lower() != p.side:
        return Decision(False, f"{outcome} favourite, but this model only bets {p.side.upper()}", leg=leg,
                        outcome=outcome, ask=ask, secs_left=secs_left)
    if bid is None:
        return Decision(False, f"{outcome} favourite has no bid", leg=leg, outcome=outcome, ask=ask, secs_left=secs_left)
    if bid >= ask:
        return Decision(False, f"{outcome} book crossed/locked", leg=leg, outcome=outcome, ask=ask, secs_left=secs_left)
    if ask - bid > p.max_spread:
        return Decision(False, f"{outcome} spread {ask - bid} > {p.max_spread}", leg=leg, outcome=outcome,
                        price=bid, ask=ask, secs_left=secs_left)
    price = ask if p.entry == "ask" else bid               # 'ask' models buy straight away at the asking price
    if not contract.grid.is_valid(price):
        return Decision(False, f"price {price} off the price grid", leg=leg, outcome=outcome, ask=ask, secs_left=secs_left)
    expiration = min(int(math.floor(now)) + p.order_ttl_s, int(math.floor(contract.close_ts - p.window_end_s)))
    if expiration <= now:
        return Decision(False, "too close to the cutoff to rest a bid", secs_left=secs_left)
    verb = "buy" if p.entry == "ask" else "bid"
    return Decision(True, f"{verb} {outcome} {price} (ask {ask})", leg=leg, outcome=outcome, price=price, ask=ask,
                    expiration_ts=expiration, secs_left=secs_left)


def should_keep(resting_leg: str, resting_price: Decimal, decision: Decision) -> bool:
    """Keep a resting bid only if the strategy would still bid this outcome at this price or higher."""
    return bool(decision.bid and decision.leg == resting_leg and decision.price is not None
                and decision.price >= resting_price)
