"""Stats about your own bets for the 'Cat Corner' insights section.

Everything comes with its sample size; with few bets most differences are luck, and the page says so.
"""
from __future__ import annotations

import time

from .money import d_or_zero


def _group(bets, key):
    g = {}
    for b in bets:
        g.setdefault(key(b), []).append(b)
    out = []
    for k, v in g.items():
        w = sum(1 for b in v if b["won"])
        cost = sum(b["cost"] for b in v)
        contracts = sum(b["qty"] for b in v) or 1
        out.append({"key": k, "n": len(v), "wins": w, "win_rate": w / len(v), "pnl": round(sum(b["pnl"] for b in v), 2),
                    "breakeven": cost / contracts, "roi": (sum(b["pnl"] for b in v) / cost) if cost else 0.0})
    return sorted(out, key=lambda x: -x["pnl"])


def band(p: float) -> str:
    for lo, hi in [(0.85, 0.90), (0.90, 0.92), (0.92, 0.94), (0.94, 0.96), (0.96, 1.0)]:
        if p < hi:
            return f"{lo * 100:.0f}–{hi * 100:.0f}¢"
    return "96¢+"


def build(store, mode: str) -> dict:
    rows = store._q("""SELECT e.*, c.close_ts FROM entries e LEFT JOIN contracts c ON c.ticker=e.ticker
                       WHERE e.mode=? AND e.settled_result IS NOT NULL AND CAST(e.filled_count AS REAL) > 0
                       ORDER BY e.settled_at""", (mode,))
    bets = []
    for r in rows:
        r = dict(r)
        fill_ts = store._q("SELECT MIN(ts) t FROM fills WHERE entry_id=?", (r["id"],))[0]["t"]
        bets.append({"ticker": r["ticker"], "coin": r["coin"], "outcome": r["outcome"], "price": float(r["price"]),
                     "qty": float(d_or_zero(r["filled_count"])),
                     "cost": float(d_or_zero(r["fill_cost"]) + d_or_zero(r["fees"])), "pnl": float(d_or_zero(r["pnl"])),
                     "won": d_or_zero(r["payout"]) > 0, "ts": r["settled_at"],
                     "secs_left_at_fill": (r["close_ts"] - fill_ts) if fill_ts and r["close_ts"] else None})
    n = len(bets)
    if not n:
        return {"n": 0}
    streak = best_streak = run = 0
    for b in bets:
        run = run + 1 if b["won"] else 0
        best_streak = max(best_streak, run)
    for b in reversed(bets):
        if not b["won"]:
            break
        streak += 1
    hours = _group(bets, lambda b: time.localtime(b["ts"]).tm_hour)
    fills = [b["secs_left_at_fill"] for b in bets if b["secs_left_at_fill"] is not None]
    wins = [b["pnl"] for b in bets if b["won"]]
    losses = [b["pnl"] for b in bets if not b["won"]]
    return {
        "n": n, "wins": sum(b["won"] for b in bets), "net": round(sum(b["pnl"] for b in bets), 2),
        "avg_win": (sum(wins) / len(wins)) if wins else None, "avg_loss": (-sum(losses) / len(losses)) if losses else None,
        "by_coin": _group(bets, lambda b: b["coin"]), "by_band": _group(bets, lambda b: band(b["price"])),
        "by_side": _group(bets, lambda b: b["outcome"]), "by_hour": hours,
        "best": sorted(bets, key=lambda b: -b["pnl"])[:3], "worst": sorted(bets, key=lambda b: b["pnl"])[:3],
        "streak": streak, "best_streak": best_streak,
        "avg_secs_left_at_fill": (sum(fills) / len(fills)) if fills else None,
    }
