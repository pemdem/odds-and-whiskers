"""Order intents, idempotency, unknown-outcome handling and reconciliation.

Rules:
- the intent row is written (and holds the contract's slot) before anything is sent;
- a timeout or 5xx on create is UNKNOWN: all new entries are blocked until the exchange is asked;
- an unknown order is re-sent at most once, with the same client_order_id;
- GET /portfolio/orders/{id} may 404 for a few seconds after creation: wait 15 s, then use the list.
"""
from __future__ import annotations

import logging
import sqlite3
import time
import uuid
from decimal import Decimal

from .logutil import log
from .models import Contract, OrderInfo, OrderRequest
from .money import ZERO, d, d_or_zero
from .providers.base import ApiError, NotFound, OrderOutcomeUnknown, TransportError
from .store import SlotTaken, Store

logger = logging.getLogger("favbot.exec")

READ_AFTER_WRITE_LAG_S = 15.0
COID_PREFIX = "fb-"


def new_client_order_id() -> str:
    return COID_PREFIX + uuid.uuid4().hex[:24]


class Execution:
    def __init__(self, store: Store, trading, mode: str, *, alerts=None, account=None, clock=time.time):
        self.store = store
        self.trading = trading
        self.mode = mode
        self.alerts = alerts
        self.account = account
        self.clock = clock
        self._mismatch: dict[str, int] = {}
        self._warned_foreign: set[str] = set()

    def _event(self, level: str, kind: str, msg: str, coin=None, ticker=None, **data) -> None:
        self.store.log_event(level, kind, msg, coin, ticker)
        log(logger, getattr(logging, level.upper()), msg, kind=kind, coin=coin, ticker=ticker, **data)
        if self.alerts and level in ("error", "critical"):
            self.alerts.error(kind, msg)

    def _invalidate(self) -> None:
        if self.account:
            self.account.invalidate()

    # ---- placing ------------------------------------------------------------------------
    async def place(self, c: Contract, *, leg: str, outcome: str, price: Decimal, count: int, max_loss: Decimal,
                    expiration_ts: int, max_attempts: int, ask: Decimal | None = None,
                    post_only: bool = True) -> dict | None:
        coid = new_client_order_id()
        try:
            eid = self.store.insert_intent(mode=self.mode, series=c.series, coin=c.coin, ticker=c.ticker, leg=leg,
                                           outcome=outcome, price=price, count=count, max_loss=max_loss,
                                           expiration_ts=expiration_ts, client_order_id=coid,
                                           max_attempts=max_attempts, ask=ask, now=self.clock())
        except SlotTaken as e:
            log(logger, logging.INFO, "entry slot not available", ticker=c.ticker, why=str(e))
            return None
        req = OrderRequest(c.ticker, coid, leg, price, count, expiration_ts, post_only=post_only)
        return await self._send(eid, req, c.coin)

    async def _send(self, eid: int, req: OrderRequest, coin: str) -> dict:
        self.store.mark_sent(eid, self.clock())
        try:
            ack = await self.trading.create_order(req)
        except OrderOutcomeUnknown as e:
            self.store.mark_unknown(eid, str(e))
            self._event("error", "order_unknown", f"order outcome UNKNOWN for {req.ticker}; blocking new entries until resolved: {e}",
                        coin, req.ticker)
            return self.store.entry(eid)
        except ApiError as e:
            self.store.mark_rejected(eid, str(e))
            level = "error" if "insufficient" in str(e).lower() else "warning"
            self._event(level, "order_rejected", f"order rejected for {req.ticker}: {e}", coin, req.ticker)
            return self.store.entry(eid)
        except Exception as e:  # noqa: BLE001 - be safe: we cannot prove it was not sent
            self.store.mark_unknown(eid, f"{type(e).__name__}: {e}")
            self._event("error", "order_unknown", f"unexpected error sending order for {req.ticker}: {type(e).__name__}: {e}",
                        coin, req.ticker)
            return self.store.entry(eid)
        self.store.mark_resting(eid, ack.order_id)
        self._invalidate()
        log(logger, logging.INFO, "bid placed", ticker=req.ticker, leg=req.leg, price=str(req.price), count=req.count,
            expires=req.expiration_ts, order_id=ack.order_id)
        self.store.log_event("info", "bid_placed", f"bid {req.leg.upper()} {req.count} @ {req.price}", coin, req.ticker)
        e = self.store.entry(eid)
        if ack.fill_count > ZERO:
            e = await self.refresh(e)
        return e

    # ---- reading back ---------------------------------------------------------------------
    async def find_by_coid(self, e: dict) -> OrderInfo | None:
        since = int((e.get("created_at") or self.clock()) - 120)
        for o in await self.trading.list_orders(ticker=e["ticker"], min_ts=since):
            if o.client_order_id == e["client_order_id"]:
                return o
        return None

    async def apply(self, e: dict, info: OrderInfo, reason: str | None = None) -> dict:
        before = d_or_zero(e["filled_count"])
        try:
            new = self.store.apply_order(e["id"], info, reason)
        except sqlite3.IntegrityError:
            # The exchange says this order is live but another entry holds the contract's slot.
            self.store.set_halt("slot_conflict", f"{e['ticker']} order {info.order_id}")
            self._event("critical", "slot_conflict", f"two live orders on {e['ticker']}; cancelling {info.order_id} and halting",
                        e["coin"], e["ticker"])
            try:
                await self.trading.cancel_order(info.order_id, e["ticker"])
            except Exception:  # noqa: BLE001
                pass
            return self.store.entry(e["id"])
        if d_or_zero(new["filled_count"]) > before:
            self._invalidate()
            await self.sync_fills(new)
            self._event("info", "fill", f"FILLED {new['filled_count']} {new['leg'].upper()} ({new['outcome']}) @ {new['price']} "
                        f"on {new['ticker']} - holding to settlement", new["coin"], new["ticker"])
        if new["state"] == "done" and e["state"] != "done":
            self._invalidate()
            log(logger, logging.INFO, "bid ended", ticker=new["ticker"], reason=new["end_reason"],
                filled=new["filled_count"])
        return new

    async def refresh(self, e: dict) -> dict:
        if not e.get("order_id"):
            return e
        info = await self.trading.get_order(e["order_id"])
        if info is None:
            if self.clock() - (e.get("sent_at") or e["created_at"]) < READ_AFTER_WRITE_LAG_S:
                return e  # read-after-write lag: not a missing order yet
            info = await self.find_by_coid(e)
            if info is None:
                self.store.mark_unknown(e["id"], "accepted order not found on the exchange")
                self._event("error", "order_missing", f"order {e['order_id']} not found after {READ_AFTER_WRITE_LAG_S:.0f}s",
                            e["coin"], e["ticker"])
                return self.store.entry(e["id"])
        return await self.apply(e, info)

    async def cancel(self, e: dict, reason: str) -> dict:
        if e["state"] != "resting" or not e.get("order_id"):
            return e
        try:
            await self.trading.cancel_order(e["order_id"], e["ticker"])
        except NotFound:
            pass
        except (ApiError, TransportError) as ex:
            log(logger, logging.WARNING, "cancel request failed; re-reading order", ticker=e["ticker"], error=str(ex))
        # Always re-read after a cancel: it may have filled first.
        try:
            info = await self.trading.get_order(e["order_id"])
            if info is None:
                info = await self.find_by_coid(e)
        except (ApiError, TransportError) as ex:
            log(logger, logging.WARNING, "re-read after cancel failed", ticker=e["ticker"], error=str(ex))
            return e
        if info is None:
            return e
        return await self.apply(e, info, reason=f"cancelled: {reason}")

    async def resolve_unknown(self, e: dict, *, still_wanted: bool) -> dict:
        """Ask the exchange about an order whose outcome is unknown. Re-send at most once."""
        try:
            found = await self.find_by_coid(e)
        except (ApiError, TransportError) as ex:
            log(logger, logging.WARNING, "could not ask exchange about unknown order", ticker=e["ticker"], error=str(ex))
            return e
        if found:
            self.store.mark_resting(e["id"], found.order_id)
            e2 = await self.apply(self.store.entry(e["id"]), found)
            self._event("warning", "order_resolved", f"unknown order found on exchange ({found.status})", e["coin"], e["ticker"])
            return e2
        now = self.clock()
        if now - (e.get("sent_at") or e["created_at"]) < READ_AFTER_WRITE_LAG_S:
            return e
        if e["resend_count"] == 0 and still_wanted and e["expiration_ts"] > now + 3:
            self.store.bump_resend(e["id"])
            self._event("warning", "order_resend", "unknown order not on exchange; re-sending once with the same client_order_id",
                        e["coin"], e["ticker"])
            req = OrderRequest(e["ticker"], e["client_order_id"], e["leg"], d(e["price"]), int(e["count"]),
                               int(e["expiration_ts"]))
            return await self._send(e["id"], req, e["coin"])
        self.store.mark_not_placed(e["id"], "exchange has no record of the order")
        self._event("warning", "order_not_placed", "unknown order confirmed absent; slot released", e["coin"], e["ticker"])
        return self.store.entry(e["id"])

    async def sync_fills(self, e: dict) -> None:
        if not e.get("order_id"):
            return
        for f in await self.trading.get_fills(order_id=e["order_id"]):
            self.store.record_fill(e["id"], f)

    # ---- reconciliation -----------------------------------------------------------------
    async def reconcile(self, series: str, now: float | None = None) -> dict:
        """Reconcile this series' orders, fills and positions with the exchange."""
        now = now or self.clock()
        report = {"refreshed": 0, "orphans": 0, "mismatch": []}
        mine = self.store.entries(self.mode, series=series, states=("resting", "unknown", "intent"))
        for e in mine:
            if e["state"] == "resting":
                await self.refresh(e)
            else:
                f = await self.find_by_coid(e)
                if f:
                    self.store.mark_resting(e["id"], f.order_id)
                    await self.apply(self.store.entry(e["id"]), f)
                elif now - (e.get("sent_at") or e["created_at"]) > 4 * READ_AFTER_WRITE_LAG_S:
                    self.store.mark_not_placed(e["id"], "not on exchange at reconciliation")
            report["refreshed"] += 1

        # Orders resting on the exchange for this series that we do not track.
        resting = await (self.account.resting_orders() if self.account else self.trading.list_orders(status="resting"))
        for o in resting:
            if not o.ticker.startswith(series + "-"):
                continue
            e = self.store.entry_by_coid(o.client_order_id) if o.client_order_id else None
            if e is None:
                if o.client_order_id.startswith(COID_PREFIX):
                    report["orphans"] += 1
                    self._event("error", "orphan_order", f"untracked bot order {o.order_id} on {o.ticker}; cancelling",
                                None, o.ticker)
                    try:
                        await self.trading.cancel_order(o.order_id, o.ticker)
                    except Exception:  # noqa: BLE001
                        pass
                elif o.order_id not in self._warned_foreign:
                    self._warned_foreign.add(o.order_id)
                    self._event("warning", "foreign_order", f"manual order {o.order_id} on {o.ticker} is not managed by the bot",
                                None, o.ticker)
            elif e["state"] != "resting":
                await self.apply(e, o)

        # Fills: make sure every filled entry has its fills recorded.
        for e in self.store.entries(self.mode, series=series, unsettled_slot=True):
            filled = d_or_zero(e["filled_count"])
            if filled <= ZERO:
                continue
            rec = self.store._q("SELECT COALESCE(SUM(CAST(count AS REAL)),0) n FROM fills WHERE entry_id=?", (e["id"],))[0]["n"]
            if Decimal(str(rec)) < filled:
                await self.sync_fills(e)

        # Positions: local fills vs exchange positions, for contracts that have not closed.
        positions = await (self.account.positions() if self.account else self.trading.get_positions())
        exch = {p.ticker: p.position for p in positions if p.ticker.startswith(series + "-")}
        local: dict[str, Decimal] = {}
        for e in self.store.entries(self.mode, series=series, unsettled_slot=True):
            filled = d_or_zero(e["filled_count"])
            if filled > ZERO:
                local[e["ticker"]] = local.get(e["ticker"], ZERO) + (filled if e["leg"] == "yes" else -filled)
        for t in set(exch) | set(local):
            c = self.store.contract(t)
            if c is not None and c.close_ts <= now:
                self._mismatch.pop(t, None)
                continue  # after close only settlement changes positions
            if exch.get(t, ZERO) != local.get(t, ZERO):
                self._mismatch[t] = self._mismatch.get(t, 0) + 1
                log(logger, logging.WARNING, "position mismatch", ticker=t, exchange=str(exch.get(t, ZERO)),
                    local=str(local.get(t, ZERO)), passes=self._mismatch[t])
                if self._mismatch[t] >= 2:
                    report["mismatch"].append(t)
                    if "position_mismatch" not in self.store.halts():
                        self.store.set_halt("position_mismatch",
                                            f"{t}: exchange {exch.get(t, ZERO)} vs local {local.get(t, ZERO)}")
                        self._event("critical", "position_mismatch",
                                    f"local fills and exchange positions disagree on {t} for two passes; no new bets", None, t)
            else:
                self._mismatch.pop(t, None)
        return report
