"""Optional "smarter answers" for the Cat Council, using Anthropic's Claude API. OFF unless the person turns it on.

What it does: the same lookups the built-in cats use are offered to Claude as read-only tools. Claude decides
which to call, and writes the reply in the cat's voice from those results only. The fact blocks shown in the app
still come from the built-in lookups, so the numbers are always the app's own.

What it never does: see any credential (lookups never contain the Kalshi key, Key ID, the Anthropic key, tokens
or emails), place a trade, or change a setting — it has no tools that can. If the API is unavailable, slow, out
of credit or not set up, the built-in answer is used and the app carries on as normal.

Cost and data: the person's own Anthropic account is billed per question (input + output tokens at Anthropic's
published prices); token use is counted and shown in Settings. Each question sends the question text and the
looked-up app data needed to answer it (balances, bets, settings, results, recent log messages with IDs and
emails removed) to Anthropic.
"""
from __future__ import annotations

import asyncio
import json
import time

from . import council, vault

API_URL = "https://api.anthropic.com/v1/messages"
MODELS = {"claude-haiku-5-5": "Claude Haiku 5.5 (fast, lowest cost)", "claude-sonnet-5-5": "Claude Sonnet 5.5 (smarter, costs more)"}
DEFAULT_MODEL = "claude-haiku-5-5"
SECRET = "anthropic"
MAX_TOOL_ROUNDS = 4
TIMEOUT_S = 25

_P = {"type": "object", "properties": {}, "additionalProperties": False}
TOOLS = [
    {"name": "account", "description": "Balance, cash, money in bets and today's P&L (real or practice money).", "input_schema": _P},
    {"name": "positions", "description": "Open bets and waiting bids right now.", "input_schema": _P},
    {"name": "activity", "description": "Bets settled and notable log events since some hours ago.",
     "input_schema": {"type": "object", "properties": {"since_hours": {"type": "number"}}, "additionalProperties": False}},
    {"name": "status", "description": "The bot's one-line status (running/watching/paused/offline/needs attention) and why.", "input_schema": _P},
    {"name": "why_no_bet", "description": "For each coin, the strategy or risk reason it isn't betting right now.", "input_schema": _P},
    {"name": "stop_history", "description": "Recent log events about stopping, pausing, kill switch, errors and restarts.", "input_schema": _P},
    {"name": "risk", "description": "Risk limits, Clump level, exposure now, daily stop.", "input_schema": _P},
    {"name": "strategy", "description": "The live strategy, the recommendation (if any) and the idea being tested.", "input_schema": _P},
    {"name": "litterbox", "description": "Fake-money model leaderboard and the simulated twin.", "input_schema": _P},
    {"name": "backtrack", "description": "Historical test results on past prices.", "input_schema": _P},
    {"name": "scorecard", "description": "Is it working: win rate, likely range, break-even, net.", "input_schema": _P},
    {"name": "losses", "description": "Loss breakdown, losing runs and how unusual recent losses are.",
     "input_schema": {"type": "object", "properties": {"coin": {"type": "string"}}, "additionalProperties": False}},
    {"name": "market", "description": "Current Kalshi prices for the contract closing next, with the time they were read.",
     "input_schema": {"type": "object", "properties": {"coin": {"type": "string"}}, "additionalProperties": False}},
    {"name": "compare", "description": "Compare two Litter Box models by name.",
     "input_schema": {"type": "object", "properties": {"a": {"type": "string"}, "b": {"type": "string"}}, "required": ["a", "b"],
                      "additionalProperties": False}},
    {"name": "coins", "description": "How each coin has done: real/practice settled bets (P&L, win count, return per $, average price), "
                                       "the Litter Box's one-coin fake-money models, and Backtrack per coin. Optional coin filter.",
     "input_schema": {"type": "object", "properties": {"coin": {"type": "string"}}, "additionalProperties": False}},
    {"name": "recap", "description": "Daily recap: P&L, fees, positions, Litter Box progress.",
     "input_schema": {"type": "object", "properties": {"day": {"type": "string", "enum": ["today", "yesterday"]}}, "additionalProperties": False}},
]
PERSONA = {          # the person's chosen sidekick answers every question; only the voice differs
    "biscuit": "Biscuit, a round, friendly ginger cat.",
    "chonk": "Le Chonk, a cute cat with huge buff arms. Gym puns, motto “Bid, don't chase. Chasing is cardio.”",
    "chill": "Le Chill, a relaxed loaf of a cat in sunglasses.",
    "katya": "Katya, a calm grey-blue cat in an ushanka; a little Slavic warmth in her English.",
}


def _system(cat: str) -> str:
    return (f"You are {PERSONA[cat]} You live inside Odds & Whiskers, a desktop app that bets small amounts on Kalshi's "
            "15-minute crypto contracts. Answer the person's question using ONLY the tool results. Rules: "
            "1) Never invent numbers; if a tool says something is unavailable, say so plainly. "
            "2) Say which kind each figure is: real money, practice money, simulated (fake money), historical test, estimate, "
            "or live market — and when it was read if that matters. "
            "3) Mention uncertainty (luck ranges, small samples) when judging results. "
            "4) You cannot trade or change settings; if the person wants a change, tell them to use the buttons shown under "
            "your answer, which keep the app's confirmations. "
            "5) Don't tell them what to do with their money; explain the evidence and the trade-offs. "
            "6) Keep it under 120 words, warm and a little playful, in your character's voice. Plain text, no markdown tables. "
            "7) You are the person's own sidekick and answer every kind of question yourself. Never mention other sidekicks. "
            "8) Follow-ups like “why?” or “compare it to ETH” refer to your previous answer. "
            "9) If the question is unclear, ask one short clarifying question instead of introducing yourself again.")


def settings(store) -> dict:
    s = store.get_meta("council_ai") or {}
    return {"enabled": bool(s.get("enabled")), "model": s.get("model") if s.get("model") in MODELS else DEFAULT_MODEL,
            "consented_at": s.get("consented_at"), "usage": s.get("usage") or {}}


def save_settings(store, **kw) -> dict:
    s = store.get_meta("council_ai") or {}
    s.update(kw)
    store.set_meta("council_ai", s)
    return settings(store)


def _count(store, usage: dict) -> None:
    s = store.get_meta("council_ai") or {}
    u = s.get("usage") or {}
    month = time.strftime("%Y-%m")
    if u.get("month") != month:
        u = {"month": month, "input_tokens": 0, "output_tokens": 0, "questions": 0}
    u["input_tokens"] += int(usage.get("input_tokens", 0))
    u["output_tokens"] += int(usage.get("output_tokens", 0))
    s["usage"] = u
    store.set_meta("council_ai", s)


def _run_tool(x: council.Ctx, name: str, args: dict) -> dict:
    if name not in council.LOOKUPS:
        return {"error": "no such lookup"}
    fn = council.LOOKUPS[name]
    if name == "activity":
        r = fn(x, x.now - float(args.get("since_hours", 24)) * 3600)
    elif name in ("losses", "market", "coins"):
        c = str(args.get("coin") or "").upper() or None
        r = fn(x, c)
    elif name == "compare":
        r = fn(x, args.get("a"), args.get("b"))
    elif name == "recap":
        r = fn(x, args.get("day", "today"))
    else:
        r = fn(x)
    # lookups never contain credentials; log messages in them are already redacted (IDs, emails, keys removed)
    return json.loads(json.dumps(r, default=str))


async def ask(bot, state: dict, question: str, cat: str | None, since: float | None, data_root, post=None,
              context: dict | None = None) -> dict:
    """The AI answer, or the built-in one with a note if the AI can't be used right now."""
    local = council.answer(bot, state, question, cat, since, context)
    cfg = settings(bot.store)
    if not cfg["enabled"]:
        return local
    try:
        key = await asyncio.to_thread(vault.load_secret, data_root, SECRET)
    except Exception:  # noqa: BLE001
        key = None
    if not key:
        return {**local, "note": "Smarter answers are on, but no Anthropic API key is saved. Built-in answer shown."}
    x = council.Ctx(bot, state, since)
    who = local["cat"]
    messages = [{"role": "user", "content": question[:1000]}]
    if context and context.get("q") and context.get("a"):        # the previous turn, so follow-ups make sense
        messages = [{"role": "user", "content": context["q"]}, {"role": "assistant", "content": context["a"]}] + messages
    usage = {"input_tokens": 0, "output_tokens": 0}
    post = post or _post
    try:
        for _ in range(MAX_TOOL_ROUNDS + 1):
            r = await asyncio.wait_for(post(key, {"model": cfg["model"], "max_tokens": 600, "system": _system(who),
                                                  "messages": messages, "tools": TOOLS}), TIMEOUT_S)
            for k in usage:
                usage[k] += int((r.get("usage") or {}).get(k, 0))
            content = r.get("content") or []
            calls = [c for c in content if c.get("type") == "tool_use"]
            if r.get("stop_reason") != "tool_use" or not calls:
                text = " ".join(c.get("text", "") for c in content if c.get("type") == "text").strip()
                break
            messages.append({"role": "assistant", "content": content})
            messages.append({"role": "user", "content": [
                {"type": "tool_result", "tool_use_id": c["id"], "content": json.dumps(_run_tool(x, c["name"], c.get("input") or {}), default=str)}
                for c in calls]})
        else:
            text = ""
    except Exception as e:  # noqa: BLE001 - any problem: the built-in cats answer, the app carries on
        return {**local, "note": f"Smarter answers aren't available right now ({type(e).__name__}). Built-in answer shown."}
    finally:
        _count(bot.store, usage)
    if not text:
        return {**local, "note": "The AI didn't give an answer. Built-in answer shown."}
    s = bot.store.get_meta("council_ai") or {}
    u = s.get("usage") or {}
    u["questions"] = int(u.get("questions", 0)) + 1
    s["usage"] = u
    bot.store.set_meta("council_ai", s)
    return {**local, "intro": "", "text": text, "mode": "ai", "model": cfg["model"], "tokens": usage}


async def _post(key: str, body: dict) -> dict:
    import aiohttp
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=TIMEOUT_S)) as s:
        async with s.post(API_URL, json=body, headers={"x-api-key": key, "anthropic-version": "2023-06-01",
                                                        "content-type": "application/json"}) as r:
            data = await r.json(content_type=None)
            if r.status != 200:
                raise RuntimeError(f"Anthropic API {r.status}: {(data.get('error') or {}).get('type', 'error')}")
            return data
