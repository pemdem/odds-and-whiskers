"""Guards for the six issues found in review (each fails on the old behaviour)."""
from decimal import Decimal as D
from types import SimpleNamespace

from favbot import dashboard
from favbot.alerts import Alerts
from favbot.config import AlertsCfg
from favbot.projection import project
from favbot.store import Store

NOW = 1_800_000_000.0


def _settle_many(s, n):
    for i in range(n):
        eid = s.insert_intent(mode="live", series="KXETH15M", coin="ETH", ticker=f"KXETH15M-{i}", leg="yes", outcome="UP",
                              price=D("0.93"), count=4, max_loss=D("3.72"), expiration_ts=1, client_order_id=f"c{i}",
                              max_attempts=20)
        s._x("UPDATE entries SET filled_count='4', fill_cost='3.72', state='done' WHERE id=?", (eid,))
        won = i % 10 != 0
        pay = D(4) if won else D(0)
        s.settle_entry(eid, "yes" if won else "no", pay, pay - D("3.72"), now=NOW + i)


def test_1_profit_history_uses_every_bet_not_just_the_listed_ones(tmp_path):
    s = Store(tmp_path / "db.sqlite3")
    _settle_many(s, 520)
    dashboard._heavy_cache.update(key=None, val=None)
    h = dashboard._heavy(SimpleNamespace(store=s, mode="live"))
    assert len(h["trades"]) == 500                       # the on-screen list is limited
    assert len(h["series"]) == 520                       # the profit history is not
    assert abs(h["series"][-1]["cum"] - sum(x["pnl"] for x in h["series"])) < 1e-6
    assert h["stats"]["trades_total"] == 520


def test_3_litter_box_streak_has_uncertainty():
    from tests.test_litterbox import test_winning_streak_still_has_uncertainty  # noqa: F401 (covered there)


def bets(n, cost, price):
    return [{"ts": NOW - 5 * 3600 + i * 600, "won": i % 14 != 0, "pnl": (cost * (1 - price) / price) if i % 14 else -cost,
             "cost": cost, "price": price} for i in range(n)]


def test_6_projection_refreshes_when_stake_changes():
    a = project(bets(30, 3.7, 0.93), 22.0, NOW, sims=300)
    b = project(bets(30, 7.4, 0.93), 22.0, NOW, sims=300)
    assert a["avg_cost"] != b["avg_cost"] and a["rows"] != b["rows"]


def test_forecast_counts_fees_in_the_cost_of_a_contract():
    # 93c contract + 1c fee = 94c all-in: a win makes 6c (not 7.1c) and break-even is 94% (not 93%)
    settled = [{"ts": NOW - 5 * 3600 + i * 600, "won": i % 14 != 0, "pnl": (4 * 0.06) if i % 14 else -3.76,
                "cost": 3.76, "price": 0.93, "qty": 4} for i in range(30)]
    p = project(settled, 22.0, NOW, sims=200)
    assert abs(p["breakeven_win_rate"] - 0.94) < 1e-9
    assert abs(p["gain"] - 0.24) < 1e-3                  # 4 contracts x 6c
    no_fee = project([dict(x, cost=3.72, pnl=0.28 if x["won"] else -3.72) for x in settled], 22.0, NOW, sims=200)
    assert abs(no_fee["breakeven_win_rate"] - 0.93) < 1e-9


def test_reliability_network_lost_and_restored_flags():
    sent = []
    a = Alerts(AlertsCfg(), "live", sender_fn=lambda s, b: sent.append(s))
    for _ in range(3):
        a.network(False, "timeout")
    assert a._net_down and a.net_since
    a.network(True)
    assert not a._net_down
