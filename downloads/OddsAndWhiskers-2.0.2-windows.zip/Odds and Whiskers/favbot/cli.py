"""Commands: run, check, ack-live, move-funds, kill, unkill, status, report."""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
import time
import uuid
from decimal import Decimal, InvalidOperation
from pathlib import Path

from .alerts import LABELS, Alerts
from .config import (DEMO_URL, PROD_URL, Config, CredentialError, load_config, load_credentials, load_dotenv)
from .liveguard import ack_phrase, phrase_matches, check_ack, preflight, require_terminal, write_ack
from .logutil import ProcessLock, setup_logging
from .money import d_or_zero
from .store import Store

logger = logging.getLogger("favbot")


def _resolve_mode(cfg: Config, cli_mode: str | None) -> str:
    """LIVE needs both `mode: live` in the config AND `--mode live` on the command line."""
    if cfg.mode == "live" and cli_mode != "live":
        raise SystemExit("config says mode: live but --mode live was not given. Refusing to guess; pass "
                         "--mode live to trade real money, or set mode: paper/demo in the config.")
    mode = cli_mode or cfg.mode
    if mode == "live" and cfg.mode != "live":
        raise SystemExit("--mode live given but the config does not say mode: live. Both are required.")
    return mode


def _store(cfg: Config, mode: str) -> Store:
    return Store(cfg.data_path(mode) / "favbot.sqlite3")


def _limits(cfg: Config, mode: str):
    lim = cfg.limits_for(mode)
    if lim is None:
        raise SystemExit(f"config has no `{mode}_limits` block. Write it yourself; there are no defaults.")
    return lim


def build_clients(cfg: Config, mode: str, store: Store, alerts: Alerts | None, holder: dict):
    from .providers.kalshi import KalshiAPI, KalshiTrading, Signer
    from .providers.paper import PaperExchange

    t = cfg.timing
    net = alerts.network if alerts else None
    if mode == "paper":
        md = KalshiAPI(PROD_URL, read_only=True, timeout_s=t.http_timeout_s, requests_per_s=t.requests_per_s,
                       on_network=net)
        trading = PaperExchange(store, cfg.paper.starting_cash_usd, latency_s=cfg.paper.latency_ms / 1000,
                                depth_fraction=cfg.paper.depth_fraction,
                                fee_lookup=lambda tk: holder["bot"].fee_lookup(tk))
        return md, trading, [md]
    creds = load_credentials(mode, cfg.base_dir, cfg.data_path("live").parent)
    signer = Signer(creds.key_id, creds.private_key)
    api = KalshiAPI(DEMO_URL if mode == "demo" else PROD_URL, signer=signer, read_only=False,
                    timeout_s=t.http_timeout_s, requests_per_s=t.requests_per_s, on_network=net)
    return api, KalshiTrading(api, exchange_index=2), [api]


# ---- run ---------------------------------------------------------------------------------
async def _run(cfg: Config, mode: str, args) -> int:
    from .dashboard import Dashboard
    from .engine import Bot

    data_dir = cfg.data_path(mode)
    store = _store(cfg, mode)
    limits = _limits(cfg, mode)
    alerts = Alerts(cfg.alerts, mode, prefs_fn=lambda: store.get_meta("alert_prefs"))
    holder: dict = {}
    md, trading, closers = build_clients(cfg, mode, store, alerts, holder)
    try:
        if mode == "live":
            creds = load_credentials("live", cfg.base_dir, cfg.data_path("live").parent)
            ok, why = check_ack(data_dir, limits, creds.key_fingerprint())
            if not ok:
                print(f"LIVE refused: {why}")
                return 2
            print(f"Live acknowledgement OK ({why}).")
        if mode in ("live", "demo"):
            checks = await preflight(md, trading, cfg.series, need_balance=True,
                                     max_skew=cfg.timing.max_clock_skew_s)
            _print_checks(checks)
            if not all(c.ok for c in checks):
                print(f"{mode.upper()} refused: pre-flight checks failed.")
                return 2

        bot = Bot(cfg, mode, store, md, trading, limits, alerts=alerts, data_dir=data_dir)
        holder["bot"] = bot
        from .presets import fingerprint
        from .versions import code_hash
        bot.code_version = code_hash()
        bot.config_fp = fingerprint(cfg, mode)
        dash = None
        if cfg.dashboard.enabled and not args.no_dashboard:
            dash = Dashboard(bot, cfg.dashboard.port, token_file=data_dir / "dashboard_token")
            try:
                await dash.start()
                print(f"\nDashboard: {dash.url()}\n")
                (data_dir / "dashboard_url.txt").write_text(dash.url() + "\n", encoding="utf-8")
            except OSError as e:
                print(f"dashboard not started: {e}")
                dash = None
        banner = {"paper": "PAPER (simulated fills on real public prices; no orders are sent)",
                  "demo": "DEMO (Kalshi demo exchange, demo money)",
                  "live": "LIVE - REAL MONEY"}[mode]
        logger.warning("starting %s | coins %s | limits %s", banner, ",".join(cfg.series),
                       {k: str(v) for k, v in limits.model_dump().items()})
        why = "stopped"
        try:
            await bot.run(duration=args.duration)
            why = f"run finished after {args.duration}s" if args.duration else "stopped"
        except asyncio.CancelledError:
            why = "interrupted (Ctrl+C)"
        finally:
            await bot.shutdown(why)
            if dash:
                await dash.stop()
            logger.warning("shutdown: %s", why)
        return 0
    finally:
        for c in closers:
            await c.close()
        store.close()


def cmd_run(cfg: Config, args) -> int:
    mode = _resolve_mode(cfg, args.mode)
    data_dir = cfg.data_path(mode)
    setup_logging(data_dir, cfg.log_level)
    lock = ProcessLock(data_dir)
    try:
        lock.acquire()
    except RuntimeError as e:
        print(e)
        return 2
    _keep_awake(True)
    try:
        return asyncio.run(_run(cfg, mode, args))
    except KeyboardInterrupt:
        return 0
    except CredentialError as e:
        print(f"credentials: {e}")
        return 2
    finally:
        _keep_awake(False)
        lock.release()


def _keep_awake(on: bool) -> None:
    """Ask Windows not to sleep while the bot runs (the screen may still turn off). No system setting is changed."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        ES_CONTINUOUS, ES_SYSTEM_REQUIRED = 0x80000000, 0x00000001
        ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS | (ES_SYSTEM_REQUIRED if on else 0))
        if on:
            logger.info("keeping the computer awake while the bot runs")
    except Exception:  # noqa: BLE001
        logger.warning("could not ask Windows to stay awake")


# ---- check -------------------------------------------------------------------------------
def _print_checks(checks) -> None:
    for c in checks:
        print(f"  [{'ok' if c.ok else 'FAIL'}] {c.name}: {c.detail}")


async def _check(cfg: Config, mode: str) -> int:
    print(f"Mode: {mode} ({LABELS[mode]})")
    lim = cfg.limits_for(mode)
    print(f"  [{'ok' if lim else 'FAIL'}] {mode}_limits block: {'present' if lim else 'missing (no defaults; write it yourself)'}")
    store = _store(cfg, mode)
    try:
        md, trading, closers = build_clients(cfg, mode, store, None, {"bot": None})
    except CredentialError as e:
        print(f"  [FAIL] credentials: {e}")
        return 2
    try:
        if mode != "paper":
            print("  [ok] credentials load")
        checks = await preflight(md, trading, cfg.series, need_balance=mode != "paper",
                                 max_skew=cfg.timing.max_clock_skew_s)
        _print_checks(checks)
        if mode == "live" and lim:
            creds = load_credentials("live", cfg.base_dir, cfg.data_path("live").parent)
            ok, why = check_ack(cfg.data_path(mode), lim, creds.key_fingerprint())
            print(f"  [{'ok' if ok else 'FAIL'}] live acknowledgement: {why}")
        return 0 if all(c.ok for c in checks) and lim else 1
    finally:
        for c in closers:
            await c.close()
        store.close()


def cmd_check(cfg: Config, args) -> int:
    mode = args.mode or cfg.mode
    return asyncio.run(_check(cfg, mode))


# ---- ack-live ----------------------------------------------------------------------------
def cmd_ack_live(cfg: Config, args) -> int:
    require_terminal()
    pending = cfg.live_limits_pending
    lim = pending or cfg.live_limits
    if lim is None:
        print("No live_limits block in the config. Write it yourself first; there are no defaults.")
        return 2
    try:
        creds = load_credentials("live", cfg.base_dir, cfg.data_path("live").parent)
    except CredentialError as e:
        print(f"credentials: {e}")
        return 2
    if pending:
        print("\nNew limits are waiting for your confirmation (chosen in the app).")
        print("Until you accept them, the bot keeps using the current ones.\n")
        cur = cfg.live_limits.model_dump() if cfg.live_limits else {}
        for k, v in pending.model_dump().items():
            was = cur.get(k)
            print(f"  {k:<28} {v}" + (f"   (now {was})" if was is not None and str(was) != str(v) else ""))
    else:
        print("\nYou are about to allow this bot to trade REAL MONEY on Kalshi with these limits:\n")
        for k, v in lim.model_dump().items():
            print(f"  {k:<28} {v}")
    print("\nThe strategy has not been shown to be profitable. Live results so far are a small sample.\n"
          "Any filled position can lose its full cost. The kill switch cancels resting bids but does not\n"
          "close filled positions. This acknowledgement expires in 30 days or when the limits or key change.\n")
    phrase = ack_phrase(lim)
    print(f"To accept, type exactly:\n\n  {phrase}\n")
    typed = input("> ").strip()
    if not phrase_matches(typed, phrase):
        print("Not accepted.")
        return 1
    if pending:
        from .configedit import update_config
        update_config(Path(cfg.config_path), {"live_limits": {k: str(v) if not isinstance(v, int) else v
                                                              for k, v in pending.model_dump().items()},
                                               "live_limits_pending": None})
        print("The new limits are now your live limits.")
    rec = write_ack(cfg.data_path("live"), lim, creds.key_fingerprint())
    print(f"Accepted. Valid until {time.strftime('%Y-%m-%d %H:%M UTC', time.gmtime(rec['expires_at']))}.")
    if pending:
        print("Restart the bot from the app (banner: Restart now) to start using them.")
    return 0


# ---- move-funds --------------------------------------------------------------------------
def _ask_decimal(prompt: str) -> Decimal | None:
    try:
        v = Decimal(input(prompt).strip().replace("$", "").replace(",", ""))
    except (InvalidOperation, EOFError):
        return None
    return v if v > 0 else None


async def _move(cfg: Config, mode: str, amount: Decimal | None, source: int | None = 0) -> int:
    from .providers.kalshi import KalshiAPI, KalshiTrading, Signer

    creds = load_credentials(mode, cfg.base_dir, cfg.data_path("live").parent)
    api = KalshiAPI(DEMO_URL if mode == "demo" else PROD_URL, signer=Signer(creds.key_id, creds.private_key),
                    read_only=False)
    try:
        tr = KalshiTrading(api, exchange_index=2)
        shard = (await api.get_series(cfg.series[0])).exchange_index
        bal = await tr.get_all_balances()
        print(f"\n{LABELS[mode]} account balances by shard:")
        rows = bal.get("balance_breakdown") or []
        for b in rows:
            print(f"  shard {b.get('exchange_index')}: ${b.get('balance')}"
                  + ("   <- crypto (where the bot trades)" if b.get("exchange_index") == shard else ""))
        if source is None:                       # asked from "Move money to crypto.bat"
            others = [b for b in rows if b.get("exchange_index") != shard and d_or_zero(b.get("balance")) > 0]
            if not others:
                print("\nThere's no money outside the crypto section. Nothing to move.")
                return 0
            source = max(others, key=lambda b: d_or_zero(b.get("balance"))).get("exchange_index")
            print(f"\nMoving from shard {source} (it has the most money outside crypto).")
        if amount is None:
            amount = _ask_decimal("How many dollars should be moved to crypto? $")
            if amount is None:
                print("Not a valid amount. Nothing moved.")
                return 1
        if source == shard:
            print(f"Source and destination are both shard {shard}; nothing to do.")
            return 2
        print(f"\nMove ${amount:.2f} from shard {source} to shard {shard} (where the crypto series trade)?")
        phrase = f"MOVE {amount:.2f} TO SHARD {shard}"
        print(f"Type exactly:  {phrase}")
        if not phrase_matches(input("> "), phrase):
            print("Not confirmed. Nothing moved.")
            return 1
        r = await tr.transfer_to_shard(amount, shard, str(uuid.uuid4()), source_shard=source)
        print(f"Transfer submitted (id {r.get('transfer_id')}); it is processed asynchronously. "
              f"Check with `python -m favbot check --mode {mode}`.")
        return 0
    finally:
        await api.close()


def cmd_move_funds(cfg: Config, args) -> int:
    require_terminal()
    mode = args.mode or cfg.mode
    if mode not in ("demo", "live"):
        print("move-funds needs --mode demo or --mode live")
        return 2
    amount = None
    if args.amount is not None:
        try:
            amount = Decimal(args.amount)
        except InvalidOperation:
            print("bad amount")
            return 2
        if amount <= 0:
            print("amount must be positive")
            return 2
    try:
        return asyncio.run(_move(cfg, mode, amount, args.from_shard))
    except CredentialError as e:
        print(f"credentials: {e}")
        return 2


# ---- kill / unkill / status / report -----------------------------------------------------
def cmd_kill(cfg: Config, args) -> int:
    mode = args.mode or cfg.mode
    store = _store(cfg, mode)
    reason = args.reason or "manual kill command"
    store.set_kill(reason)
    kf = cfg.data_path(mode) / "KILL"
    kf.write_text(reason + "\n", encoding="utf-8")
    store.log_event("critical", "kill", f"kill switch on: {reason}")
    print(f"KILL SWITCH ON for {mode}. A running bot blocks all orders and cancels its resting bids within ~2 s.\n"
          "Filled positions are NOT closed: they are held to settlement. Undo with `unkill`.")
    return 0


def cmd_unkill(cfg: Config, args) -> int:
    mode = args.mode or cfg.mode
    store = _store(cfg, mode)
    store.clear_kill()
    kf = cfg.data_path(mode) / "KILL"
    if kf.exists():
        kf.unlink()
    msg = "kill switch cleared"
    if args.halts:
        store.clear_halt()
        msg += " and reconciliation halts cleared"
    store.log_event("warning", "unkill", msg)
    print(msg + ".")
    if not args.halts and store.halts():
        print(f"Still halted: {store.halts()}. Investigate, then run `unkill --halts`.")
    return 0


def cmd_status(cfg: Config, args) -> int:
    mode = args.mode or cfg.mode
    store = _store(cfg, mode)
    print(f"Mode {mode} ({LABELS[mode]})  data: {cfg.data_path(mode)}")
    k = store.kill_state()
    print(f"Kill switch: {'ON - ' + k['reason'] if k else 'off'}")
    print(f"Halts: {store.halts() or 'none'}")
    if mode == "paper":
        st = store.get_meta("paper_state")
        if st:
            print(f"Paper cash: ${Decimal(st['cash']):.2f}")
    live = store.entries(mode, states=("intent", "resting", "unknown"))
    hold = [e for e in store.entries(mode, unsettled_slot=True) if d_or_zero(e["filled_count"]) > 0]
    print(f"Pending bids: {len(live)}")
    for e in live:
        print(f"  {e['ticker']} {e['state']} {e['outcome']} {e['count']}@{e['price']}")
    print(f"Open positions: {len(hold)}")
    for e in hold:
        print(f"  {e['ticker']} {e['outcome']} {e['filled_count']}@{e['price']}")
    print("Recent warnings/errors:")
    for ev in store.recent_events(10):
        print(f"  {time.strftime('%m-%d %H:%M:%S', time.gmtime(ev['ts']))}Z {ev['level']:<8} {ev['kind']}: {ev['message']}")
    return 0


def cmd_report(cfg: Config, args) -> int:
    from .report import build_report, format_report

    mode = args.mode or cfg.mode
    r = build_report(_store(cfg, mode), mode)
    print(json.dumps(r, indent=2, default=str) if args.json else format_report(r))
    return 0


def cmd_backtrack(cfg: Config, args) -> int:
    from .backtrack import run

    from .config import DEFAULT_SERIES
    from .litterbox import backtrack_params, load_models
    root = cfg.data_path("live").parent
    series = list(dict.fromkeys(list(DEFAULT_SERIES) + list(cfg.series)))   # every coin, even ones your bot skips
    res = run(series, args.days, root / "backtrack", extra=backtrack_params(load_models(Path(cfg.base_dir), root)))
    cur = res["current"]["all"]
    print(f"Replayed {res['contracts']:,} contracts over {args.days:g} days.")
    if cur.get("n"):
        print(f"Current settings: {cur['n']} bets, win rate {cur['win_rate']:.1%}, return {cur['roi']:+.2%} per $ bet "
              f"(±{2 * cur['se']:.2%})")
    for s in res["suggestions"]:
        print(f"Suggestion: {s['label']}: test return {s['test']['roi']:+.2%} vs current {res['current']['test'].get('roi', 0):+.2%}")
    if not res["suggestions"]:
        print("No setting beat the current one convincingly on the held-out test period.")
    return 0


def cmd_litterbox(cfg: Config, args) -> int:
    from .litterbox import main as lb_main
    return lb_main(cfg, cfg.data_path("live").parent / "litterbox", args.duration)


def cmd_versions(cfg: Config, args) -> int:
    from . import versions as V

    if args.action == "save":
        p = V.save(args.label or "manual")
        print(f"Saved restore point #{p['number']}: {p['label']} ({p['files']} files)")
    elif args.action == "restore":
        r = V.restore(int(args.label))
        print(f"Restored #{r['restored']['number']} ({r['restored']['label']}). "
              f"The code from just before was saved as #{r['saved_current_as']['number']}.")
        print("If the bot is running, restart it to use the restored code.")
    else:
        pts = V.list_points()
        if not pts:
            print("No restore points yet.")
        for p in pts:
            print(f"  #{p['number']:<3} {p['saved_at']}  {p['label']}")
    return 0


# ---- setting up a new copy (a friend's PC) ---------------------------------------------------
def _set_env(path: Path, values: dict[str, str]) -> None:
    """Set KEY=value lines in .env, keeping everything else."""
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    done = set()
    for i, ln in enumerate(lines):
        k = ln.split("=", 1)[0].strip()
        if k in values and not ln.lstrip().startswith("#"):
            lines[i] = f"{k}={values[k]}"
            done.add(k)
    lines += [f"{k}={v}" for k, v in values.items() if k not in done]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


async def _show_balances(cfg: Config) -> dict:
    from .providers.kalshi import KalshiAPI, KalshiTrading, Signer
    creds = load_credentials("live", cfg.base_dir, cfg.data_path("live").parent)
    api = KalshiAPI(PROD_URL, signer=Signer(creds.key_id, creds.private_key), read_only=False)
    try:
        shard = (await api.get_series(cfg.series[0])).exchange_index
        bal = await KalshiTrading(api, exchange_index=2).get_all_balances()
        out = {}
        for b in bal.get("balance_breakdown") or []:
            out[b.get("exchange_index")] = d_or_zero(b.get("balance"))
            print(f"  shard {b.get('exchange_index')}: ${b.get('balance')}" + ("   <- crypto (where the bot trades)"
                                                                                 if b.get("exchange_index") == shard else ""))
        return {"crypto": out.get(shard, Decimal(0)), "other": sum(v for k, v in out.items() if k != shard)}
    finally:
        await api.close()


def cmd_setup_key(cfg: Config, args) -> int:
    """Typed by the owner of the key, on their own PC. The key goes to keys/ and .env — never into the config."""
    require_terminal()
    import os
    import re
    from cryptography.hazmat.primitives import serialization
    root = Path(cfg.base_dir)
    env = root / ".env"
    print("\nSet up YOUR Kalshi API key (kalshi.com -> Account & security -> API keys -> Create key).")
    print("It stays on this computer: the key file goes in the keys folder, the Key ID in .env.\n")
    if os.environ.get("KALSHI_API_KEY_ID"):
        if input("A key is already set up here. Replace it? Type yes to replace: ").strip().lower() != "yes":
            print("Kept the current key.")
            return 0
    key_id = input("1) Paste your Key ID (the short code, NOT the private key) and press Enter:\n> ").strip()
    if not re.fullmatch(r"[A-Za-z0-9-]{8,80}", key_id):
        print("That doesn't look like a Key ID. Nothing changed.")
        return 1
    print("\n2) Drag the private key file you downloaded from Kalshi into this window, then press Enter.")
    print("   (No file? Just press Enter, then paste the whole key, BEGIN and END lines included.)")
    raw = input("> ").strip().strip('"').strip("'")
    if raw:
        p = Path(raw).expanduser()
        if not p.is_file():
            print("Can't find that file. Nothing changed.")
            return 1
        pem = p.read_bytes()
    else:
        lines = []
        while len(lines) < 200:
            ln = input()
            lines.append(ln)
            if "END" in ln and "PRIVATE KEY" in ln:
                break
        pem = ("\n".join(x.strip() for x in lines) + "\n").encode()
    try:
        serialization.load_pem_private_key(pem.strip() + b"\n", password=None)
    except Exception:  # noqa: BLE001 - any parse problem means the same thing to the user
        print("That isn't a valid private key (it must include the BEGIN and END lines). Nothing changed.")
        return 1
    keys = root / "keys"
    keys.mkdir(exist_ok=True)
    dest = keys / "kalshi-private-key.pem"
    dest.write_bytes(pem.strip() + b"\n")
    _set_env(env, {"KALSHI_API_KEY_ID": key_id, "KALSHI_PRIVATE_KEY_FILE": str(dest)})
    os.environ.update(KALSHI_API_KEY_ID=key_id, KALSHI_PRIVATE_KEY_FILE=str(dest))
    print("\nSaved. Checking it with Kalshi (read-only)...")
    try:
        b = asyncio.run(_show_balances(cfg))
    except Exception as e:  # noqa: BLE001
        print(f"Kalshi didn't accept it: {type(e).__name__}: {str(e)[:200]}\nCheck the Key ID and file, then run this again.")
        return 1
    print("\nYour key works.")
    if not b["crypto"] and b["other"]:
        print("Your money is outside the crypto section. Double-click 'Move money to crypto.bat' to move some.")
    print("When you're ready for real money, double-click 'Go live.bat'.")
    return 0


def _stop_bot(cfg: Config, mode: str) -> bool:
    """Ask a running bot of this copy to turn off through its own app endpoint."""
    import urllib.request
    d = cfg.data_path(mode)
    try:
        url = (d / "dashboard_url.txt").read_text(encoding="utf-8").split("/?")[0]
        token = (d / "dashboard_token").read_text(encoding="utf-8").strip()
        req = urllib.request.Request(url + "/api/shutdown", method="POST", headers={"X-Token": token})
        urllib.request.urlopen(req, timeout=5).read()
        return True
    except (OSError, ValueError):
        return False


def cmd_go_live(cfg: Config, args) -> int:
    """Real money, step by step. The person whose money it is chooses the limits and types the confirmation."""
    require_terminal()
    from .config import Limits
    from .configedit import update_config
    from .presets import RISK_LEVELS, limits_for_level
    if cfg.mode == "live" and cfg.live_limits:
        print("This copy is already set up for real money. Change risk with the Clump slider in the app.")
        return 0
    try:
        load_credentials("live", cfg.base_dir, cfg.data_path("live").parent)
    except CredentialError:
        print("Set up your Kalshi key first: double-click 'Set up my Kalshi key.bat'.")
        return 2
    print("\nGoing live means the bot bets REAL money from your Kalshi account.\nYour balances:")
    try:
        bal = asyncio.run(_show_balances(cfg))
    except Exception as e:  # noqa: BLE001
        print(f"Couldn't read your balance: {type(e).__name__}: {str(e)[:200]}")
        return 2
    if not bal["crypto"]:
        print("\nThe crypto section has $0. Move money there first ('Move money to crypto.bat'), then run this again.")
        return 2
    cap = _ask_decimal(f"\n1) The most money the bot may use (you have ${bal['crypto']:.2f} in crypto). Dollars: $")
    if cap is None:
        print("Not a valid amount. Nothing changed.")
        return 1
    print("\n2) Risk level (the Clump slider). Start low; you can change it in the app later.")
    for lv, nm, stake, exp, pos in RISK_LEVELS:
        print(f"   {lv} = {nm:<7} up to ${stake} per bet, {pos} bet(s) open at once")
    try:
        level = int(input("Pick 1-5: ").strip())
        assert 1 <= level <= 5
    except (ValueError, AssertionError, EOFError):
        print("Not a valid level. Nothing changed.")
        return 1
    base = Limits(capital_cap_usd=cap, max_loss_per_position_usd=Decimal("1"), max_loss_per_position_pct=Decimal("0.1"),
                  max_total_exposure_pct=Decimal("0.1"), daily_loss_pct=Decimal("0.20"), max_open_positions=1)
    lim = limits_for_level(level, base)
    path = Path(cfg.config_path)
    update_config(path, {"live_limits_pending": {k: (v if isinstance(v, int) else str(v)) for k, v in lim.model_dump().items()}})
    rc = cmd_ack_live(load_config(path), args)            # shows the limits and asks YOU to type the phrase
    if rc != 0:
        update_config(path, {"live_limits_pending": None})
        print("Nothing changed: the bot stays in practice mode.")
        return rc
    update_config(path, {"mode": "live"})
    stopped = _stop_bot(cfg, "paper")
    print("\nDone: this copy now trades real money with the limits above."
          + ("\nThe practice bot was turned off." if stopped else "")
          + "\nDouble-click the Odds & Whiskers icon on your Desktop to start it.")
    return 0


def cmd_release(cfg: Config, args) -> int:
    from . import release as R
    try:
        if args.action == "init":
            pub = R.init_signing()
            print(f"Signing key ready: {R.SIGNING_KEY}\nKeep it safe (it's outside the app folder; restore points and zips never "
                  f"include it). Public key {pub[:16]}… is now part of the code, so friends' copies trust it.")
        elif args.action == "publish":
            folder = Path(args.to) if args.to else R.default_folder()
            r = R.publish(folder, args.notes or "", args.version)
            print(f"Published Odds & Whiskers {r['version']} ({r['files']} files) to {r['path']}")
            for plat, p in r.get("share", {}).items():
                print(f"Share file ({'Mac' if plat == 'macos' else 'Windows'}) updated: {p}")
        elif args.action == "install":
            info = R.check()
            if not info["available"]:
                print(f"No newer version found (installed {info['installed']}).")
                return 0
            r = R.install(Path(info["available"]["path"]))
            print(f"Installed {r['version']}. Restore point #{r['restore_point']} has the previous code. Restart the bot.")
        else:
            info = R.check()
            print(f"Installed: {info['installed']}  ·  publisher on this PC: {R.is_publisher()}")
            print(f"Update folders: {', '.join(info['folders']) or 'none found'}")
            a = info["available"]
            print(f"Available: {a['version']} — {a['notes']}" if a else "No newer version available.")
            for x in info["rejected"]:
                print("Ignored:", x)
    except R.ReleaseError as e:
        print(f"release: {e}")
        return 2
    return 0


def _use_certifi() -> None:
    """Python from python.org on a Mac has no trusted certificates until 'Install Certificates' is run, so every
    secure connection (Kalshi, the update website) would fail. Point it at certifi's bundle instead."""
    import os
    if sys.platform == "darwin" and not os.environ.get("SSL_CERT_FILE"):
        try:
            import certifi
            os.environ["SSL_CERT_FILE"] = certifi.where()
        except ImportError:
            pass


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="favbot", description="Kalshi 15-minute crypto favourite bot")
    p.add_argument("--config", default="config.yaml")
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--mode", choices=["paper", "demo", "live"])
    r.add_argument("--duration", type=float, help="stop after N seconds")
    r.add_argument("--no-dashboard", action="store_true")
    for name in ("check", "status", "kill", "unkill", "report", "move-funds"):
        sp = sub.add_parser(name)
        sp.add_argument("--mode", choices=["paper", "demo", "live"])
        if name == "kill":
            sp.add_argument("--reason")
        if name == "unkill":
            sp.add_argument("--halts", action="store_true", help="also clear reconciliation halts")
        if name == "report":
            sp.add_argument("--json", action="store_true")
        if name == "move-funds":
            sp.add_argument("--amount", help="dollars to move (asked if left out)")
            sp.add_argument("--from-shard", type=int, default=None,
                            help="shard to move money out of (default: the one with the most money outside crypto)")
    sub.add_parser("ack-live")
    bp = sub.add_parser("backtrack", help="replay the strategy on Kalshi's public price history (read-only)")
    bp.add_argument("--days", type=float, default=7)
    lp = sub.add_parser("litterbox", help="run the fake-money Litter Box models (read-only market data)")
    lp.add_argument("--duration", type=float)
    vp = sub.add_parser("versions", help="restore points: list | save LABEL | restore NUMBER")
    vp.add_argument("action", nargs="?", default="list", choices=["list", "save", "restore"])
    vp.add_argument("label", nargs="?")
    sub.add_parser("setup-key", help="save YOUR Kalshi key on this PC (interactive)")
    sub.add_parser("go-live", help="switch this copy to real money, step by step (interactive)")
    rp = sub.add_parser("release", help="sharing: status | init | publish | install")
    rp.add_argument("action", nargs="?", default="status", choices=["status", "init", "publish", "install"])
    rp.add_argument("--notes", help="what's new (shown to friends)")
    rp.add_argument("--version", help="e.g. 1.9.0 (default: next number)")
    rp.add_argument("--to", help="folder to publish to (default: the shared OneDrive updates folder)")
    args = p.parse_args(argv)

    cfg_path = Path(args.config)
    if not cfg_path.exists():
        print(f"config not found: {cfg_path} (copy config.example.yaml to config.yaml)")
        return 2
    load_dotenv(cfg_path.resolve().parent / ".env")
    _use_certifi()
    cfg = load_config(cfg_path)
    handler = {"run": cmd_run, "check": cmd_check, "ack-live": cmd_ack_live, "move-funds": cmd_move_funds,
               "kill": cmd_kill, "unkill": cmd_unkill, "status": cmd_status, "report": cmd_report,
               "versions": cmd_versions, "backtrack": cmd_backtrack,
               "litterbox": cmd_litterbox, "setup-key": cmd_setup_key, "go-live": cmd_go_live,
               "release": cmd_release}[args.cmd]
    return handler(cfg, args)


if __name__ == "__main__":
    sys.exit(main())
