from favbot.backtrack import CURRENT, Params, analyse, replay, stats

CLOSE = 1_800_000_900


def contract(result="yes", up=True, fills=True, ticker="KXETH15M-T", close=CLOSE):
    # minute candles: (bid_close, ask_close, bid_high, ask_low)
    c = {close - 300: (0.91, 0.93, 0.91, 0.93)}                     # state at 5 min left: YES bid .91 ask .93
    c[close - 240] = (0.91, 0.93, 0.91, 0.90 if fills else 0.91)    # next minute: ask trades through .91 (or only touches)
    for k in (180, 120, 60):
        c[close - k] = (0.91, 0.93, 0.91, 0.93)
    return {"ticker": ticker, "series": "KXETH15M", "coin": "ETH", "close": close, "up": up, "result": result, "c": c}


def test_bid_fills_only_on_trade_through_and_holds_to_result():
    b = replay([contract(fills=True)], CURRENT)
    assert len(b) == 1 and b[0]["price"] == 0.91 and b[0]["won"] and abs(b[0]["pnl"] - 0.09) < 1e-9
    assert replay([contract(fills=False)], CURRENT) == []           # a touch is not a fill


def test_loss_and_side_mapping():
    b = replay([contract(result="no")], CURRENT)
    assert not b[0]["won"] and abs(b[0]["pnl"] + 0.91) < 1e-9 and b[0]["outcome"] == "UP"
    inv = replay([contract(up=False)], CURRENT)                     # YES means DOWN on an inverted contract
    assert inv[0]["outcome"] == "DOWN"
    assert replay([contract()], Params(side="down")) == []


def test_taker_pays_ask_and_fee():
    b = replay([contract()], CURRENT, taker=True)
    # $4 bet -> 4 contracts at 0.93; fee rounded up per order: ceil(0.07*4*0.93*0.07) = $0.02
    assert b[0]["price"] == 0.93 and b[0]["qty"] == 4 and b[0]["fee"] == 0.02
    assert abs(b[0]["pnl"] * 4 - (4 - 3.72 - 0.02)) < 1e-9
    assert replay([contract()], Params(mode="ask"))[0]["price"] == 0.93


def test_every_bid_fill_is_uncertain_even_a_sustained_cross():
    from favbot.backtrack import prepare, replay_fast
    c = contract(fills=True)                           # ask dips to .90 but closes back at .93
    b = replay_fast(prepare([c]), CURRENT)[0]
    assert b["sustained"] is False and b["certain"] is False
    assert replay_fast(prepare([c]), CURRENT, strict=True) == []
    c["c"][CLOSE - 240] = (0.91, 0.90, 0.91, 0.90)     # still through at the minute's close: stricter, NOT proof
    b = replay_fast(prepare([c]), CURRENT, strict=True)[0]
    assert b["sustained"] is True and b["certain"] is False
    assert stats([b])["uncertain_fills"] == 1.0 and stats([b])["sustained_share"] == 1.0
    t = replay_fast(prepare([c]), CURRENT, taker=True)[0]     # buying at the ask has no fill question
    assert t["certain"] is True and stats([t])["uncertain_fills"] == 0.0


def test_uncertain_fills_are_never_rated_strong():
    from favbot.backtrack import _judge
    cur = {"n": 500, "roi": -0.02, "se": 0.005, "max_drawdown_4": 20}
    great = {"n": 500, "roi": 0.03, "se": 0.005, "max_drawdown_4": 18}
    assert _judge(dict(great, uncertain_fills=0.0), cur)[3] == "strong"
    assert _judge(dict(great, uncertain_fills=1.0), cur)[3] == "better"        # bid fills from minute data


def test_proposal_includes_a_coin_choice_tested_walk_forward():
    from favbot.backtrack import best_choice, coin_sets, prepare, walk_forward
    cs = []
    for i in range(400):            # ETH favourites always win; SOL favourites lose 1 in 4
        eth = i % 2 == 0
        cs.append(contract(close=CLOSE + 900 * i, ticker=f"KX{'ETH' if eth else 'SOL'}15M-{i}",
                           result="yes" if eth or i % 8 != 1 else "no"))
        cs[-1]["coin"] = "ETH" if eth else "SOL"
    prep = prepare(cs)
    bets = __import__("favbot.backtrack", fromlist=["replay_fast"]).replay_fast(prep, Params(mode="ask"))
    assert coin_sets(bets) == [None, ["ETH"]]
    p, coins, st = best_choice(prep, 50)
    assert coins == ["ETH"] and st["n"] == 200 and st["win_rate"] == 1.0
    wf = walk_forward(prep, folds=4)
    assert wf["folds"] and all(f["coins"] == ["ETH"] for f in wf["folds"])
    r = analyse(cs, 4)
    assert r["proposal"]["coins"] == ["ETH"]


def test_band_and_spread_filters():
    assert replay([contract()], Params(ask_min=0.94)) == []
    assert replay([contract()], Params(max_spread=0.01)) == []


def test_stats_and_analyse_shape():
    cs = [contract(close=CLOSE + 900 * i, ticker=f"KXETH15M-{i}", result="yes" if i % 10 else "no") for i in range(60)]
    s = stats(replay(cs, CURRENT))
    assert s["n"] == 60 and abs(s["win_rate"] - 54 / 60) < 1e-9
    r = analyse(cs, 1)
    assert r["contracts"] == 60 and r["current"]["all"]["n"] == 60 and "top" in r and "picked_off_gap" in r


def test_5_suggestion_must_beat_current_on_fresh_data_incl_stress_test_and_risk():
    from favbot.backtrack import _judge
    cur = {"n": 500, "roi": -0.02, "se": 0.005, "max_drawdown_4": 20}
    good = {"n": 500, "roi": 0.01, "se": 0.005, "max_drawdown_4": 18}
    assert _judge(good, cur, {"roi": 0.0}, {"roi": -0.1})[3] in ("better", "strong")
    assert _judge(good, cur, {"roi": -0.2}, {"roi": -0.1})[3] not in ("better", "strong")   # fails the stress test
    risky = dict(good, max_drawdown_4=60)
    assert _judge(risky, cur, None, None)[3] not in ("better", "strong")                     # much bigger losing runs
    few = dict(good, n=30)
    assert _judge(few, cur, None, None)[3] not in ("better", "strong")                       # too little fresh data
