import yaml

from favbot.configedit import set_block, update_config

TEXT = """# my notes
mode: live
series:                   # keep this comment? (block is replaced)
  - KXETH15M
  - KXSOL15M

strategy:                 # tuned
  window_start_s: 300
  ask_min: "0.88"

# live limits below
live_limits:
  capital_cap_usd: "22"
log_level: INFO
"""


def test_replace_block_keeps_the_rest():
    out = set_block(TEXT, "strategy", {"entry": "ask", "ask_min": "0.88"})
    d = yaml.safe_load(out)
    assert d["strategy"] == {"entry": "ask", "ask_min": "0.88"}
    assert d["live_limits"] == {"capital_cap_usd": "22"} and d["mode"] == "live" and d["log_level"] == "INFO"
    assert "# my notes" in out and "# live limits below" in out


def test_append_and_remove_block():
    out = set_block(TEXT, "live_limits_pending", {"capital_cap_usd": "22", "max_open_positions": 3})
    assert yaml.safe_load(out)["live_limits_pending"]["max_open_positions"] == 3
    back = set_block(out, "live_limits_pending", None)
    assert "live_limits_pending" not in yaml.safe_load(back)


def test_update_config_makes_backup(tmp_path):
    p = tmp_path / "config.yaml"
    p.write_text(TEXT, encoding="utf-8")
    b = update_config(p, {"series": ["KXETH15M"]})
    assert b.exists() and yaml.safe_load(p.read_text())["series"] == ["KXETH15M"]
