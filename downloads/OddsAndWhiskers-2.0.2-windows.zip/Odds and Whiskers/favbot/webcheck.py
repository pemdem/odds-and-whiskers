"""Catch a broken page script before it ships.

One stray quote or backtick in a page script stops that whole file from loading, and the app window
can then show nothing at all. There's no Node on the release PC, so this is a small checker of its own:
it walks each script and makes sure every bracket, quote, template string and regex is closed and
matched. It isn't a full JavaScript parser, but it catches the mistakes a hand edit makes.
"""
from __future__ import annotations

from pathlib import Path

PAIRS = {")": "(", "]": "[", "}": "{"}
# after these a "/" starts a regex rather than dividing
REGEX_AFTER = set("(,=:[!&|?{};+-*%<>~^")
REGEX_WORDS = {"return", "typeof", "case", "do", "else", "in", "of", "new", "delete", "void", "throw",
               "instanceof", "yield", "await"}


def check_js(src: str) -> list[str]:
    """Problems found in one script, as 'line N: ...' strings (empty when it looks well formed)."""
    errors: list[str] = []
    stack: list[tuple[str, int]] = []          # "(", "[", "{", "`" (template text) or "${" (code inside one)
    i, n, line, last = 0, len(src), 1, ""

    while i < n:
        c = src[i]
        if stack and stack[-1][0] == "`":      # inside a template string's text
            if c == "\\":
                line += src[i + 1:i + 2] == "\n"
                i += 2
            elif c == "`":
                stack.pop(); last = "x"; i += 1
            elif src.startswith("${", i):
                stack.append(("${", line)); last = "{"; i += 2
            else:
                line += c == "\n"
                i += 1
            continue
        if c == "\n":
            line += 1; i += 1
        elif c in " \t\r﻿":
            i += 1
        elif src.startswith("//", i):
            j = src.find("\n", i)
            i = n if j < 0 else j
        elif src.startswith("/*", i):
            j = src.find("*/", i + 2)
            if j < 0:
                errors.append(f"line {line}: a /* comment is never closed"); return errors
            line += src.count("\n", i, j); i = j + 2
        elif c in "'\"":
            j = i + 1
            while j < n and src[j] != c and src[j] != "\n":
                j += 2 if src[j] == "\\" else 1
            if j >= n or src[j] != c:
                errors.append(f"line {line}: a {c}string{c} is never closed"); return errors
            last = "x"; i = j + 1
        elif c == "`":
            stack.append(("`", line)); i += 1
        elif c == "/" and (last == "" or last in REGEX_AFTER or last in REGEX_WORDS):
            j, in_class = i + 1, False
            while j < n and src[j] != "\n" and (src[j] != "/" or in_class):
                if src[j] == "\\":
                    j += 1
                elif src[j] == "[":
                    in_class = True
                elif src[j] == "]":
                    in_class = False
                j += 1
            if j >= n or src[j] != "/":
                errors.append(f"line {line}: a /regex/ is never closed"); return errors
            j += 1
            while j < n and src[j].isalpha():
                j += 1
            last = "x"; i = j
        elif c in "([{":
            stack.append((c, line)); last = c; i += 1
        elif c in ")]}":
            top = stack[-1][0] if stack else None
            if c == "}" and top == "${":
                stack.pop(); i += 1                # back into the template's text
                continue
            if top != PAIRS[c]:
                where = f" (the {top!r} from line {stack[-1][1]} is still open)" if stack else ""
                errors.append(f"line {line}: unexpected {c!r}{where}"); return errors
            stack.pop(); last = c; i += 1
        elif c.isalnum() or c in "$_":
            j = i
            while j < n and (src[j].isalnum() or src[j] in "$_"):
                j += 1
            word = src[i:j]
            last = word if word in REGEX_WORDS else "x"; i = j
        else:
            last = c; i += 1
    for ch, ln in stack:
        errors.append(f"line {ln}: {'a template string' if ch == '`' else repr(ch)} opened here is never closed")
    return errors


def check_web(web_dir: Path) -> dict[str, list[str]]:
    """{file name: problems} for every page script that looks broken."""
    if not web_dir.is_dir():
        return {}
    out = {}
    for f in sorted(web_dir.glob("*.js")):
        problems = check_js(f.read_text(encoding="utf-8"))
        if problems:
            out[f.name] = problems
    return out
