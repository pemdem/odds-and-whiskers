@echo off
cd /d "%~dp0"
.venv\Scripts\python.exe -m favbot report --mode paper
pause
