"""3.0 Bigger and Fatter: the Polymarket US practice workspace next to Kalshi.
Read-only market data, Kalshi-shaped markets that pass the same checks, separate data, a guarded workspace API."""
import json
import re
import sqlite3
from decimal import Decimal as D
from pathlib import Path
from types import SimpleNamespace

import pytest
from aiohttp import web

from favbot import dashboard, exchanges
from favbot import release as R
from favbot.config import Config, Limits
from favbot.litterbox import MODELS, for_exchange
from favbot.models import coin_of
from favbot.money import maker_fee, taker_fee
from favbot.providers import polymarket_us as pm
from favbot.providers.base import NotFound, ReadOnlyViolation
from favbot.providers.kalshi import verify_market

ROOT = Path(__file__).resolve().parents[1]
DESC = ("This market will settle to Up if the Ethereum price at 1:45AM ET on Oct 17, 2026 is greater than or equal to the "
        "price at 1:30AM ET on Oct 17, 2026. Otherwise, this market will settle to Down. Outcome sourced from CF Benchmarks' "
        "Ether-Dollar Real-Time Index (ETHUSD_RTI). The price at the beginning and at the end of the time range is determined "
        "the same way: in the last minute before each of those two times, 60 ETHUSD_RTI prices are collected. The official "
        "value for that time is the simple average of these prices, rounded to the nearest 2 decimal places.")


def market(status="MARKET_STATUS_OPEN", start="2026-10-17T05:30:00Z", end="2026-10-17T05:45:00Z", beat="2422.36", desc=DESC):
    return {"slug": "cpceth-eth-updown-15m-2026-10-17-0530z", "question": "ETH Up or Down 15m", "description": desc,
            "status": status, "orderPriceMinTickSize": 0.01,
            "marketSides": [{"description": "Yes", "long": True}, {"description": "No", "long": False}],
            "assetPriceTerms": {"marketType": "ASSET_PRICE_MARKET_TYPE_UP_DOWN", "indexSymbol": "ETHUSD_RTI", "horizon": "15m",
                                "windowStart": start, "windowEnd": end, "priceToBeat": {"value": beat} if beat else None}}


# ---- the market data: Polymarket US markets pass the same checks as Kalshi's ------------------------------------
def test_an_open_market_passes_the_engines_checks():
    rec = pm.market_record("PMETH15M", market())
    c, why = verify_market(rec, "PMETH15M", 0)
    assert why == "ok" and c.coin == "ETH" and c.yes_is_up and c.floor_strike == D("2422.36")
    assert c.close_ts - c.open_ts == 900 and c.grid.is_valid(D("0.93")) and not c.grid.is_valid(D("0.935"))   # whole cents


def test_markets_that_must_not_be_traded_are_refused():
    future = pm.market_record("PMETH15M", market(status="MARKET_STATUS_CLOSED"), now=0)
    assert verify_market(future, "PMETH15M", 0)[1] == "status initialized"                      # not open yet
    other_rule = pm.market_record("PMETH15M", market(desc="Settles on Coinbase's last trade."))
    assert "CF Benchmarks" in verify_market(other_rule, "PMETH15M", 0)[1]                         # rule text changed
    hourly = pm.market_record("PMETH15M", market(end="2026-10-17T06:30:00Z"))
    assert verify_market(hourly, "PMETH15M", 0)[1] == "not a 900 s contract"


def test_the_down_side_mirrors_the_up_book():
    raw = {"marketData": {"bids": [{"px": {"value": "0.9300"}, "qty": "50"}, {"px": {"value": "0.9200"}, "qty": "10"}],
                          "offers": [{"px": {"value": "0.9500"}, "qty": "40"}, {"px": {"value": "0.9700"}, "qty": "5"}]}}
    b = pm.book_from("PMETH15M-x", raw, 1.0)
    assert b.best_bid("yes") == D("0.9300") and b.best_ask("yes") == D("0.9500")
    assert b.best_bid("no") == D("0.0500") and b.best_ask("no") == D("0.0700")          # Down = 1 − Up
    assert b.ask_levels("yes") == [(D("0.9500"), D("40")), (D("0.9700"), D("5"))]


async def test_settlement_one_is_up_zero_is_down_and_waits_until_settled():
    api = pm.PolymarketUSAPI()
    answers = {}

    async def fake(method, path, **kw):
        a = answers[path]
        if isinstance(a, Exception):
            raise a
        return a
    api.request = fake
    t = "PMETH15M-cpceth-eth-updown-15m-2026-10-17-0530z"
    path = "/markets/cpceth-eth-updown-15m-2026-10-17-0530z/settlement"
    answers[path] = NotFound(404, "not settled")
    m = await api.get_market(t)
    assert m["status"] == "closed" and m["result"] == ""                                 # no result until it's official
    answers[path] = {"settlement": 1}
    assert (await api.get_market(t))["result"] == ""                                     # asked again only after 30 s
    api._settled[t] = (0, api._settled[t][1])
    assert await api.get_market(t) == {"ticker": t, "status": "finalized", "result": "yes"}
    answers[path] = {"settlement": 0}
    assert (await api.get_market(t))["result"] == "yes"                                  # a known result is kept
    t2 = "PMETH15M-cpceth-eth-updown-15m-2026-10-17-0545z"
    answers["/markets/cpceth-eth-updown-15m-2026-10-17-0545z/settlement"] = {"settlement": 0}
    assert (await api.get_market(t2))["result"] == "no"                                  # 0 = Down won
    await api.close()


async def test_the_client_can_never_send_an_order():
    api = pm.PolymarketUSAPI()
    for method in ("POST", "PUT", "DELETE"):
        with pytest.raises(ReadOnlyViolation):
            await api.request(method, "/orders", body={})
    with pytest.raises(NotFound):
        await api.get_series("PMDOGE15M")                                                  # not listed there
    await api.close()


async def test_pacing_slows_down_on_too_many_requests_and_recovers():
    lim = pm.AdaptiveLimiter(1.5)
    lim.back_off(0.01)
    lim.back_off(0.01)
    assert lim.rate == 0.375
    for _ in range(4):
        lim.back_off(0.01)
    assert lim.rate == 0.25                                                                 # never below one every 4 s
    lim.updated -= 100
    await lim.acquire()
    assert lim.rate == 1.5                                                                 # back to the ceiling


def test_fees_and_coins():
    assert taker_fee("polymarket_us", 1, 1000, "0.50") == D("17.38")                       # the documented example
    assert taker_fee("polymarket_us", 1, 4, "0.95") == D("0.01")
    assert maker_fee("polymarket_us", 1, 10, "0.93") == D("0")                             # rebates not counted
    assert coin_of("PMETH15M") == "ETH" and coin_of("KXETH15M") == "ETH"
    assert pm.event_slug("SOL", 1792215000) == "sol-updown-15m-2026-10-17-0530z"


# ---- which strategies work there ---------------------------------------------------------------------------
def _cfg(tmp_path, series=("KXETH15M", "KXSOL15M", "KXDOGE15M")):
    lim = Limits(capital_cap_usd="22", max_loss_per_position_usd="4", max_loss_per_position_pct="0.2",
                 max_total_exposure_pct="0.4", daily_loss_pct="0.2", max_open_positions=2)
    return Config(mode="live", live_limits=lim, series=list(series), data_dir=str(tmp_path / "data"), base_dir=str(tmp_path),
                  config_path=str(tmp_path / "config.yaml"))


def test_equivalence_marks_each_strategy_with_a_reason(tmp_path):
    e = exchanges.equivalence(_cfg(tmp_path))
    coins = {c["coin"]: c for c in e["coins"]}
    assert coins["ETH"]["testable"] and coins["XRP"]["testable"]
    assert not coins["DOGE"]["testable"] and "no 15-minute DOGE market" in coins["DOGE"]["why"]
    assert not coins["BTC"]["testable"] and "leaves Bitcoin out" in coins["BTC"]["why"]
    s = {x["name"]: x for x in e["strategies"]}
    assert s["Your strategy"]["status"] == "partial" and s["Your strategy"]["coins"] == ["ETH", "SOL"]
    assert s["Original"]["status"] == "partial" and "DOGE" in s["Original"]["why"]
    assert s["Big Three"]["status"] == "available"
    assert s["Small Fry"]["status"] == "unavailable" and s["DOGE Solo"]["status"] == "unavailable"
    tools = {t["name"]: t for t in e["tools"]}
    assert tools["Real-money trading"]["status"] == "unavailable" and tools["Backtrack"]["status"] == "unavailable"
    same = {r["topic"] for r in e["rules"] if r["same"]}
    assert same == {"Time window", "Price source", "Settlement"}


def test_litter_box_runs_what_it_can_and_explains_the_rest():
    ok, skipped = for_exchange(MODELS, "polymarket_us")
    runs = {m.id: series for m, series in ok}
    assert runs["original"] == ["PMETH15M", "PMSOL15M", "PMXRP15M"] and runs["solo-eth"] == ["PMETH15M"]
    assert {x["id"] for x in skipped} == {"smalls", "solo-doge", "solo-bnb", "solo-zec", "solo-hype", "solo-near"}
    assert all(x["why"] for x in skipped)
    assert all(s.startswith("KX") for _, series in for_exchange(MODELS, "kalshi")[0] for s in series)   # Kalshi unchanged


def test_the_workspace_has_its_own_data_port_and_practice_mode(tmp_path):
    cfg = _cfg(tmp_path, ("KXETH15M", "KXSOL15M", "KXDOGE15M"))
    w = exchanges.workspace_config(cfg)
    assert w.mode == "paper" and w.series == ["PMETH15M", "PMSOL15M"]                      # its coins, never BTC
    assert w.data_path("paper") == tmp_path / "data" / "polymarket_us" / "paper"
    assert w.dashboard.port == cfg.dashboard.port + 100 and w.paper_limits == cfg.live_limits
    assert w.paper.starting_cash_usd == D("22")
    assert cfg.series == ["KXETH15M", "KXSOL15M", "KXDOGE15M"] and cfg.mode == "live"      # your settings untouched


# ---- the workspace's app only answers what it should ---------------------------------------------------------
def _dash(tmp_path, exchange="polymarket_us"):
    store = SimpleNamespace(log_event=lambda *a: None, clear_kill=lambda: None)
    bot = SimpleNamespace(exchange=exchange, cfg=_cfg(tmp_path), store=store, data_dir=tmp_path / "data" / "live",
                          kill_file=lambda: None)
    d = dashboard.Dashboard(bot, 0)
    d.token = "t"
    return d, bot


class _Req:
    def __init__(self, path="/api/state", method="GET", match=None, body=b""):
        self.path, self.method, self.match_info, self._body = path, method, match or {}, body
        self.headers = {"X-Token": "t"}

    async def read(self):
        return self._body

    async def json(self):
        return json.loads(self._body or b"{}")


@pytest.mark.parametrize("path", ["/api/golive", "/api/kalshi/connect", "/api/kalshi/move", "/api/apply", "/api/install_update",
                                  "/api/restart", "/api/shutdown", "/api/prefs", "/api/council_ai", "/api/backtrack",
                                  "/api/alert_prefs", "/api/workspace"])
async def test_the_practice_workspace_refuses_everything_else(tmp_path, path):
    d, _ = _dash(tmp_path)

    async def handler(r):
        return web.Response(text="ran")
    with pytest.raises(web.HTTPConflict):
        await d._guard(_Req(path), handler)


async def test_the_practice_workspace_answers_its_own_api_and_kalshi_answers_everything(tmp_path):
    d, _ = _dash(tmp_path)

    async def handler(r):
        return web.Response(text="ran")
    for name in dashboard.WORKSPACE_API:
        assert (await d._guard(_Req("/api/" + name), handler)).text == "ran"
    k, _ = _dash(tmp_path, "kalshi")
    assert (await k._guard(_Req("/api/golive"), handler)).text == "ran"                   # the Kalshi app is unchanged


async def test_the_proxy_only_forwards_the_workspace_api(tmp_path):
    d, bot = _dash(tmp_path, "kalshi")
    with pytest.raises(web.HTTPNotFound):
        await d.ws_proxy(_Req(match={"ex": "polymarket_us", "name": "golive"}))
    with pytest.raises(web.HTTPNotFound):
        await d.ws_proxy(_Req(match={"ex": "somewhere", "name": "state"}))
    r = await d.ws_proxy(_Req(match={"ex": "polymarket_us", "name": "state"}))
    assert r.status == 503 and json.loads(r.body)["workspace_off"]                            # switched off: nothing to ask
    sent = []

    async def fake_call(method, name, body=None, timeout=15):
        sent.append((method, name, body))
        return 200, '{"exchange": "polymarket_us"}'
    d._ws_call = fake_call
    (exchanges.workspace_root(bot.cfg)).mkdir(parents=True)
    (exchanges.workspace_root(bot.cfg) / "ENABLED").write_text("on")
    r = await d.ws_proxy(_Req(method="POST", match={"ex": "polymarket_us", "name": "pause"}, body=b"{}"))
    assert r.status == 200 and sent == [("POST", "pause", b"{}")]


async def test_kalshi_kill_switch_still_needs_the_unkill_command(tmp_path):
    d, _ = _dash(tmp_path, "kalshi")
    with pytest.raises(web.HTTPConflict):
        await d.unkill(_Req(method="POST"))
    p, _ = _dash(tmp_path)
    assert json.loads((await p.unkill(_Req(method="POST"))).body)["ok"]                    # fake money: the app can undo it


def test_page_and_server_agree_on_the_workspace_api():
    js = (ROOT / "favbot" / "web" / "core.js").read_text(encoding="utf-8")
    names = set(re.findall(r"'([a-z_]+)'", re.search(r"const WS_API = new Set\(\[(.*?)\]\)", js, re.S).group(1)))
    assert names == set(dashboard.WORKSPACE_API)


def test_backups_keep_the_workspace_too(tmp_path):
    data = tmp_path / "data"
    (data / "live").mkdir(parents=True)
    ws = data / "polymarket_us" / "paper"
    ws.mkdir(parents=True)
    con = sqlite3.connect(ws / "favbot.sqlite3")
    con.execute("CREATE TABLE t(x)")
    con.execute("INSERT INTO t VALUES ('practice bets')")
    con.commit()
    con.close()
    (data / "polymarket_us" / "ENABLED").write_text("on")
    dest = R.backup_data(data / "live", None, "before-3.0")
    assert sqlite3.connect(dest / "polymarket_us" / "paper" / "favbot.sqlite3").execute("SELECT x FROM t").fetchone() == ("practice bets",)
    assert (dest / "polymarket_us" / "ENABLED").exists()


async def test_practice_workspace_stops_promptly_but_kalshi_finishes_its_work(tmp_path, clock, monkeypatch):
    import asyncio
    from favbot import engine
    from tests.test_execution_engine import make_bot
    monkeypatch.setattr(engine, "PRACTICE_STOP_GRACE_S", 0.2)

    async def stuck(self):                       # an engine stuck behind a rate-limited request
        await asyncio.sleep(3600)

    async def quick():
        return None
    for exchange, should_stop in (("polymarket_us", True), ("kalshi", False)):
        bot, md, store, sim = make_bot(tmp_path / exchange, clock)
        bot.exchange = exchange
        bot.startup = quick
        monkeypatch.setattr(engine.Engine, "run", stuck)
        for name in ("status_loop", "guard_loop", "watch_loop"):
            monkeypatch.setattr(bot, name, quick)
        task = asyncio.create_task(bot.run())
        await asyncio.sleep(0.05)
        bot.stop.set()
        done, _ = await asyncio.wait({task}, timeout=1.0)
        assert bool(done) == should_stop, exchange
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)


async def test_many_bots_asking_at_once_send_one_request():
    import asyncio
    api = pm.PolymarketUSAPI()
    sent = []

    async def fake(method, path, **kw):
        sent.append(path)
        await asyncio.sleep(0.05)
        return {"event": {"slug": "eth-updown-15m-2026-10-17-0530z", "markets": []}}
    api.request = fake
    got = await asyncio.gather(*(api._event("ETH", 1792215000) for _ in range(13)))
    assert len(sent) == 1 and all(g == got[0] for g in got)                               # 13 bots, 1 request
    st = await asyncio.gather(*(api.get_exchange_status() for _ in range(13)))
    assert sent.count("/markets") == 1 and all(x.trading_active for x in st)

    async def boom(method, path, **kw):
        sent.append(path)
        await asyncio.sleep(0.01)
        raise pm.ApiError(500, "down")
    api.request = boom
    res = await asyncio.gather(*(api._event("SOL", 1792215000) for _ in range(5)), return_exceptions=True)
    assert all(isinstance(r, pm.ApiError) for r in res) and sent.count("/events/slug/sol-updown-15m-2026-10-17-0530z") == 1
    await api.close()
