// ---- Real vs Simulated (Cat Corner): your real bot next to "Simulated you", its fake-money twin -----------
// The twin runs in the Litter Box with your real bot's exact strategy, coins and limits, on the same live prices,
// with fake money that starts at your capital cap. It starts fresh whenever your real settings change.
let lastSim = '';
function simSpark(curve, start, w = 260, h = 56) {
  if (!curve || curve.length < 2) return `<svg viewBox="0 0 ${w} ${h}" aria-hidden="true"><line x1="0" x2="${w}" y1="${h / 2}" y2="${h / 2}" stroke="var(--line)" stroke-dasharray="4 4"/></svg>`;
  const ys = curve.map(p => p[1]).concat([start]), lo = Math.min(...ys), hi = Math.max(...ys), span = hi - lo || 1;
  const pts = [[0, start], ...curve.map((p, i) => [i + 1, p[1]])];
  const X = i => i / (pts.length - 1) * (w - 6) + 3, Y = v => h - 4 - (v - lo) / span * (h - 8);
  const up = curve[curve.length - 1][1] >= start, col = up ? 'var(--pos)' : 'var(--neg)';
  const line = pts.map(([i, v]) => `${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join(' ');
  return `<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true"><line x1="0" x2="${w}" y1="${Y(start)}" y2="${Y(start)}" stroke="var(--line)" stroke-dasharray="4 4" vector-effect="non-scaling-stroke"/>` +
    `<polygon points="${X(0)},${h} ${line} ${X(pts.length - 1)},${h}" fill="${col}" opacity=".12"/>` +
    `<polyline points="${line}" fill="none" stroke="${col}" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/></svg>`;
}

function simSide(label, d) {
  const last = (d.last || []).slice(0, 5);
  return `<div class="simside">` +
    `<div class="simhead"><span class="pre-tag">${label}</span><span class="simbal">${money(d.equity)}</span></div>` +
    `<div class="simpnl ${d.pnl > 0 ? 'pos' : d.pnl < 0 ? 'neg' : 'mut'}">${money(d.pnl, true)} <span class="mut">since ${esc(d.sinceTxt)}</span></div>` +
    `<div class="simspark">${simSpark(d.curve, d.start)}</div>` +
    `<div class="facts">` + tile('Bets', d.bets) + tile('Won', d.bets ? `${d.wins}–${d.bets - d.wins}` : '–') +
      tile('Return per $', d.staked ? `${d.pnl >= 0 ? '+' : ''}${(d.pnl / d.staked * 100).toFixed(1)}%` : '–') + `</div>` +
    (last.length ? `<div class="simlast">${last.map(x => `<span class="${x.won ? 'pos' : 'neg'}" data-tip="${esc(x.coin)} ${x.outcome === 'UP' ? 'Up' : 'Down'} at ${cents(x.price)}, ${tm(x.ts)}">` +
      `${esc(x.coin)} ${money(x.pnl, true)}</span>`).join('')}</div>` : `<div class="sub" style="margin-top:8px">No settled bets in this window yet.</div>`) +
    `</div>`;
}

function renderSim(s) {
  const box = $('simbody'); if (!box) return;
  const lb = s.litterbox || {}, twin = ((lb.summary || {}).models || []).find(m => m.id === 'twin');
  const view = prefs.simView === 'sim' ? 'sim' : 'real';
  const key = JSON.stringify([view, twin && [twin.bets, twin.equity, twin.since, Math.floor((lb.summary || {}).ts / 30)],
    s.series.length, s.account && s.account.equity, lb.running, prefs.odds]);
  document.querySelectorAll('#simswitch').forEach(sw => { sw.setAttribute('aria-checked', String(view === 'sim')); sw.dataset.view = view; });
  if (key === lastSim) return; lastSim = key;
  if (!twin) {
    box.innerHTML = `<div class="simempty"><div><b>Simulated you isn’t running yet.</b><div class="sub">It lives in the Litter Box: your real bot’s exact settings, ` +
      `coins and limits, trading the same live prices with fake money. ${lb.enabled ? 'It starts within a minute or two.' : 'Turn the Litter Box on to start it.'}</div></div>` +
      (lb.enabled ? '' : `<button class="primary" id="simstart">Turn on the Litter Box</button>`) + `</div>`;
    return;
  }
  const since = twin.since || (lb.summary || {}).started_at || s.now;
  const sinceTxt = dt(since);
  // real results over the same window, so the two are comparable
  const realSet = s.series.filter(p => (p.ts || 0) >= since);
  const eq = +((s.account || {}).equity || 0), realPnl = realSet.reduce((t, p) => t + p.pnl, 0);
  let run = eq - realPnl;
  const realCurve = realSet.map(p => [p.ts, +(run += p.pnl).toFixed(2)]);
  const realLast = realSet.slice(-5).reverse()
    .map(p => ({coin: p.coin, outcome: p.outcome, pnl: p.pnl, won: p.pnl > 0, ts: p.ts, price: p.price}));
  const realStaked = realSet.reduce((t, p) => t + (p.cost || 0), 0);
  const real = {equity: eq, pnl: realPnl, start: eq - realPnl, curve: realCurve, bets: realSet.length,
    wins: realSet.filter(p => p.pnl > 0).length, staked: realStaked, last: realLast, sinceTxt};
  const sim = {equity: twin.equity, pnl: twin.pnl, start: +twin.cash_start, curve: twin.curve, bets: twin.bets, wins: twin.wins,
    staked: twin.staked, last: twin.last, sinceTxt};
  const diff = sim.pnl - real.pnl;
  box.innerHTML =
    `<div class="simstage" data-view="${view}">` +
      `<div class="simpane real">${simSide('Real money', real)}</div>` +
      `<div class="simpane sim">${simSide('Simulated (fake money)', sim)}</div>` +
    `</div>` +
    `<div class="simcmp"><span data-tip="Same window, same settings. Differences come from fills: the simulation guesses whether a waiting bid would have been hit.">` +
      `Since ${esc(sinceTxt)}: real <b class="${real.pnl >= 0 ? 'pos' : 'neg'}">${money(real.pnl, true)}</b> over ${real.bets} bet${real.bets === 1 ? '' : 's'} · ` +
      `simulated <b class="${sim.pnl >= 0 ? 'pos' : 'neg'}">${money(sim.pnl, true)}</b> over ${sim.bets}` +
      `${real.bets + sim.bets ? ` · gap ${money(diff, true)}` : ''}</span></div>` +
    `<div class="sub" style="margin-top:6px">Simulated you uses your real bot’s exact strategy, coins and limits, on the same live prices, with fake money ` +
      `starting at ${money(sim.start)}. It starts fresh when you change your settings. Real fills can differ from simulated ones.</div>`;
}

$('simswitch').addEventListener('click', () => { prefs.simView = prefs.simView === 'sim' ? 'real' : 'sim'; savePrefs(); renderSimSwitch(); });
$('simswitch').addEventListener('keydown', e => { if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') { e.preventDefault();
  prefs.simView = e.key === 'ArrowRight' ? 'sim' : 'real'; savePrefs(); renderSimSwitch(); } });
$('simlabels').addEventListener('click', e => { const b = e.target.closest('[data-v]'); if (!b) return; prefs.simView = b.dataset.v; savePrefs(); renderSimSwitch(); });
function renderSimSwitch() {
  const view = prefs.simView === 'sim' ? 'sim' : 'real';
  $('simswitch').setAttribute('aria-checked', String(view === 'sim')); $('simswitch').dataset.view = view;
  document.querySelectorAll('#simlabels [data-v]').forEach(b => b.classList.toggle('on', b.dataset.v === view));
  const st = document.querySelector('#simbody .simstage'); if (st) st.dataset.view = view;      // slides, no rebuild
}
$('simbody').addEventListener('click', async e => { if (e.target.id !== 'simstart') return;
  e.target.disabled = true; try { await postJSON('/api/litterbox', {action: 'start'}); } catch (err) { alert(err.message); }
  lastSim = ''; setTimeout(load, 1500); });
renderSimSwitch();
