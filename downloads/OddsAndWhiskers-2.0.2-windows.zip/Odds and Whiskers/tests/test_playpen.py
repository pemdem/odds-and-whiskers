﻿"""The Play Pen update: fresh downloads per platform, safe updates while trading, what's new, update history."""
import asyncio
import json
import shutil
import sqlite3
import zipfile
from pathlib import Path
from types import SimpleNamespace

import pytest

from favbot import dashboard
from favbot import release as R
from tests.test_release import make_copy


@pytest.fixture()
def pub(tmp_path):
    root = make_copy(tmp_path / "me")
    for name in ("Install Odds and Whiskers.bat", "Go live.bat", "Install Odds and Whiskers.command", "Go live.command"):
        (root / name).write_text("helper\n")
    (root / "app" / "install.ps1").write_text("# win\n")
    (root / "app" / "install_mac.sh").write_text("#!/bin/bash\n")
    (root / "app" / "setup_mac.sh").write_text("#!/bin/bash\n# setup\n")
    (root / "app" / "python_windows.txt").write_text("x86_64 url sha\n")
    shutil.copy(R.ROOT / "app" / "BetterBot.ico", root / "app" / "BetterBot.ico")
    (root / "favbot" / "CHANGELOG.json").write_text(json.dumps([{"version": "1.1.0", "date": "2026-10-14", "title": "T",
                                                                "added": ["New thing"], "fixed": []}]))
    key = tmp_path / "key.pem"
    R.init_signing(key, root / "favbot" / "release_pubkey.txt")
    return root, key, tmp_path / "share"


def test_fresh_downloads_one_per_platform_with_only_that_platforms_helpers(pub):
    root, key, share = pub
    r = R.publish(share, "", "1.1.0", root=root, key_path=key)
    assert set(r["packages"]) == {"windows", "macos"}
    win = zipfile.ZipFile(r["packages"]["windows"])
    mac = zipfile.ZipFile(r["packages"]["macos"])
    wn, mn = win.namelist(), mac.namelist()
    assert all(n.startswith("Odds and Whiskers/") for n in wn + mn)            # no "&" in folder names
    assert "Odds and Whiskers/Install Odds and Whiskers.bat" in wn and "Odds and Whiskers/app/install.ps1" in wn
    assert not any(n.endswith((".command", ".sh")) for n in wn)
    # macOS: one double-clickable Setup app that carries the whole app inside it
    app = "Odds and Whiskers/Odds & Whiskers Setup.app/Contents/"
    assert app + "Info.plist" in mn and app + "MacOS/setup" in mn and app + "Resources/AppIcon.icns" in mn
    assert app + "Resources/app/favbot/core.py" in mn and app + "Resources/app/app/install_mac.sh" in mn
    assert set(mn) - {n for n in mn if n.startswith(app)} == {"Odds and Whiskers/START HERE.txt"}
    assert not any(n.endswith((".bat", ".ps1")) for n in mn)
    assert b"<string>setup</string>" in mac.read(app + "Info.plist") and mac.read(app + "Resources/AppIcon.icns")[:4] == b"icns"
    assert "no Python download" in win.read("Odds and Whiskers/START HERE.txt").decode()  # brings its own Python
    assert "Odds and Whiskers/app/python_windows.txt" in wn and not any(n.endswith("python_windows.txt") for n in mn)
    assert "Odds & Whiskers Setup" in mac.read("Odds and Whiskers/START HERE.txt").decode()
    for n in wn + mn:                                                          # nothing personal
        assert not n.endswith(("config.yaml", ".env", "k.pem", "Move sports money to crypto.bat")), n
    for n in (app + "MacOS/setup", app + "Resources/app/Install Odds and Whiskers.command"):
        assert (mac.getinfo(n).external_attr >> 16) & 0o111, n                 # stays runnable on a Mac
    assert not (mac.getinfo(app + "Info.plist").external_attr >> 16) & 0o111
    readme = (share / "READ ME FIRST.txt").read_text(encoding="utf-8")
    assert "-windows.zip" in readme and "-macos.zip" in readme and "bring their own Python" in readme
    assert R.notes_for("1.1.0", root).startswith("T: New thing")
    assert json.loads(zipfile.ZipFile(r["path"]).read("release.json"))["notes"].startswith("T:")   # default notes


def test_every_publish_refreshes_the_share_files(pub):
    root, key, share = pub
    (root / "BetterBot-share.zip").write_bytes(b"an old copy")
    for v in ("1.1.0", "1.1.1"):
        r = R.publish(share, "", v, root=root, key_path=key)
        for plat, name in (("windows", "BetterBot-share.zip"), ("macos", "BetterBot-share-mac.zip")):
            assert r["share"][plat] == str(root / name)
            assert (root / name).read_bytes() == Path(r["packages"][plat]).read_bytes()      # this version, exactly
    names = zipfile.ZipFile(root / "BetterBot-share.zip").namelist()
    assert "Odds and Whiskers/Install Odds and Whiskers.bat" in names
    assert not any(n.endswith(("config.yaml", ".env", "k.pem")) for n in names)              # nothing personal
    assert "BetterBot-share.zip" not in R.release_files(root)                                # never shipped itself


def test_update_zip_still_readable_by_copies_from_before_the_rename(pub):
    root, key, share = pub
    r = R.publish(share, "x", "1.1.0", root=root, key_path=key)
    z = zipfile.ZipFile(r["path"])
    assert Path(r["path"]).name == "BetterBot-1.1.0.zip"
    assert json.loads(z.read("release.json"))["app"] == "Better Bot"
    assert "Better Bot/favbot/core.py" in z.namelist()


def test_install_takes_only_this_platforms_helpers(pub, tmp_path):
    root, key, share = pub
    friend = make_copy(tmp_path / "friend")
    (friend / "favbot" / "release_pubkey.txt").write_text((root / "favbot" / "release_pubkey.txt").read_text())
    R.publish(share, "", "1.1.0", root=root, key_path=key)
    R.install(share / "BetterBot-1.1.0.zip", friend, save_point=False, run_pip=False, platform="windows")
    assert (friend / "Go live.bat").exists() and not (friend / "Go live.command").exists()
    assert (friend / "app" / "install.ps1").exists() and not (friend / "app" / "install_mac.sh").exists()


def test_backup_keeps_a_consistent_copy_of_history_and_settings(tmp_path):
    data = tmp_path / "data" / "live"
    data.mkdir(parents=True)
    con = sqlite3.connect(data / "favbot.sqlite3")
    con.execute("CREATE TABLE t(x)")
    con.execute("INSERT INTO t VALUES (42)")
    con.commit()
    (data / "live_ack.json").write_text("{}")
    cfg = tmp_path / "config.yaml"
    cfg.write_text("mode: live\n")
    for i in range(7):
        dest = R.backup_data(data, cfg, f"before-1.9.{i}")
    assert sqlite3.connect(dest / "favbot.sqlite3").execute("SELECT x FROM t").fetchone() == (42,)
    assert (dest / "config.yaml").read_text() == "mode: live\n" and (dest / "live_ack.json").exists()
    assert len(list((tmp_path / "data" / "backups").iterdir())) == 5                    # only the newest few
    con.close()


def test_changelog_is_complete_and_matches_the_installed_version():
    log = R.changelog()
    assert log[0]["version"] == R.installed_version()                                   # newest first, installed
    vs = [tuple(map(int, c["version"].split("."))) for c in log]
    assert vs == sorted(vs, reverse=True) and len(set(vs)) == len(vs)
    for c in log:
        assert c["date"] and c["title"] and isinstance(c["added"], list) and isinstance(c["fixed"], list)


class _Store:
    def __init__(self, resting):
        self.resting, self.events, self.meta = resting, [], {}

    def entries(self, mode, states=None):
        return [{"state": "resting"}] if self.resting() else []

    def log_event(self, level, kind, msg, *a):
        self.events.append(msg)

    def set_meta(self, k, v):
        self.meta[k] = v


def _bot(tmp_path, resting):
    data = tmp_path / "data" / "live"
    data.mkdir(parents=True)
    (data / "supervisor.pid").write_text("1")
    cfg = tmp_path / "config.yaml"
    cfg.write_text("mode: live\n")
    return SimpleNamespace(paused=False, mode="live", data_dir=data, store=_Store(resting),
                           cfg=SimpleNamespace(config_path=str(cfg)), stop=asyncio.Event())


class _Req:
    headers = {"X-Token": "t"}

    async def json(self):
        return {}


async def test_update_while_trading_pauses_cancels_backs_up_installs_then_restarts(tmp_path, monkeypatch):
    calls, polls = [], {"n": 0}

    def resting():                                   # the engines cancel the waiting bid after a couple of ticks
        polls["n"] += 1
        return polls["n"] < 3
    bot = _bot(tmp_path, resting)
    monkeypatch.setattr(dashboard, "_release_state",
                        lambda force=False: {"available": {"version": "9.9.9", "path": str(tmp_path / "u.zip")}})
    monkeypatch.setattr(dashboard, "_version_info", lambda b: {"code_changed": True})

    def fake_install(path):
        calls.append(("install", bot.paused, polls["n"]))
        return {"version": "9.9.9", "files": 3, "removed": 0, "restore_point": 7, "pip": False}
    monkeypatch.setattr(R, "install", fake_install)
    monkeypatch.setattr(R, "migrate_shortcut", lambda root=None: False)
    d = dashboard.Dashboard(bot, 0)
    d.token = "t"
    resp = await d.install_update(_Req())
    out = json.loads(resp.body)
    assert calls == [("install", True, 3)]                     # paused, and only after the waiting bid was gone
    assert out["restarting"] and (bot.data_dir / "RESTART").exists()
    assert list((tmp_path / "data" / "backups").iterdir())    # data backed up first
    assert any("pausing new bets" in e for e in bot.store.events)
    await asyncio.sleep(1.2)
    assert bot.stop.is_set()                                   # restarts; startup reconciles before betting again


async def test_failed_update_resumes_trading_as_before(tmp_path, monkeypatch):
    bot = _bot(tmp_path, lambda: False)
    monkeypatch.setattr(dashboard, "_release_state",
                        lambda force=False: {"available": {"version": "9.9.9", "path": str(tmp_path / "u.zip")}})

    def bad(path):
        raise R.ReleaseError("signature doesn't match")
    monkeypatch.setattr(R, "install", bad)
    d = dashboard.Dashboard(bot, 0)
    d.token = "t"
    from aiohttp import web
    with pytest.raises(web.HTTPBadRequest):
        await d.install_update(_Req())
    assert bot.paused is False and not (bot.data_dir / "RESTART").exists()


async def test_whats_new_is_remembered_per_person(tmp_path):
    bot = _bot(tmp_path, lambda: False)
    d = dashboard.Dashboard(bot, 0)
    d.token = "t"

    class Req(_Req):
        async def json(self):
            return {"version": "1.9.0"}
    await d.whats_new_seen(Req())
    assert bot.store.meta["whats_new_seen"] == "1.9.0"
