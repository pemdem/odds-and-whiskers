// ---- Cat Nap: one clear status, Why no bet?, daily recap, Help menu, diagnostics, leaving options -----------
const ST_ICON = {running: '●', watching: '●', paused: '❚❚', offline: '○', attention: '!'};
function renderStatus(s) {
  const S = s.status, c = $('conn');
  if (!S) return;
  c.h = `<span class="stdot ${S.level}" aria-hidden="true"></span>${esc(S.title)}`;
  c.className = 'chip status ' + S.level;
  c.dataset.tip = `${S.headline}. ${S.detail}${S.next_step ? ' ' + S.next_step : ''} (Click for details.)`;
  c.setAttribute('role', 'button'); c.tabIndex = 0;
  if ($('napbody') && $('napscrim').classList.contains('open')) fillCatNap(s);
}
function statusOffline() {
  const c = $('conn');
  c.h = '<span class="stdot offline" aria-hidden="true"></span>Offline';
  c.className = 'chip status offline';
  c.dataset.tip = 'This window can’t reach the bot. If you turned it off, open it with the icon; otherwise it restarts by itself.';
}

function sheet(id, inner, cls = '') {
  let n = $(id);
  if (!n) {
    n = document.createElement('div'); n.id = id; n.className = 'scrim wn';
    n.innerHTML = `<div class="sheet wnsheet ${cls}" role="dialog" aria-modal="true"></div>`;
    document.body.appendChild(n);
    n.addEventListener('click', e => { if (e.target === n || e.target.closest('[data-close]')) closeSheet(id); });
  }
  n.querySelector('.sheet').innerHTML = inner;
  requestAnimationFrame(() => n.classList.add('open'));
  return n;
}
function closeSheet(id) { const n = $(id); if (n) n.classList.remove('open'); }
addEventListener('keydown', e => { if (e.key === 'Escape') document.querySelectorAll('.scrim.wn.open').forEach(n => { if (n.id !== 'obscrim') n.classList.remove('open'); }); });

// ---- the status panel with "Why no bet?" -----------------------------------------------------------------
function openCatNap() {
  sheet('napscrim', `<div class="pre-tag">Cat Nap</div><div id="napbody"></div>
    <div class="pre-act" style="justify-content:flex-end"><button data-close>Close</button>
      <button id="napask">Ask Le Chonk</button><button class="primary" id="naprecap">Daily recap</button></div>`);
  $('napask').onclick = () => { closeSheet('napscrim'); openCouncil('chonk', (window._state.status || {}).level === 'watching' ? 'Why no bet?' : 'Why did trading stop?'); };
  $('naprecap').onclick = () => { closeSheet('napscrim'); openRecap('today'); };
  fillCatNap(window._state || {});
}
const KIND_TIP = {timing: 'Timing: bets only open near the end of each contract', strategy: 'The strategy’s own rule said no',
  risk: 'A safety check said no', betting: 'In play', off: 'Turned off by you', attention: 'Needs a look', other: ''};
function fillCatNap(s) {
  const S = s.status, w = s.why || [];
  if (!S || !$('napbody')) return;
  const head = S.headline && S.headline !== S.title ? ` <span class="mut">· ${esc(S.headline)}</span>` : '';
  const step = S.next_step && !(S.action && S.action.type === 'whynobet') ? `<p class="sub"><b>Next step:</b> ${esc(S.next_step)}</p>` : '';
  $('napbody').h = `<h2 class="napt"><span class="stdot big ${S.level}"></span>${esc(S.title)}${head}</h2>
    <p>${esc(S.detail)}</p>${step}
    ${S.action && S.action.type === 'resume' ? '<div class="pre-act"><button class="primary" id="napresume">Resume betting</button></div>' : ''}
    <h3 class="naph" data-tip="Each coin’s reason right now, straight from the strategy and the risk checks">Why no bet?</h3>
    <div class="napcoins">${w.map(c => `<div class="napcoin ${c.kind}" data-tip="${esc(KIND_TIP[c.kind] || '')}${c.raw ? ' · bot says: ' + esc(c.raw) : ''}">
      <b>${esc(c.coin)}</b><span>${esc(c.plain)}</span></div>`).join('') || '<div class="sub">No coins yet.</div>'}</div>
    <div class="sub" style="margin-top:8px">Updated ${tm(S.as_of)} · refreshes every few seconds.</div>`;
  const r = $('napresume'); if (r) r.onclick = async () => { await fetch('/api/resume', {method: 'POST', headers: H}); load(); };
}
document.addEventListener('click', e => { if (e.target.closest('#conn')) openCatNap(); });
document.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target.id === 'conn') { e.preventDefault(); openCatNap(); } });

// ---- daily recap --------------------------------------------------------------------------------------
async function openRecap(day = 'today') {
  sheet('recapscrim', `<div class="pre-tag">Daily recap</div><div class="seg small" id="recapday" style="margin:6px 0 10px">
      <button data-d="today" class="${day === 'today' ? 'on' : ''}">Today</button><button data-d="yesterday" class="${day === 'yesterday' ? 'on' : ''}">Yesterday</button></div>
    <div id="recapbody"><div class="sub">Gathering…</div></div>
    <div class="pre-act" style="justify-content:flex-end"><button data-close>Close</button><button id="recapask">Ask Biscuit</button></div>`);
  $('recapday').onclick = e => { const b = e.target.closest('[data-d]'); if (b) openRecap(b.dataset.d); };
  $('recapask').onclick = () => { closeSheet('recapscrim'); openCouncil('biscuit', day === 'yesterday' ? 'Recap of yesterday' : 'What happened while I was away?'); };
  try {
    const r = await postJSON('/api/recap', {day});
    const lb = r.litterbox, label = r.real_money ? 'Real money' : 'Practice money';
    $('recapbody').innerHTML = `<h2 style="margin:0 0 8px">${esc(r.day)}</h2>
      <div class="facts">${tile('Profit / loss', money(r.pnl, true), +r.pnl > 0 ? 'pos' : +r.pnl < 0 ? 'neg' : '')}${tile('Bets', `${r.bets} · ${r.wins}–${r.losses}`)}
        ${tile('Fees', money(r.fees))}</div>
      <div class="cblock ${r.real_money ? 'real' : 'practice'}"><div class="clabel"><span class="ctag ${r.real_money ? 'real' : 'practice'}">${label}</span>${asOf(r.as_of)}</div><ul>
        <li>Bids sent: ${r.bids_sent}; money staked ${money(r.staked)}</li>
        ${r.best_coin ? `<li>Best coin: ${esc(r.best_coin[0])} ${money(r.best_coin[1], true)}</li>` : ''}
        ${r.worst_coin ? `<li>Worst coin: ${esc(r.worst_coin[0])} ${money(r.worst_coin[1], true)}</li>` : ''}
        <li>${r.open_positions.length ? 'Open now: ' + r.open_positions.map(p => `${esc(p.coin)} ${p.outcome === 'UP' ? 'Up' : 'Down'} ×${esc(p.qty)}`).join(', ') : 'No open bets right now'}</li></ul></div>
      ${lb ? `<div class="cblock sim"><div class="clabel"><span class="ctag sim">Simulated (fake money)</span>${asOf(lb.as_of)}</div><ul>
        <li>Litter Box: ${lb.models} models, ${lb.fake_bets} fake bets so far</li>
        ${lb.leader ? `<li>Leader: ${esc(lb.leader.name)} ${(lb.leader.roi * 100).toFixed(1)}% per $ over ${lb.leader.bets} bets (could be luck)</li>` : ''}
        ${lb.twin ? `<li>Simulated you: ${money(lb.twin.pnl, true)} over ${lb.twin.bets} bets</li>` : ''}</ul></div>`
        : '<div class="sub">Litter Box isn’t running, so no fake-money progress today.</div>'}`;
  } catch (err) { $('recapbody').innerHTML = `<div class="neg">Couldn’t get the recap: ${esc(err.message)}</div>`; }
}

// ---- diagnostics -----------------------------------------------------------------------------------------
async function exportDiagnostics() {
  if (!confirm('Export diagnostics?\n\nIncluded: app version, system, status, non-money settings, each coin’s reason, and recent warnings and log lines with amounts, IDs and emails removed.\n\n' +
               'Never included: your Kalshi key or Key ID, API keys, tokens, emails, balances, dollar amounts, or your trade history.')) return;
  try {
    const d = await postJSON('/api/diagnostics', {});
    const blob = new Blob([JSON.stringify(d, null, 1)], {type: 'application/json'});
    const a = document.createElement('a'), stamp = new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '');
    a.href = URL.createObjectURL(blob); a.download = `odds-whiskers-diagnostics-${stamp}.json`;
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  } catch (err) { alert(err.message); }
}

// ---- leaving: close the window / pause / turn off ----------------------------------------------------------
function openLeaving() {
  const s = window._state || {};
  sheet('leavescrim', `<div class="pre-tag">Leaving?</div><h2 style="margin:4px 0 12px">Three different things</h2>
    <div class="leaveopt"><div><b>Close this window</b><span>The bot keeps running in the background and the cats keep watching.
      Open it again any time with the icon.</span></div><button id="lvclose">Close window</button></div>
    <div class="leaveopt"><div><b>Pause new bets</b><span>The bot stays on and keeps watching, but places no new bets and cancels a waiting bid.
      Bets that already filled still finish.</span></div><button id="lvpause">${s.paused ? 'Resume' : 'Pause'}</button></div>
    <div class="leaveopt danger"><div><b>Turn off completely</b><span>Stops the bot and the Litter Box until you open the icon again.
      Bets that already filled still finish on Kalshi.</span></div><button class="solid-danger" id="lvoff">Turn off</button></div>
    <div class="pre-act" style="justify-content:flex-end"><button data-close>Never mind</button></div>`);
  $('lvclose').onclick = () => { closeSheet('leavescrim'); window.close();
    setTimeout(() => alert('Your browser didn’t let the page close itself. Just close this window — the bot keeps running.'), 400); };
  $('lvpause').onclick = async () => { await fetch(s.paused ? '/api/resume' : '/api/pause', {method: 'POST', headers: H}); closeSheet('leavescrim'); load(); };
  $('lvoff').onclick = () => { closeSheet('leavescrim'); $('turnoff').click(); };
}

// ---- Help menu -----------------------------------------------------------------------------------------------
function toggleHelp(open) {
  let m = $('helpmenu');
  if (!m) {
    m = document.createElement('div'); m.id = 'helpmenu'; m.className = 'helpmenu'; m.setAttribute('role', 'menu');
    m.innerHTML = [['ask', '🐾', 'Ask the cats'], ['why', '?', 'Why no bet?'], ['recap', '☀', 'Daily recap'], ['tour', '➜', 'Show me around'],
      ['new', '✦', 'What’s new'], ['diag', '⇩', 'Export diagnostics'], ['leave', '⏻', 'Close, pause or turn off']]
      .map(([k, i, t]) => `<button role="menuitem" data-help="${k}"><i>${i}</i>${t}</button>`).join('');
    document.body.appendChild(m);
    m.addEventListener('click', e => { const b = e.target.closest('[data-help]'); if (!b) return; toggleHelp(false);
      ({ask: () => openCouncil(), why: openCatNap, recap: () => openRecap('today'), tour: tourStart, diag: exportDiagnostics, leave: openLeaving,
        new: () => { prefs.pane = 'updates'; savePrefs(); $('gear').click(); }})[b.dataset.help](); });
  }
  const on = open ?? !m.classList.contains('open');
  if (on) { const r = $('helpbtn').getBoundingClientRect(), z = pageScale($('helpbtn'));      // text size scales the page
    m.style.top = (r.bottom + 6) / z + 'px'; m.style.right = Math.max(8, (innerWidth - r.right) / z) + 'px'; }
  m.classList.toggle('open', on); $('helpbtn').setAttribute('aria-expanded', String(on));
  if (on) m.querySelector('button').focus();
}
$('helpbtn').addEventListener('click', e => { e.stopPropagation(); toggleHelp(); });
document.addEventListener('click', e => { if (!e.target.closest('#helpmenu') && $('helpmenu')) toggleHelp(false); });
addEventListener('keydown', e => { if (e.key === 'Escape' && $('helpmenu')) toggleHelp(false); });
