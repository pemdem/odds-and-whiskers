#!/bin/bash
# Odds & Whiskers launcher for macOS (the Mac twin of BetterBot.ps1). Starts the bot in the background if it
# isn't running (kept awake with caffeinate while it runs), then opens the app window.
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MODE="$(sed -n 's/^mode:[[:space:]]*\([a-z]*\).*/\1/p' "$ROOT/config.yaml" 2>/dev/null | head -n 1)"
MODE="${MODE:-paper}"
DATA="$ROOT/data/$MODE"
URLFILE="$DATA/dashboard_url.txt"
mkdir -p "$DATA"

running() { pgrep -f "favbot --config config.yaml run --mode $MODE" > /dev/null; }
supervised() { pgrep -f "supervisor_mac.sh $MODE" > /dev/null; }

say_error() {
    osascript -e "display dialog \"$1\" with title \"Odds & Whiskers\" buttons {\"OK\"} default button 1" > /dev/null 2>&1 || echo "$1"
}

if ! running; then
    STARTED=$(date +%s)
    rm -f "$DATA/STOPPED"
    if ! supervised; then
        nohup caffeinate -i /bin/bash "$ROOT/app/supervisor_mac.sh" "$MODE" > /dev/null 2>&1 &
    fi
    READY=0
    for _ in $(seq 1 180); do
        if [ -f "$URLFILE" ] && [ "$(stat -f %m "$URLFILE")" -ge "$STARTED" ]; then READY=1; break; fi
        if [ -f "$DATA/STOPPED" ]; then break; fi
        sleep 0.5
    done
    if [ "$READY" -ne 1 ]; then
        WHY="$(tail -n 12 "$DATA/console.log" 2>/dev/null | grep -E 'refused|FAIL|error|credentials' | tail -n 3 | tr '"' "'")"
        say_error "The bot didn't start. ${WHY:-See data/$MODE/console.log in the Odds and Whiskers folder.}"
        exit 1
    fi
fi

URL="$(head -n 1 "$URLFILE" | tr -d '[:space:]')"
for APP in "Google Chrome" "Microsoft Edge" "Brave Browser"; do
    if [ -d "/Applications/$APP.app" ]; then
        open -na "$APP" --args --app="$URL" --window-size=1240,940
        exit 0
    fi
done
open "$URL"
