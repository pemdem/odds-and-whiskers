# Odds & Whiskers installer for Windows (run by "Install Odds and Whiskers.bat"). Safe to run again: it never touches an existing
# config.yaml, .env, keys or data. It starts the copy in PRACTICE mode (paper: fake money, real prices).
#
# A fresh starter package is copied to %LOCALAPPDATA%\Odds and Whiskers first, so the downloaded folder can be deleted
# afterwards. No Python on this PC? It downloads its own (checked against a fixed SHA-256) into the app's folder.
param(
    [switch]$NoDesktop,      # don't create the Desktop icon (test installs)
    [switch]$InPlace,        # install right here instead of in %LOCALAPPDATA% (test installs)
    [switch]$NoLaunch,       # don't open the app at the end (test installs)
    [switch]$OwnPython       # use the app's own downloaded Python even if this PC has one (repair / tests)
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'       # Windows PowerShell downloads crawl with the progress bar on
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

function Step($n, $text) { Write-Host "`n[$n/4] $text" -ForegroundColor Cyan }

# ---- 1. where it lives --------------------------------------------------------------------------------------
Step 1 'Putting Odds & Whiskers in place'
$target = Join-Path $env:LOCALAPPDATA 'Odds and Whiskers'
$isCopy = (Test-Path (Join-Path $root 'config.yaml')) -or (Test-Path (Join-Path $root 'data')) -or (Test-Path (Join-Path $root '.venv'))
$moved = $false
if (-not $InPlace -and -not $isCopy -and ($root.TrimEnd('\') -ne $target.TrimEnd('\'))) {
    # a fresh download: copy the app (only app files are in the package - an existing copy's settings, key and data stay)
    New-Item -ItemType Directory -Force $target | Out-Null
    & robocopy $root $target /E /XD .venv .python /NFL /NDL /NJH /NJS /NP | Out-Null
    if ($LASTEXITCODE -ge 8) { throw "Couldn't copy the app to $target (robocopy code $LASTEXITCODE)." }
    $root = $target
    $moved = $true
}
Set-Location $root
Write-Host "    $root"
# files from a downloaded zip are marked as "from the internet"; clear that so Windows doesn't block them
Get-ChildItem -Path $root -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.FullName -notlike '*\.venv\*' -and $_.FullName -notlike '*\.python\*' } |
    Unblock-File -ErrorAction SilentlyContinue

# ---- 2. Python ----------------------------------------------------------------------------------------------
Step 2 'Getting Python ready'
function Find-Python {
    # Supported: Python 3.11 to 3.14 (every part the app needs has a ready-made Windows package for these)
    $check = 'import sys; print((3, 11) <= sys.version_info[:2] <= (3, 14), sys.executable)'
    $cands = @(
        @{ exe = (Join-Path $root '.python\python\python.exe'); args = @() },
        @{ exe = 'py'; args = @('-3.12') }, @{ exe = 'py'; args = @('-3.13') }, @{ exe = 'py'; args = @('-3.14') },
        @{ exe = 'py'; args = @('-3.11') },
        @{ exe = "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe"; args = @() },
        @{ exe = "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe"; args = @() },
        @{ exe = "$env:LOCALAPPDATA\Programs\Python\Python314\python.exe"; args = @() },
        @{ exe = 'python'; args = @() })
    foreach ($c in $cands) {
        try {
            $out = & $c.exe @($c.args + @('-c', $check)) 2>$null
            if ($LASTEXITCODE -eq 0 -and "$out" -match '^True (.+)$') { return $Matches[1].Trim() }
        } catch { }
    }
    return $null
}

function Get-OwnPython {
    # the app's own Python, in its folder: nothing installed system-wide, no python.org, no PATH settings
    $line = Get-Content (Join-Path $root 'app\python_windows.txt') | Where-Object { $_ -match '^x86_64\s' } | Select-Object -First 1
    if (-not $line) { throw "app\python_windows.txt is missing. Download Odds & Whiskers again from the website." }
    $parts = $line -split '\s+'
    $url, $want = $parts[1], $parts[2]
    $tmp = Join-Path $env:TEMP ("odds-whiskers-python-" + [guid]::NewGuid().ToString('N') + '.tar.gz')
    Write-Host "    No Python on this PC, so Odds & Whiskers is getting its own (about 30 MB)..."
    try {
        Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing
        $got = (Get-FileHash -Algorithm SHA256 -LiteralPath $tmp).Hash
        if ($got -ine $want) { throw "The Python download didn't match its fingerprint, so it wasn't used. Try again later." }
        $dest = Join-Path $root '.python'
        if (Test-Path $dest) { Remove-Item -Recurse -Force $dest }
        New-Item -ItemType Directory -Force $dest | Out-Null
        & "$env:WINDIR\System32\tar.exe" -xzf $tmp -C $dest
        if ($LASTEXITCODE -ne 0) { throw "Couldn't unpack Python (tar exited with $LASTEXITCODE)." }
    } finally {
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    }
    return (Join-Path $root '.python\python\python.exe')
}

$py = if ($OwnPython -and -not (Test-Path (Join-Path $root '.python\python\python.exe'))) { $null } else { Find-Python }
if ($OwnPython -and $py -and $py -notlike "$root\.python\*") { $py = $null }
if (-not $py) {
    try { $py = Get-OwnPython }
    catch {
        Write-Host "    $($_.Exception.Message)" -ForegroundColor Yellow
        Write-Host "    Check the internet connection and double-click 'Install Odds and Whiskers' again."
        exit 1
    }
}
Write-Host "    Using $py"

$venvPy = Join-Path $root '.venv\Scripts\python.exe'
if (Test-Path $venvPy) {
    # an environment from an earlier attempt (an unsupported or since-removed Python) is rebuilt
    $okVenv = $null
    try { $okVenv = & $venvPy -c 'import sys; print((3, 11) <= sys.version_info[:2] <= (3, 14))' 2>$null } catch { }
    if ("$okVenv" -ne 'True') {
        Write-Host "    Rebuilding the app's Python environment..."
        Remove-Item -Recurse -Force (Join-Path $root '.venv')
    }
}
if (-not (Test-Path $venvPy)) {
    & $py -m venv (Join-Path $root '.venv')
    if ($LASTEXITCODE -ne 0) { throw "Couldn't create the app's Python environment." }
}

# ---- 3. the parts it needs ----------------------------------------------------------------------------------
Step 3 'Installing the parts it needs (a minute or two)'
& $venvPy -m pip install --disable-pip-version-check --prefer-binary -q -r (Join-Path $root 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw "Installing the parts failed. Check the internet connection and run it again. If it still fails, send a screenshot of this window to whoever shared Odds & Whiskers." }

# ---- 4. settings, icons, open -------------------------------------------------------------------------------
Step 4 'Adding the Odds & Whiskers icon'
if (-not (Test-Path (Join-Path $root 'config.yaml'))) { Copy-Item (Join-Path $root 'config.example.yaml') (Join-Path $root 'config.yaml') }
if (-not (Test-Path (Join-Path $root '.env'))) { Copy-Item (Join-Path $root '.env.example') (Join-Path $root '.env') }
New-Item -ItemType Directory -Force (Join-Path $root 'keys'), (Join-Path $root 'data') | Out-Null

$desktop = [Environment]::GetFolderPath('Desktop')
$ws = New-Object -ComObject WScript.Shell
$links = @((Join-Path $root 'Odds & Whiskers.lnk'))
if (-not $NoDesktop) {
    $links += (Join-Path $desktop 'Odds & Whiskers.lnk')
    $links += (Join-Path ([Environment]::GetFolderPath('Programs')) 'Odds & Whiskers.lnk')     # Start menu
    $old = Join-Path $desktop 'Better Bot.lnk'          # the app's old name
    if ((Test-Path -LiteralPath $old) -and ($ws.CreateShortcut($old).Arguments -like "*$root*")) { Remove-Item -LiteralPath $old }
}
foreach ($lnkPath in $links) {
    $s = $ws.CreateShortcut($lnkPath)
    $s.TargetPath = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
    $s.Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$(Join-Path $root 'app\BetterBot.ps1')`""
    $s.WorkingDirectory = $root
    $s.IconLocation = "$(Join-Path $root 'app\BetterBot.ico'),0"
    $s.WindowStyle = 7
    $s.Save()
}
& $venvPy -m favbot --config config.yaml release status | Out-Null
if ($LASTEXITCODE -ne 0) { throw "The app didn't start its self-check. Send a screenshot of this window to whoever shared Odds & Whiskers." }

Write-Host "`nDone! Odds & Whiskers is installed." -ForegroundColor Green
Write-Host "It starts in PRACTICE mode: fake money on real prices. A short welcome walks you through the rest,"
Write-Host "including connecting your Kalshi account (your key stays on this PC, encrypted)."
Write-Host "Open it any time with the Odds & Whiskers icon on your Desktop or in the Start menu."
if ($moved) { Write-Host "You can delete the downloaded folder now; the app lives in $root." }
if (-not $NoLaunch) {
    Write-Host "`nOpening Odds & Whiskers..."
    Start-Process -FilePath "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe" -WorkingDirectory $root -WindowStyle Hidden `
        -ArgumentList '-NoProfile', '-WindowStyle', 'Hidden', '-ExecutionPolicy', 'Bypass', '-File', "`"$(Join-Path $root 'app\BetterBot.ps1')`""
}
exit 0
