#!/bin/bash
# Odds & Whiskers installer for macOS (run by "Install Odds and Whiskers.command"). Safe to run again: it never
# touches an existing config.yaml, .env, keys or data. A new copy starts in PRACTICE mode (fake money, real prices).
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
echo "Setting up Odds & Whiskers in $ROOT"
echo

# files from a downloaded zip are quarantined by macOS; clear that for this folder so the helpers can run
xattr -dr com.apple.quarantine "$ROOT" 2>/dev/null || true
chmod +x "$ROOT"/*.command "$ROOT"/app/*.sh 2>/dev/null || true

# Supported: Python 3.11 to 3.14 (every part the app needs has a ready-made Mac package for these).
SUPPORTED='import sys; sys.exit(0 if (3, 11) <= sys.version_info[:2] <= (3, 14) else 1)'
PY=""
for c in python3.12 python3.13 python3.14 python3.11 \
         /Library/Frameworks/Python.framework/Versions/3.12/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.13/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.14/bin/python3 python3; do
    if command -v "$c" > /dev/null 2>&1 && "$c" -c "$SUPPORTED" 2>/dev/null; then
        PY="$(command -v "$c")"; break
    fi
done
if [ -z "$PY" ]; then
    HAVE="$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null || echo none)"
    echo "Odds & Whiskers needs Python 3.12, 3.13 or 3.14 (this Mac has: $HAVE)."
    echo "1. On the page that opens, find Python 3.14 (or 3.13) and download its macOS 64-bit universal2 installer."
    echo "   Newer versions like 3.15 aren't supported yet; you can keep them, just add 3.14 alongside."
    echo "2. Open it and click through the installer."
    echo "3. Double-click 'Install Odds and Whiskers.command' again."
    open "https://www.python.org/downloads/macos/"
    exit 1
fi
echo "Using Python: $PY ($("$PY" -c 'import sys; print("%d.%d.%d" % sys.version_info[:3])'))"

# an environment left by an earlier attempt with an unsupported Python is rebuilt
if [ -x "$ROOT/.venv/bin/python" ] && ! "$ROOT/.venv/bin/python" -c "$SUPPORTED" 2>/dev/null; then
    echo "Rebuilding the app's Python environment (it was made with an unsupported Python)..."
    rm -rf "$ROOT/.venv"
fi
if [ ! -x "$ROOT/.venv/bin/python" ]; then
    echo "Creating the app's own Python environment..."
    "$PY" -m venv "$ROOT/.venv"
fi
echo "Installing the parts it needs (a minute or two)..."
if ! "$ROOT/.venv/bin/python" -m pip install --disable-pip-version-check --prefer-binary -q -r "$ROOT/requirements.txt"; then
    echo
    echo "Installing the parts failed. Check the internet connection and run this again."
    echo "If it still fails, take a screenshot of this window and send it to whoever shared Odds & Whiskers."
    exit 1
fi

[ -f "$ROOT/config.yaml" ] || cp "$ROOT/config.example.yaml" "$ROOT/config.yaml"
[ -f "$ROOT/.env" ] || cp "$ROOT/.env.example" "$ROOT/.env"
mkdir -p "$ROOT/keys" "$ROOT/data"
chmod 700 "$ROOT/keys"

# a Desktop app that opens Odds & Whiskers (falls back to a double-clickable file)
DESK="$HOME/Desktop"
if [ "${1:-}" != "--no-desktop" ]; then
    rm -rf "$DESK/Odds & Whiskers.app"
    if ! osacompile -o "$DESK/Odds & Whiskers.app" \
        -e "do shell script \"/bin/bash \" & quoted form of \"$ROOT/app/launch_mac.sh\"" > /dev/null 2>&1; then
        cp "$ROOT/Open Odds and Whiskers.command" "$DESK/Odds & Whiskers.command"
        chmod +x "$DESK/Odds & Whiskers.command"
    fi
fi

echo "Checking the install..."
"$ROOT/.venv/bin/python" -m favbot --config config.yaml release status

echo
echo "Done! Odds & Whiskers is on your Desktop."
echo "It starts in PRACTICE mode: fake money on real prices."
echo "Real money, when you're ready:  1) Set up my Kalshi key.command   2) Go live.command"
echo "Updates appear in the app by themselves when the shared updates folder is in your OneDrive."
