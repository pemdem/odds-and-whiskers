#!/bin/bash
cd "$(dirname "$0")"
.venv/bin/python -m favbot setup-key
echo
read -n 1 -s -r -p "Press any key to close this window."
echo
