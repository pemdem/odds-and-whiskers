import json
from decimal import Decimal as D

from favbot import lab
from favbot.store import Store

T0 = 1_800_000_000.0
PROP = {"proposal": {"params": {"ask_min": 0.88, "ask_max": 0.95, "max_spread": 0.03, "window_s": 300, "side": "down",
                                "mode": "ask", "window_end_s": 60},
                     "coins": None,
                     "label": "buy at the ask, DOWN only", "past": {"n": 900, "roi": 0.01}, "past_current": {"n": 3000, "roi": -0.02},
                     "walk_forward": {"verdict": "better"}}}


def fill(db_path, n, win_every, start, price="0.93", qty=4):
    s = Store(db_path)
    for i in range(n):
        won = (i % win_every) != 0 if win_every else True
        eid = s.insert_intent(mode="paper", series="KXETH15M", coin="ETH", ticker=f"T-{start}-{i}", leg="yes", outcome="UP",
                              price=D(price), count=qty, max_loss=D(price) * qty, expiration_ts=1,
                              client_order_id=f"c{start}-{i}", max_attempts=20)
        cost = D(price) * qty
        s._x("UPDATE entries SET filled_count=?, fill_cost=?, state='done' WHERE id=?", (str(qty), str(cost), eid))
        pay = D(qty) if won else D(0)
        s.settle_entry(eid, "yes" if won else "no", pay, pay - cost, now=start + i * 60)
    s.close()


def test_proposal_is_frozen_then_concluded_on_fresh_data_only(tmp_path):
    r = lab.step(tmp_path, PROP, now=T0)
    assert r["restart_litterbox"] and r["candidate"]["status"] == "testing"
    cid = r["candidate"]["id"]
    # results from BEFORE the proposal must not count
    fill(tmp_path / "litterbox" / f"candidate-{cid}" / "favbot.sqlite3", 50, 0, T0 - 10_000)
    ev = lab.evaluate(r["candidate"], tmp_path, now=T0 + 3600)
    assert ev["candidate"]["n"] == 0
    # a new proposal is NOT made while one is testing, even if Backtrack changes its mind
    other = json.loads(json.dumps(PROP)); other["proposal"]["params"]["side"] = "up"
    assert lab.step(tmp_path, other, now=T0 + 7200)["candidate"]["strategy"]["side"] == "down"


def test_graduates_only_when_clearly_better_and_profitable(tmp_path):
    cand = lab.step(tmp_path, PROP, now=T0)["candidate"]
    lb = tmp_path / "litterbox"
    fill(lb / f"candidate-{cand['id']}" / "favbot.sqlite3", 400, 0, T0 + 10)        # wins every bet
    fill(lb / "original" / "favbot.sqlite3", 400, 8, T0 + 10)                       # loses 1 in 8
    r = lab.step(tmp_path, None, now=T0 + 4 * 86400)
    assert r["candidate"]["status"] == "graduated" and r["history"][-1]["status"] == "graduated"
    rec = lab.recommendation(tmp_path)
    assert rec["ready"] and rec["strategy"]["entry"] == "ask" and rec["max_drop"] == 0


def test_rejected_when_within_luck_and_not_proposed_again(tmp_path):
    cand = lab.step(tmp_path, PROP, now=T0)["candidate"]
    lb = tmp_path / "litterbox"
    fill(lb / f"candidate-{cand['id']}" / "favbot.sqlite3", 320, 14, T0 + 10)
    fill(lb / "original" / "favbot.sqlite3", 320, 14, T0 + 10)
    r = lab.step(tmp_path, None, now=T0 + 4 * 86400)
    assert r["candidate"]["status"] == "rejected"
    assert not lab.recommendation(tmp_path)["ready"]
    r2 = lab.step(tmp_path, PROP, now=T0 + 5 * 86400)                               # same idea again
    assert not r2["restart_litterbox"] and r2["candidate"]["status"] == "rejected"


def test_400_candidate_bets_vs_1_original_bet_does_not_graduate(tmp_path):
    cand = lab.step(tmp_path, PROP, now=T0)["candidate"]
    lb = tmp_path / "litterbox"
    fill(lb / f"candidate-{cand['id']}" / "favbot.sqlite3", 400, 0, T0 + 10)        # wins every bet
    fill(lb / "original" / "favbot.sqlite3", 1, 0, T0 + 10, price="0.97")          # one bet: nothing to compare with
    r = lab.step(tmp_path, None, now=T0 + 4 * 86400)
    assert r["candidate"]["status"] == "testing"                                    # keeps waiting for the Original
    assert r["candidate"]["last_eval"]["progress"] < 0.01
    r = lab.step(tmp_path, None, now=T0 + 22 * 86400)                               # out of time
    assert r["candidate"]["status"] == "inconclusive" and not lab.recommendation(tmp_path)["ready"]
    r2 = lab.step(tmp_path, PROP, now=T0 + 23 * 86400)                              # an inconclusive idea may run again
    assert r2["restart_litterbox"] and r2["candidate"]["status"] == "testing" and r2["candidate"]["id"] == 2


def test_coins_are_part_of_the_idea(tmp_path):
    p = json.loads(json.dumps(PROP)); p["proposal"]["coins"] = ["ETH", "SOL"]
    c = lab.step(tmp_path, p, now=T0)["candidate"]
    assert c["coins"] == ["ETH", "SOL"] and "ETH, SOL" in c["label"]
    # same strategy on all coins is a different idea once the coin version is rejected
    lb = tmp_path / "litterbox"
    fill(lb / f"candidate-{c['id']}" / "favbot.sqlite3", 320, 14, T0 + 10)
    fill(lb / "original" / "favbot.sqlite3", 320, 14, T0 + 10)
    assert lab.step(tmp_path, None, now=T0 + 4 * 86400)["candidate"]["status"] == "rejected"
    assert not lab.step(tmp_path, p, now=T0 + 5 * 86400)["restart_litterbox"]          # same idea: no
    assert lab.step(tmp_path, PROP, now=T0 + 5 * 86400)["candidate"]["coins"] is None  # all coins: a new idea
    # the baseline strategy on fewer coins IS a real idea
    base = json.loads(json.dumps(PROP)); base["proposal"]["params"].update(mode="bid", side="both", ask_max=0.97)
    base["proposal"]["coins"] = ["ETH"]
    assert lab.step(tmp_path / "b", base, now=T0)["restart_litterbox"]


def test_old_rules_candidate_is_withdrawn_and_old_backtrack_results_wait(tmp_path):
    (tmp_path / "lab").mkdir()
    (tmp_path / "lab" / "candidate.json").write_text(json.dumps(
        {"id": 1, "label": "old", "strategy": {"entry": "ask"}, "coins": None, "bet_usd": 4, "created_at": T0,
         "status": "testing", "evidence": {}}), encoding="utf-8")
    r = lab.step(tmp_path, PROP, now=T0 + 100)
    assert r["restart_litterbox"] and r["candidate"]["status"] == "withdrawn" and r["history"][-1]["status"] == "withdrawn"
    old = json.loads(json.dumps(PROP)); del old["proposal"]["coins"]                # made before coins were searched
    assert not lab.step(tmp_path, old, now=T0 + 200)["restart_litterbox"]
    assert lab.step(tmp_path, PROP, now=T0 + 300)["candidate"]["status"] == "testing"


def test_baseline_is_never_proposed(tmp_path):
    base = json.loads(json.dumps(PROP))
    base["proposal"]["params"].update(mode="bid", side="both", ask_max=0.97)
    assert not lab.step(tmp_path, base, now=T0)["restart_litterbox"]
