"""Cat Nap: one clear status, "Why no bet?" in plain words, the daily recap and diagnostics without secrets.

Everything here reads what the bot really decided (the strategy's decision text, the risk check's reason, the
kill switch, halts, the network and the exchange) and puts it into plain language. Nothing here trades.
"""
from __future__ import annotations

import json
import platform
import re
import sys
import time
from decimal import Decimal
from pathlib import Path

from .money import d_or_zero

LEVELS = ("running", "watching", "paused", "offline", "attention")
TITLES = {"running": "Running", "watching": "Watching", "paused": "Paused", "offline": "Offline", "attention": "Needs attention"}


def _mmss(s: float) -> str:
    s = max(0, int(s))
    return f"{s // 60}:{s % 60:02d}"


def _c(p) -> str:
    """0.93 -> 93¢"""
    try:
        return f"{float(p) * 100:.0f}¢"
    except (TypeError, ValueError):
        return str(p)


# ---- "Why no bet?" ---------------------------------------------------------------------------
_RULES = [
    (r"^waiting \((\d+)s left\)", "timing", lambda m, w: (
        f"Too early: bets open {w // 60} min before the close (in {_mmss(int(m[1]) - w)})." if int(m[1]) > w
        else "Bets are open; checking prices.")),
    (r"^closed$", "timing", lambda m, w: "That contract just closed; the next one opens soon."),
    (r"^final 60s", "timing", lambda m, w: "Too late: no new bets in the last minute."),
    (r"^too close to the cutoff", "timing", lambda m, w: "Too close to the end to place a 20-second bid."),
    (r"^no favourite in ([\d.]+)-([\d.]+)", "strategy", lambda m, w: (
        f"No side is a strong enough favourite (it needs a price between {_c(m[1])} and {_c(m[2])}).")),
    (r"^both sides in band", "strategy", lambda m, w: "Both sides look like favourites, which means a thin, unreliable book. Skipped."),
    (r"^(UP|DOWN) favourite, but this model only bets (\w+)", "strategy", lambda m, w: (
        f"The favourite is {m[1].title()}, but your settings only bet {m[2].title()}.")),
    (r"favourite has no bid", "strategy", lambda m, w: "The favourite has no bid to join yet."),
    (r"book crossed/locked", "strategy", lambda m, w: "The prices were crossed for a moment (a glitch). Skipped."),
    (r"spread ([\d.]+) > ([\d.]+)", "strategy", lambda m, w: (
        f"The gap between bid and ask ({_c(m[1])}) is wider than your limit ({_c(m[2])}).")),
    (r"off the price grid", "strategy", lambda m, w: "That price isn't on Kalshi's price grid. Skipped."),
    (r"^(bid|buy) (UP|DOWN) ([\d.]+)", "betting", lambda m, w: f"Betting: {m[2].title()} at {_c(m[3])}."),
    (r"^kill switch", "risk", lambda m, w: "The kill switch is on: no new bets until it's turned off."),
    (r"^paused", "risk", lambda m, w: "You paused new bets."),
    (r"^recovering: (.+)", "risk", lambda m, w: f"Re-checking every order with Kalshi ({m[1]}) before betting again."),
    (r"^halted: (.+)", "risk", lambda m, w: f"Stopped to double-check something: {m[1]}."),
    (r"(\d+) order\(s\) with unknown outcome", "risk", lambda m, w: "Checking an order with Kalshi first (its result wasn't clear)."),
    (r"exchange trading not confirmed active", "risk", lambda m, w: "Kalshi's exchange isn't confirmed open right now."),
    (r"clock skew unknown", "risk", lambda m, w: "Waiting to compare this computer's clock with Kalshi's."),
    (r"clock skew ([+-][\d.]+)s exceeds", "risk", lambda m, w: f"This computer's clock is off by {m[1]}s, so bets wait until it's right."),
    (r"stale book \(([\d.]+)s\)", "risk", lambda m, w: f"The prices were too old to trust ({float(m[1]):.0f}s). Skipped."),
    (r"daily loss limit", "risk", lambda m, w: "Today's loss limit was reached: no more bets until tomorrow (UTC)."),
    (r"max open positions \((\d+)/(\d+)\)", "risk", lambda m, w: f"Already holding {m[1]} of the {m[2]} bets allowed at once."),
    (r"no budget left", "risk", lambda m, w: "No money left within your limits for another bet."),
    (r"buys less than one contract", "risk", lambda m, w: "The money left within your limits can't buy one contract."),
    (r"bid cap (\d+) reached", "risk", lambda m, w: f"Already tried {m[1]} bids on this contract (the maximum)."),
    (r"no equity", "risk", lambda m, w: "The account shows no money to bet with."),
    (r"turned off in settings", "off", lambda m, w: "This coin is turned off in Settings → Coins."),
    (r"no verified contract open", "timing", lambda m, w: "No contract is open for this coin right now."),
    (r"series info unavailable|unrecognised fee_type", "attention", lambda m, w: "Couldn't load this coin's details from Kalshi."),
    (r"^starting", "timing", lambda m, w: "Starting up."),
]


def explain(text: str | None, window_s: int = 300) -> tuple[str, str]:
    """(plain sentence, kind) for a raw decision / risk reason. kind: timing | strategy | risk | betting | off | attention."""
    t = (text or "").strip()
    for pat, kind, fn in _RULES:
        m = re.search(pat, t, re.I)
        if m:
            return fn(m, window_s), kind
    return (t[:1].upper() + t[1:] if t else "No decision yet."), "other"


def why_no_bet(bot) -> list[dict]:
    """Per coin: what the bot decided right now and why, from the engine's own status."""
    out = []
    off = set(bot.coins_off())
    w = bot.cfg.strategy.window_start_s
    for e in bot.engines:
        st = e.status
        if st.get("position"):
            raw, plain, kind = st["position"], f"Holding a bet: {st['position'].replace('holding ', '')}.", "betting"
        elif st.get("entry"):
            raw, plain, kind = st["entry"], f"A bid is waiting: {st['entry']}.", "betting"
        else:
            raw = ("turned off in settings" if e.coin in off else None) or st.get("blocked") or st.get("decision")
            plain, kind = explain(raw, w)
        if st.get("error") and kind not in ("betting",):
            plain, kind = f"Couldn't check prices last time ({st['error'][:80]}). It retries every few seconds.", "attention"
        out.append({"coin": e.coin, "plain": plain, "kind": kind, "raw": raw, "secs_left": st.get("secs_left"),
                    "up_ask": st.get("up_ask"), "down_ask": st.get("down_ask"), "as_of": st.get("book_ts")})
    return out


# ---- one status ------------------------------------------------------------------------------
def status(bot, update_ready: bool = False) -> dict:
    """One clear status: running | watching | paused | offline | attention, with a plain explanation and next step."""
    now = bot.clock()
    k = bot.killed()
    halts = bot.store.halts()
    net_down = bool(bot.alerts and getattr(bot.alerts, "_net_down", False))
    rec = getattr(bot, "recovering", None)
    ta = bot.trading_active()
    errors = [e for e in bot.engines if e.status.get("error")]

    def S(level, title_detail, detail, step=None, action=None):
        return {"level": level, "title": TITLES[level], "headline": title_detail, "detail": detail,
                "next_step": step, "action": action, "as_of": now}

    if k:
        return S("attention", "Kill switch is on", f"No new bets: {k}. Bets that already filled still finish.",
                 "When you're ready, turn it off from a terminal with the unkill command (or ask Claude).", None)
    if halts:
        names = ", ".join(halts)
        return S("attention", "Stopped to double-check orders", f"The bot paused itself because something didn't add up ({names}).",
                 "Open Warnings to see what happened; it clears once the order is confirmed with Kalshi.", {"type": "open", "target": "section:sec-warn"})
    if rec:
        return S("paused", "Re-checking with Kalshi", f"{rec[:1].upper() + rec[1:]}. Every order and the balance are being checked "
                 "with Kalshi before any new bet.", "Nothing to do — it resumes by itself in a few seconds.")
    if net_down:
        since = getattr(bot.alerts, "net_since", None)
        return S("offline", "Can't reach Kalshi", "The internet connection to Kalshi is down" +
                 (f" since {time.strftime('%H:%M', time.localtime(since))}" if since else "") +
                 ". No new bets until it's back; bets that already filled settle on Kalshi anyway.",
                 "Check this computer's internet. The bot retries by itself and re-checks orders when it's back.")
    if errors and len(errors) == len(bot.engines):
        return S("offline", "Can't load prices", f"Every coin failed its last price check ({errors[0].status['error'][:80]}).",
                 "Usually a brief Kalshi or internet hiccup; it retries every few seconds.")
    if ta is False:
        return S("paused", "Kalshi's exchange is closed", "Kalshi isn't trading right now, so there's nothing to bet on.",
                 "Nothing to do — the bot starts again when the exchange opens.")
    if bot.paused:
        return S("paused", "Paused by you", "No new bets and no waiting bids. Bets that already filled still finish.",
                 "Press Resume when you want it betting again.", {"type": "resume"})
    if bot.daily_loss_hit():
        return S("paused", "Daily loss limit reached", "Today's losses hit your daily stop, so new bets wait until tomorrow (UTC).",
                 "Nothing to do. If this keeps happening, consider a lower risk level (Clump).", {"type": "open", "target": "section:sec-preset"})
    attention = None
    if bot.mode == "live" and bot.data_dir:
        try:
            ack = json.loads((bot.data_dir / "live_ack.json").read_text(encoding="utf-8"))
            days = (ack.get("expires_at", 0) - now) / 86400
            if days < 3:
                attention = S("attention", "Real-money confirmation expires soon",
                              f"Your 30-day confirmation ends in {max(0, days):.1f} days; after that the bot won't start with real money.",
                              "Double-click “Confirm new limits” (or run ack-live) before it runs out.")
        except (OSError, ValueError):
            pass
    if errors:
        attention = attention or S("attention", f"{', '.join(e.coin for e in errors)} had trouble",
                                   f"{errors[0].coin}: {errors[0].status['error'][:100]}. Other coins keep going.",
                                   "It retries every few seconds; check Warnings if it lasts.")
    if attention:
        return attention
    resting = bot.store.entries(bot.mode, states=("resting",))
    holding = [e for e in bot.store.entries(bot.mode, unsettled_slot=True) if d_or_zero(e["filled_count"]) > 0]
    if holding or resting:
        bits = []
        if holding:
            e = holding[0]
            bits.append(f"holding {e['filled_count']} {e['coin']} {str(e['outcome']).title()} at {_c(e['price'])}")
        if resting:
            e = resting[0]
            bits.append(f"a bid is waiting on {e['coin']} {str(e['outcome']).title()} at {_c(e['price'])}")
        more = len(holding) + len(resting) - 1
        return S("running", "Betting", ("; ".join(bits) + (f" (+{more} more)" if more > 0 else "") + ".").capitalize(),
                 None)
    w = why_no_bet(bot)
    soon = min((x["secs_left"] - bot.cfg.strategy.window_start_s for x in w
                if x["secs_left"] and x["secs_left"] > bot.cfg.strategy.window_start_s), default=None)
    detail = ("Watching prices; no bet right now." +
              (f" The next betting window opens in {_mmss(soon)}." if soon else " " + (w[0]["plain"] if w else "")))
    return S("watching", "Watching", detail.strip(), "Ask “Why no bet?” to see each coin's reason.", {"type": "whynobet"})


# ---- daily recap -------------------------------------------------------------------------------
def _day_bounds(day: str, now: float) -> tuple[float, float, str]:
    lt = time.localtime(now)
    start = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1))
    if day == "yesterday":
        return start - 86400, start, time.strftime("%A %b %d", time.localtime(start - 86400))
    return start, now, "Today"


def recap(bot, day: str = "today", lb_summary: dict | None = None) -> dict:
    now = bot.clock()
    t0, t1, label = _day_bounds(day, now)
    rows = bot.store._q("""SELECT coin, outcome, price, pnl, fees, fill_cost, payout, filled_count FROM entries
                           WHERE mode=? AND settled_result IS NOT NULL AND CAST(filled_count AS REAL) > 0
                           AND settled_at >= ? AND settled_at < ?""", (bot.mode, t0, t1))
    sent = bot.store._q("SELECT COUNT(*) n FROM entries WHERE mode=? AND order_id IS NOT NULL AND created_at >= ? AND created_at < ?",
                        (bot.mode, t0, t1))[0]["n"]
    wins = sum(1 for r in rows if d_or_zero(r["payout"]) > 0)
    pnl = sum((d_or_zero(r["pnl"]) for r in rows), Decimal(0))
    fees = sum((d_or_zero(r["fees"]) for r in rows), Decimal(0))
    staked = sum((d_or_zero(r["fill_cost"]) + d_or_zero(r["fees"]) for r in rows), Decimal(0))
    by_coin: dict[str, Decimal] = {}
    for r in rows:
        by_coin[r["coin"]] = by_coin.get(r["coin"], Decimal(0)) + d_or_zero(r["pnl"])
    best = max(by_coin.items(), key=lambda kv: kv[1]) if by_coin else None
    worst = min(by_coin.items(), key=lambda kv: kv[1]) if by_coin else None
    holding = [e for e in bot.store.entries(bot.mode, unsettled_slot=True) if d_or_zero(e["filled_count"]) > 0]
    lb = None
    if lb_summary and lb_summary.get("models"):
        ms = lb_summary["models"]
        ranked = sorted((m for m in ms if m.get("bets", 0) >= 10), key=lambda m: -(m.get("roi") or 0))
        twin = next((m for m in ms if m.get("id") == "twin"), None)
        lb = {"models": len(ms), "fake_bets": sum(m.get("bets", 0) for m in ms),
              "leader": {"name": ranked[0]["name"], "roi": ranked[0]["roi"], "bets": ranked[0]["bets"]} if ranked else None,
              "twin": {"pnl": twin.get("pnl"), "bets": twin.get("bets")} if twin else None,
              "as_of": lb_summary.get("ts")}
    return {"day": label, "from": t0, "to": t1, "real_money": bot.mode == "live", "bets": len(rows), "wins": wins,
            "losses": len(rows) - wins, "pnl": f"{pnl:.2f}", "fees": f"{fees:.2f}", "staked": f"{staked:.2f}",
            "bids_sent": sent, "best_coin": [best[0], f"{best[1]:.2f}"] if best else None,
            "worst_coin": [worst[0], f"{worst[1]:.2f}"] if worst and worst != best else None,
            "open_positions": [{"coin": e["coin"], "outcome": e["outcome"], "qty": str(e["filled_count"]), "price": str(e["price"])}
                               for e in holding],
            "litterbox": lb, "as_of": now}


# ---- diagnostics without secrets ----------------------------------------------------------------
_AMOUNTS = [
    (re.compile(r"\$\s?-?[\d,]+(\.\d+)?"), "$<amount>"),
    (re.compile(r"(?i)(P&L|pnl|equity|balance|cash|exposure|limit)[=: ]+[-+]?[\d.]+"), r"\1=<amount>"),
]
_SECRETS = [
    (re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.I), "<id>"),
    (re.compile(r"-----BEGIN[^-]*-----.*?-----END[^-]*-----", re.S), "<key removed>"),
    (re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"), "<email>"),
    (re.compile(r"(?i)token=[\w-]+"), "token=<removed>"),
    (re.compile(r"(?i)(api[_-]?key|key_id|secret|password)[\"']?\s*[:=]\s*[\"']?[^\s\"',}]+"), r"\1=<removed>"),
]


def scrub(text: str) -> str:
    """Remove anything secret-looking (IDs, keys, emails, tokens) but keep the person's own numbers."""
    for pat, rep in _SECRETS:
        text = pat.sub(rep, text)
    return text


def redact(text: str) -> str:
    """For diagnostics that may be shared: secrets AND money amounts removed."""
    text = scrub(text)
    for pat, rep in _AMOUNTS:
        text = pat.sub(rep, text)
    return text


def _tail(path: Path, n: int = 80) -> list[str]:
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()[-n:]
    except OSError:
        return []
    return [redact(x)[:400] for x in lines]


def diagnostics(bot, version: dict | None = None) -> dict:
    """Help → Export diagnostics. Never included: keys, Key IDs, tokens, emails, balances, amounts, limits' dollar
    values, order IDs or trade-by-trade history. Included: versions, status, settings that aren't money, and
    recent warnings/log lines with amounts and IDs removed."""
    st = status(bot)
    events = [{"t": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(e["ts"])), "level": e["level"], "kind": e["kind"],
               "message": redact(str(e["message"]))[:300]} for e in bot.store.recent_events(60)]
    strat = {k: str(v) for k, v in bot.cfg.strategy.model_dump().items()}
    return {
        "generated": time.strftime("%Y-%m-%d %H:%M:%S %z"),
        "app": {"version": (version or {}).get("installed"), "code": getattr(bot, "code_version", None)},
        "system": {"os": platform.platform(), "python": sys.version.split()[0], "machine": platform.machine()},
        "mode": bot.mode, "uptime_min": round((bot.clock() - bot.started_at) / 60, 1),
        "status": {k: st[k] for k in ("level", "headline", "detail")},
        "coins": [{"coin": w["coin"], "reason": w["plain"], "kind": w["kind"]} for w in why_no_bet(bot)],
        "strategy": strat, "coins_on": [e.coin for e in bot.engines if e.coin not in set(bot.coins_off())],
        "limits": {"max_open_positions": bot.limits.max_open_positions,
                   "max_total_exposure_pct": str(bot.limits.max_total_exposure_pct),
                   "daily_loss_pct": str(bot.limits.daily_loss_pct)},
        "health": {"kill_switch": bool(bot.killed()), "paused": bot.paused, "halts": list(bot.store.halts()),
                   "unknown_orders": bot.store.unknown_count(bot.mode), "network_down": bool(bot.alerts and bot.alerts._net_down),
                   "exchange_open": bot.trading_active(), "clock_skew_s": bot.md.clock_skew_s,
                   "recovering": getattr(bot, "recovering", None), "last_recovery": getattr(bot, "last_recovery", None)},
        "recent_events": events,
        "supervisor_log": _tail(bot.data_dir / "supervisor.log", 40) if bot.data_dir else [],
        "console_errors": [x for x in _tail(bot.data_dir / "console.log", 400) if re.search(r"error|fail|refused|traceback", x, re.I)][-40:]
                          if bot.data_dir else [],
    }
