"""Typed confirmation phrases: forgiving about how they're typed, strict about what they say (2.0.2).
Before, anything but an exact, case-sensitive copy was refused with "The phrase doesn't match"."""
from decimal import Decimal as D

import pytest

from favbot import account
from favbot.liveguard import ack_phrase, phrase_matches

LIVE = ack_phrase(account.live_limits(D(25), 1))          # I ACCEPT REAL-MONEY RISK C2602D34
MOVE = account.move_phrase(D("25.00"), 2)                   # MOVE 25.00 TO SHARD 2
CODE = LIVE.rsplit(" ", 1)[1]


@pytest.mark.parametrize("typed", [
    LIVE, LIVE.lower(), LIVE.title(), "  " + LIVE + "  ", LIVE + ".",
    LIVE.replace("REAL-MONEY", "REAL MONEY"), LIVE.replace("REAL-MONEY", "REALMONEY"),
    LIVE.replace("-", "–"), LIVE.replace(" ", "  "), LIVE.replace("0", "O"),
    "i accept real-money risk " + CODE.lower(),
])
def test_live_phrase_typed_by_a_person(typed):
    assert phrase_matches(typed, LIVE)


@pytest.mark.parametrize("typed", [
    MOVE, MOVE.lower(), "move 25 to shard 2", "MOVE $25.00 TO SHARD 2", "Move 25.0 to shard 2.", "MOVE 25.00 T0 SHARD 2",
])
def test_move_phrase_typed_by_a_person(typed):
    assert phrase_matches(typed, MOVE)


@pytest.mark.parametrize("typed,phrase", [
    ("", LIVE), (None, LIVE), ("   ", LIVE),
    ("I ACCEPT REAL-MONEY RISK", LIVE),                                   # code left out
    ("I ACCEPT REAL-MONEY RISK 12345678", LIVE),                          # a different code
    (LIVE[:-1] + ("0" if LIVE[-1] != "0" else "1"), LIVE),               # one character off
    ("I ACCEPT RISK " + CODE, LIVE),                                      # a word missing
    ("MOVE 250.00 TO SHARD 2", MOVE), ("MOVE 2500 TO SHARD 2", MOVE),    # another amount
    ("MOVE 25.00 TO SHARD 3", MOVE), ("MOVE 25.01 TO SHARD 2", MOVE),
    ("yes", MOVE),
])
def test_still_refuses_anything_that_says_something_else(typed, phrase):
    assert not phrase_matches(typed, phrase)


def test_the_page_uses_the_same_rule():
    from pathlib import Path
    js = (Path(__file__).resolve().parents[1] / "favbot" / "web" / "onboard.js").read_text(encoding="utf-8")
    assert "function canonPhrase" in js and "phraseOK(t.value, t.dataset.phrase)" in js
