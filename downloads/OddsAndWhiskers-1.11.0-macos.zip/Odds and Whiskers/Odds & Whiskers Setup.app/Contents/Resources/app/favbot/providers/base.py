"""Interfaces. The engine only talks to these; Kalshi and the paper simulator implement them."""
from __future__ import annotations

from typing import Protocol

from ..models import (BalanceInfo, Book, ExchangeStatus, FillInfo, OrderAck, OrderInfo, OrderRequest,
                      PositionInfo, SeriesInfo)


class ApiError(Exception):
    def __init__(self, status: int, message: str, code: str = ""):
        super().__init__(f"HTTP {status} {code} {message}".strip())
        self.status = status
        self.code = code
        self.message = message


class NotFound(ApiError):
    pass


class RateLimited(ApiError):
    pass


class TransportError(Exception):
    """Network failure. maybe_sent=False only when the connection was never established."""

    def __init__(self, message: str, maybe_sent: bool):
        super().__init__(message)
        self.maybe_sent = maybe_sent


class OrderOutcomeUnknown(Exception):
    """Timeout or 5xx on an order write: the exchange may or may not have it."""


class ReadOnlyViolation(RuntimeError):
    """A non-GET request was attempted on a read-only client. Raised before any I/O."""


class MarketData(Protocol):
    clock_skew_s: float | None

    async def get_exchange_status(self) -> ExchangeStatus: ...
    async def get_series(self, series: str) -> SeriesInfo: ...
    async def list_markets(self, series: str, min_close_ts: int, max_close_ts: int) -> list[dict]: ...
    async def get_market(self, ticker: str) -> dict: ...
    async def get_orderbook(self, ticker: str) -> Book: ...


class Trading(Protocol):
    kind: str  # "paper" | "kalshi"

    async def create_order(self, req: OrderRequest) -> OrderAck: ...
    async def cancel_order(self, order_id: str, ticker: str) -> None: ...
    async def get_order(self, order_id: str) -> OrderInfo | None: ...
    async def list_orders(self, *, ticker: str | None = None, status: str | None = None,
                          min_ts: int | None = None) -> list[OrderInfo]: ...
    async def get_fills(self, *, order_id: str | None = None, ticker: str | None = None,
                        min_ts: int | None = None) -> list[FillInfo]: ...
    async def get_positions(self) -> list[PositionInfo]: ...
    async def get_balance(self) -> BalanceInfo: ...

    def observe_book(self, book: Book, now: float) -> None: ...
    async def settle(self, ticker: str, result: str) -> None: ...
