"""Every risk limit, in one function.

budget   = min(max_loss_per_position_usd,
               max_loss_per_position_pct * equity_for_limits,
               max_total_exposure_pct * equity_for_limits - current_exposure,
               available_cash)
equity_for_limits = min(account_equity, capital_cap_usd)
quantity = floor(budget / bid_price);  skip if quantity < 1
max_loss = quantity * bid_price + maker_fee
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import ROUND_FLOOR, Decimal
from typing import Callable

from .config import Limits
from .money import ZERO


@dataclass
class RiskInputs:
    limits: Limits
    equity: Decimal                 # account equity on the trading shard
    available_cash: Decimal         # shard balance minus unconfirmed orders' worst case
    exposure: Decimal               # open cost basis + cash behind resting bids + unconfirmed worst case
    open_positions: int             # filled-unsettled + resting + unconfirmed, across all coins
    daily_pnl: Decimal              # realized since 00:00 UTC + unrealized at the executable bid
    price: Decimal
    fee_fn: Callable[[int, Decimal], Decimal]
    killed: bool = False
    paused: bool = False
    halts: tuple[str, ...] = ()
    unknown_orders: int = 0
    trading_active: bool | None = None
    clock_skew_s: float | None = None
    max_clock_skew_s: float = 2.0
    book_age_s: float | None = None
    stale_book_s: float = 6.0


@dataclass
class RiskResult:
    ok: bool
    reason: str
    quantity: int = 0
    max_loss: Decimal = ZERO
    budget: Decimal = ZERO


def equity_for_limits(limits: Limits, equity: Decimal) -> Decimal:
    return min(equity, limits.capital_cap_usd)


def daily_loss_breached(limits: Limits, equity: Decimal, daily_pnl: Decimal) -> bool:
    return daily_pnl <= -(limits.daily_loss_pct * equity_for_limits(limits, equity))


def evaluate(i: RiskInputs) -> RiskResult:
    L = i.limits
    if i.killed:
        return RiskResult(False, "kill switch on")
    if i.paused:
        return RiskResult(False, "paused")
    if i.halts:
        return RiskResult(False, f"halted: {', '.join(i.halts)}")
    if i.unknown_orders:
        return RiskResult(False, f"{i.unknown_orders} order(s) with unknown outcome: asking the exchange first")
    if i.trading_active is not True:
        return RiskResult(False, "exchange trading not confirmed active")
    if i.clock_skew_s is None:
        return RiskResult(False, "clock skew unknown")
    if abs(i.clock_skew_s) > i.max_clock_skew_s:
        return RiskResult(False, f"clock skew {i.clock_skew_s:+.2f}s exceeds {i.max_clock_skew_s}s")
    if i.book_age_s is None or i.book_age_s > i.stale_book_s:
        return RiskResult(False, f"stale book ({i.book_age_s}s)")
    if i.price <= ZERO:
        return RiskResult(False, "bad price")

    efl = equity_for_limits(L, i.equity)
    if efl <= ZERO:
        return RiskResult(False, "no equity")
    if daily_loss_breached(L, i.equity, i.daily_pnl):
        return RiskResult(False, f"daily loss limit reached ({i.daily_pnl})")
    if i.open_positions >= L.max_open_positions:
        return RiskResult(False, f"max open positions ({i.open_positions}/{L.max_open_positions})")

    budget = min(
        L.max_loss_per_position_usd,
        L.max_loss_per_position_pct * efl,
        L.max_total_exposure_pct * efl - i.exposure,
        i.available_cash,
    )
    if budget <= ZERO:
        return RiskResult(False, "no budget left (exposure or cash)", budget=budget)
    qty = int((budget / i.price).to_integral_value(rounding=ROUND_FLOOR))
    while qty >= 1:
        max_loss = qty * i.price + i.fee_fn(qty, i.price)
        if max_loss <= budget:
            return RiskResult(True, "ok", qty, max_loss, budget)
        qty -= 1
    return RiskResult(False, f"budget {budget:.2f} buys less than one contract at {i.price}", budget=budget)
