from favbot.scorecard import MIN_FOR_VERDICT, bets_to_know, scorecard, wilson


def bets(wins, losses, price=0.93, qty=4):
    win = {"won": True, "contracts": qty, "cost": qty * price, "pnl": qty * (1 - price)}
    loss = {"won": False, "contracts": qty, "cost": qty * price, "pnl": -qty * price}
    return [dict(win) for _ in range(wins)] + [dict(loss) for _ in range(losses)]


def test_wilson_brackets_the_rate():
    lo, hi = wilson(22, 22)
    assert 0.84 < lo < 0.86 and hi == 1.0
    lo, hi = wilson(93, 100)
    assert lo < 0.93 < hi


def test_break_even_is_average_price():
    s = scorecard(bets(10, 0, price=0.93))
    assert abs(s["breakeven"] - 0.93) < 1e-9


def test_perfect_start_is_still_early():
    s = scorecard(bets(22, 0))
    assert s["verdict"] == "early" and s["low"] < s["breakeven"]
    assert s["more_bets"] and s["more_bets"] > 0


def test_clearly_ahead_and_clearly_behind():
    assert scorecard(bets(990, 10))["verdict"] == "ahead"            # 99% vs 93% over 1000 bets
    assert scorecard(bets(80, 20))["verdict"] == "behind"            # 80% vs 93%
    assert scorecard(bets(93, 7))["verdict"] == "unclear"            # exactly break-even rate


def test_behind_shows_even_when_early():
    s = scorecard(bets(10, 10))
    assert s["n"] < MIN_FOR_VERDICT and s["verdict"] == "behind"


def test_mixed_sizes_cannot_look_ahead_while_losing():
    # 40 tiny $1 wins and 2 big $8 losses: 95% of bets won, but money was lost
    small = [{"won": True, "contracts": 1, "cost": 0.93, "pnl": 0.07} for _ in range(40)]
    big = [{"won": False, "contracts": 8, "cost": 7.44, "pnl": -7.44} for _ in range(2)]
    s = scorecard(small + big)
    assert s["net"] < 0 and s["verdict"] in ("behind", "unclear")
    assert s["win_rate"] < s["breakeven"]          # contract-weighted: 40/56 contracts won


def test_cushion_counts_losses_covered_by_profit():
    s = scorecard(bets(26, 0, price=0.93, qty=4))                    # profit 26*0.28 = 7.28, a loss = 3.72
    assert s["cushion_losses"] == round(7.28 / 3.72, 1)


def test_bets_to_know():
    assert bets_to_know(0.93, 0.93, 10) is None
    assert bets_to_know(1.0, 0.93, 22) > 22
