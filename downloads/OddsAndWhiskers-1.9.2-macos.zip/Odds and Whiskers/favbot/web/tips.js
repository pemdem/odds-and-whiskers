// ---- Hover tips: a short explanation on everything (Settings → General → Hover tips) ---------------
// Any element can carry its own data-tip. Buttons with a title get a styled tip instead of the browser's.
// Common labels get a tip from the glossary below, matched by how their text starts.
const TIP_IDS = {
  '#tabseg [data-tab=home]': 'Cat Corner: your home screen — balance, presets, the version picker and the cats.',
  '#tabseg [data-tab=stats]': 'Statistics: charts, the future, Backtrack and every trade.',
  '#tabseg [data-tab=litter]': 'Litter Box: fake-money models testing other ideas on live prices. No real money.',
  '#mode': 'Which money this bot uses: Live = real money, Demo = Kalshi’s test exchange, Paper = simulated.',
  '#conn': 'Whether this window can reach the bot right now.',
  '#pause': 'Pause: no new bids and waiting bids are cancelled. Bets that already filled still finish.',
  '#kill': 'Emergency stop: cancels waiting bids and blocks new ones until you undo it with unkill.',
  '#gear': 'Settings: look, sidekick, coins, alerts, limits and how the bot behaves.',
  '#editlayout': 'Move, resize or hide the sections on this screen.',
  '#pnlseg': 'The period for the profit number next to your balance.',
  '#s-pnlseg': 'The period for the profit number.',
  '#btdays': 'How many past days Backtrack replays.',
  '#btrun': 'Replay the strategy on Kalshi’s past prices. Read-only — it never places an order.',
  '#lbstart': 'Start the fake-money models. They keep running when the window is closed.',
  '#lbstop': 'Stop the fake-money models. Their results are kept.',
  '#lbreset': 'Archive the current results and start a new season with every model at $100.',
  '#lbchip': 'Whether the Litter Box models are running.',
  '#rangeseg': 'Which trades to list.',
  '#expandall': 'Open the details of every trade in the list.',
  '#collapseall': 'Close the details of every trade.',
  '#cat': 'Your sidekick. Click for a comment.',
  '#logo': 'Odds & Whiskers. Change the logo in Settings → General.',
  '#bar3': 'How your money is split right now.',
  '#equity': 'Cash plus what your open bets are worth right now.',
  '#s-equity': 'Cash plus what your open bets are worth right now.',
  '#today': 'Profit or loss over the period you picked.',
  '#clump': 'Clump slider: how much to risk. Changes bet size and limits — never which bets are taken.',
};
const GLOSSARY = [
  ['Total balance', 'Cash plus what your open bets are worth right now.'],
  ['Win rate', 'Share of settled bets that won (weighted by contracts).'],
  ['Record', 'Wins – losses of settled bets.'],
  ['Open bets', 'Bets that filled and are waiting for their 15-minute result.'],
  ['At risk now', 'The most you could lose on open bets and waiting bids right now.'],
  ['Fill rate', 'Share of bids sent that got filled.'],
  ['Cap', 'The most money the bot is allowed to use, whatever is in the account.'],
  ['Available cash', 'Money not tied up in bets or waiting bids.'],
  ['In bets', 'Open bets, valued at what they could be sold for right now.'],
  ['Held for waiting bids', 'Money reserved by bids that haven’t filled yet.'],
  ['Waiting bids', 'Money reserved by bids that haven’t filled yet.'],
  ['Profit so far', 'Total profit or loss of all settled bets.'],
  ['One loss costs about', 'A losing bet loses its whole price — about this much at your size.'],
  ['Profit covers', 'How many losses your profit so far could absorb.'],
  ['Your settings', 'Your current strategy replayed on the past days.'],
  ['Stress test', 'Same replay, but a bid only counts as filled if the price was still through it at the minute’s end. Stricter, still not proof.'],
  ['Buying at the ask instead', 'Same favourites, but buying at the asking price right away (pays a taker fee, no waiting).'],
  ['Picked-off gap', 'How much less often filled bids win than all favourites. Big = fills mostly happen just before the price turns.'],
  ['Models', 'How many fake-money models are running.'],
  ['Fake bets settled', 'Fake-money bets that have their result, across all models.'],
  ['Running since', 'When this Litter Box season started.'],
  ['Experiment set', 'The fixed line-up being tested. It doesn’t change while it runs.'],
  ['On fresh markets', 'Results on markets that happened after the idea was proposed — the honest test.'],
  ['Original, same period', 'The unchanged original strategy over exactly the same time.'],
  ['Biggest bankroll drop', 'The largest fall from a high point, in fake money.'],
  ['Real chance a bet wins', 'Best guess of the true win chance, mixing the market’s odds with your record.'],
  ['Likely range', 'Where the true win chance probably is (90% range).'],
  ['Needed to break even', 'The win rate where you’d make exactly $0, fees included.'],
  ['Most per bet', 'The most one bet can lose.'],
  ['Most at risk at once', 'The most money that can be in bets and waiting bids at the same time.'],
  ['Bets open at the same time', 'How many bets can wait for their result at once.'],
  ['Daily stop', 'If you lose this much in a day, the bot stops betting until tomorrow.'],
  ['Fake balance', 'The model’s fake money: $100 start plus its fake profit.'],
  ['Total staked', 'All the fake money this model has bet so far.'],
  ['Doing now', 'What the model is doing this moment.'],
  ['Profit', 'Profit or loss, fees included.'],
  ['Return per $', 'Profit per dollar bet. ± is the range luck alone could explain.'],
  ['Bets', 'Number of settled bets.'],
  ['W–L', 'Wins – losses.'],
  ['Backtrack', 'How the same settings did on past prices (an estimate).'],
  ['Balance', 'Fake-money balance over time.'],
  ['Older days', 'The older 70% of past contracts, where the settings were picked.'],
  ['Newer days', 'The newest 30% — the fair test, because nothing was picked on it.'],
  ['It made', 'Return per $ of the setting picked from earlier data, on the next period.'],
  ['Yours made', 'Return per $ of your settings over the same period.'],
  ['live', 'Your real bot uses this.'],
  ['fixed yardstick', 'Never changes, so every other model is compared with the same thing.'],
  ['being tested', 'The learning loop’s current idea, tested on fresh markets.'],
  ['testing', 'Still collecting fresh bets.'],
  ['won', 'This bet won.'], ['lost', 'This bet lost.'], ['open', 'Waiting for its result.'],
];
const SECTION_TIPS = {
  'sec-balance': 'Your money right now, and how it’s split.',
  'sec-preset': 'What the learning loop recommends, and the Clump slider for how much to risk.',
  'sec-score': 'Is the bot really making money, or could it be luck? Compares your win rate with break-even.',
  'sec-cats': 'Your three sidekicks read your bets and Backtrack, and tell you what they found.',
  'sec-profit': 'Running total of every settled bet.',
  'sec-each': 'Profit or loss of each settled bet.',
  'sec-future': 'A range of where your balance could be, from thousands of simulated futures. Not a promise.',
  'sec-backtrack': 'Replays the strategy on past prices to see what works — and what only looks like it.',
  'sec-now': 'Live prices for the contract closing next on each coin.',
  'sec-trades': 'Every trade. Click one for details.',
  'sec-bids': 'Every bid sent, including ones that never filled.',
  'sec-warn': 'Problems and notices from the bot.',
};

function applyTips() {
  for (const [sel, tip] of Object.entries(TIP_IDS)) document.querySelectorAll(sel).forEach(el => { if (!el.dataset.tip) el.dataset.tip = tip; });
  for (const [id, tip] of Object.entries(SECTION_TIPS)) { const h = document.querySelector(`#${id} h2`); if (h && !h.dataset.tip) h.dataset.tip = tip; }
  document.querySelectorAll('.tile>span:first-child, .kv>span:first-child, .lbrow.head>span, th, .pill, h4').forEach(el => {
    if (el.dataset.tip || el.querySelector('[data-tip]')) return;
    const t = el.textContent.trim(), hit = GLOSSARY.find(([k]) => t === k || t.startsWith(k + ' ') || t.startsWith(k + ':') || t.startsWith(k + ' ('));
    if (hit) el.dataset.tip = hit[1];
  });
}

// one floating bubble for the whole app
const tipBox = document.createElement('div');
tipBox.id = 'tipbox'; tipBox.setAttribute('role', 'tooltip');
document.body.appendChild(tipBox);
let tipEl = null, tipTimer = null;
function tipTarget(node) {
  let el = node && node.closest ? node.closest('[data-tip],[title]') : null;
  if (el && el.hasAttribute('title') && !el.dataset.tip && el.id !== 'cat') { el.dataset.tip = el.title; el.removeAttribute('title'); }
  else if (el && el.hasAttribute('title')) el.removeAttribute('title');
  return el && el.dataset.tip ? el : null;
}
function showTip(el) {
  if (prefs.tips === 'off' || !el || !document.body.contains(el)) return;
  tipBox.textContent = el.dataset.tip;
  tipBox.classList.add('on');
  const r = el.getBoundingClientRect(), b = tipBox.getBoundingClientRect();
  let x = r.left + r.width / 2 - b.width / 2, y = r.top - b.height - 8;
  if (y < 6) y = r.bottom + 8;
  x = Math.max(8, Math.min(innerWidth - b.width - 8, x));
  tipBox.style.left = x + 'px'; tipBox.style.top = y + 'px';
}
function hideTip() { clearTimeout(tipTimer); tipEl = null; tipBox.classList.remove('on'); }
document.addEventListener('mouseover', e => {
  const el = tipTarget(e.target);
  if (el === tipEl) return;
  hideTip(); if (!el) return;
  tipEl = el; tipTimer = setTimeout(() => showTip(el), 350);
});
document.addEventListener('focusin', e => { const el = tipTarget(e.target); if (el) { tipEl = el; tipTimer = setTimeout(() => showTip(el), 500); } });
document.addEventListener('focusout', hideTip);
document.addEventListener('scroll', hideTip, true);
document.addEventListener('mousedown', hideTip);
// touch: press and hold for a tip
let holdT = null;
document.addEventListener('touchstart', e => { const el = tipTarget(e.target); clearTimeout(holdT);
  if (el) holdT = setTimeout(() => { showTip(el); setTimeout(hideTip, 3500); }, 550); }, {passive: true});
document.addEventListener('touchend', () => clearTimeout(holdT), {passive: true});
