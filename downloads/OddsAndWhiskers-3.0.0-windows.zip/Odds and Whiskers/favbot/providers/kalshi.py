"""Kalshi REST adapter: signing, discovery and verification, order book, orders.

Facts used here (re-checked against docs.kalshi.com, October 2026):
- sign  timestamp_ms + METHOD + full path without query; RSA-PSS/SHA-256/salt=digest or Ed25519
- order book returns bids only (ascending, best last); asks are 1 - opposite bid
- orders are quoted on the YES leg (side bid/ask); crypto series live on exchange shard 2
- 429 has no Retry-After; GET /portfolio/orders/{id} can 404 briefly after creation
"""
from __future__ import annotations

import asyncio
import base64
import logging
import statistics
import re
import time
from collections import deque
from email.utils import parsedate_to_datetime
from urllib.parse import urlparse

import aiohttp
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from ..logutil import log
from ..models import (BalanceInfo, Book, Contract, ExchangeStatus, FillInfo, OrderAck, OrderInfo, OrderRequest,
                      PositionInfo, SeriesInfo, coin_of, parse_ts)
from ..money import PriceGrid, d, d_or_zero
from .base import (ApiError, NotFound, OrderOutcomeUnknown, RateLimited, ReadOnlyViolation, TransportError)

logger = logging.getLogger("favbot.kalshi")

UP_STRIKES = {"greater_or_equal", "greater"}
DOWN_STRIKES = {"less_or_equal", "less"}


class Signer:
    def __init__(self, key_id: str, private_key):
        if not isinstance(private_key, (rsa.RSAPrivateKey, Ed25519PrivateKey)):
            raise ValueError("unsupported private key type (need RSA or Ed25519)")
        self._key_id = key_id
        self._key = private_key

    def __repr__(self) -> str:
        return "Signer(<redacted>)"

    def sign(self, message: bytes) -> bytes:
        if isinstance(self._key, Ed25519PrivateKey):
            return self._key.sign(message)
        return self._key.sign(
            message,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.DIGEST_LENGTH),
            hashes.SHA256(),
        )

    def headers(self, method: str, full_path: str, ts_ms: int | None = None) -> dict:
        ts = str(ts_ms if ts_ms is not None else int(time.time() * 1000))
        path = full_path.split("?", 1)[0]
        sig = self.sign((ts + method.upper() + path).encode())
        return {
            "KALSHI-ACCESS-KEY": self._key_id,
            "KALSHI-ACCESS-TIMESTAMP": ts,
            "KALSHI-ACCESS-SIGNATURE": base64.b64encode(sig).decode(),
        }


class RateLimiter:
    """Token bucket shared by every engine in this process."""

    def __init__(self, rate_per_s: float, burst: float | None = None):
        self.rate = rate_per_s
        self.capacity = burst or max(1.0, rate_per_s)
        self.tokens = self.capacity
        self.updated = time.monotonic()
        self._lock = asyncio.Lock()
        self.penalty_until = 0.0

    async def acquire(self, cost: float = 1.0) -> None:
        """Wait for `cost` request-equivalents. Kalshi bills batch requests per item, so a 96-contract
        candlestick or order-book batch costs 96, not 1."""
        async with self._lock:
            while True:
                now = time.monotonic()
                if now < self.penalty_until:
                    await asyncio.sleep(self.penalty_until - now)
                    continue
                cap = max(self.capacity, cost)
                self.tokens = min(cap, self.tokens + (now - self.updated) * self.rate)
                self.updated = now
                if self.tokens >= cost:
                    self.tokens -= cost
                    return
                await asyncio.sleep((cost - self.tokens) / self.rate)

    def back_off(self, seconds: float) -> None:
        self.penalty_until = max(self.penalty_until, time.monotonic() + seconds)


class KalshiAPI:
    """Low-level HTTP client. With read_only=True any non-GET raises before I/O."""

    def __init__(self, base_url: str, *, signer: Signer | None = None, read_only: bool,
                 timeout_s: float = 10.0, requests_per_s: float = 8.0, on_network=None):
        self.base_url = base_url.rstrip("/")
        self.root_path = urlparse(self.base_url).path
        self.signer = signer
        self.read_only = read_only
        self.timeout = aiohttp.ClientTimeout(total=timeout_s)
        self.limiter = RateLimiter(requests_per_s, burst=requests_per_s * 2)
        self.on_network = on_network
        self._session: aiohttp.ClientSession | None = None
        self._skews: deque[float] = deque(maxlen=15)
        self.clock_skew_s: float | None = None
        self._429_streak = 0

    async def _sess(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(timeout=self.timeout, headers={"Accept": "application/json"})
        return self._session

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    def _note_date(self, hdr: str | None, t0: float, t1: float) -> None:
        if not hdr:
            return
        try:
            server = parsedate_to_datetime(hdr).timestamp() + 0.5  # Date has 1 s resolution
        except Exception:  # noqa: BLE001
            return
        self._skews.append((t0 + t1) / 2 - server)
        self.clock_skew_s = statistics.median(self._skews)

    async def request(self, method: str, path: str, *, params: dict | None = None, body: dict | None = None,
                      auth: bool = False, retries: int = 3, cost: float = 1.0):
        method = method.upper()
        if self.read_only and method != "GET":
            raise ReadOnlyViolation(f"{method} {path} refused: this client is read-only")
        if auth and self.signer is None:
            raise ApiError(401, "no credentials loaded for an authenticated endpoint")
        # lists become repeated parameters (tickers=A&tickers=B)
        params = [(k, x) for k, v in (params or {}).items() if v is not None for x in (v if isinstance(v, list) else [v])]
        attempt = 0
        while True:
            attempt += 1
            await self.limiter.acquire(cost)
            headers = self.signer.headers(method, self.root_path + path) if auth else {}
            if body is not None:
                headers["Content-Type"] = "application/json"
            sess = await self._sess()
            t0 = time.time()
            try:
                async with sess.request(method, self.base_url + path, params=params or None, json=body,
                                        headers=headers) as resp:
                    text = await resp.text()
                    t1 = time.time()
                    self._note_date(resp.headers.get("Date"), t0, t1)
                    status = resp.status
            except aiohttp.ClientConnectorError as e:
                self._net(False, f"connect: {e}")
                if method == "GET" and attempt <= retries:
                    await asyncio.sleep(min(8, 0.5 * 2 ** attempt))
                    continue
                raise TransportError(f"connect failed: {e}", maybe_sent=False) from None
            except (asyncio.TimeoutError, aiohttp.ClientError) as e:
                self._net(False, f"{type(e).__name__}: {e}")
                if method == "GET" and attempt <= retries:
                    await asyncio.sleep(min(8, 0.5 * 2 ** attempt))
                    continue
                raise TransportError(f"{type(e).__name__}: {e}", maybe_sent=True) from None
            self._net(True, "")

            if status == 429:
                self._429_streak += 1
                wait = min(10.0, 0.5 * 2 ** min(self._429_streak, 5))
                self.limiter.back_off(wait)
                log(logger, logging.WARNING, "rate limited (429), backing off", path=path, wait_s=wait)
                if method == "GET" and attempt <= retries + 2:
                    continue
                raise RateLimited(429, "too many requests")
            self._429_streak = 0
            if status >= 500:
                if method == "GET" and attempt <= retries:
                    await asyncio.sleep(min(8, 0.5 * 2 ** attempt))
                    continue
                raise ApiError(status, text[:300])
            if status == 404:
                raise NotFound(404, text[:300])
            if status >= 400:
                code, msg = "", text[:300]
                try:
                    import json
                    j = json.loads(text)
                    err = j.get("error", j)
                    if isinstance(err, dict):
                        code, msg = str(err.get("code", "")), str(err.get("message", msg))
                    elif isinstance(err, str):
                        msg = err
                except Exception:  # noqa: BLE001
                    pass
                raise ApiError(status, msg, code)
            if not text:
                return {}
            import json
            return json.loads(text)

    def _net(self, ok: bool, err: str) -> None:
        if self.on_network:
            try:
                self.on_network(ok, err)
            except Exception:  # noqa: BLE001
                pass

    # ---- public market data ---------------------------------------------------------------
    async def get_exchange_status(self, exchange_index: int = 2) -> ExchangeStatus:
        j = await self.request("GET", "/exchange/status")
        ex_active, tr_active = bool(j.get("exchange_active")), bool(j.get("trading_active"))
        for s in j.get("exchange_index_statuses") or []:
            if s.get("exchange_index") == exchange_index:
                ex_active, tr_active = bool(s.get("exchange_active")), bool(s.get("trading_active"))
        return ExchangeStatus(ex_active, ex_active and tr_active, time.time())

    async def get_series(self, series: str) -> SeriesInfo:
        s = (await self.request("GET", f"/series/{series}"))["series"]
        return SeriesInfo(s["ticker"], s.get("fee_type") or "", d(s.get("fee_multiplier", 1)),
                          int(s.get("exchange_index") if s.get("exchange_index") is not None else -1))

    async def list_markets(self, series: str, min_close_ts: int, max_close_ts: int) -> list[dict]:
        out, cursor = [], None
        for _ in range(10):
            j = await self.request("GET", "/markets", params={"series_ticker": series, "min_close_ts": min_close_ts,
                                                             "max_close_ts": max_close_ts, "limit": 200,
                                                             "cursor": cursor})
            out += j.get("markets") or []
            cursor = j.get("cursor")
            if not cursor:
                break
        return out

    async def get_market(self, ticker: str) -> dict:
        return (await self.request("GET", f"/markets/{ticker}"))["market"]

    async def get_orderbook(self, ticker: str) -> Book:
        j = await self.request("GET", f"/markets/{ticker}/orderbook")
        return Book.from_api(ticker, j, time.time())


def verify_market(m: dict, series: str, expected_exchange_index: int | None = None) -> tuple[Contract | None, str]:
    """Every check from the spec. Returns (contract, "ok") or (None, reason)."""
    t = m.get("ticker", "")
    if not t.startswith(series + "-"):
        return None, "ticker not in series"
    if m.get("market_type") != "binary":
        return None, f"market_type {m.get('market_type')}"
    o, c = parse_ts(m.get("open_time")), parse_ts(m.get("close_time"))
    if o is None or c is None or round(c - o) != 900:
        return None, "not a 900 s contract"
    if m.get("settlement_bounds_type") != "default":
        return None, f"settlement_bounds_type {m.get('settlement_bounds_type')}"
    st = m.get("strike_type")
    if st in UP_STRIKES:
        yes_is_up = True
    elif st in DOWN_STRIKES:
        yes_is_up = False
    elif st is None:
        return None, "strike_type not set yet"
    else:
        return None, f"unsupported strike_type {st}"
    rules = (m.get("rules_primary") or "") + " " + (m.get("rules_secondary") or "")
    low = rules.lower()
    # Kalshi says "sixty seconds of CF Benchmarks' ETHUSDRTI"; Polymarket US says "60 ETHUSD_RTI prices are collected"
    if "cf benchmarks" not in low or not ("sixty seconds" in low or "60 seconds" in low
                                         or re.search(r"\b60 [a-z_]*rti prices\b", low)):
        return None, "rule text no longer names a CF Benchmarks index and a sixty-second average"
    if m.get("status") != "active":
        return None, f"status {m.get('status')}"
    if expected_exchange_index is not None and m.get("exchange_index") is not None \
            and int(m["exchange_index"]) != expected_exchange_index:
        return None, f"exchange_index {m.get('exchange_index')} != {expected_exchange_index}"
    try:
        grid = PriceGrid.from_api(m.get("price_ranges"))
    except Exception:  # noqa: BLE001
        return None, "bad price_ranges"
    fs = m.get("floor_strike")
    return Contract(
        ticker=t, series=series, coin=coin_of(series), open_ts=o, close_ts=c, yes_is_up=yes_is_up,
        status=m["status"], floor_strike=d(fs) if fs is not None else None,
        exchange_index=m.get("exchange_index"), grid=grid, result=m.get("result") or "",
    ), "ok"


class KalshiTrading:
    """Trading interface on a real Kalshi exchange (demo or production)."""

    kind = "kalshi"

    def __init__(self, api: KalshiAPI, exchange_index: int):
        if api.read_only:
            raise ValueError("KalshiTrading needs a non-read-only client")
        self.api = api
        self.exchange_index = exchange_index

    async def create_order(self, req: OrderRequest) -> OrderAck:
        try:
            j = await self.api.request("POST", "/portfolio/events/orders", body=req.to_payload(), auth=True)
        except TransportError as e:
            if e.maybe_sent:
                raise OrderOutcomeUnknown(str(e)) from None
            raise ApiError(0, f"not sent: {e}") from None
        except ApiError as e:
            if e.status >= 500:
                raise OrderOutcomeUnknown(str(e)) from None
            raise
        return OrderAck(j["order_id"], j.get("client_order_id"), d_or_zero(j.get("fill_count")),
                        d_or_zero(j.get("remaining_count")))

    async def cancel_order(self, order_id: str, ticker: str) -> None:
        await self.api.request("DELETE", f"/portfolio/events/orders/{order_id}",
                               params={"market_ticker": ticker}, auth=True, retries=0)

    async def get_order(self, order_id: str) -> OrderInfo | None:
        try:
            j = await self.api.request("GET", f"/portfolio/orders/{order_id}", auth=True)
        except NotFound:
            return None
        return OrderInfo.from_api(j["order"])

    async def list_orders(self, *, ticker=None, status=None, min_ts=None) -> list[OrderInfo]:
        out, cursor = [], None
        for _ in range(20):
            j = await self.api.request("GET", "/portfolio/orders", auth=True, params={
                "ticker": ticker, "status": status, "min_ts": min_ts, "limit": 200, "cursor": cursor,
                "exchange_index": self.exchange_index})
            out += [OrderInfo.from_api(o) for o in j.get("orders") or []]
            cursor = j.get("cursor")
            if not cursor:
                break
        return out

    async def get_fills(self, *, order_id=None, ticker=None, min_ts=None) -> list[FillInfo]:
        out, cursor = [], None
        for _ in range(20):
            j = await self.api.request("GET", "/portfolio/fills", auth=True, params={
                "order_id": order_id, "ticker": ticker, "min_ts": min_ts, "limit": 200, "cursor": cursor})
            out += [FillInfo.from_api(f) for f in j.get("fills") or []]
            cursor = j.get("cursor")
            if not cursor:
                break
        return out

    async def get_positions(self) -> list[PositionInfo]:
        out, cursor = [], None
        for _ in range(20):
            j = await self.api.request("GET", "/portfolio/positions", auth=True, params={
                "count_filter": "position", "limit": 200, "cursor": cursor,
                "exchange_index": self.exchange_index})
            out += [PositionInfo.from_api(p) for p in j.get("market_positions") or []]
            cursor = j.get("cursor")
            if not cursor:
                break
        return out

    async def get_balance(self) -> BalanceInfo:
        j = await self.api.request("GET", "/portfolio/balance", auth=True,
                                   params={"exchange_index": self.exchange_index})
        return BalanceInfo.from_api(j)

    async def get_all_balances(self) -> dict:
        return await self.api.request("GET", "/portfolio/balance", auth=True)

    async def transfer_to_shard(self, amount_dollars, destination_shard: int, client_transfer_id: str,
                                source_shard: int = 0) -> dict:
        centicents = int((d(amount_dollars) * 10000).to_integral_value())
        return await self.api.request("POST", "/portfolio/intra_exchange_instance_transfer", auth=True, retries=0, body={
            "source": "event_contract", "destination": "event_contract",
            "source_exchange_shard": source_shard, "destination_exchange_shard": destination_shard,
            "amount": centicents, "client_transfer_id": client_transfer_id})

    def observe_book(self, book: Book, now: float) -> None:
        return None

    async def settle(self, ticker: str, result: str) -> None:
        return None  # the exchange settles real positions itself
