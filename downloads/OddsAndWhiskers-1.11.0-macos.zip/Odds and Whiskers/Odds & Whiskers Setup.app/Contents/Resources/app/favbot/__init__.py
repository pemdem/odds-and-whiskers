"""Kalshi 15-minute crypto 'favourite' bot."""
from pathlib import Path as _Path

try:
    __version__ = (_Path(__file__).with_name("VERSION")).read_text(encoding="utf-8").strip()
except OSError:
    __version__ = "0.0.0"
