"""'Is it working?' scorecard.

Each contract pays $1 if it wins, so the win rate needed to break even equals the average price paid per
contract (fees included). The scorecard compares your win rate with that, using a 95% Wilson interval
so a short lucky (or unlucky) streak is not mistaken for an edge.
"""
from __future__ import annotations

import math

Z = 1.96
MIN_FOR_VERDICT = 30


def wilson(wins: float, n: float, z: float = Z) -> tuple[float, float]:
    if n <= 0:
        return 0.0, 1.0
    p = wins / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return max(0.0, centre - half), min(1.0, centre + half)


def bets_to_know(p: float, breakeven: float, n: int, cap: int = 100_000) -> int | None:
    """If the win rate stays at p, how many settled bets until the 95% range clears break-even."""
    if p == breakeven:
        return None
    m = max(n, 1)
    while m <= cap:
        lo, hi = wilson(p * m, m)
        if (p > breakeven and lo > breakeven) or (p < breakeven and hi < breakeven):
            return m
        m = m + max(1, m // 10)
    return None


def scorecard(settled: list[dict], picked: dict | None = None) -> dict:
    """settled: [{"won": bool, "contracts": float, "cost": float, "pnl": float}] for settled filled bets."""
    n = len(settled)
    out = {"n": n, "ready": n > 0, "min_for_verdict": MIN_FOR_VERDICT, "picked": picked}
    if not n:
        out["verdict"] = "none"
        return out
    w = sum(1 for s in settled if s["won"])
    contracts = sum(s["contracts"] for s in settled) or 1
    cost = sum(s["cost"] for s in settled)
    net = sum(s["pnl"] for s in settled)
    losses_cost = [s["cost"] for s in settled]
    breakeven = cost / contracts
    # Win rate weighted by contracts, so it is comparable with break-even (price per contract) even when bet
    # sizes differ: a big losing bet counts for more than a small winning one. Bets are the independent units.
    p = sum(s["contracts"] for s in settled if s["won"]) / contracts
    lo, hi = wilson(p * n, n)
    roi = net / cost if cost else 0.0
    rets = [s["pnl"] / s["cost"] for s in settled if s["cost"]]
    sd = math.sqrt(sum((r - roi) ** 2 for r in rets) / max(1, len(rets) - 1)) if len(rets) > 1 else 0.0
    roi_se = sd / math.sqrt(len(rets)) if rets else 0.0
    if hi < breakeven or (n >= MIN_FOR_VERDICT and roi + 2 * roi_se < 0):
        verdict = "behind"
    elif n < MIN_FOR_VERDICT:
        verdict = "early"
    elif lo > breakeven and net > 0 and roi - 2 * roi_se > 0:
        verdict = "ahead"                       # never "ahead" while the money says otherwise
    else:
        verdict = "unclear"
    need = bets_to_know(p, breakeven, n)
    avg_cost = sum(losses_cost) / n
    out.update({
        "wins": w, "losses": n - w, "win_rate": p, "bet_win_rate": w / n, "low": lo, "high": hi, "breakeven": breakeven,
        "roi": roi, "roi_se": roi_se,
        "verdict": verdict, "bets_to_know": need, "more_bets": (max(0, need - n) if need else None),
        "net": round(net, 2), "avg_loss": round(avg_cost, 2),
        "cushion_losses": round(net / avg_cost, 1) if avg_cost else None,
        "return_on_cost": (net / cost) if cost else None,
    })
    return out
