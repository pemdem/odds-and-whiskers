# Odds & Whiskers (Kalshi 15-minute crypto) — formerly Better Bot

A bot for Kalshi's 15-minute crypto "price up or down" contracts. In the last five minutes of each
contract it places a resting, post-only limit buy at the favourite's best bid. Filled bids are held to
settlement.

**This bot has not been shown to be profitable.** Live results so far are a small sample and do not
prove an edge. The research below shows the prices are roughly fair. The only advantage being tested
is getting filled at the bid with no fee instead of paying the ask plus the taker fee.

## The strategy, exactly

For each 15-minute contract on each configured coin:

1. Ignore it until **300 s or less** remain before close. Place no new bids once **60 s or less** remain.
2. Read the order book. An outcome (UP or DOWN) is the **favourite** if its **best ask is in
   [0.88, 0.97]**. If both sides qualify (a thin book), skip.
3. Skip if the favourite's `ask - bid > 0.03` or if `bid >= ask`.
4. Place a **resting, post-only limit BUY at the favourite's best bid** (never at the ask). It expires
   after **20 s** and never rests into the final 60 s.
5. Re-evaluate every 2 s. **Cancel at once** if the strategy would no longer bid this outcome at this
   price or higher. After an unfilled bid ends, a fresh one may go out (at most 20 per contract).
6. Once any part fills, place nothing more on that contract and **hold to settlement**. There are no
   exits, stop-losses or take-profits.

There is no price model. The market's own price is the only signal.

**Sizing**

```
equity_for_limits = min(account_equity, capital_cap_usd)
budget   = min(max_loss_per_position_usd,
               max_loss_per_position_pct * equity_for_limits,
               max_total_exposure_pct * equity_for_limits - current_exposure,
               available_cash)
quantity = floor(budget / bid_price);  skip if < 1
max_loss = quantity * bid_price + maker_fee      # maker fee is 0 on these series
```

`current_exposure` is the cost of open positions, plus cash behind resting bids, plus the worst case
of any order sent but not yet confirmed.

**Fees.** These are read from `GET /series/{ticker}`:
taker `ceil_to_cent(0.07 × m × C × P × (1−P))`, maker `ceil_to_cent(0.0175 × m × C × P × (1−P))`, and the
maker fee applies only when `fee_type` includes maker fees. The crypto series are `quadratic` with
multiplier 1, so **resting fills pay no fee**. That is the whole reason the bot bids instead of taking.
An unrecognised `fee_type` disables that coin.

## Why it is built this way

The research used minute-by-minute bid/ask history: 2,848 settled Bitcoin contracts over 30 days, and
about 950 contracts for each of eight other coins over 10 days.

- Favourites priced 88–97 ¢ win about 92–94% of the time. The prices are fair.
- Buying at the ask and paying the taker fee returned about −1%.
- Getting filled at the bid with no fee returned between about −0.4% and +2% in the best case. On
  Bitcoin it was about −0.2%, because its bid-ask gap is only about 0.3 ¢, so there is nothing to save.
- No filter helped: not favourite stability, price trend, distance of spot from the strike, or a
  volatility model. Where a model disagreed with the market, the market was right.

So the bot **excludes Bitcoin**, trades the smaller coins, and bids rather than takes. The best case
assumes your bids fill as often as the price touches them. In practice the fills you get may be the
ones where the price is about to move against you (adverse selection). The report's "picked-off test"
measures exactly that.

## Markets

The bot scans `KXETH15M, KXSOL15M, KXXRP15M, KXDOGE15M, KXBNB15M, KXZEC15M, KXHYPE15M, KXNEAR15M`.
`KXBCH15M`, `KXADA15M` and `KXTON15M` are listed in the config, commented out, because they often have
no contracts. `KXBTC15M`, `KXCRYPTOLEAD15M` and `KXCRYPTOCOMP15M` are refused by the config validator.

Each contract is verified before it can be traded. It must be a binary market lasting 900 s with
`settlement_bounds_type == default` and status `active`, on the same exchange shard as its series. Its
rule text must still name CF Benchmarks and a sixty-second average. UP/DOWN comes from `strike_type`:
`greater[_or_equal]` means YES = UP and `less[_or_equal]` means YES = DOWN. Results come only from the
exchange (`result` once `status == finalized`).

## Install

Python 3.12+.

```bash
python -m venv .venv
```

```bash
.venv\Scripts\python -m pip install -r requirements.txt
```

(On macOS or Linux use `.venv/bin/python`.) Then copy the example files:

```bash
copy config.example.yaml config.yaml
```

```bash
copy .env.example .env
```

## Modes

| Mode | Orders | Money | Needs |
|---|---|---|---|
| `paper` (default) | simulated locally on real public prices; the HTTP client is read-only, so a non-GET raises before any I/O | none | nothing |
| `demo` | Kalshi demo exchange | demo money | `KALSHI_DEMO_API_KEY_ID`, `KALSHI_DEMO_PRIVATE_KEY_FILE`, `demo_limits` |
| `live` | Kalshi | **real money** | see "Going live" |

The paper simulator is deliberately pessimistic. It waits 400 ms before an order can match, and treats
the first book after that as the arrival book (a post-only bid that would cross is cancelled). It counts
only half of the displayed depth as real. A resting bid fills only when the best offer moves **strictly
through** its price, never when it just touches it. Positions settle only from the official result.
Paper results are still optimistic about queue position. Treat them as an upper bound.

## Commands

```bash
python -m favbot check --mode paper
```

```bash
python -m favbot run --mode paper
```

| Command | What it does |
|---|---|
| `run [--mode M] [--duration S] [--no-dashboard]` | start the bot; prints the dashboard URL |
| `check [--mode M]` | pre-flight: limits block, credentials, fee types, exchange open, verified contract, clock, shard balance, live ack |
| `status [--mode M]` | kill switch, halts, pending bids, open positions, recent warnings (offline) |
| `report [--mode M] [--json]` | net P&L, wins/losses, fees, fill rate, picked-off test, per-contract table |
| `kill [--mode M] [--reason R]` | persistent kill switch (database flag + `KILL` file) |
| `unkill [--mode M] [--halts]` | clear the kill switch (and, with `--halts`, reconciliation halts) |
| `ack-live` | typed live acknowledgement; must be run by you at a real terminal |
| `move-funds --mode live --amount N` | move N dollars from shard 0 to the crypto shard; asks you to type a confirmation |

**Dashboard.** It runs on `http://127.0.0.1:8787/?token=...` (the token is new each run and is also
written to `data/<mode>/dashboard_url.txt`). It shows mode, per-coin status and prices, balance,
exposure, positions, pending bids, history, settlements and errors, and has pause and kill buttons.

**Desktop app.** The **Odds & Whiskers** icon on the Desktop runs `app\BetterBot.ps1`. If the live bot isn't
running, it starts `app\supervisor.ps1` with no window. The supervisor runs the bot (which keeps the PC awake) and
restarts it 30 s after a crash. It does not restart it after **Settings → Turn off** (marker `data\live\STOPPED`),
or when the bot refuses to start (exit code 2, e.g. an expired acknowledgement). The launcher then opens the
dashboard as an Edge app window. The dashboard token is kept in `data\live\dashboard_token`, so an open window
reconnects after a restart. Closing the window does not stop the bot. Logs: `data\live\console.log`,
`data\live\supervisor.log`, `data\live\bot.log.jsonl`.

**Email alerts.** Set `alerts:` in `config.yaml` (Gmail: `smtp.gmail.com`, port 587, your address as username,
sender and recipient) and put a Gmail app password in `.env` as `FAVBOT_SMTP_PASSWORD`. Choose what you get in
Settings: losses, wins, a morning summary at a chosen hour, and problems. "Send a test email" checks the setup.

**Dashboard settings** (gear button) cover theme, time zone, refresh rate, which sections show, and switching
individual coins off or on (off only stops new bets on that coin). Limits are shown read-only and can only be
changed in `config.yaml` followed by `ack-live`. The **future** section shows a 7/30/60/90-day range from your
measured bets per day, the research's edge range (−0.4% to +2%), and a 90% luck band. It is not a forecast.

**Kill switch.** It blocks all orders and cancels resting bids. **It does not close filled positions.**
Those are held to settlement, because these contracts are not exited. Pausing does the same until you
resume.

## Safety rules implemented

- **Intents first.** Each order intent is written to SQLite before it is sent. `client_order_id` is
  unique. There is one live entry per contract (a partial unique index); an entry that ends with zero
  fill frees the slot. A filled entry keeps it for good.
- **Unknown outcomes.** A timeout or 5xx on create is "unknown". All new entries are blocked until the
  exchange has been asked. If the order isn't there after the 15 s read-after-write lag, it is resent
  at most once with the same `client_order_id`, and only if it is still wanted.
- **Read-after-write lag.** A 404 on `GET /portfolio/orders/{id}` right after creation is not treated as
  missing. The bot waits 15 s, then falls back to the order list.
- **Position cap.** Resting bids and unconfirmed orders count as open positions, so fills can never
  exceed `max_open_positions`. The cap is shared across all coins.
- **Reconciliation.** Orders, fills, balance and positions are reconciled at startup and every 10 s.
  If local fills and exchange positions disagree for two passes, the bot halts new bets and cancels
  resting ones until you clear it with `unkill --halts`.
- **Daily loss.** Daily loss is realized P&L since 00:00 UTC plus unrealized P&L, with open positions
  marked at the executable bid. At the limit the bot stops new bids and cancels resting ones.
- **Data checks.** Entries are rejected on a stale book (over 6 s), unknown or excessive clock skew
  (over 2 s, measured from the exchange's `Date` header), or when the shard reports trading inactive.
- **General.** Money is Decimal. Logs are JSON lines (`data/<mode>/bot.log.jsonl`) with secrets
  redacted. A lock file allows one process per data directory.
- **Secrets.** These come only from environment variables or `.env`, a key **file path**, or a
  secret-manager command. Never paste a key into chat, the config, or a log.

## Exchange shards

Kalshi holds balance **per shard**, and API orders do not move money between shards. The crypto series
are on shard 2. The bot reads `GET /portfolio/balance?exchange_index=2` and sizes against that. An order
placed with no funds there fails with "insufficient shard balance". Move funds yourself:

```bash
python -m favbot move-funds --mode live --amount 20
```

(This calls `POST /portfolio/intra_exchange_instance_transfer` with the amount in centicents. Only you
run it, and only after typing the confirmation.)

## Going live

Do these yourself, in this order. Nothing in this repository will do them for you.

1. Run `paper` for a while and read `report`.
2. Create a **demo** account at demo.kalshi.co and an API key there. Set `KALSHI_DEMO_API_KEY_ID` and
   `KALSHI_DEMO_PRIVATE_KEY_FILE`, run `check --mode demo`, then `run --mode demo`. Fix anything that
   breaks.
3. Set `KALSHI_API_KEY_ID` and `KALSHI_PRIVATE_KEY_FILE` for the live key (the file path, not its
   contents).
4. Write a `live_limits` block in `config.yaml`. There are no defaults. Start with the smallest size,
   for example:
   ```yaml
   live_limits:
     capital_cap_usd: "20"
     max_loss_per_position_usd: "1"     # one contract at a time
     max_loss_per_position_pct: "0.05"
     max_total_exposure_pct: "0.25"
     daily_loss_pct: "0.10"
     max_open_positions: 2
   ```
5. Set `mode: live` in `config.yaml`.
6. Move funds to shard 2: `python -m favbot move-funds --mode live --amount 20`.
7. Run `python -m favbot check --mode live`.
8. Run `python -m favbot ack-live` and type the phrase. It is tied to these exact limits and this key,
   and expires in 30 days.
9. Run `python -m favbot run --mode live`.

Changing any live limit or the key invalidates the acknowledgement.

## Layout

```
favbot/
  providers/base.py     interfaces (MarketData, Trading) and errors
  providers/kalshi.py   signing, discovery + verification, order book, orders, shard transfer
  providers/paper.py    simulator implementing the Trading interface
  strategy/favourite.py the rule above
  risk.py               every limit in one function
  execution.py          intents, idempotency, unknown outcomes, reconciliation
  portfolio.py          shared account cache (2 s) and exposure / daily P&L
  store.py              SQLite
  engine.py             one Engine per coin inside one Bot
  dashboard.py, alerts.py, report.py, liveguard.py, cli.py
tests/                  pytest suite
```

Run the tests with `python -m pytest -q`.

## Learning loop, presets and the Clump slider

Learning here means doing better on **new** markets after fees and realistic fills, not repeatedly picking whichever
settings looked best in the past. The loop (`favbot/lab.py`) runs every few minutes inside the app:

1. **Propose:** the nightly Backtrack picks the best configuration **and coins** on all past data. The walk-forward
   test repeats that choice (settings *and* coins) using only earlier periods, so the coin choice is tested too.
2. **Freeze:** it becomes the Litter Box *candidate* and does not change while it is being tested.
3. **Test on fresh markets:** only bets on markets after the proposal count, next to the unchanged **Original**
   strategy (all coins) over the same period (paper fills, taker fees included).
4. **Conclude:** once **both** the candidate and the Original have 300 fresh bets and 3 days have passed it
   **graduates** only if it beats the Original by more than luck *and* makes money on its own; otherwise it is
   **rejected** and never proposed again (same strategy and coins). If either side is still short after 21 days the
   result is **inconclusive** — 400 bets against 1 proves nothing. Results are kept in `data/lab/history.json`.

Litter Box **Season 3** is a fixed set of experiments: single coins, coin groups, entry style and timing, plus the
**Original** as a fixed yardstick. Every model is built on the original strategy written out in `litterbox.py`
(`ORIGINAL_STRATEGY`, `ORIGINAL_COINS`), never on `config.yaml`, so switching your real bot doesn't move the yardstick.
Each model folder is marked with its season; folders from an older season are moved to `data/litterbox/_old/`.
The small **Clump slider on each model** adds a fake-money copy of that model at another risk level (same strategy
and coins, different stake/limits; at most 12, kept in `data/litterbox/variants.json`). Original · Tiny and
Original · Chonky run by default. It only changes when you press Reset or move a slider.

**Backtrack fills:** the real bid lives 20 seconds and minute data can't show whether a cross happened inside them,
so every resting-bid fill in Backtrack is marked *uncertain* (even when the price was still through at the minute's
end — that stricter count is shown only as a stress test). A waiting-at-the-bid setting is never rated "strong" from
Backtrack alone. **Forecasts** use the cost of a contract *including fees*: a 93¢ contract with a 1¢ fee makes 6¢ on a
win and needs 94% wins to break even.

**Pick a version** (Cat Corner) lets you combine a model, coins and a Clump level. Model rows show results for the
coins you picked; coin chips show results for the model you picked (fake money on live markets, and past data).

**Recommended preset** (Cat Corner) shows the graduated configuration, with its fresh-market results and biggest
bankroll drop, or *Not enough evidence yet*. **Apply** writes the strategy to `config.yaml`; it is used after a restart.
The **Clump slider** changes only stake, total exposure and how many bets can be open at once, never which bets are
taken. For real money, new limits are saved as `live_limits_pending` and only become live after you confirm them by
double-clicking **Confirm new limits** (runs `ack-live`). Every change keeps a `config.backup-*.yaml`.

## Sharing, downloads and updates (one app, separate accounts)

The person who shares is the **publisher**; everyone else runs their own copy with **their own** Kalshi key, money,
limits, settings, layouts, trade history, Litter Box results and strategy recommendations — all kept on their own
computer. Only the app's code is shared. Recommendations are learned from each person's own results; nothing about
anyone's account or bets is shared (there is no shared-learning feature).

**Website: https://pemdem.github.io/odds-and-whiskers/** (GitHub Pages, repository `pemdem/odds-and-whiskers`). It has
direct downloads for both platforms, the setup tutorial, the update history, and the update feed
(`updates/latest.json` + the signed `BetterBot-<version>.zip`). Copies whose code has `favbot/update_feed.txt` check it
twice an hour in the background (`release.fetch_feed`) and keep the download in `data/web_updates/`; it is offered only
if its signature matches. The website is only a delivery route, so a changed website can't push unsigned code.
Each update: `favbot release publish`, then `python website\build_site.py` (builds `website/site/`) and
`python website\deploy_site.py` (commits and pushes it; needs `gh auth login` once).

**Easy setup (1.11).** The macOS download is one `Odds & Whiskers Setup.app` (built by `release.setup_app_files`
from `app/setup_mac.sh`): it copies the app to `~/Library/Application Support/Odds and Whiskers`, downloads its own
CPython 3.12 from python-build-standalone (`app/python_mac.txt`, refused unless the SHA-256 matches), installs the parts
and makes `Odds & Whiskers.app` in Applications and on the Desktop — clicks only, after the one-time "Open Anyway".
New copies open a welcome wizard (`web/onboard.js`): connect the Kalshi key, move money, go live — each money step
needs the same typed phrase as the terminal helpers (`/api/kalshi/*`, `/api/golive`). A key connected in the app is
stored by `favbot/vault.py`: AES-256-GCM in `data/vault/kalshi-live.vault`, unlocked by a random key kept in the macOS
Keychain / Windows Credential Manager (`keyring`). A key file named in `.env` always takes priority.

**Fresh downloads (starter packages).** Each release also builds `OddsAndWhiskers-<version>-windows.zip` and
`OddsAndWhiskers-<version>-macos.zip`: the app's code, example settings and a *START HERE* guide for that platform.
They are **starter packages, not self-contained apps**: they need Python 3.12, 3.13 or 3.14 (3.15 isn't supported yet; the installer checks and opens the
download page if it's missing) and install their parts from the internet on first run. They are not code-signed, so
Windows SmartScreen ("More info → Run anyway") or macOS Gatekeeper (right-click → Open) asks once.
Windows is tested end to end (install, launch, update). The macOS scripts (`app/install_mac.sh`, `app/launch_mac.sh`,
`app/supervisor_mac.sh` and the `.command` helpers) mirror the Windows ones but have not yet been run on a Mac.

- Publisher, once: `favbot release init` creates a signing key in `%APPDATA%\BetterBot\` (never in this folder, never in
  a zip or restore point) and writes its public half into `favbot/release_pubkey.txt`.
- Publisher, each update: add the version to `favbot/CHANGELOG.json`, bump `favbot/VERSION`, then
  `favbot release publish`. It signs `BetterBot-<version>.zip` (the update feed; the old name stays so copies from
  before the rename keep finding it), builds the two starter packages and puts all of it in the shared OneDrive folder
  **Better Bot updates** (keeps the last 3 updates). A release can never contain `config.yaml`, `.env`, `keys/`,
  `data/`, `versions/` or personal `.bat` files, and publishing refuses anything that looks like a private key or
  contains your Kalshi key id.
- Share that OneDrive folder (right-click → Share, *Can view*). The friend adds it to his OneDrive ("Add shortcut to My
  files"), unzips the package for his computer and runs **Install Odds and Whiskers** (.bat on Windows, .command on a
  Mac): it sets up the Python parts, `config.yaml` (practice/paper mode), `.env` and the Desktop icon. Real money later:
  **Set up my Kalshi key**, **Move money to crypto** if needed, then **Go live** — he picks his own cap and Clump level
  and types the confirmation himself.
- Both Windows and Mac copies check the same folder (Windows: the OneDrive environment variables; Mac:
  `~/Library/CloudStorage/OneDrive-*` or `~/OneDrive`) every 2 minutes. A newer version shows **Update available →
  Install update**; the signature must match the publisher's key and every file must match its fingerprint.

**Installing an update while trading** (`Dashboard.install_update`): new bets pause and the engines cancel any waiting
bid (filled bets are not touched) → the trade history (SQLite snapshot), `config.yaml` and the live confirmation are
copied to `data/backups/` (last 5 kept) → a restore point is saved and only code files are replaced (this platform's
helpers only) → the bot restarts, and at startup reconciles every order with Kalshi before it bets again. If the
install fails, nothing changes and trading resumes. A plain **Restart now** also backs up the data first.

**What's new / update history.** `favbot/CHANGELOG.json` lists every version (date, title, added, fixed). After a new
version is installed the app shows a *What's new* popup once (remembered in that person's own database, so it doesn't
come back on every open). **Settings → Updates** shows the installed version, update status and the full history.
`favbot release status` shows what a copy sees; `favbot release install` installs from a terminal.

## Everyday behaviour

| When… | What happens |
|---|---|
| You close the app window | The bot keeps running. |
| You press **Restart now** | Back in about 5 s; a waiting bid is cancelled, filled bets are safe. |
| The bot crashes | The background helper restarts it after 30 s; it re-checks everything with Kalshi. |
| The internet drops | A banner shows it; no new bets; it retries by itself. Filled bets settle on Kalshi anyway. |
| You press **Turn off** | The bot and the Litter Box stop until you click the Odds & Whiskers icon (Litter Box comes back too). |
| The 30-day confirmation expires | The bot refuses to start and the icon tells you why. |

Background helpers (Backtrack, Litter Box) have small, fixed shares of Kalshi's request budget, with batch requests
counted per item, so they can't crowd out the live bot.
