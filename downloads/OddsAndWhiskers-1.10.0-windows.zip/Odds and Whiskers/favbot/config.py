"""Configuration (YAML -> pydantic) and secrets loading.

Secrets come only from environment variables, a key file, or a secret-manager command.
They are never printed and never written to the database or logs.
"""
from __future__ import annotations

import hashlib
import json
import os
import shlex
import subprocess
from decimal import Decimal
from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator

MODES = ("paper", "demo", "live")
PROD_URL = "https://external-api.kalshi.com/trade-api/v2"
DEMO_URL = "https://external-api.demo.kalshi.co/trade-api/v2"

DEFAULT_SERIES = ["KXETH15M", "KXSOL15M", "KXXRP15M", "KXDOGE15M", "KXBNB15M",
                  "KXZEC15M", "KXHYPE15M", "KXNEAR15M"]
OPTIONAL_SERIES = ["KXBCH15M", "KXADA15M", "KXTON15M"]
FORBIDDEN_SERIES = {"KXBTC15M", "KXCRYPTOLEAD15M", "KXCRYPTOCOMP15M"}


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Limits(Strict):
    """Every field is required. There are deliberately no defaults."""

    capital_cap_usd: Decimal = Field(gt=0)
    max_loss_per_position_usd: Decimal = Field(gt=0)
    max_loss_per_position_pct: Decimal = Field(gt=0, le=1)
    max_total_exposure_pct: Decimal = Field(gt=0, le=1)
    daily_loss_pct: Decimal = Field(gt=0, le=1)
    max_open_positions: int = Field(ge=1)

    def fingerprint(self) -> str:
        blob = json.dumps({k: str(v) for k, v in self.model_dump().items()}, sort_keys=True)
        return hashlib.sha256(blob.encode()).hexdigest()


class StrategyCfg(Strict):
    window_start_s: int = 300
    window_end_s: int = 60
    ask_min: Decimal = Decimal("0.88")
    ask_max: Decimal = Decimal("0.97")
    max_spread: Decimal = Decimal("0.03")
    order_ttl_s: int = 20
    poll_s: float = 2.0
    max_bids_per_contract: int = 20
    entry: Literal["bid", "ask"] = "bid"          # bid = rest post-only at the best bid; ask = buy at the ask (taker)
    side: Literal["both", "up", "down"] = "both"


class TimingCfg(Strict):
    metadata_refresh_s: float = 15.0
    reconcile_s: float = 10.0
    stale_book_s: float = 6.0
    max_clock_skew_s: float = 2.0
    account_cache_s: float = 2.0
    requests_per_s: float = 8.0
    http_timeout_s: float = 10.0


class PaperCfg(Strict):
    starting_cash_usd: Decimal = Decimal("1000")
    latency_ms: int = 400
    depth_fraction: Decimal = Decimal("0.5")


class DashboardCfg(Strict):
    enabled: bool = True
    port: int = 8787


class AlertsCfg(Strict):
    enabled: bool = False
    smtp_host: str = ""
    smtp_port: int = 587
    starttls: bool = True
    username: str = ""
    password_env: str = "FAVBOT_SMTP_PASSWORD"
    sender: str = ""
    recipients: list[str] = []
    result_coins: list[str] = []          # e.g. ["ETH", "SOL"]: win/loss emails only for these
    error_min_interval_s: int = 600


class Config(Strict):
    mode: Literal["paper", "demo", "live"] = "paper"
    data_dir: str = "data"
    series: list[str] = Field(default_factory=lambda: list(DEFAULT_SERIES))
    strategy: StrategyCfg = StrategyCfg()
    timing: TimingCfg = TimingCfg()
    paper: PaperCfg = PaperCfg()
    paper_limits: Limits | None = None
    demo_limits: Limits | None = None
    live_limits: Limits | None = None
    live_limits_pending: Limits | None = None      # chosen in the app; becomes live only after ack-live
    dashboard: DashboardCfg = DashboardCfg()
    alerts: AlertsCfg = AlertsCfg()
    log_level: str = "INFO"

    # set by load_config
    base_dir: str = "."
    config_path: str = ""

    @field_validator("series")
    @classmethod
    def _no_btc(cls, v: list[str]) -> list[str]:
        bad = [s for s in v if s.upper() in FORBIDDEN_SERIES]
        if bad:
            raise ValueError(f"series not allowed by the strategy: {bad}")
        return [s.upper() for s in v]

    def limits_for(self, mode: str) -> Limits | None:
        return {"paper": self.paper_limits, "demo": self.demo_limits, "live": self.live_limits}[mode]

    def data_path(self, mode: str) -> Path:
        p = Path(self.data_dir)
        if not p.is_absolute():
            p = Path(self.base_dir) / p
        return p / mode


def load_config(path: str | os.PathLike) -> Config:
    path = Path(path)
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    raw["base_dir"] = str(path.resolve().parent)
    raw["config_path"] = str(path.resolve())
    return Config.model_validate(raw)


def load_dotenv(path: Path) -> None:
    """Minimal .env reader. Existing environment variables win."""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k, v = k.strip(), v.strip().strip('"').strip("'")
        if k and k not in os.environ:
            os.environ[k] = v


class CredentialError(RuntimeError):
    pass


class Credentials:
    """Holds the key id and the parsed private key. repr never shows either."""

    def __init__(self, key_id: str, private_key):
        self.key_id = key_id
        self.private_key = private_key

    def __repr__(self) -> str:
        return "Credentials(<redacted>)"

    def key_fingerprint(self) -> str:
        return hashlib.sha256(self.key_id.encode()).hexdigest()[:12]


def load_credentials(mode: str, base_dir: str = ".") -> Credentials:
    """Live uses KALSHI_*; demo uses KALSHI_DEMO_*. They are never mixed."""
    from cryptography.hazmat.primitives import serialization

    if mode not in ("demo", "live"):
        raise CredentialError("paper mode uses no credentials")
    prefix = "KALSHI_DEMO_" if mode == "demo" else "KALSHI_"
    key_id = os.environ.get(prefix + "API_KEY_ID", "").strip()
    key_file = os.environ.get(prefix + "PRIVATE_KEY_FILE", "").strip()
    key_cmd = os.environ.get(prefix + "PRIVATE_KEY_COMMAND", "").strip()
    if not key_id:
        raise CredentialError(f"{prefix}API_KEY_ID is not set")
    if key_file:
        p = Path(key_file).expanduser()
        if not p.is_absolute():
            p = Path(base_dir) / p
        if not p.exists():
            raise CredentialError(f"{prefix}PRIVATE_KEY_FILE points to a file that does not exist")
        pem = p.read_bytes()
    elif key_cmd:
        try:
            pem = subprocess.run(shlex.split(key_cmd, posix=os.name != "nt"), capture_output=True,
                                 check=True, timeout=30).stdout
        except Exception as e:  # noqa: BLE001 - message only, never output
            raise CredentialError(f"{prefix}PRIVATE_KEY_COMMAND failed: {type(e).__name__}") from None
    else:
        raise CredentialError(f"set {prefix}PRIVATE_KEY_FILE (a path to the PEM file) or {prefix}PRIVATE_KEY_COMMAND")
    try:
        key = serialization.load_pem_private_key(pem, password=None)
    except Exception as e:  # noqa: BLE001
        raise CredentialError(f"private key could not be parsed ({type(e).__name__})") from None
    return Credentials(key_id, key)
