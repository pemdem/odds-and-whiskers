import favbot.versions as V


def setup_root(tmp_path, monkeypatch):
    (tmp_path / "favbot").mkdir()
    (tmp_path / "favbot" / "a.py").write_text("v1")
    (tmp_path / "config.yaml").write_text("live_limits: secret-ish")
    (tmp_path / ".env").write_text("KEY=1")
    (tmp_path / "data").mkdir()
    (tmp_path / "data" / "x.sqlite3").write_text("trades")
    monkeypatch.setattr(V, "ROOT", tmp_path)
    monkeypatch.setattr(V, "STORE", tmp_path / "versions")
    return tmp_path


def test_save_excludes_settings_keys_and_data(tmp_path, monkeypatch):
    root = setup_root(tmp_path, monkeypatch)
    p = V.save("baseline")
    saved = {f.relative_to(root / "versions" / p["dir"]).as_posix() for f in (root / "versions" / p["dir"]).rglob("*") if f.is_file()}
    assert saved == {"favbot/a.py", "manifest.json"}


def test_restore_round_trip_and_undo(tmp_path, monkeypatch):
    root = setup_root(tmp_path, monkeypatch)
    V.save("baseline")                                     # #1
    (root / "favbot" / "a.py").write_text("v2-broken")
    (root / "favbot" / "new.py").write_text("added by the update")
    h_broken = V.code_hash()
    r = V.restore(1)                                       # saves #2 first
    assert (root / "favbot" / "a.py").read_text() == "v1"
    assert not (root / "favbot" / "new.py").exists()
    assert (root / "config.yaml").read_text() == "live_limits: secret-ish"   # settings untouched
    assert (root / "data" / "x.sqlite3").exists() and (root / ".env").exists()
    assert r["saved_current_as"]["number"] == 2
    V.restore(2)                                           # undo the restore
    assert (root / "favbot" / "a.py").read_text() == "v2-broken" and V.code_hash() == h_broken
    assert [p["number"] for p in V.list_points()] == [1, 2, 3]
