// ---- settings -------------------------------------------------------------------------
let timer;
function restartTimer() { clearInterval(timer); timer = setInterval(load, (+prefs.refresh || 2) * 1000); }
function applyPrefs() {
  if (prefs.theme === 'auto') document.documentElement.removeAttribute('data-theme');
  else document.documentElement.setAttribute('data-theme', prefs.theme);
  applyLayout();
  document.body.dataset.width = prefs.width || 'wide';
  // text size scales the whole app (charts, cats and dialogs too) so nothing gets out of proportion
  const z = {S: 0.9, M: 1, L: 1.12, XL: 1.25}[prefs.textSize] || 1;
  if (document.body.style.zoom !== String(z)) { document.body.style.zoom = z; if (typeof lastSeries !== 'undefined') lastSeries = ''; }
  if (prefs.view === 'full' || !prefs.view) prefs.view = 'classic';          // older names
  if (prefs.tab === 'live' || !prefs.tab) prefs.tab = 'home';
  if (prefs.view === 'classic' && prefs.tab === 'stats') prefs.tab = 'home';  // Classic already includes the statistics
  document.body.classList.toggle('tab-litter', prefs.tab === 'litter');
  document.body.classList.toggle('tab-stats', prefs.tab === 'stats');
  document.body.classList.toggle('tab-home', prefs.tab === 'home');
  document.body.classList.toggle('classic', prefs.view === 'classic');
  document.querySelectorAll('#tabseg button').forEach(b => b.classList.toggle('on', b.dataset.tab === prefs.tab));
  lastLogo = ''; applyLogo();
  document.body.classList.toggle('simple', prefs.view === 'simple' && prefs.tab === 'home');
  document.querySelectorAll('#viewseg button').forEach(b => b.classList.toggle('on', b.dataset.view === prefs.view));
  applyLayout();
  document.querySelectorAll('.seg[data-pref]').forEach(seg => seg.querySelectorAll('button').forEach(b =>
    b.classList.toggle('on', String(prefs[seg.dataset.pref]) === b.dataset.v)));
  renderCat();
  applyTradesCollapsed();
  lastSeries = ''; lastTrades = ''; restartTimer();
}
document.querySelectorAll('.seg[data-pref] button').forEach(b => b.onclick = () => {
  prefs[b.parentElement.dataset.pref] = b.dataset.v; savePrefs(); applyPrefs(); load(); });
const LIMIT_NAMES = {capital_cap_usd: ['Money the bot may use', v => '$' + v], max_loss_per_position_usd: ['Most per bet', v => '$' + v],
  max_loss_per_position_pct: ['Most per bet (% of money)', v => Math.round(v * 100) + '%'],
  max_total_exposure_pct: ['Most at risk at once', v => Math.round(v * 100) + '%'],
  daily_loss_pct: ['Stop for the day after losing', v => Math.round(v * 100) + '%'], max_open_positions: ['Most bets open at once', v => v]};
function renderCoinToggles() {
  const s = window._state; if (!s) return;
  if (!document.activeElement || !document.activeElement.dataset.coin)
    $('cointoggles').innerHTML = s.coins.map(c => `<label class="opt"><span>${esc(c.coin)}</span><span class="sw">` +
      `<input type="checkbox" data-coin="${esc(c.coin)}" ${c.on ? 'checked' : ''}><span></span></span></label>`).join('');
  $('limits').innerHTML = Object.entries(s.limits).map(([k, v]) => { const n = LIMIT_NAMES[k] || [k, x => x];
    return `<div class="kv"><span>${n[0]}</span><span>${n[1](v)}</span></div>`; }).join('');
  renderAlertSettings(s.alerts || {});
  const v = s.version || {}, lp = v.latest_point, rel = s.release || {};
  $('versioninfo').innerHTML = `<b>Odds & Whiskers ${esc(rel.installed || '')}</b>` +
    (rel.publisher ? ' · this PC publishes updates for friends' : rel.folders && rel.folders.length
      ? ` · updates come from ${esc(rel.folders[0])}` : ' · no shared updates folder found') +
    ((rel.rejected || []).length ? `<br><span class="neg">An update file failed the safety check and was ignored.</span>` : '') + '<br>' +
    (lp ?`Latest restore point: <b>#${lp.number}</b> — ${esc(lp.label)} (${esc(lp.saved_at)}).<br>` : '') +
    (v.update_ready ? '<span class="pos">An update is installed and waiting for a restart.</span>' : 'Running the latest installed code.') +
    '<br>Ask Claude to undo an update at any time; every update can be rolled back.';
}

const ALERT_KINDS = [['losses', 'When a bet loses'], ['wins', 'When a bet wins'], ['summary', 'Morning summary'],
  ['problems', 'Problems (bot stopped, errors, loss limit)']];
function renderAlertSettings(a) {
  const p = a.prefs || {};
  $('alertstatus').innerHTML = a.configured
    ? `Sending to <b>${esc((a.recipients || []).join(', '))}</b>.` + (a.has_password ? '' : ' <span class="neg">The email password is missing from .env.</span>')
    : 'Not set up yet. Ask Claude to walk you through it (about 5 minutes with a Gmail app password).';
  if (!document.activeElement || !document.activeElement.dataset.alert)
    $('alerttoggles').innerHTML = ALERT_KINDS.map(([k, label]) => `<label class="opt"><span>${label}</span><span class="sw">` +
      `<input type="checkbox" data-alert="${k}" ${p[k] ? 'checked' : ''} ${a.configured ? '' : 'disabled'}><span></span></span></label>`).join('');
  document.querySelectorAll('#hourseg button').forEach(b => { b.classList.toggle('on', +b.dataset.h === +p.summary_hour); b.disabled = !a.configured; });
  $('testmail').disabled = !a.configured;
}
async function postJSON(path, body) {
  const r = await fetch(path, {method: 'POST', headers: {...H, 'Content-Type': 'application/json'}, body: JSON.stringify(body)});
  if (!r.ok) throw new Error(await r.text()); return r.json();
}
$('alerttoggles').onchange = async e => { const k = e.target.dataset.alert;
  try { await postJSON('/api/alert_prefs', {[k]: e.target.checked}); } catch (err) { alert(err.message); e.target.checked = !e.target.checked; }
  e.target.blur(); load(); };
document.querySelectorAll('#hourseg button').forEach(b => b.onclick = async () => {
  try { await postJSON('/api/alert_prefs', {summary_hour: +b.dataset.h}); } catch (err) { alert(err.message); } load(); });
$('testmail').onclick = async () => {
  $('testmsg').textContent = 'Sending…'; $('testmsg').className = 'msg mut';
  try { const r = await postJSON('/api/alert_test', {});
    $('testmsg').textContent = r.ok ? 'Sent. Check your inbox.' : 'Failed: ' + r.error; $('testmsg').className = 'msg ' + (r.ok ? 'pos' : 'neg');
  } catch (err) { $('testmsg').textContent = 'Failed: ' + err.message; $('testmsg').className = 'msg neg'; }
};
$('turnoff').onclick = async () => {
  if (!confirm('Turn the bot off?\n\nWaiting bids are cancelled. Bets that already filled still finish at their 15-minute result.\n\nStart it again with the Odds & Whiskers icon on your Desktop.')) return;
  try { await postJSON('/api/shutdown', {}); } catch (err) { alert(err.message); return; }
  closeSettings();
  $('banners').innerHTML = '<div class="banner warn">Turning off…</div>';
};
$('cointoggles').onchange = async e => {
  const coin = e.target.dataset.coin, on = e.target.checked;
  const r = await fetch('/api/coin', {method: 'POST', headers: {...H, 'Content-Type': 'application/json'}, body: JSON.stringify({coin, on})});
  if (!r.ok) { alert(await r.text()); e.target.checked = !on; }
  e.target.blur(); load();
};
function showPane(name) {
  if (!document.querySelector(`.pane[data-pane="${name}"]`)) name = 'general';
  prefs.pane = name; savePrefs();
  document.querySelectorAll('#setnav button').forEach(b => b.classList.toggle('on', b.dataset.pane === name));
  document.querySelectorAll('.pane').forEach(p => p.classList.toggle('on', p.dataset.pane === name));
  if (name === 'sidekick') renderCatPick();
  if (name === 'page') renderPageSettings();
}
$('setnav').onclick = e => { const b = e.target.closest('button'); if (b) showPane(b.dataset.pane); };
const openSettings = () => { renderCoinToggles(); showPane(prefs.pane || 'general'); $('scrim').classList.add('open'); $('done').focus(); };
const closeSettings = () => { $('scrim').classList.remove('open'); $('gear').focus(); };
$('gear').onclick = openSettings; $('done').onclick = closeSettings;
$('scrim').onclick = e => { if (e.target === $('scrim')) closeSettings(); };
addEventListener('keydown', e => { if (e.key === 'Escape' && $('scrim').classList.contains('open')) closeSettings(); });

applyPrefs(); load();
let rt; addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => { lastSeries = ''; load(); }, 200); });
