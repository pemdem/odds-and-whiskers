"""Shared account view: cached balance/positions and the numbers the risk check needs."""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from decimal import Decimal

from .models import Book
from .money import ZERO, d, d_or_zero


class AccountCache:
    """One balance/positions/resting-orders request shared by all engines for `ttl` seconds."""

    def __init__(self, trading, ttl: float = 2.0, clock=time.time):
        self.trading = trading
        self.ttl = ttl
        self.clock = clock
        self._cache: dict[str, tuple[float, object]] = {}
        self._locks: dict[str, asyncio.Lock] = {}

    async def _get(self, key: str, fn):
        lock = self._locks.setdefault(key, asyncio.Lock())
        async with lock:
            hit = self._cache.get(key)
            if hit and self.clock() - hit[0] < self.ttl:
                return hit[1]
            val = await fn()
            self._cache[key] = (self.clock(), val)
            return val

    async def balance(self):
        return await self._get("balance", self.trading.get_balance)

    async def positions(self):
        return await self._get("positions", self.trading.get_positions)

    async def resting_orders(self):
        return await self._get("resting", lambda: self.trading.list_orders(status="resting"))

    def invalidate(self) -> None:
        self._cache.clear()


@dataclass
class Snapshot:
    balance: Decimal
    portfolio_value: Decimal
    equity: Decimal
    available_cash: Decimal
    exposure: Decimal
    open_positions: int
    daily_pnl: Decimal
    realized_today: Decimal
    unrealized: Decimal
    pending_worst: Decimal
    foreign_positions: list = field(default_factory=list)
    ts: float = 0.0
    reserved: Decimal = ZERO        # cash held behind our waiting (unfilled) bids


def entry_exposure(e: dict) -> Decimal:
    filled = d_or_zero(e["filled_count"])
    if e["state"] in ("intent", "unknown"):
        return d(e["max_loss"])
    base = d_or_zero(e["fill_cost"]) + d_or_zero(e["fees"])
    if e["state"] == "resting":
        base += (d(e["count"]) - filled) * d(e["price"])
    return base


class Portfolio:
    def __init__(self, store, mode: str, account: AccountCache, marks: dict[str, Book], clock=time.time):
        self.store = store
        self.mode = mode
        self.account = account
        self.marks = marks
        self.clock = clock
        self.last: Snapshot | None = None

    def realized_today(self, now: float) -> Decimal:
        day_start = (int(now) // 86400) * 86400
        rows = self.store._q("SELECT pnl FROM entries WHERE mode=? AND settled_at>=? AND pnl IS NOT NULL",
                             (self.mode, day_start))
        return sum((d(r["pnl"]) for r in rows), ZERO)

    def mark(self, ticker: str, leg: str) -> Decimal | None:
        b = self.marks.get(ticker)
        return b.best_bid(leg) if b else None

    async def snapshot(self) -> Snapshot:
        now = self.clock()
        bal = await self.account.balance()
        positions = await self.account.positions()
        open_entries = self.store.entries(self.mode, unsettled_slot=True)
        known = {r["ticker"] for r in self.store._q("SELECT DISTINCT ticker FROM entries WHERE mode=?", (self.mode,))}

        exposure, pending, reserved, unreal = ZERO, ZERO, ZERO, ZERO
        for e in open_entries:
            exposure += entry_exposure(e)
            if e["state"] in ("intent", "unknown"):
                pending += d(e["max_loss"])
            if e["state"] == "resting":
                reserved += (d(e["count"]) - d_or_zero(e["filled_count"])) * d(e["price"])
            filled = d_or_zero(e["filled_count"])
            if filled > ZERO:
                m = self.mark(e["ticker"], e["leg"])
                if m is not None:
                    unreal += filled * m - d_or_zero(e["fill_cost"]) - d_or_zero(e["fees"])

        foreign = [p for p in positions if p.ticker not in known]
        for p in foreign:
            exposure += abs(p.exposure)
        realized = self.realized_today(now)
        snap = Snapshot(
            balance=bal.balance, portfolio_value=bal.portfolio_value,
            equity=bal.balance + bal.portfolio_value + reserved,
            available_cash=bal.balance - pending, exposure=exposure,
            open_positions=len(open_entries) + len(foreign),
            daily_pnl=realized + unreal, realized_today=realized, unrealized=unreal,
            pending_worst=pending, foreign_positions=[p.ticker for p in foreign], ts=now, reserved=reserved)
        self.last = snap
        return snap
