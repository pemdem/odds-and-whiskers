#!/bin/bash
cd "$(dirname "$0")"
echo 'This shows the new limits you picked in the app and asks you to type a phrase to accept them.'
echo 'Your bot keeps using its current limits until you do.'
echo
.venv/bin/python -m favbot ack-live
echo
read -n 1 -s -r -p "Press any key to close this window."
echo
