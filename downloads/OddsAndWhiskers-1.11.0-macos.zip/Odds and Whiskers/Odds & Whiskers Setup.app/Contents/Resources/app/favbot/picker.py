"""Version picker: choose a model (strategy) and coins together, seeing how each choice did.

Two sources, never mixed into one number:
- fresh: Litter Box fake-money bets on live markets (paper fills, fees included);
- past: Backtrack's replay of the last days (bid fills are estimates).
For each strategy and coin, the Litter Box model with the most bets on that coin is used (models that share a
strategy bet on the same markets, so adding them up would count the same bet twice).
"""
from __future__ import annotations

from .presets import ORIGINAL, STRATEGY_KEYS, describe

COINS = ["ETH", "SOL", "XRP", "DOGE", "BNB", "ZEC", "HYPE", "NEAR"]


def strategy_key(st: dict) -> str:
    return "|".join(f"{float(st.get(k)):.2f}" if k in ("ask_min", "ask_max", "max_spread") else str(st.get(k))
                    for k in STRATEGY_KEYS)


def build(lb_summary: dict | None, bt_results: dict | None, live_strategy: dict, live_coins: list[str],
          recommended: dict | None = None) -> dict:
    lb_models = [m for m in (lb_summary or {}).get("models", []) if not m.get("base")]   # risk-level copies aside
    bt_models = (bt_results or {}).get("models") or {}
    groups: dict[str, dict] = {}

    def entry(key, st, name, blurb, rid, default_coins, kind):
        g = groups.get(key)
        if g is None:
            g = groups[key] = {"key": rid, "name": name, "blurb": blurb, "kind": kind,
                               "strategy": {k: st.get(k) for k in STRATEGY_KEYS}, "describe": describe(st)[:4],
                               "default_coins": default_coins, "fresh": {}, "past": {}, "members": []}
        return g

    entry(strategy_key(ORIGINAL), ORIGINAL, "Original", "Your original strategy: waits at the bid.", "original", None,
          "original")
    # models trading every coin come first, so they name their group; coin-subset models only add their coins
    for m in sorted(lb_models, key=lambda m: (m.get("role") != "candidate", bool(m.get("coins")))):
        st = {**ORIGINAL, **(m.get("strategy") or {})}
        g = entry(strategy_key(st), st, m["name"], m.get("blurb", ""), m["id"], m.get("coins"), m.get("role", "experiment"))
        g["members"].append(m["id"])
        for coin, c in (m.get("by_coin") or {}).items():
            if c.get("bets", 0) > g["fresh"].get(coin, {}).get("bets", 0):
                g["fresh"][coin] = {**c, "from": m["id"]}
        b = bt_models.get(m["id"])
        if b and b.get("by_coin"):
            for coin, s in b["by_coin"].items():
                if s.get("n") and coin not in g["past"]:
                    g["past"][coin] = {"n": s["n"], "wins": s.get("wins", 0), "pnl": round(s.get("pnl_usd", 0.0), 2),
                                       "staked": round(s.get("staked_usd", 0.0), 2), "uncertain": s.get("uncertain_fills", 0)}
    if recommended and recommended.get("ready"):
        st = {**ORIGINAL, **recommended["strategy"]}
        g = entry(strategy_key(st), st, "Recommended", "Passed the fresh-market test.", "recommended",
                  recommended.get("coins"), "recommended")
        g.update(kind="recommended", default_coins=recommended.get("coins"), key="recommended", name="Recommended")
    live_key = strategy_key({**ORIGINAL, **live_strategy})
    models = []
    for k, g in groups.items():
        g["is_live"] = k == live_key
        models.append(g)
    order = {"original": 0, "recommended": 1, "candidate": 2}
    models.sort(key=lambda g: (order.get(g["kind"], 3), g["name"]))
    return {"coins": COINS, "models": models, "live": {"key": next((g["key"] for g in models if g["is_live"]), None),
                                                       "coins": live_coins}}


def find(picker: dict, key: str) -> dict | None:
    return next((g for g in picker["models"] if g["key"] == key), None)
