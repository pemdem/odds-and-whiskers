from favbot.projection import MIN_BETS, project

NOW = 1_800_000_000.0


def bets(wins, losses, hours, cost=3.7, price=0.93):
    n = wins + losses
    out = []
    for i in range(n):
        won = i < wins
        out.append({"ts": NOW - hours * 3600 + i * (hours * 3600 / n), "won": won,
                    "pnl": cost * (1 - price) / price if won else -cost, "cost": cost, "price": price})
    return out


def test_not_ready_until_enough_history():
    assert not project(bets(MIN_BETS - 1, 0, 10), 22.0, NOW)["ready"]
    assert not project(bets(50, 0, 1), 22.0, NOW)["ready"]          # plenty of bets but only an hour
    assert project(bets(MIN_BETS, 0, 4), 22.0, NOW, sims=500)["ready"]


def test_box_quantiles_are_ordered_and_spread_grows():
    p = project(bets(22, 2, 12), 22.0, NOW, sims=1500)
    assert p["per_day"] == 48.0 and [r["days"] for r in p["rows"]] == [7, 30, 60, 90]
    for r in p["rows"]:
        assert 0 <= r["p5"] <= r["p25"] <= r["p50"] <= r["p75"] <= r["p95"]
        assert 0 <= r["chance_up"] <= 1
    w = [r["p95"] - r["p5"] for r in p["rows"]]
    assert w[-1] > w[0]


def test_estimate_starts_at_market_odds_and_moves_with_record():
    fair = project(bets(93, 7, 50), 22.0, NOW, sims=300)
    assert abs(fair["p_est"] - 0.93) < 0.01                         # record matches the price: stays there
    good = project(bets(300, 0, 200), 22.0, NOW, sims=300)
    assert good["p_est"] > 0.98                                     # a long perfect record pulls it up
    bad = project(bets(80, 20, 50), 22.0, NOW, sims=300)
    assert bad["p_est"] < 0.88 and bad["rows"][0]["chance_up"] < 0.5


def test_stable_between_refreshes():
    a = project(bets(24, 2, 4), 22.0, NOW, sims=800)
    b = project(bets(24, 2, 4), 22.0, NOW, sims=800)
    assert a["rows"] == b["rows"]
