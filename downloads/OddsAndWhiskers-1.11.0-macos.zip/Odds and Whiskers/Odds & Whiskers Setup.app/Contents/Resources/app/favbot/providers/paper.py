"""Paper simulator: the Trading interface, matched against real public order books.

Deliberately pessimistic:
- an order cannot match until `latency` (400 ms) after it is sent;
- the first book seen after that is the arrival book: if it would cross, a post-only order is cancelled;
- a resting bid fills only when the best offer trades strictly *through* its price, never on a touch;
- only `depth_fraction` (half) of the displayed depth through our price is treated as real;
- positions settle only from the exchange's official result.
State is persisted in the bot's SQLite database so a restart reconciles like the real exchange.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import asdict, dataclass, field
from decimal import ROUND_FLOOR, Decimal

from ..models import BalanceInfo, Book, FillInfo, OrderAck, OrderInfo, OrderRequest, PositionInfo
from ..money import ONE, ZERO, d, maker_fee, taker_fee
from .base import ApiError

STATE_KEY = "paper_state"


@dataclass
class SimOrder:
    order_id: str
    client_order_id: str
    ticker: str
    leg: str
    price: str
    count: str
    filled: str = "0"
    fill_cost: str = "0"
    fees: str = "0"
    status: str = "resting"
    created: float = 0.0
    active_at: float = 0.0
    expiration_ts: int = 0
    arrived: bool = False      # post-only check against the arrival book done
    reserved: str = "0"


@dataclass
class SimState:
    cash: str
    orders: dict = field(default_factory=dict)          # order_id -> SimOrder dict
    fills: list = field(default_factory=list)           # FillInfo-like dicts
    positions: dict = field(default_factory=dict)       # ticker -> {"yes": count, "no": count, "cost": x}
    settled: dict = field(default_factory=dict)         # ticker -> result


class PaperExchange:
    kind = "paper"

    def __init__(self, store, starting_cash: Decimal, *, latency_s: float = 0.4,
                 depth_fraction: Decimal = Decimal("0.5"), fee_lookup=None, clock=time.time):
        self.store = store
        self.latency_s = latency_s
        self.depth_fraction = d(depth_fraction)
        self.fee_lookup = fee_lookup or (lambda ticker: ("quadratic", Decimal(1)))
        self.clock = clock
        raw = store.get_meta(STATE_KEY) if store else None
        if raw:
            self.state = SimState(**raw)
        else:
            self.state = SimState(cash=str(d(starting_cash)))
        self.marks: dict[str, Book] = {}
        self._save()

    # ---- persistence ----------------------------------------------------------------------
    def _save(self) -> None:
        if self.store:
            self.store.set_meta(STATE_KEY, asdict(self.state))

    def _order(self, oid: str) -> SimOrder | None:
        o = self.state.orders.get(oid)
        return SimOrder(**o) if o else None

    def _put(self, o: SimOrder) -> None:
        self.state.orders[o.order_id] = asdict(o)

    # ---- Trading interface ----------------------------------------------------------------
    async def create_order(self, req: OrderRequest) -> OrderAck:
        req.to_payload()  # same validation as the real payload
        now = self.clock()
        if any(o["client_order_id"] == req.client_order_id for o in self.state.orders.values()):
            raise ApiError(409, "duplicate client_order_id", "order_already_exists")
        if req.expiration_ts <= now:
            raise ApiError(400, "expiration_time in the past", "invalid_parameters")
        fee_type, mult = self.fee_lookup(req.ticker)
        reserve = d(req.count) * req.price + maker_fee(fee_type, mult, req.count, req.price)
        cash = d(self.state.cash)
        if reserve > cash:
            raise ApiError(400, "insufficient shard balance", "insufficient_balance")
        if not req.post_only:
            reserve = d(req.count) * req.price + taker_fee(fee_type, mult, req.count, req.price)
            if reserve > cash:
                raise ApiError(400, "insufficient shard balance", "insufficient_balance")
        self.state.cash = str(cash - reserve)
        o = SimOrder(order_id="paper-" + uuid.uuid4().hex[:16], client_order_id=req.client_order_id,
                     ticker=req.ticker, leg=req.leg, price=str(req.price), count=str(req.count),
                     created=now, active_at=now + self.latency_s, expiration_ts=int(req.expiration_ts),
                     reserved=str(reserve))
        self._put(o)
        if not req.post_only:
            self._take(o, now)       # buy at the ask now, against the book we last saw; the rest is cancelled
        self._save()
        o = self._order(o.order_id)
        return OrderAck(o.order_id, o.client_order_id, d(o.filled), d(o.count) - d(o.filled))

    def _take(self, o: SimOrder, now: float) -> None:
        """Taker fill: walk the asks at or below our limit, only half of each level counts as real."""
        book = self.marks.get(o.ticker)
        limit, want = d(o.price), d(o.count)
        fee_type, mult = self.fee_lookup(o.ticker)
        got, cost = ZERO, ZERO
        if book is not None:
            for p, q in book.ask_levels(o.leg):
                if p > limit or got >= want:
                    break
                take = min(want - got, (q * self.depth_fraction).to_integral_value(rounding=ROUND_FLOOR))
                got += take
                cost += take * p
        if got >= ONE:
            fee = taker_fee(fee_type, mult, got, cost / got)
            o.filled, o.fill_cost, o.fees = str(got), str(cost), str(fee)
            pos = self.state.positions.setdefault(o.ticker, {"yes": "0", "no": "0", "cost": "0"})
            pos[o.leg] = str(d(pos[o.leg]) + got)
            pos["cost"] = str(d(pos["cost"]) + cost + fee)
            self.state.fills.append({"fill_id": "pfill-" + uuid.uuid4().hex[:16], "order_id": o.order_id,
                                     "ticker": o.ticker, "leg": o.leg, "count": str(got), "price": str(cost / got),
                                     "fee": str(fee), "ts": now})
            o.reserved = str(max(ZERO, d(o.reserved) - cost - fee))
        o.status = "executed" if got >= want else "canceled"
        self.state.cash = str(d(self.state.cash) + d(o.reserved))
        o.reserved = "0"
        self._put(o)

    async def cancel_order(self, order_id: str, ticker: str) -> None:
        o = self._order(order_id)
        if not o:
            raise ApiError(404, "order not found")
        if o.status != "resting":
            raise ApiError(400, f"order is {o.status}", "order_not_resting")
        self._close(o, "canceled")
        self._save()

    async def get_order(self, order_id: str) -> OrderInfo | None:
        self._expire(self.clock())
        o = self._order(order_id)
        return self._info(o) if o else None

    async def list_orders(self, *, ticker=None, status=None, min_ts=None) -> list[OrderInfo]:
        self._expire(self.clock())
        out = []
        for raw in self.state.orders.values():
            o = SimOrder(**raw)
            if ticker and o.ticker != ticker:
                continue
            if status and o.status != status:
                continue
            if min_ts and o.created < min_ts:
                continue
            out.append(self._info(o))
        return out

    async def get_fills(self, *, order_id=None, ticker=None, min_ts=None) -> list[FillInfo]:
        out = []
        for f in self.state.fills:
            if order_id and f["order_id"] != order_id:
                continue
            if ticker and f["ticker"] != ticker:
                continue
            if min_ts and (f["ts"] or 0) < min_ts:
                continue
            out.append(FillInfo(f["fill_id"], f["order_id"], f["ticker"], f["leg"], d(f["count"]), d(f["price"]),
                                d(f["fee"]), False, f["ts"]))
        return out

    async def get_positions(self) -> list[PositionInfo]:
        out = []
        for t, p in self.state.positions.items():
            net = d(p["yes"]) - d(p["no"])
            if net != ZERO:
                out.append(PositionInfo(t, net, d(p["cost"])))
        return out

    async def get_balance(self) -> BalanceInfo:
        self._expire(self.clock())
        value = ZERO
        for t, p in self.state.positions.items():
            book = self.marks.get(t)
            for leg in ("yes", "no"):
                n = d(p[leg])
                if n == ZERO:
                    continue
                bid = book.best_bid(leg) if book else None
                value += n * (bid if bid is not None else d(p["cost"]) / n)
        return BalanceInfo(d(self.state.cash), value)

    # ---- matching -------------------------------------------------------------------------
    def observe_book(self, book: Book, now: float) -> None:
        self.marks[book.ticker] = book
        self._expire(now)
        changed = False
        for raw in list(self.state.orders.values()):
            o = SimOrder(**raw)
            if o.ticker != book.ticker or o.status != "resting" or now < o.active_at or book.fetched_at < o.active_at:
                continue
            price = d(o.price)
            ask = book.best_ask(o.leg)
            if not o.arrived:
                o.arrived = True
                if ask is not None and ask <= price:
                    self._put(o)
                    self._close(o, "canceled")     # post-only would have crossed on arrival
                    changed = True
                    continue
                self._put(o)
                changed = True
                continue
            if ask is None or ask >= price:
                continue                            # a touch is not a fill
            through = sum((q for p, q in book.ask_levels(o.leg) if p < price), ZERO)
            real = (through * self.depth_fraction).to_integral_value(rounding=ROUND_FLOOR)
            remaining = d(o.count) - d(o.filled)
            qty = min(remaining, real)
            if qty < ONE:
                continue
            self._fill(o, qty, now)
            changed = True
        if changed:
            self._save()

    def _fill(self, o: SimOrder, qty: Decimal, now: float) -> None:
        price = d(o.price)
        fee_type, mult = self.fee_lookup(o.ticker)
        fee = maker_fee(fee_type, mult, qty, price)
        cost = qty * price
        o.filled = str(d(o.filled) + qty)
        o.fill_cost = str(d(o.fill_cost) + cost)
        o.fees = str(d(o.fees) + fee)
        o.reserved = str(max(ZERO, d(o.reserved) - cost - fee))
        pos = self.state.positions.setdefault(o.ticker, {"yes": "0", "no": "0", "cost": "0"})
        pos[o.leg] = str(d(pos[o.leg]) + qty)
        pos["cost"] = str(d(pos["cost"]) + cost + fee)
        self.state.fills.append({"fill_id": "pfill-" + uuid.uuid4().hex[:16], "order_id": o.order_id,
                                 "ticker": o.ticker, "leg": o.leg, "count": str(qty), "price": o.price,
                                 "fee": str(fee), "ts": now})
        if d(o.filled) >= d(o.count):
            o.status = "executed"
            self.state.cash = str(d(self.state.cash) + d(o.reserved))  # release fee over-reserve
            o.reserved = "0"
        self._put(o)

    def _close(self, o: SimOrder, status: str) -> None:
        o.status = status
        self.state.cash = str(d(self.state.cash) + d(o.reserved))
        o.reserved = "0"
        self._put(o)

    def _expire(self, now: float) -> None:
        changed = False
        for raw in list(self.state.orders.values()):
            o = SimOrder(**raw)
            if o.status == "resting" and now >= o.expiration_ts:
                self._close(o, "canceled")
                changed = True
        if changed:
            self._save()

    async def settle(self, ticker: str, result: str) -> None:
        """Pay out from the official result only. Called once the market is finalized."""
        if ticker in self.state.settled or result not in ("yes", "no"):
            return
        pos = self.state.positions.pop(ticker, None)
        if pos:
            self.state.cash = str(d(self.state.cash) + d(pos[result]))
        self.state.settled[ticker] = result
        self._save()

    def _info(self, o: SimOrder) -> OrderInfo:
        return OrderInfo(order_id=o.order_id, client_order_id=o.client_order_id, ticker=o.ticker, leg=o.leg,
                         price=d(o.price), status=o.status, fill_count=d(o.filled),
                         remaining_count=(d(o.count) - d(o.filled)) if o.status == "resting" else ZERO,
                         initial_count=d(o.count), fill_cost=d(o.fill_cost), fees=d(o.fees), created_ts=o.created)
