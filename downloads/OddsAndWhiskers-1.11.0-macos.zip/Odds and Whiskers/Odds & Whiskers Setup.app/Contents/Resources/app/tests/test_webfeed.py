"""Updates from the website: only a correctly signed, newer zip is kept; nothing is installed by the download."""
import json
import shutil

import pytest

from favbot import release as R
from tests.test_release import make_copy


@pytest.fixture()
def setup(tmp_path):
    pub = make_copy(tmp_path / "me")
    key = tmp_path / "key.pem"
    R.init_signing(key, pub / "favbot" / "release_pubkey.txt")
    friend = tmp_path / "friend"
    shutil.copytree(pub, friend)
    (friend / "favbot" / "update_feed.txt").write_text("https://example.github.io/odds-and-whiskers/updates/\n")
    share = tmp_path / "share"
    return pub, friend, key, share


def site(share, version):
    files = {"latest.json": json.dumps({"version": version}).encode()}
    zp = share / f"BetterBot-{version}.zip"
    if zp.exists():
        files[zp.name] = zp.read_bytes()
    seen = []

    def opener(url):
        seen.append(url)
        name = url.rsplit("/", 1)[1]
        return files[name]
    return opener, seen


def test_newer_signed_update_is_fetched_then_offered(setup):
    pub, friend, key, share = setup
    R.publish(share, "web", "1.2.0", root=pub, key_path=key, packages=False)
    opener, seen = site(share, "1.2.0")
    r = R.fetch_feed(friend, opener=opener)
    assert r["newer"] and seen == ["https://example.github.io/odds-and-whiskers/updates/latest.json",
                                   "https://example.github.io/odds-and-whiskers/updates/BetterBot-1.2.0.zip"]
    info = R.check(friend)
    assert info["available"]["version"] == "1.2.0" and "web_updates" in info["available"]["path"]
    assert R.installed_version(friend) == "1.0.0"                    # fetching never installs
    R.fetch_feed(friend, opener=opener)
    assert len(seen) == 3                                            # already downloaded: only latest.json again


def test_website_cannot_push_unsigned_code(setup, tmp_path):
    pub, friend, key, share = setup
    other = make_copy(tmp_path / "stranger")
    okey = tmp_path / "other.pem"
    R.init_signing(okey, other / "favbot" / "release_pubkey.txt")
    R.publish(share, "evil", "2.0.0", root=other, key_path=okey, packages=False)
    opener, _ = site(share, "2.0.0")
    with pytest.raises(R.ReleaseError):
        R.fetch_feed(friend, opener=opener)
    assert not list((friend / "data" / "web_updates").glob("*.zip*"))
    assert R.check(friend)["available"] is None


def test_nothing_newer_means_no_download(setup):
    _, friend, _, share = setup
    opener, seen = site(share, "1.0.0")
    assert R.fetch_feed(friend, opener=opener)["newer"] is False and len(seen) == 1


def test_feed_must_be_https(setup):
    _, friend, _, _ = setup
    (friend / "favbot" / "update_feed.txt").write_text("http://example.com/updates/")
    assert R.feed_url(friend) is None and R.fetch_feed(friend)["ok"] is False
