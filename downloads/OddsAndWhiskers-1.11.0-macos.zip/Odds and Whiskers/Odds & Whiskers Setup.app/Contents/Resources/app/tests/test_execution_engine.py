"""Idempotency, unknown outcomes, restart reconciliation, kill switch, shared caps, paper read-only."""
from decimal import Decimal as D

import aiohttp
import pytest

from favbot.cli import build_clients
from favbot.config import PROD_URL, Config
from favbot.engine import Bot
from favbot.execution import Execution
from favbot.models import OrderInfo
from favbot.providers.base import OrderOutcomeUnknown, ReadOnlyViolation
from favbot.providers.kalshi import KalshiAPI, KalshiTrading, verify_market
from favbot.providers.paper import PaperExchange
from favbot.store import SlotTaken, Store

from .conftest import T0, FakeMD, book, limits, market

CLOSE = T0 + 900
FAV = ([("0.50", "10"), ("0.91", "100")], [("0.02", "10"), ("0.07", "80")])        # UP bid .91 ask .93


def entry_kw(**kw):
    base = dict(mode="paper", series="KXETH15M", coin="ETH", ticker="KXETH15M-X", leg="yes", outcome="UP",
                price=D("0.91"), count=1, max_loss=D("0.91"), expiration_ts=1, max_attempts=20)
    base.update(kw)
    return base


# ---- database-level idempotency -----------------------------------------------------------
def test_duplicate_prevention_across_two_connections(tmp_path):
    p = tmp_path / "db.sqlite3"
    s1, s2 = Store(p), Store(p)
    a = s1.insert_intent(client_order_id="a", **entry_kw())
    with pytest.raises(SlotTaken):
        s2.insert_intent(client_order_id="b", **entry_kw())          # same contract, other connection
    with pytest.raises(SlotTaken):
        s2.insert_intent(client_order_id="a", **entry_kw(ticker="KXETH15M-Y"))   # client_order_id unique
    s1.mark_rejected(a, "post-only would cross")                       # ended with zero fill -> slot freed
    b = s2.insert_intent(client_order_id="b", **entry_kw())
    s2.mark_resting(b, "o-b")
    s1.apply_order(b, OrderInfo("o-b", "b", "KXETH15M-X", "yes", D("0.91"), "canceled", D(1), D(0), D(1),
                                D("0.91"), D(0)))
    with pytest.raises(SlotTaken):                                     # filled -> nothing more on this contract
        s1.insert_intent(client_order_id="c", **entry_kw())


def test_bid_cap_per_contract(tmp_path):
    s = Store(tmp_path / "db.sqlite3")
    for i in range(3):
        e = s.insert_intent(client_order_id=f"c{i}", **entry_kw(max_attempts=3))
        s.mark_rejected(e, "x")
    with pytest.raises(SlotTaken, match="cap"):
        s.insert_intent(client_order_id="c9", **entry_kw(max_attempts=3))


# ---- unknown outcomes ---------------------------------------------------------------------
class FlakyPaper(PaperExchange):
    """create_order raises OrderOutcomeUnknown; `accept` decides whether the exchange really got it."""

    def __init__(self, *a, accept: bool, failures: int = 1, **k):
        super().__init__(*a, **k)
        self.accept = accept
        self.failures = failures
        self.sent = 0

    async def create_order(self, req):
        self.sent += 1
        if self.failures > 0:
            self.failures -= 1
            if self.accept:
                await super().create_order(req)
            raise OrderOutcomeUnknown("read timeout")
        return await super().create_order(req)


def contract():
    c, _ = verify_market(market(close_ts=CLOSE), "KXETH15M", 2)
    return c


async def _place(ex, store, clock):
    c = contract()
    store.upsert_contract(c)
    return c, await ex.place(c, leg="yes", outcome="UP", price=D("0.91"), count=5, max_loss=D("4.55"),
                             expiration_ts=int(clock() + 20), max_attempts=20)


async def test_timeout_but_accepted_is_found_not_resent(tmp_path, clock):
    store = Store(tmp_path / "db.sqlite3")
    sim = FlakyPaper(store, D(100), accept=True, clock=clock)
    ex = Execution(store, sim, "paper", clock=clock)
    c, e = await _place(ex, store, clock)
    assert e["state"] == "unknown" and store.unknown_count("paper") == 1   # blocks all new entries
    e = await ex.resolve_unknown(e, still_wanted=True)
    assert e["state"] == "resting" and e["order_id"] and sim.sent == 1
    assert store.unknown_count("paper") == 0


async def test_timeout_not_accepted_resends_once_with_same_id(tmp_path, clock):
    store = Store(tmp_path / "db.sqlite3")
    sim = FlakyPaper(store, D(100), accept=False, clock=clock)
    ex = Execution(store, sim, "paper", clock=clock)
    c, e = await _place(ex, store, clock)
    e = await ex.resolve_unknown(e, still_wanted=True)
    assert e["state"] == "unknown" and sim.sent == 1                     # read-after-write lag: wait first
    clock.advance(16)
    e = await ex.resolve_unknown(e, still_wanted=False)
    assert e["state"] == "not_placed" and e["slot"] is None               # not wanted any more: no resend


async def test_resend_at_most_once(tmp_path, clock):
    store = Store(tmp_path / "db.sqlite3")
    sim = FlakyPaper(store, D(100), accept=False, failures=2, clock=clock)
    ex = Execution(store, sim, "paper", clock=clock)
    c, e = await _place(ex, store, clock)
    coid = e["client_order_id"]
    clock.advance(16)
    e = await ex.resolve_unknown(e, still_wanted=True)        # resend #1 -> unknown again
    assert sim.sent == 2 and e["state"] == "unknown" and e["resend_count"] == 1
    clock.advance(1)
    # still within 20 s expiry, but already re-sent once: confirmed absent -> released, no third send
    clock.advance(15)
    e = await ex.resolve_unknown(e, still_wanted=True)
    assert sim.sent == 2 and e["state"] == "not_placed"
    assert store.entry_by_coid(coid)["id"] == e["id"]


async def test_resend_succeeds(tmp_path, clock):
    store = Store(tmp_path / "db.sqlite3")
    sim = FlakyPaper(store, D(100), accept=False, failures=1, clock=clock)
    ex = Execution(store, sim, "paper", clock=clock)
    c, e = await _place(ex, store, clock)
    clock.advance(1)
    store.mark_sent(e["id"], clock() - 16)                    # pretend the lag has passed
    e = await ex.resolve_unknown(store.entry(e["id"]), still_wanted=True)
    assert e["state"] == "resting" and sim.sent == 2
    assert (await sim.list_orders())[0].client_order_id == e["client_order_id"]


# ---- restart reconciliation ---------------------------------------------------------------
async def test_restart_reconciles_fill_that_happened_while_down(tmp_path, clock):
    p = tmp_path / "db.sqlite3"
    store = Store(p)
    sim = PaperExchange(store, D(100), clock=clock)
    ex = Execution(store, sim, "paper", clock=clock)
    c, e = await _place(ex, store, clock)
    t = c.ticker
    clock.advance(1)
    sim.observe_book(book(t, [("0.90", "5")], [("0.07", "50")], fetched_at=clock()), clock())   # arrival
    clock.advance(2)
    sim.observe_book(book(t, [("0.90", "5")], [("0.10", "40")], fetched_at=clock()), clock())   # through
    # --- process dies; a new one starts on the same database ---
    store2 = Store(p)
    sim2 = PaperExchange(store2, D(100), clock=clock)
    ex2 = Execution(store2, sim2, "paper", clock=clock)
    await ex2.reconcile("KXETH15M")
    e2 = store2.entry(e["id"])
    assert e2["state"] == "done" and D(e2["filled_count"]) == 5 and e2["slot"] == 1
    assert len(store2.fills("paper")) == 1
    assert store2.halts() == {}


async def test_intent_left_by_crash_becomes_unknown(tmp_path, clock):
    store = Store(tmp_path / "db.sqlite3")
    store.insert_intent(client_order_id="fb-x", **entry_kw())
    assert store.intents_to_unknown("paper") == 1
    assert store.unknown_count("paper") == 1


async def test_position_mismatch_two_passes_halts(tmp_path, clock):
    store = Store(tmp_path / "db.sqlite3")
    sim = PaperExchange(store, D(100), clock=clock)
    ex = Execution(store, sim, "paper", clock=clock)
    c = contract()
    store.upsert_contract(c)
    sim.state.positions[c.ticker] = {"yes": "3", "no": "0", "cost": "2.7"}   # a position we never recorded
    await ex.reconcile("KXETH15M", now=clock())
    assert store.halts() == {}
    await ex.reconcile("KXETH15M", now=clock())
    assert "position_mismatch" in store.halts()


# ---- engine-level ------------------------------------------------------------------------
def make_bot(tmp_path, clock, series=("KXETH15M",), lim=None, md=None):
    cfg = Config(data_dir=str(tmp_path), base_dir=str(tmp_path), series=list(series), paper_limits=lim or limits())
    store = Store(tmp_path / "db.sqlite3")
    md = md or FakeMD(clock, series)
    holder = {}
    sim = PaperExchange(store, D(1000), clock=clock, fee_lookup=lambda t: holder["bot"].fee_lookup(t))
    bot = Bot(cfg, "paper", store, md, sim, cfg.paper_limits, data_dir=tmp_path, clock=clock)
    holder["bot"] = bot
    for s in series:
        m = market(series=s, close_ts=CLOSE)
        md.markets[s].append(m)
        md.books[m["ticker"]] = FAV
    return bot, md, store, sim


async def test_engine_bids_then_cancels_when_favourite_weakens(tmp_path, clock):
    clock.t = CLOSE - 200
    bot, md, store, sim = make_bot(tmp_path, clock)
    await bot.startup()
    eng = bot.engines[0]
    t = f"KXETH15M-{int(CLOSE)}"
    await eng.tick()
    e = store.active_entry("paper", t)
    assert e["state"] == "resting" and e["price"] == "0.91" and e["leg"] == "yes"
    # favourite's bid falls from 0.91 to 0.90 -> cancel; a fresh bid at 0.90 is allowed
    md.books[t] = ([("0.50", "10"), ("0.90", "100")], [("0.02", "10"), ("0.07", "80")])
    clock.advance(2)
    await eng.tick()
    rows = store.entries("paper", ticker=t)
    first = [r for r in rows if r["attempt"] == 1][0]
    assert first["state"] == "done" and first["end_reason"].startswith("cancelled")
    assert store.active_entry("paper", t)["price"] == "0.90"


async def test_engine_holds_after_fill_and_settles(tmp_path, clock):
    clock.t = CLOSE - 200
    bot, md, store, sim = make_bot(tmp_path, clock)
    await bot.startup()
    eng = bot.engines[0]
    t = f"KXETH15M-{int(CLOSE)}"
    await eng.tick()                                    # place at 0.91
    clock.advance(2)
    await eng.tick()                                    # arrival book: ask 0.93, no cross
    md.books[t] = ([("0.91", "100")], [("0.02", "10"), ("0.07", "80"), ("0.10", "200")])  # asks through 0.91
    clock.advance(2)
    await eng.tick()
    e = store.active_entry("paper", t)
    assert D(e["filled_count"]) > 0
    n_entries = len(store.entries("paper", ticker=t))
    md.books[t] = FAV
    for _ in range(5):                                  # no more bids on this contract
        clock.advance(2)
        await eng.tick()
    assert len(store.entries("paper", ticker=t)) == n_entries
    # settle from the official result only
    clock.t = CLOSE + 60
    md.results[t] = {"status": "finalized", "result": "yes"}
    eng._next_meta = 0
    await eng.tick()
    e = store.entry(e["id"])
    assert e["settled_result"] == "yes" and D(e["pnl"]) == D(e["filled_count"]) - D(e["fill_cost"])


async def test_position_cap_shared_across_coins(tmp_path, clock):
    clock.t = CLOSE - 200
    bot, md, store, sim = make_bot(tmp_path, clock, series=("KXETH15M", "KXSOL15M"), lim=limits(max_open_positions=1))
    await bot.startup()
    for eng in bot.engines:
        await eng.tick()
    live = store.entries("paper", states=("resting",))
    assert len(live) == 1
    assert "max open positions" in bot.engines[1].status.get("blocked", "")


async def test_engine_only_manages_its_own_coin(tmp_path, clock):
    clock.t = CLOSE - 200
    bot, md, store, sim = make_bot(tmp_path, clock, series=("KXETH15M", "KXSOL15M"))
    await bot.startup()
    await bot.engines[0].tick()
    assert all(t.startswith("KXETH15M-") for t in md.calls)


async def test_kill_switch_persists_and_cancels(tmp_path, clock):
    clock.t = CLOSE - 200
    bot, md, store, sim = make_bot(tmp_path, clock)
    await bot.startup()
    eng = bot.engines[0]
    await eng.tick()
    assert store.entries("paper", states=("resting",))
    (tmp_path / "KILL").write_text("stop")
    assert bot.killed() == "KILL file present"
    assert Store(tmp_path / "db.sqlite3").kill_state()["reason"] == "KILL file present"   # persisted
    clock.advance(2)
    await eng.tick()
    assert not store.entries("paper", states=("resting",))
    before = len(store.entries("paper"))
    for _ in range(3):
        clock.advance(2)
        await eng.tick()
    assert len(store.entries("paper")) == before
    (tmp_path / "KILL").unlink()
    assert bot.killed()                      # the database flag survives the file being removed
    store.clear_kill()
    assert bot.killed() is None


async def test_coin_switched_off_cancels_and_stops_bidding(tmp_path, clock):
    clock.t = CLOSE - 200
    bot, md, store, sim = make_bot(tmp_path, clock)
    await bot.startup()
    eng = bot.engines[0]
    await eng.tick()
    assert store.entries("paper", states=("resting",))
    store.set_meta("coins_off", ["ETH"])
    clock.advance(2)
    await eng.tick()
    assert not store.entries("paper", states=("resting",))
    n = len(store.entries("paper"))
    clock.advance(2)
    await eng.tick()
    assert len(store.entries("paper")) == n
    store.set_meta("coins_off", [])
    clock.advance(2)
    await eng.tick()
    assert store.entries("paper", states=("resting",))


async def test_unknown_order_blocks_other_coins(tmp_path, clock):
    clock.t = CLOSE - 200
    bot, md, store, sim = make_bot(tmp_path, clock, series=("KXETH15M", "KXSOL15M"))
    await bot.startup()
    store.insert_intent(client_order_id="fb-u", **entry_kw(ticker="KXETH15M-OTHER"))
    store.mark_unknown(1, "timeout")
    await bot.engines[1].tick()
    assert not store.entries("paper", states=("resting",))
    assert "unknown outcome" in bot.engines[1].status["blocked"]


# ---- paper mode is read-only ------------------------------------------------------------
async def test_read_only_client_raises_before_io():
    api = KalshiAPI(PROD_URL, read_only=True)

    async def no_io():
        raise AssertionError("network I/O attempted")

    api._sess = no_io
    for method in ("POST", "DELETE", "PUT", "PATCH"):
        with pytest.raises(ReadOnlyViolation):
            await api.request(method, "/portfolio/events/orders", body={})
    with pytest.raises(ValueError):
        KalshiTrading(api, 2)


async def test_paper_wiring_is_read_only(tmp_path):
    cfg = Config(data_dir=str(tmp_path), base_dir=str(tmp_path), paper_limits=limits())
    store = Store(tmp_path / "db.sqlite3")
    md, trading, closers = build_clients(cfg, "paper", store, None, {})
    assert md.read_only is True and md.signer is None and trading.kind == "paper"
    await md.close()


async def test_paper_run_issues_no_non_get_requests(tmp_path, clock, monkeypatch):
    seen = []
    orig = aiohttp.ClientSession._request

    async def spy(self, method, *a, **k):
        seen.append(method)
        return await orig(self, method, *a, **k)

    monkeypatch.setattr(aiohttp.ClientSession, "_request", spy)
    clock.t = CLOSE - 200
    bot, md, store, sim = make_bot(tmp_path, clock)
    await bot.startup()
    for _ in range(4):
        await bot.engines[0].tick()
        clock.advance(2)
    await bot.shutdown("test")
    assert store.entries("paper")              # it did trade (in the simulator)
    assert [m for m in seen if m.upper() != "GET"] == []
