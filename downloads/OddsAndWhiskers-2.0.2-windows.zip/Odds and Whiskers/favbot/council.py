"""Cat Council: the sidekicks answer questions from the app's real data.

One shared system with four personalities. Every answer is built from "lookups" (tools) that read the real
balances, bets, settings, logs, Litter Box and Backtrack results; the cats only change the voice around the same
facts. Each fact block is labelled — real money, practice/simulated, historical test, estimate, live market, app
status — with the time it was read. If something isn't available, the answer says so rather than guessing.

Answers can offer actions (open a screen, preview a Clump change, start a fake-money experiment, resume). The
app only carries them out when the person clicks, through the same endpoints and confirmations as before; no
lookup here can trade or change a setting. Credentials never appear in any lookup result.

Works fully offline. An optional AI mode (council_ai.py) may rephrase and reason over the same lookups.
"""
from __future__ import annotations

import math
import re
import time
from decimal import Decimal

from . import catnap
from .money import d_or_zero

CATS = ("biscuit", "chonk", "chill", "katya")
NAMES = {"biscuit": "Biscuit", "chonk": "Le Chonk", "chill": "Le Chill", "katya": "Katya"}
COINS = ("ETH", "SOL", "XRP", "DOGE", "BNB", "ZEC", "HYPE", "NEAR", "BTC")
LEVEL_NAMES = ("tiny", "light", "steady", "bold", "chonky")

# labels on every fact block
REAL, PRACTICE, SIM, HIST, EST, LIVE, APP = ("Real money", "Practice money", "Simulated (fake money)",
                                             "Historical test", "Estimate", "Live market", "App status")


def _c(p) -> str:
    try:
        return f"{float(p) * 100:.0f}¢"
    except (TypeError, ValueError):
        return "–"


def _m(v, sign=False) -> str:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return "–"
    s = f"${abs(x):,.2f}"
    return (("+" if x > 0 else "−" if x < 0 else "") + s) if sign else ("−" + s if x < 0 else s)


def _pct(v, digits=1) -> str:
    try:
        return f"{float(v) * 100:+.{digits}f}%"
    except (TypeError, ValueError):
        return "–"


def _ago(ts, now) -> str:
    if not ts:
        return "unknown time"
    s = now - ts
    if s < 90:
        return "just now"
    if s < 3600:
        return f"{int(s // 60)} min ago"
    if s < 86400:
        return f"{s / 3600:.1f} h ago"
    return f"{s / 86400:.1f} days ago"


def block(label: str, items: list[str], as_of: float | None = None, note: str | None = None) -> dict:
    return {"label": label, "items": [i for i in items if i], "as_of": as_of, "note": note}


# ---- the lookups (the only way an answer gets facts) ---------------------------------------------
class Ctx:
    """Everything a lookup may read. Built per question by the dashboard."""
    def __init__(self, bot, state: dict, since: float | None = None):
        self.bot, self.s, self.now = bot, state, bot.clock()
        self.money = REAL if bot.mode == "live" else PRACTICE
        self.since = since


def look_account(x: Ctx) -> dict:
    a = x.s.get("account")
    if not a:
        return {"unavailable": "The account balance hasn't been read from Kalshi yet (the bot may still be starting)."}
    return {"label": x.money, "as_of": x.now, "equity": a["equity"], "cash": a["balance"], "in_bets": a["positions_value"],
            "reserved": a.get("reserved"), "open_positions": a["open_positions"], "today_pnl": a.get("daily_pnl"),
            "cap": x.s.get("limits", {}).get("capital_cap_usd")}


def look_positions(x: Ctx) -> dict:
    ob = x.s.get("open_bets") or []
    pend = [e for e in (x.s.get("pending") or []) if e.get("state") == "resting"]
    return {"label": x.money, "as_of": x.now,
            "holding": [{"coin": b["coin"], "side": b["outcome"], "qty": b["qty"], "price": b["price"], "cost": b["cost"],
                         "worth_now": b.get("value"), "pays_if_win": b["if_win"],
                         "result_in_s": (b["closes_at"] - x.now) if b.get("closes_at") else None} for b in ob],
            "waiting_bids": [{"coin": e["coin"], "side": e["outcome"], "price": e["price"], "count": e["count"]} for e in pend]}


def look_activity(x: Ctx, since: float | None = None) -> dict:
    since = since or x.since or (x.now - 86400)
    ser = [p for p in (x.s.get("series") or []) if (p.get("ts") or 0) >= since]
    wins = sum(1 for p in ser if p["pnl"] > 0)
    ev = [e for e in (x.s.get("errors") or []) if (e.get("ts") or 0) >= since]
    kinds = {}
    for e in ev:
        kinds[e["kind"]] = kinds.get(e["kind"], 0) + 1
    return {"label": x.money, "since": since, "as_of": x.now, "settled": len(ser), "wins": wins, "losses": len(ser) - wins,
            "pnl": round(sum(p["pnl"] for p in ser), 2), "fees": None,
            "last": [{"coin": p["coin"], "side": p["outcome"], "pnl": p["pnl"], "ts": p["ts"]} for p in ser[-5:]][::-1],
            "notable_events": [{"ts": e["ts"], "kind": e["kind"], "message": catnap.scrub(e["message"])[:160]} for e in ev[:6]],
            "event_counts": kinds}


def look_status(x: Ctx) -> dict:
    st = catnap.status(x.bot)
    return {"label": APP, "as_of": x.now, **{k: st[k] for k in ("level", "title", "headline", "detail", "next_step", "action")}}


def look_why_no_bet(x: Ctx) -> dict:
    return {"label": APP, "as_of": x.now, "coins": catnap.why_no_bet(x.bot)}


def look_stop_history(x: Ctx) -> dict:
    """The last things that stopped or paused trading, from the bot's own event log."""
    kinds = ("kill", "daily_loss", "halt", "pause", "turned_off", "restart", "recovering", "recovered", "update",
             "engine_error", "shutdown", "settings", "go_live", "unkill", "resume")
    rows = x.bot.store._q(f"SELECT ts, level, kind, message FROM events WHERE kind IN ({','.join('?' * len(kinds))}) "
                          "ORDER BY id DESC LIMIT 8", kinds)
    return {"label": APP, "as_of": x.now, "events": [{"ts": r["ts"], "kind": r["kind"], "level": r["level"],
                                                    "message": catnap.scrub(r["message"])[:200]} for r in rows]}


def look_risk(x: Ctx) -> dict:
    lim, a, p = x.s.get("limits") or {}, x.s.get("account") or {}, x.s.get("presets") or {}
    cur = (p.get("current") or {})
    lv = cur.get("level")
    names = [l["name"] for l in p.get("levels", [])]
    return {"label": x.money, "as_of": x.now, "level": names[lv - 1] if lv and names else None, "level_n": lv,
            "per_bet": lim.get("max_loss_per_position_usd"), "cap": lim.get("capital_cap_usd"),
            "max_open": lim.get("max_open_positions"), "exposure_pct": lim.get("max_total_exposure_pct"),
            "daily_stop_pct": lim.get("daily_loss_pct"), "exposure_now": a.get("exposure"), "open_now": a.get("open_positions"),
            "today_pnl": a.get("daily_pnl"), "pending_limits": bool(p.get("pending_limits")),
            "kill": x.s.get("killed"), "paused": x.s.get("paused"), "daily_loss_hit": x.s.get("daily_loss_hit")}


def look_strategy(x: Ctx) -> dict:
    p = x.s.get("presets") or {}
    cur, rec = p.get("current") or {}, p.get("recommended") or {}
    lab = (x.s.get("lab") or {}).get("candidate") or {}
    ev = lab.get("last_eval") or {}
    return {"label": APP, "as_of": x.now, "live_strategy": cur.get("describe"), "is_original": cur.get("is_original"),
            "recommended": ({"label": rec.get("label"), "fresh_roi": (rec.get("fresh") or {}).get("roi"),
                             "fresh_bets": (rec.get("fresh") or {}).get("n"), "days": rec.get("days")} if rec.get("ready") else None),
            "testing": ({"id": lab.get("id"), "label": lab.get("label"), "cand_bets": (ev.get("candidate") or {}).get("n", 0),
                         "orig_bets": (ev.get("original") or {}).get("n", 0), "need": ev.get("need", 300),
                         "cand_roi": (ev.get("candidate") or {}).get("roi"), "orig_roi": (ev.get("original") or {}).get("roi"),
                         "days": ev.get("age_days")} if lab.get("status") == "testing" else None),
            "ideas_tested": rec.get("tested", 0)}


def _lb_models(x: Ctx) -> list[dict]:
    return ((x.s.get("litterbox") or {}).get("summary") or {}).get("models") or []


def look_litterbox(x: Ctx) -> dict:
    lb = x.s.get("litterbox") or {}
    ms = _lb_models(x)
    if not ms:
        return {"unavailable": "The Litter Box isn't running, so there are no fake-money results yet."}
    ranked = sorted((m for m in ms if m.get("bets", 0) >= 10), key=lambda m: -(m.get("roi") or 0))
    fmt = lambda m: {"id": m["id"], "name": m["name"], "bets": m.get("bets", 0), "roi": m.get("roi"),  # noqa: E731
                     "se": m.get("se"), "pnl": m.get("pnl"), "group": m.get("group")}
    twin = next((m for m in ms if m["id"] == "twin"), None)
    return {"label": SIM, "as_of": (lb.get("summary") or {}).get("ts"), "running": lb.get("running"), "models": len(ms),
            "fake_bets": sum(m.get("bets", 0) for m in ms), "top": [fmt(m) for m in ranked[:3]],
            "bottom": [fmt(m) for m in ranked[-2:]] if len(ranked) > 3 else [],
            "too_few": [m["name"] for m in ms if m.get("bets", 0) < 10][:6], "twin": fmt(twin) if twin else None}


def look_backtrack(x: Ctx) -> dict:
    r = ((x.s.get("backtrack") or {}).get("results")) or None
    if not r:
        return {"unavailable": "Backtrack hasn't been run yet (it runs every night at 3 AM, or press Run Backtrack)."}
    c, wf = r["current"]["all"], r.get("walk_forward") or {}
    return {"label": HIST, "as_of": r.get("generated_at"), "days": r.get("days"), "contracts": r.get("contracts"),
            "yours": {"bets": c.get("n"), "win_rate": c.get("win_rate"), "roi": c.get("roi"), "se": c.get("se"),
                      "uncertain_fills": c.get("uncertain_fills")},
            "walk_forward": {"verdict": wf.get("verdict"), "chosen_roi": (wf.get("chosen_overall") or {}).get("roi"),
                             "current_roi": (wf.get("current_overall") or {}).get("roi")},
            "proposal": (r.get("proposal") or {}).get("label")}


def look_scorecard(x: Ctx) -> dict:
    sc = x.s.get("scorecard") or {}
    if not sc.get("n"):
        return {"unavailable": "No settled bets yet, so there's no record to judge."}
    return {"label": x.money, "as_of": x.now, "bets": sc["n"], "win_rate": sc.get("win_rate"), "low": sc.get("low"),
            "high": sc.get("high"), "breakeven": sc.get("breakeven"), "net": sc.get("net"), "verdict": sc.get("verdict"),
            "roi": sc.get("roi"), "roi_se": sc.get("roi_se")}


def look_losses(x: Ctx, coin: str | None = None) -> dict:
    ser = [p for p in (x.s.get("series") or []) if not coin or p.get("coin") == coin]
    if not ser:
        return {"unavailable": "No settled bets yet" + (f" on {coin}" if coin else "") + "."}
    losses = [p for p in ser if p["pnl"] < 0]
    n, w = len(ser), len(ser) - len(losses)
    by_coin: dict[str, list] = {}
    for p in losses:
        by_coin.setdefault(p["coin"], []).append(p["pnl"])
    run = best_run = 0
    for p in ser:
        run = run + 1 if p["pnl"] < 0 else 0
        best_run = max(best_run, run)
    recent = ser[-20:]
    rl = sum(1 for p in recent if p["pnl"] < 0)
    q = max(0.01, min(0.99, len(losses) / n))            # the loss rate so far
    # how surprising are the recent losses, if the long-run loss rate held? (binomial tail)
    tail = sum(math.comb(len(recent), k) * q ** k * (1 - q) ** (len(recent) - k) for k in range(rl, len(recent) + 1))
    prices = [p.get("price") for p in losses if p.get("price")]
    return {"label": x.money, "as_of": x.now, "bets": n, "wins": w, "losses": len(losses),
            "lost_total": round(sum(p["pnl"] for p in losses), 2), "avg_loss": round(sum(p["pnl"] for p in losses) / len(losses), 2) if losses else 0,
            "avg_win": round(sum(p["pnl"] for p in ser if p["pnl"] > 0) / w, 2) if w else 0,
            "by_coin": sorted(((k, len(v), round(sum(v), 2)) for k, v in by_coin.items()), key=lambda t: t[2])[:5],
            "longest_losing_run": best_run, "recent_losses": rl, "recent_n": len(recent), "recent_tail_prob": tail,
            "avg_loss_price": (sum(prices) / len(prices)) if prices else None,
            "last_losses": [{"coin": p["coin"], "side": p["outcome"], "pnl": p["pnl"], "ts": p["ts"]} for p in losses[-4:]][::-1]}


def look_market(x: Ctx, coin: str | None = None) -> dict:
    rows = [c for c in (x.s.get("coins") or []) if not coin or c.get("coin") == coin]
    if not rows:
        return {"unavailable": f"I'm not watching {coin} — it isn't one of your coins." if coin else "No prices yet."}
    return {"label": LIVE, "as_of": max((c.get("book_ts") or 0) for c in rows) or x.now,
            "coins": [{"coin": c["coin"], "up_ask": c.get("up_ask"), "down_ask": c.get("down_ask"),
                       "closes_in_s": c.get("secs_left"), "book_ts": c.get("book_ts")} for c in rows]}


def look_compare(x: Ctx, a: str | None, b: str | None) -> dict:
    ms = _lb_models(x)
    find = lambda q: next((m for m in ms if q and (q.lower() in m["name"].lower() or q.lower() == m["id"])), None)  # noqa: E731
    ma, mb = find(a), find(b)
    if not ma or not mb:
        return {"unavailable": "I need two Litter Box models to compare (for example “compare Ask Buyer and Down Dog”)."}
    diff = (ma.get("roi") or 0) - (mb.get("roi") or 0)
    noise = math.sqrt((ma.get("se") or 0) ** 2 + (mb.get("se") or 0) ** 2) or None
    return {"label": SIM, "as_of": ((x.s.get("litterbox") or {}).get("summary") or {}).get("ts"),
            "a": {k: ma.get(k) for k in ("name", "bets", "roi", "se", "pnl")}, "b": {k: mb.get(k) for k in ("name", "bets", "roi", "se", "pnl")},
            "diff": diff, "noise": noise, "clear": bool(noise and abs(diff) > 2 * noise)}


def look_recap(x: Ctx, day: str = "today") -> dict:
    r = catnap.recap(x.bot, day, (x.s.get("litterbox") or {}).get("summary"))
    return {"label": x.money, **r}


LOOKUPS = {"account": look_account, "positions": look_positions, "activity": look_activity, "status": look_status,
           "why_no_bet": look_why_no_bet, "stop_history": look_stop_history, "risk": look_risk, "strategy": look_strategy,
           "litterbox": look_litterbox, "backtrack": look_backtrack, "scorecard": look_scorecard, "losses": look_losses,
           "market": look_market, "compare": look_compare, "recap": look_recap}


async def refresh_market(bot, coin: str | None = None) -> None:
    """Fetch current prices from Kalshi now (read-only) for the contract each coin shows, so a market answer is
    fresh even outside the betting window. Only fills in the price fields the app already shows."""
    from .engine import _s
    for e in bot.engines:
        if coin and e.coin != coin:
            continue
        t = e.status.get("contract")
        c = e.contracts.get(t) if t else None
        if not c:
            continue
        try:
            book = await bot.md.get_orderbook(t)
        except Exception:  # noqa: BLE001 - keep whatever the engine last saw
            continue
        up, dn = c.leg_of("UP"), c.leg_of("DOWN")
        e.status.update({"up_bid": _s(book.best_bid(up)), "up_ask": _s(book.best_ask(up)),
                         "down_bid": _s(book.best_bid(dn)), "down_ask": _s(book.best_ask(dn)), "book_ts": book.fetched_at})


# ---- understanding the question --------------------------------------------------------------------
INTENTS = [
    # intent, home cat, phrases (more specific first)
    ("stopped", "chonk", ["why did trading stop", "why did it stop", "why stopped", "trading stop", "stopped trading",
                          "not trading", "why is it off", "why paused", "kill switch", "halted", "why stop", "stopped"]),
    ("nobet", "chonk", ["why no bet", "why not bet", "why isn't it betting", "why isnt it betting", "no bets", "not betting",
                        "why no trade", "isn't trading", "no trades", "why hasn't it", "why hasnt it"]),
    ("away", "biscuit", ["while i was away", "what happened", "since i left", "catch me up", "what did i miss",
                         "while away", "overnight", "since last", "anything happen"]),
    ("recap", "biscuit", ["recap", "daily summary", "today's results", "todays results", "how did i do", "how was today",
                          "how did today", "yesterday"]),
    ("experiment", "chill", ["create an experiment", "create experiment", "start an experiment", "paper experiment",
                             "test it at", "try it at", "with fake money", "fake money test", "make a copy"]),
    ("clump", "chonk", ["set clump", "change clump", "clump to", "switch to bold", "switch to tiny", "risk level to",
                        "preview", "lower my risk", "less risk", "more risk", "raise my risk", "change risk"]),
    ("compare", "katya", ["compare", " vs ", "versus", "difference between", "better than"]),
    ("unusual", "katya", ["unusual", "weird", "strange", "odd", "anomal", "suspicious", "doesn't make sense", "not normal"]),
    ("losses", "katya", ["why did i lose", "losing", "loss", "lost", "losses", "bad day", "drawdown", "down money"]),
    ("recommend", "chill", ["recommend", "should i switch", "should i change", "better strategy", "which strategy",
                            "best model", "does it support", "is it proven", "worth switching"]),
    ("backtrack", "chill", ["backtrack", "backtest", "past data", "historical", "history test"]),
    ("litterbox", "chill", ["litter box", "litterbox", "experiment", "models", "leaderboard", "simulated", "fake money", "twin"]),
    ("strategy", "chill", ["strategy", "how does it work", "how does the bot", "what does it bet", "favourite", "favorite", "rule"]),
    ("risk", "chonk", ["risk", "exposure", "limit", "clump", "how much can i lose", "safe", "daily stop", "per bet", "cap"]),
    ("working", "chonk", ["is it working", "making money", "profitable", "scorecard", "edge", "win rate", "winning"]),
    ("market", "biscuit", ["price", "market", "odds", "right now on", "how much is", "quote"]),
    ("positions", "biscuit", ["position", "open bet", "holding", "in play", "waiting bid", "current bet"]),
    ("balance", "biscuit", ["balance", "how much money", "how much do i have", "cash", "equity", "funds", "account", "worth"]),
    ("activity", "biscuit", ["recent", "activity", "last bets", "trades", "history", "fills", "today"]),
    ("status", "chonk", ["status", "is it running", "is it on", "what's it doing", "whats it doing", "doing now", "alive"]),
    ("help", None, ["help", "what can you", "what do you know", "hello", "hi ", "hey", "who are you"]),
]
HOME = {i: c for i, c, _ in INTENTS}


def understand(q: str) -> tuple[str, dict]:
    """(intent, details) — details: coin, level, model names, day."""
    t = " " + re.sub(r"\s+", " ", q.lower().replace("’", "'")) + " "
    best, score = "help", 0
    for intent, _, phrases in INTENTS:
        s = sum(len(p) for p in phrases if p in t)
        if s > score:
            best, score = intent, s
    det: dict = {}
    for c in COINS:
        if re.search(rf"\b{c.lower()}\b", t):
            det["coin"] = c
            break
    for i, n in enumerate(LEVEL_NAMES):
        if re.search(rf"\b{n}\b", t):
            det["level"] = i + 1
    m = re.search(r"\blevel (\d)\b", t)
    if m:
        det["level"] = int(m.group(1))
    det["day"] = "yesterday" if "yesterday" in t else "today"
    if best == "help" and det.get("coin"):
        best = "market"
    if best == "risk" and det.get("level") and re.search(r"\b(set|change|switch|use|preview|go to|move to|try)\b", t):
        best = "clump"
    return best, det


# ---- personalities (same facts, different voice) -----------------------------------------------------
VOICE = {
    "biscuit": {"hi": "Biscuit here! I keep an eye on the money.", "good": "Good news, fish for dinner!",
                "bad": "Not our best day, but the bets were small.", "neutral": "Here's what I see:",
                "unknown": "Hmm, I don't have that one. I'd rather say so than make it up.", "away": "Welcome back! While you were gone:"},
    "chonk": {"hi": "Le Chonk. Risk is the weight on the bar; I spot it.", "good": "Clean lift. Form looks good.",
              "bad": "Heavy set. Here's what's on the bar.", "neutral": "Spotting it now:",
              "unknown": "No data on the bar for that. I won't guess.", "away": "Recovery report:"},
    "chill": {"hi": "Le Chill. I read the experiments so you don't have to.", "good": "Nice. Very nice. But let's not get excited.",
              "bad": "Eh. Not great, not a disaster.", "neutral": "Okay, here's the deal:",
              "unknown": "I don't know that one, and I'm too relaxed to make it up.", "away": "While you were out, nothing rattled me. Here:"},
    "katya": {"hi": "Privet, I am Katya. I investigate the strange things.", "good": "Is good. No mystery here.",
              "bad": "Something to investigate. Let us look calmly.", "neutral": "Let us look at the evidence:",
              "unknown": "This I cannot know from what the app has. I will not invent it.", "away": "While you were away, I kept notes:"},
}


def _act(kind: str, label: str, **kw) -> dict:
    return {"type": kind, "label": label, **kw}


def _rt(x: Ctx, ts) -> str:
    return time.strftime("%H:%M", time.localtime(ts)) if ts else "–"


# ---- composing answers ---------------------------------------------------------------------------------
def answer(bot, state: dict, question: str, cat: str | None = None, since: float | None = None) -> dict:
    x = Ctx(bot, state, since)
    intent, det = understand(question)
    home = HOME.get(intent) or "biscuit"
    who = cat if cat in CATS else home
    if who == "katya" and not (state.get("ui") or {}).get("katya") and cat != "katya":
        who = "biscuit"
    v = VOICE[who]
    blocks, evidence, actions, unavailable, tone, text, uncertainty = [], [], [], [], "neutral", "", None
    used: list[str] = []

    def L(name, *a):
        used.append(name)
        r = LOOKUPS[name](x, *a)
        if "unavailable" in r:
            unavailable.append(r["unavailable"])
        return r

    if intent in ("stopped", "status"):
        st = L("status")
        hist = L("stop_history")
        stopped = st["level"] in ("paused", "offline", "attention")
        tone = "bad" if stopped else "good"
        text = (f"{st['headline']}. {st['detail']}" if intent == "stopped" or stopped else
                f"It's {st['title'].lower()}: {st['detail']}")
        if intent == "stopped" and not stopped:
            text = f"Trading hasn't stopped: it's {st['title'].lower()}. {st['detail']}"
            day0 = time.mktime(time.localtime(x.now)[:3] + (0, 0, 0, 0, 0, -1))
            earlier = next((e for e in hist["events"] if e["ts"] >= day0 and e["kind"] in
                            ("daily_loss", "kill", "halt", "pause", "turned_off", "recovering", "engine_error")), None)
            if earlier:
                what = {"daily_loss": "hit the daily loss limit", "kill": "had the kill switch on", "halt": "paused itself to check an order",
                        "pause": "was paused", "turned_off": "was turned off", "recovering": "re-checked with Kalshi after a gap",
                        "engine_error": "had an error"}[earlier["kind"]]
                text += f" Earlier today, at {_rt(x, earlier['ts'])}, it {what}."
        blocks.append(block(APP, [f"Status: {st['title']} — {st['headline']}", st["detail"],
                                  st["next_step"] and f"Next step: {st['next_step']}"], x.now))
        ev = [f"{_rt(x, e['ts'])} · {e['message']}" for e in hist["events"][:5]]
        if ev:
            blocks.append(block("From the bot's log", ev, x.now))
        if st.get("action"):
            a = st["action"]
            actions.append(_act(a["type"], {"resume": "Resume betting", "whynobet": "Why no bet?"}.get(a["type"], "Open it"),
                                **{k: v2 for k, v2 in a.items() if k != "type"}))
        actions.append(_act("open", "Open Warnings", target="section:sec-warn"))
    elif intent == "nobet":
        w = L("why_no_bet")
        st = L("status")
        blocks.append(block(APP, [f"{c['coin']}: {c['plain']}" for c in w["coins"]], x.now))
        kinds = {c["kind"] for c in w["coins"]}
        text = ("Right now no coin is ready for a bet. " if "betting" not in kinds else "One is in play right now. ") + \
               ("Mostly it's timing: bets only open near the end of each 15-minute contract." if kinds <= {"timing"} else
                "The reasons are listed per coin below, straight from the strategy and the risk checks.")
        if st["level"] in ("paused", "attention", "offline"):
            text = f"{st['headline']}: {st['detail']} " + text
        actions.append(_act("open", "Open Right now", target="section:sec-now"))
    elif intent in ("balance", "positions"):
        a = L("account")
        pz = L("positions")
        if "unavailable" not in a:
            blocks.append(block(a["label"], [f"Total balance {_m(a['equity'])} (cash {_m(a['cash'])}, in bets {_m(a['in_bets'])})",
                                             a.get("today_pnl") and f"Today so far {_m(a['today_pnl'], True)}",
                                             f"Bot may use up to {_m(a['cap'])}" if a.get("cap") else None], a["as_of"]))
            text = f"You have {_m(a['equity'])} in total" + (f", {_m(a['today_pnl'], True)} today" if a.get("today_pnl") else "") + "."
        hold = [f"{h['coin']} {h['side'].title()}: {h['qty']} × {_c(h['price'])} = {_m(h['cost'])}, pays {_m(h['pays_if_win'])} if it wins"
                + (f", result in {int(h['result_in_s'] // 60)}:{int(h['result_in_s'] % 60):02d}" if h.get("result_in_s") and h["result_in_s"] > 0 else "")
                for h in pz["holding"]]
        hold += [f"Waiting bid: {w2['coin']} {w2['side'].title()} at {_c(w2['price'])} × {w2['count']}" for w2 in pz["waiting_bids"]]
        blocks.append(block(pz["label"], hold or ["No open bets or waiting bids right now."], pz["as_of"]))
        if pz["holding"]:
            text += f" {len(pz['holding'])} bet{'s' if len(pz['holding']) > 1 else ''} in play."
    elif intent in ("activity", "away"):
        since = since or (x.now - (12 * 3600 if intent == "away" else 86400))
        a = L("activity", since)
        st = L("status")
        tone = "good" if a["pnl"] > 0 else "bad" if a["pnl"] < 0 else "neutral"
        items = [f"{a['settled']} bets settled: {a['wins']} won, {a['losses']} lost, {_m(a['pnl'], True)}"]
        items += [f"{_rt(x, p['ts'])} · {p['coin']} {p['side'].title()} {_m(p['pnl'], True)}" for p in a["last"]]
        blocks.append(block(a["label"], items, x.now, f"Since {time.strftime('%a %H:%M', time.localtime(since))}"))
        if a["notable_events"]:
            blocks.append(block("From the bot's log", [f"{_rt(x, e['ts'])} · {e['message']}" for e in a["notable_events"]], x.now))
        blocks.append(block(APP, [f"Now: {st['title']} — {st['detail']}"], x.now))
        text = (v["away"] + " " if intent == "away" else "") + \
               (f"{a['settled']} bets settled for {_m(a['pnl'], True)}." if a["settled"] else "No bets settled in that time.")
        actions.append(_act("recap", "Open today's recap"))
    elif intent == "recap":
        r = L("recap", det.get("day", "today"))
        tone = "good" if float(r["pnl"]) > 0 else "bad" if float(r["pnl"]) < 0 else "neutral"
        items = [f"{r['bets']} bets: {r['wins']} won, {r['losses']} lost", f"Profit/loss {_m(r['pnl'], True)} (fees {_m(r['fees'])})",
                 r["best_coin"] and f"Best coin {r['best_coin'][0]} {_m(r['best_coin'][1], True)}",
                 r["worst_coin"] and f"Worst coin {r['worst_coin'][0]} {_m(r['worst_coin'][1], True)}",
                 f"Open now: {len(r['open_positions'])}"]
        blocks.append(block(r["label"], items, r["as_of"], r["day"]))
        if r["litterbox"]:
            lb = r["litterbox"]
            blocks.append(block(SIM, [f"{lb['models']} models, {lb['fake_bets']} fake bets so far",
                                      lb["leader"] and f"Leader: {lb['leader']['name']} {_pct(lb['leader']['roi'])} per $ over {lb['leader']['bets']} bets",
                                      lb["twin"] and f"Simulated you: {_m(lb['twin']['pnl'], True)} over {lb['twin']['bets']} bets"], lb["as_of"]))
        text = f"{r['day']}: {r['bets']} bets, {_m(r['pnl'], True)} after fees."
        actions.append(_act("recap", "Open the full recap", day=det.get("day", "today")))
    elif intent == "risk" or intent == "clump":
        r = L("risk")
        blocks.append(block(r["label"], [r["level"] and f"Clump level: {r['level']}",
                                         f"Most per bet {_m(r['per_bet'])}; up to {r['max_open']} bets open at once",
                                         r["exposure_pct"] and f"Most at risk at once: {float(r['exposure_pct']) * 100:.0f}% of {_m(r['cap'])}",
                                         r["daily_stop_pct"] and f"Daily stop: {float(r['daily_stop_pct']) * 100:.0f}% of the cap",
                                         r["exposure_now"] is not None and f"At risk right now: {_m(r['exposure_now'])} in {r['open_now']} bet(s)",
                                         r["pending_limits"] and "New limits are waiting for your typed confirmation"], x.now))
        text = f"You're on {r['level'] or 'custom'} limits: up to {_m(r['per_bet'])} a bet, {r['max_open']} at once."
        if r["kill"] or r["paused"] or r["daily_loss_hit"]:
            text += " Trading is stopped right now (" + ", ".join(k for k, on in (("kill switch", r["kill"]), ("paused", r["paused"]),
                                                                                   ("daily stop", r["daily_loss_hit"])) if on) + ")."
        if intent == "clump" or det.get("level"):
            lv = det.get("level")
            if lv:
                actions.append(_act("preview_clump", f"Preview {LEVEL_NAMES[lv - 1].title()}", level=lv))
                text += f" Here's a preview of {LEVEL_NAMES[lv - 1].title()}; nothing changes until you apply it."
            else:
                actions += [_act("preview_clump", f"Preview {n.title()}", level=i + 1) for i, n in enumerate(LEVEL_NAMES)]
        uncertainty = "Limits cap how much you can lose; they don't change which bets are taken or the odds."
    elif intent == "working":
        sc = L("scorecard")
        if "unavailable" not in sc:
            blocks.append(block(sc["label"], [f"{sc['bets']} bets, win rate {float(sc['win_rate']) * 100:.1f}% "
                                              f"(likely range {float(sc['low']) * 100:.1f}–{float(sc['high']) * 100:.1f}%)",
                                              f"Needed to break even (fees in): {float(sc['breakeven']) * 100:.1f}%",
                                              f"Net {_m(sc['net'], True)}"], sc["as_of"]))
            verdict = {"ahead": "ahead of break-even by more than luck", "behind": "behind break-even",
                       "early": "too early to tell", "unclear": "too close to call"}.get(sc.get("verdict"), "not clear yet")
            tone = "good" if sc.get("verdict") == "ahead" else "bad" if sc.get("verdict") == "behind" else "neutral"
            text = f"Honest answer: it's {verdict}."
            uncertainty = "The likely range is the span luck alone could explain; it shrinks as more bets settle."
        bt = L("backtrack")
        if "unavailable" not in bt:
            blocks.append(block(HIST, [f"Your rule on {bt['contracts']:,} past contracts: {_pct(bt['yours']['roi'])} per $ "
                                       f"(± {float(bt['yours']['se'] or 0) * 200:.1f}%)",
                                       bt["yours"].get("uncertain_fills") and "Fills at the bid are estimates in past data"], bt["as_of"]))
    elif intent in ("strategy", "recommend", "backtrack"):
        s = L("strategy")
        blocks.append(block(APP, [s["live_strategy"] and "Your bot: " + " · ".join(s["live_strategy"]),
                                  "That's the original strategy" if s["is_original"] else "Not the original strategy"], x.now))
        if intent in ("recommend", "strategy"):
            if s["recommended"]:
                r = s["recommended"]
                blocks.append(block(SIM, [f"Recommended: {r['label']}", f"On new markets: {_pct(r['fresh_roi'])} per $ over {r['fresh_bets']} fake bets in {r['days']} days"]))
                text = "There is a recommendation, and it earned it on markets it hadn't seen."
                uncertainty = "Fake fills can be kinder than real ones; a recommendation is evidence, not a promise."
            else:
                t2 = s["testing"]
                items = [f"{s['ideas_tested']} idea(s) tested so far; none proven yet"]
                if t2:
                    items.append(f"Testing #{t2['id']}: {t2['label']}")
                    items.append(f"Fresh bets: candidate {t2['cand_bets']}, original {t2['orig_bets']} of {t2['need']} each needed")
                    if t2["cand_roi"] is not None and t2["orig_roi"] is not None:
                        items.append(f"So far: candidate {_pct(t2['cand_roi'])} vs original {_pct(t2['orig_roi'])} per $")
                blocks.append(block(SIM, items))
                text = "No — nothing has earned a recommendation yet. Results so far don't support switching."
                uncertainty = "An idea needs enough fresh bets on both sides and must beat the original by more than luck."
            actions.append(_act("open", "Open Recommended preset", target="section:sec-preset"))
        bt = L("backtrack")
        if "unavailable" not in bt:
            blocks.append(block(HIST, [f"{bt['days']:g} days, {bt['contracts']:,} contracts: yours {_pct(bt['yours']['roi'])} per $",
                                       bt["walk_forward"]["verdict"] and f"Fair test (walk-forward): picked settings {_pct(bt['walk_forward']['chosen_roi'])} "
                                       f"vs yours {_pct(bt['walk_forward']['current_roi'])} → {bt['walk_forward']['verdict']}",
                                       bt["proposal"] and f"Next idea to test: {bt['proposal']}"], bt["as_of"]))
            if intent == "backtrack":
                text = text or f"Backtrack replayed {bt['contracts']:,} real past contracts. Past results are estimates, not promises."
                actions.append(_act("open", "Open Backtrack", target="section:sec-backtrack"))
        if intent == "strategy" and not text:
            text = "It waits at the bid for the favourite in the last few minutes of each 15-minute contract, then holds to the result."
    elif intent in ("litterbox", "experiment"):
        lb = L("litterbox")
        if "unavailable" not in lb:
            items = [f"{lb['models']} models, {lb['fake_bets']} fake bets"]
            items += [f"#{i + 1} {m['name']}: {_pct(m['roi'])} per $ (± {float(m['se'] or 0) * 200:.1f}%) over {m['bets']} bets"
                      for i, m in enumerate(lb["top"])]
            if lb["twin"]:
                items.append(f"Simulated you: {_m(lb['twin']['pnl'], True)} over {lb['twin']['bets']} bets")
            blocks.append(block(SIM, items, lb["as_of"]))
            lead = lb["top"][0] if lb["top"] else None
            text = (f"{lead['name']} leads, but " + ("that's within luck." if lead["se"] and abs(lead["roi"]) < 2 * lead["se"] else "check the ± range.")
                    if lead else "Too early to rank the models (they need 10+ bets each).")
            uncertainty = "Litter Box uses fake money and simulated fills on live prices; a few days of results can be luck."
        actions.append(_act("open", "Open Litter Box", target="tab:litter"))
        if intent == "experiment":
            ms = _lb_models(x)
            base = next((m for m in ms if not m.get("base") and m["name"].lower() in question.lower()), None) \
                or next((m for m in ms if m["id"] == "original"), None)
            lv = det.get("level") or 1
            if base:
                actions.insert(0, _act("experiment", f"Create: {base['name']} at {LEVEL_NAMES[lv - 1].title()} (fake money)",
                                       base=base["id"], level=lv))
                text = (f"I can start a fake-money copy of {base['name']} at the {LEVEL_NAMES[lv - 1].title()} risk level. "
                        "Click the button to create it; it runs in the Litter Box next to the original.")
    elif intent == "losses":
        lo = L("losses", det.get("coin"))
        if "unavailable" not in lo:
            tone = "bad" if lo["losses"] else "good"
            items = [f"{lo['losses']} losses in {lo['bets']} bets, {_m(lo['lost_total'], True)} lost in total",
                     f"Average loss {_m(lo['avg_loss'])} vs average win {_m(lo['avg_win'])}",
                     f"Longest losing run: {lo['longest_losing_run']}"]
            items += [f"{c}: {n} loss(es), {_m(t, True)}" for c, n, t in lo["by_coin"]]
            items += [f"{_rt(x, p['ts'])} · {p['coin']} {p['side'].title()} {_m(p['pnl'], True)}" for p in lo["last_losses"]]
            blocks.append(block(lo["label"], items, lo["as_of"]))
            ratio = abs(lo["avg_loss"] / lo["avg_win"]) if lo["avg_win"] else None
            text = (f"Each loss costs about {ratio:.0f} wins — that's the shape of this strategy: many small wins, rare big losses. "
                    if ratio else "") + (f"The last {lo['recent_n']} bets had {lo['recent_losses']} loss(es)." if lo["recent_n"] else "")
            uncertainty = (f"If your long-run loss rate held, {lo['recent_losses']}+ losses in {lo['recent_n']} bets would happen "
                           f"about {lo['recent_tail_prob'] * 100:.0f}% of the time — " +
                           ("not unusual." if lo["recent_tail_prob"] > 0.1 else "unusual enough to keep an eye on."))
        actions.append(_act("open", "Open Each bet", target="section:sec-each"))
        actions.append(_act("ask", "Is it working overall?", text="Is it working?"))
    elif intent == "unusual":
        lo = L("losses")
        sc = L("scorecard")
        lb = L("litterbox")
        items = []
        if "unavailable" not in lo:
            items.append(f"Recent losses: {lo['recent_losses']} of the last {lo['recent_n']} "
                         f"({lo['recent_tail_prob'] * 100:.0f}% chance by luck alone at your usual loss rate)")
        if "unavailable" not in lb and lb["twin"] and "unavailable" not in sc:
            items.append(f"Simulated you vs real over its run: {_m(lb['twin']['pnl'], True)} simulated — "
                         "a big gap usually means fills differ (the sim guesses whether a waiting bid was hit)")
        w = L("why_no_bet")
        errs = [c for c in w["coins"] if c["kind"] == "attention"]
        if errs:
            items.append("Coins with trouble right now: " + ", ".join(c["coin"] for c in errs))
        blocks.append(block("Investigation", items or ["Nothing stands out in the data I can see."], x.now))
        text = "I checked the loss rate, the simulated twin and each coin's status." + (
            " Something looks off — details below." if any("unusual" in i or "trouble" in i for i in items) else " Nothing looks out of the ordinary.")
    elif intent == "compare":
        names = re.split(r"\b(?:vs\.?|versus|and|with|to|against)\b", question, flags=re.I)
        ms = _lb_models(x)
        found = [m["name"] for m in ms if m["name"].lower() in question.lower()]
        a, b = (found + [None, None])[:2] if len(found) >= 2 else ((names[0].replace("compare", "").strip(" ?") if names else None),
                                                                  (names[1].strip(" ?") if len(names) > 1 else None))
        c = L("compare", a, b)
        if "unavailable" not in c:
            items = [f"{c['a']['name']}: {_pct(c['a']['roi'])} per $ over {c['a']['bets']} bets ({_m(c['a']['pnl'], True)})",
                     f"{c['b']['name']}: {_pct(c['b']['roi'])} per $ over {c['b']['bets']} bets ({_m(c['b']['pnl'], True)})",
                     f"Difference {_pct(c['diff'])} per $" + (f", luck range ± {c['noise'] * 200:.1f}%" if c["noise"] else "")]
            blocks.append(block(SIM, items, c["as_of"]))
            leader = c["a"]["name"] if c["diff"] > 0 else c["b"]["name"]
            text = f"{leader} is ahead" + (" by more than luck." if c["clear"] else ", but within luck — not a real difference yet.")
            uncertainty = "Both are fake-money results with simulated fills."
    elif intent == "market":
        mk = L("market", det.get("coin"))
        if "unavailable" not in mk:
            items = [f"{c['coin']}: Up {_c(c['up_ask'])} · Down {_c(c['down_ask'])}" +
                     (f" · closes in {int(c['closes_in_s'] // 60)}:{int(c['closes_in_s'] % 60):02d}" if c.get("closes_in_s") else "")
                     for c in mk["coins"]]
            have = [c for c in mk["coins"] if c.get("up_ask") or c.get("down_ask")]
            blocks.append(block(LIVE, items, mk["as_of"] if have else None, "Ask prices for the contract closing next"))
            text = (("Prices from Kalshi" + (f", read {_ago(mk['as_of'], x.now)}" if mk["as_of"] else "") + ":") if have else
                    "Kalshi isn't showing prices for that contract right now (no offers yet, or it's between contracts).")
            if not have:
                unavailable.append("No current prices.")
    else:  # help
        text = (f"{v['hi']} Ask me things like: “What happened while I was away?”, “Why did trading stop?”, “Why no bet?”, "
                "“How much risk am I taking?”, “Should I switch strategies?”, “Why did I lose?” or “Daily recap”.")
        actions += [_act("ask", q2, text=q2) for q2 in ("What happened while I was away?", "Why no bet?", "Is it working?", "Daily recap")]

    if not blocks and unavailable:
        text = v["unknown"] + " " + " ".join(unavailable)
        tone = "neutral"
    intro = v["good"] if tone == "good" else v["bad"] if tone == "bad" else v["neutral"]
    if intent == "help":
        intro = ""
    if who != home and intent not in ("help",):
        intro = f"(This is {NAMES[home]}'s area, but the facts are the same.) " + intro
    return {"cat": who, "name": NAMES[who], "intent": intent, "intro": intro, "text": text.strip(), "blocks": blocks,
            "uncertainty": uncertainty, "unavailable": unavailable, "actions": actions[:5], "lookups": used,
            "asked_at": x.now, "mode": "local"}
