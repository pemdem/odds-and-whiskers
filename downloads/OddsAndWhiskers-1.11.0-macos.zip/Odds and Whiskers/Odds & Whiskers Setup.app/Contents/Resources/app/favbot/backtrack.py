"""Backtrack: replay the favourite strategy on Kalshi's public price history.

Read-only. Downloads settled 15-minute contracts and their 1-minute bid/ask candles
(GET /markets, GET /markets/candlesticks), caches them in data/backtrack/cache.sqlite3, and replays the rule:

  at each minute mark inside the window, the favourite (ask in band, spread ok) gets a bid at its best bid;
  it fills only if, during the next minute, the best offer trades strictly through that bid (never on a touch);
  once filled, hold to the official result. Maker fills on these series pay no fee.
  Minute data can't show whether that cross came within the real bid's 20 seconds, so every resting-bid fill
  here is an ESTIMATE (marked uncertain). Buying at the ask has no such question.

Then it tries a grid of settings. To avoid fooling ourselves, settings are chosen on the older 70% of
contracts ("train") and judged on the newest 30% ("test"). A change is suggested only if it beats the
current settings on the test period by more than twice the statistical noise.
"""
from __future__ import annotations

import asyncio
import itertools
import json
import math
import os
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path

from .config import PROD_URL
from .models import parse_ts
from .providers.kalshi import DOWN_STRIKES, UP_STRIKES, KalshiAPI

TRAIN_SHARE = 0.7


# ---- data ---------------------------------------------------------------------------------
class Cache:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path)
        self.db.executescript("""
          CREATE TABLE IF NOT EXISTS contracts(ticker TEXT PRIMARY KEY, series TEXT, close_ts INTEGER, yes_is_up INTEGER,
            result TEXT, has_candles INTEGER DEFAULT 0);
          CREATE TABLE IF NOT EXISTS candles(ticker TEXT, end_ts INTEGER, bid_c REAL, ask_c REAL, bid_h REAL, ask_l REAL,
            PRIMARY KEY(ticker, end_ts));""")

    def add_contract(self, t, series, close_ts, up, result):
        self.db.execute("INSERT OR IGNORE INTO contracts(ticker,series,close_ts,yes_is_up,result) VALUES(?,?,?,?,?)",
                        (t, series, close_ts, int(up), result))

    def missing(self, since):
        return [r for r in self.db.execute(
            "SELECT ticker, close_ts FROM contracts WHERE has_candles=0 AND close_ts>=? ORDER BY close_ts", (since,))]

    def add_candles(self, ticker, rows):
        self.db.executemany("INSERT OR REPLACE INTO candles VALUES(?,?,?,?,?,?)", [(ticker, *r) for r in rows])
        self.db.execute("UPDATE contracts SET has_candles=1 WHERE ticker=?", (ticker,))

    def load(self, since) -> list[dict]:
        cs = {}
        for t, s, close, up, res in self.db.execute(
                "SELECT ticker,series,close_ts,yes_is_up,result FROM contracts WHERE has_candles=1 AND close_ts>=?", (since,)):
            cs[t] = {"ticker": t, "series": s, "coin": s[2:-3], "close": close, "up": bool(up), "result": res, "c": {}}
        for t, end, bc, ac, bh, al in self.db.execute(
                "SELECT c.* FROM candles c JOIN contracts k ON k.ticker=c.ticker WHERE k.close_ts>=?", (since,)):
            if t in cs:
                cs[t]["c"][end] = (bc, ac, bh, al)
        return sorted(cs.values(), key=lambda c: c["close"])


def _f(x):
    try:
        return float(x) if x not in (None, "") else None
    except (TypeError, ValueError):
        return None


async def download(series: list[str], days: float, cache: Cache, status, rate: float = 1.0) -> None:
    api = KalshiAPI(PROD_URL, read_only=True, requests_per_s=rate)
    api.limiter.capacity = 2.0
    try:
        now = int(time.time())
        since = now - int(days * 86400)
        for i, s in enumerate(series):
            status(f"Listing settled {s[2:-3]} contracts", 5 + 25 * i / len(series))
            cursor = None
            for _ in range(30):
                j = await api.request("GET", "/markets", params={"series_ticker": s, "status": "settled",
                                                                 "min_settled_ts": since, "limit": 1000, "cursor": cursor})
                for m in j.get("markets") or []:
                    o, c = parse_ts(m.get("open_time")), parse_ts(m.get("close_time"))
                    st = m.get("strike_type")
                    if (m.get("market_type") != "binary" or not o or not c or round(c - o) != 900
                            or m.get("result") not in ("yes", "no") or st not in UP_STRIKES | DOWN_STRIKES):
                        continue
                    cache.add_contract(m["ticker"], s, int(c), st in UP_STRIKES, m["result"])
                cursor = j.get("cursor")
                if not cursor:
                    break
            cache.db.commit()
        todo = cache.missing(since)
        # The endpoint caps a request at 10,000 candles counted as tickers x minutes in the window, so keep
        # batches to <= 96 tickers whose closes span at most an hour (96 x 67 min = 6,432).
        batches, cur = [], []
        for t, close in todo:
            if cur and (len(cur) >= 96 or close - cur[0][1] > 3600):
                batches.append(cur); cur = []
            cur.append((t, close))
        if cur:
            batches.append(cur)
        for bi, b in enumerate(batches):
            status(f"Downloading prices ({bi + 1}/{len(batches)})", 30 + 65 * bi / max(1, len(batches)))
            j = await api.request("GET", "/markets/candlesticks", params={
                "market_tickers": ",".join(t for t, _ in b), "start_ts": b[0][1] - 420, "end_ts": b[-1][1],
                "period_interval": 1}, cost=len(b))
            for m in j.get("markets") or []:
                rows = []
                for k in m.get("candlesticks") or []:
                    yb, ya = k.get("yes_bid") or {}, k.get("yes_ask") or {}
                    rows.append((int(k["end_period_ts"]), _f(yb.get("close_dollars")), _f(ya.get("close_dollars")),
                                 _f(yb.get("high_dollars")), _f(ya.get("low_dollars"))))
                cache.add_candles(m["market_ticker"], rows)
            for t, _ in b:   # mark tickers the API returned nothing for, so we don't refetch forever
                cache.db.execute("UPDATE contracts SET has_candles=1 WHERE ticker=?", (t,))
            cache.db.commit()
    finally:
        await api.close()


# ---- replay -------------------------------------------------------------------------------
@dataclass(frozen=True)
class Params:
    ask_min: float = 0.88
    ask_max: float = 0.97
    max_spread: float = 0.03
    window_s: int = 300
    side: str = "both"          # both | up | down
    mode: str = "bid"           # bid = rest at the best bid (no fee) | ask = buy at the ask (taker fee)
    window_end_s: int = 60      # stop placing new bets when this many seconds are left

    def label(self) -> str:
        w = f"last {self.window_s // 60} min" if self.window_end_s == 60 else \
            f"{self.window_s // 60}–{self.window_end_s // 60} min left"
        s = "" if self.side == "both" else f", {self.side.upper()} only"
        m = "buy at the ask" if self.mode == "ask" else "wait at the bid"
        return f"{m}, {self.ask_min * 100:.0f}–{self.ask_max * 100:.0f}¢, spread ≤{self.max_spread * 100:.0f}¢, {w}{s}"


CURRENT = Params()
MAX_K = 5
BET_USD = 4.0


def prepare(contracts: list[dict]) -> list[tuple]:
    """Precompute, per contract and minute mark, the prices and whether a resting bid would have filled.
    Each contract becomes (ticker, coin, close, up, result, {k: (yb, ya, fill_yes, fill_no)})."""
    out = []
    for c in contracts:
        close, cand, ev = c["close"], c["c"], {}
        for k in range(MAX_K, 1, -1):
            now, nxt = cand.get(close - 60 * k), cand.get(close - 60 * k + 60)
            if not now or now[0] is None or now[1] is None:
                continue
            yb, ya = now[0], now[1]
            fy = bool(nxt and nxt[3] is not None and nxt[3] < yb - 1e-9)                 # YES ask traded through the YES bid
            fn = bool(nxt and nxt[2] is not None and (1 - nxt[2]) < (1 - ya) - 1e-9)     # NO ask (1-YES bid) through the NO bid
            # 'sustained' crosses: still through at the minute's close. Stricter, but NOT proof: the real bid lives
            # 20 seconds, and minute data can't say whether the cross came inside those 20 seconds. Every
            # resting-bid fill in Backtrack is therefore an estimate; 'sustained' is only a stress test.
            fyc = bool(fy and nxt[1] is not None and nxt[1] < yb - 1e-9)
            fnc = bool(fn and nxt[0] is not None and (1 - nxt[0]) < (1 - ya) - 1e-9)
            ev[k] = (yb, ya, fy, fn, nxt is not None, fyc, fnc)
        out.append((c["ticker"], c["coin"], close, c["up"], c["result"], ev))
    return out


def replay_fast(prep: list[tuple], p: Params, taker: bool = False, strict: bool = False,
                bet_usd: float = BET_USD) -> list[dict]:
    """strict: count a resting bid only when the cross was still there at the minute's close (stress test)."""
    taker = taker or p.mode == "ask"
    lo, hi, sp = p.ask_min - 1e-9, p.ask_max + 1e-9, p.max_spread + 1e-9
    bets = []
    for ticker, coin, close, up, result, ev in prep:
        for k in range(p.window_s // 60, p.window_end_s // 60, -1):
            e = ev.get(k)
            if e is None:
                continue
            yb, ya, fy, fn, has_next, fyc, fnc = e
            y_in, n_in = lo <= ya <= hi, lo <= 1 - yb <= hi
            if y_in == n_in:
                continue                                   # no favourite, or both sides (thin book)
            if y_in:
                leg, bid, ask, fill, sustained = "yes", yb, ya, fy, fyc
            else:
                leg, bid, ask, fill, sustained = "no", 1 - ya, 1 - yb, fn, fnc
            outcome = "UP" if (leg == "yes") == up else "DOWN"
            if p.side != "both" and outcome.lower() != p.side:
                continue
            if bid >= ask or ask - bid > sp or bid <= 0:
                continue
            if taker:
                price, sustained = ask, True       # buying at the ask doesn't wait for anyone, so no fill question
            else:
                if not has_next or not fill or (strict and not sustained):
                    continue
                price = bid
            won = leg == result
            qty = max(1, math.floor(bet_usd / price + 1e-9))     # whole contracts, like the live bot's sizing
            fee = math.ceil(0.07 * qty * price * (1 - price) * 100 - 1e-9) / 100 if taker else 0.0   # per order, rounded up
            cost = qty * price + fee
            pnl = (qty if won else 0.0) - cost
            bets.append({"ticker": ticker, "coin": coin, "close": close, "outcome": outcome, "price": price,
                         "won": won, "pnl": pnl / qty, "ret": pnl / cost, "minute": k, "qty": qty, "fee": fee,
                         "cost": cost, "usd": pnl, "certain": taker, "sustained": sustained})
            break
    return bets


def replay(contracts: list[dict], p: Params, taker: bool = False) -> list[dict]:
    return replay_fast(prepare(contracts), p, taker)


def stats(bets: list[dict]) -> dict:
    n = len(bets)
    if not n:
        return {"n": 0}
    rets = [b["ret"] for b in bets]
    mean = sum(rets) / n
    sd = math.sqrt(sum((r - mean) ** 2 for r in rets) / max(1, n - 1))
    wins = sum(b["won"] for b in bets)
    avg_price = sum(b["price"] for b in bets) / n
    bal = peak = dd = 0.0                                  # drawdown of a $4-per-bet account
    for b in bets:
        bal += 4 * b["ret"]
        peak = max(peak, bal)
        dd = max(dd, peak - bal)
    # Every resting-bid fill is an estimate from minute data (see prepare), so it counts as uncertain.
    bid_fills = [b for b in bets if not b.get("certain", True)]
    return {"n": n, "wins": wins, "win_rate": wins / n, "avg_price": avg_price, "roi": mean, "se": sd / math.sqrt(n),
            "pnl_per_4": 4 * mean * n, "max_drawdown_4": dd,
            "pnl_usd": sum(b.get("usd", 0.0) for b in bets), "staked_usd": sum(b.get("cost", 0.0) for b in bets),
            "uncertain_fills": len(bid_fills) / n,
            "sustained_share": (sum(1 for b in bid_fills if b.get("sustained")) / len(bid_fills)) if bid_fills else None}


def grid() -> list[Params]:
    out = []
    for lo, hi, sp, (w, we), side, mode in itertools.product(
            [0.88, 0.90, 0.92, 0.94], [0.95, 0.97, 0.98], [0.02, 0.03], [(300, 60), (180, 60), (120, 60), (300, 240)],
            ["both", "up", "down"], ["bid", "ask"]):
        out.append(Params(lo, hi, sp, w, side, mode, we))
    return out


def breakdown(bets: list[dict], key) -> list[dict]:
    g = {}
    for b in bets:
        g.setdefault(key(b), []).append(b)
    return [{"key": k, **stats(v)} for k, v in sorted(g.items(), key=lambda kv: str(kv[0]))]


def band(p: float) -> str:
    for lo, hi in [(0.85, 0.88), (0.88, 0.90), (0.90, 0.92), (0.92, 0.94), (0.94, 0.96), (0.96, 0.99)]:
        if p < hi:
            return f"{lo * 100:.0f}–{hi * 100:.0f}¢"
    return "96¢+"


def _judge(te: dict, cur: dict, te_strict: dict | None = None, cur_strict: dict | None = None) -> tuple[float, float, bool, str]:
    """strong: beats yours AND makes money even at the low end of its luck range (on data it wasn't picked from).
    better: clearly beats the current settings, but its own profit could still be luck.
    promising: positive and ahead, but within luck. failed: fell apart on the newer data.
    A setting whose fills are uncertain (waiting at the bid) is never called 'strong' from minute data alone."""
    diff = te.get("roi", 0) - cur.get("roi", 0)
    noise = math.sqrt(te.get("se", 0) ** 2 + cur.get("se", 0) ** 2)
    enough = te.get("n", 0) >= 100
    # risk: not a much bigger worst losing run (per bet, so different bet counts compare fairly)
    dd_ok = te.get("max_drawdown_4", 0) / max(1, te.get("n", 1)) <= 1.25 * cur.get("max_drawdown_4", 0) / max(1, cur.get("n", 1)) + 1e-9
    # stress test: must also hold when only sustained crosses count as fills
    strict_ok = te_strict is None or cur_strict is None or te_strict.get("roi", -1) >= cur_strict.get("roi", 0)
    beats = enough and diff - 2 * noise > 0 and dd_ok and strict_ok
    if beats and te.get("roi", 0) - 2 * te.get("se", 0) > 0 and not te.get("uncertain_fills"):
        verdict = "strong"          # beats yours on fresh data AND profitable even at the low end of its luck range
    elif beats:
        verdict = "better"          # beats yours on fresh data; its own profit is still within luck
    elif te.get("roi", 0) > 0 and diff > 0:
        verdict = "promising"
    else:
        verdict = "failed"
    return diff, noise, beats and te.get("roi", 0) > 0, verdict


def coin_sets(bets: list[dict]) -> list[list[str] | None]:
    """Coin choices to try for one setting: every coin (None), and the best k coins by past return per $."""
    agg: dict[str, list[float]] = {}
    for b in bets:
        a = agg.setdefault(b["coin"], [0, 0.0])
        a[0] += 1
        a[1] += b["ret"]
    ranked = sorted(agg, key=lambda c: -agg[c][1] / agg[c][0])
    return [None] + [sorted(ranked[:k]) for k in range(1, len(ranked))]


def best_choice(prep: list[tuple], min_n: float, params: list[Params] | None = None, with_coins: bool = True):
    """The setting AND coin choice with the best return per $ on `prep` (at least min_n bets).
    Returns (Params, coins or None, stats) or None. Picked in-sample: only use it on data that comes later."""
    best = None
    for p in params or grid():
        bets = replay_fast(prep, p)
        for coins in (coin_sets(bets) if with_coins else [None]):
            sub = bets if coins is None else [b for b in bets if b["coin"] in coins]
            n = len(sub)
            if n < min_n:
                continue
            roi = sum(b["ret"] for b in sub) / n
            if best is None or roi > best[0]:
                best = (roi, p, coins, sub)
    return (best[1], best[2], stats(best[3])) if best else None


def _coins_label(coins) -> str:
    return "all coins" if not coins else ", ".join(coins)


def walk_forward(prep: list[tuple], folds: int = 5, params: list[Params] | None = None) -> dict:
    """Cut history into `folds` periods in time order. For each period after the first, pick the best setting
    AND coins using only the periods before it, then score that choice on that period. Nothing is judged on data
    it was picked from — including the coin choice, which is the easiest thing to fool yourself with."""
    n = len(prep)
    if n < folds * 50:
        return {"folds": [], "note": "not enough contracts for a walk-forward test"}
    edges = [round(i * n / folds) for i in range(folds + 1)]
    parts = [prep[edges[i]:edges[i + 1]] for i in range(folds)]
    rows, chosen_bets, current_bets = [], [], []
    for i in range(1, folds):
        past = [c for part in parts[:i] for c in part]
        cur_past = stats(replay_fast(past, CURRENT))
        pick = best_choice(past, max(40, 0.25 * cur_past.get("n", 0)), params)
        if pick is None:
            continue
        p, coins, past_stats = pick
        cb = [b for b in replay_fast(parts[i], p) if coins is None or b["coin"] in coins]
        kb = replay_fast(parts[i], CURRENT)
        chosen_bets += cb
        current_bets += kb
        rows.append({"period": i + 1, "from": parts[i][0][2], "to": parts[i][-1][2],
                     "chosen": f"{p.label()} · {_coins_label(coins)}", "coins": coins,
                     "chosen_past": past_stats, "chosen_next": stats(cb), "current_next": stats(kb)})
    ch, cu = stats(chosen_bets), stats(current_bets)
    diff, noise, convincing, verdict = _judge(ch, cu)
    return {"folds": rows, "chosen_overall": ch, "current_overall": cu, "beats_current_by": diff, "noise": noise,
            "verdict": verdict}


def analyse(contracts: list[dict], days: float, extra: dict[str, Params] | None = None) -> dict:
    prep = prepare(contracts)
    n = len(prep)
    split = int(n * TRAIN_SHARE)
    train, test = prep[:split], prep[split:]
    cur_all, cur_train, cur_test = (replay_fast(x, CURRENT) for x in (prep, train, test))
    taker = replay_fast(prep, CURRENT, taker=True)
    ranked = []
    ctr = stats(cur_train)
    for p in grid():
        tr = stats(replay_fast(train, p))
        if tr["n"] >= max(60, 0.25 * ctr.get("n", 0)):
            ranked.append((tr["roi"], p, tr))
    ranked.sort(key=lambda x: -x[0])
    cte = stats(cur_test)
    top = []
    cte_strict = stats(replay_fast(test, CURRENT, strict=True))
    for _, p, tr in ranked[:8]:
        te = stats(replay_fast(test, p))
        diff, noise, convincing, verdict = _judge(te, cte, stats(replay_fast(test, p, strict=True)), cte_strict)
        top.append({"label": p.label(), "params": p.__dict__, "train": tr, "test": te, "beats_current_by": diff,
                    "noise": noise, "convincing": convincing, "verdict": verdict})
    hours = {}
    for b in cur_all:
        hours.setdefault(time.localtime(b["close"]).tm_hour, []).append(b)
    first, last = (prep[0][2], prep[-1][2]) if prep else (0, 0)
    models = {}
    for name, spec in (extra or {}).items():
        p, coins, bet = spec if isinstance(spec, tuple) else (spec, None, BET_USD)
        sub = [c for c in prep if coins is None or c[1] in coins]
        sub_test = [c for c in test if coins is None or c[1] in coins]
        every = replay_fast(prep, p, bet_usd=bet)      # every coin, so the app can show any coin choice
        models[name] = {"label": p.label(), "coins": coins, "all": stats(replay_fast(sub, p, bet_usd=bet)),
                        "test": stats(replay_fast(sub_test, p, bet_usd=bet)),
                        "by_coin": {r["key"]: r for r in breakdown(every, lambda b: b["coin"])}}
    wf_all = walk_forward(prep)
    # proposal for the learning loop: the best setting AND coins on ALL the data we have so far. It is only a
    # proposal — it must then prove itself on markets that happen AFTER this moment (Litter Box candidate slot).
    best = best_choice(prep, max(200, 0.25 * len(cur_all)))
    proposal = None
    if best:
        p, coins, st_ = best
        proposal = {"params": p.__dict__, "coins": coins, "label": p.label(), "past": st_, "past_current": stats(cur_all),
                    "walk_forward": {"verdict": (wf := wf_all).get("verdict"),
                                     "chosen": wf.get("chosen_overall"), "current": wf.get("current_overall")},
                    "made_from": [first, last]}
    return {
        "generated_at": time.time(), "days": days, "contracts": n, "from": first, "to": last,
        "train_contracts": len(train), "test_contracts": len(test),
        "coverage": {c: sum(1 for x in prep if x[1] == c) for c in sorted({x[1] for x in prep})},
        "current": {"label": CURRENT.label(), "all": stats(cur_all), "train": ctr, "test": cte,
                    "strict": stats(replay_fast(prep, CURRENT, strict=True)),
                    "bets_per_day": len(cur_all) / max(days, 1e-9), "fill_rate": len(cur_all) / max(1, len(taker))},
        "taker": stats(taker), "taker_test": stats(replay_fast(test, CURRENT, taker=True)),
        "picked_off_gap": (stats(taker).get("win_rate", 0) - stats(cur_all).get("win_rate", 0)) if cur_all and taker else None,
        "by_coin": breakdown(cur_all, lambda b: b["coin"]), "by_band": breakdown(cur_all, lambda b: band(b["price"])),
        "by_side": breakdown(cur_all, lambda b: b["outcome"]),
        "by_minute": breakdown(cur_all, lambda b: f"{b['minute']} min left"),
        "by_hour": [{"key": h, **stats(v)} for h, v in sorted(hours.items())],
        "top": top, "suggestions": [t for t in top if t["convincing"]][:3],
        "walk_forward": wf_all, "models": models, "proposal": proposal,
    }


# ---- entry point ----------------------------------------------------------------------------
def run(series: list[str], days: float, out_dir: Path, extra: dict | None = None) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    status_file = out_dir / "status.json"

    def status(msg, pct, state="running"):
        status_file.write_text(json.dumps({"state": state, "message": msg, "progress": round(pct), "pid": os.getpid(),
                                           "ts": time.time()}), encoding="utf-8")

    try:
        status("Starting", 1)
        cache = Cache(out_dir / "cache.sqlite3")
        asyncio.run(download(series, days, cache, status))
        status("Replaying the strategy", 96)
        res = analyse(cache.load(int(time.time() - days * 86400)), days, extra)
        (out_dir / "results.json").write_text(json.dumps(res), encoding="utf-8")
        status(f"Done: {res['contracts']:,} contracts replayed", 100, "done")
        return res
    except Exception as e:  # noqa: BLE001
        status(f"Failed: {type(e).__name__}: {e}"[:300], 100, "error")
        raise
