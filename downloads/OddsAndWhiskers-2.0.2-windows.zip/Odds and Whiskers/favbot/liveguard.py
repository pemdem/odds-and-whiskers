"""Gates in front of real money: the typed acknowledgement and the pre-flight checks."""
from __future__ import annotations

import json
import re
import sys
import time
import unicodedata
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path

from .config import Limits
from .money import d
from .providers.base import ApiError, TransportError
from .providers.kalshi import verify_market

ACK_DAYS = 30


def ack_path(data_dir: Path) -> Path:
    return data_dir / "live_ack.json"


def ack_phrase(limits: Limits) -> str:
    return f"I ACCEPT REAL-MONEY RISK {limits.fingerprint()[:8].upper()}"


# letters people type for look-alike digits in the code at the end of a phrase
_LOOKALIKE = str.maketrans({"O": "0", "I": "1", "L": "1"})
_DASHES = re.compile("[‐‑‒–—―−]")
_NUMBER = re.compile(r"\d+(?:\.\d+)?")


def _canon(text: str) -> str:
    """A phrase reduced to what matters: same words, numbers and code, in order. Capitals, spaces, dashes,
    a $ sign, a full stop at the end, 25 vs 25.00 and O-for-0 / I-for-1 don't."""
    s = unicodedata.normalize("NFKC", str(text)).upper().translate(_LOOKALIKE)
    s = _DASHES.sub("-", s).strip().rstrip(".")
    out = []
    for tok in re.split(r"[\s\-]+", s):
        tok = tok.replace("$", "").replace(",", "")
        if _NUMBER.fullmatch(tok):
            tok = format(Decimal(tok).normalize(), "f")
        out.append(tok)
    return "".join(out)


def phrase_matches(typed: str | None, phrase: str) -> bool:
    """Did the person type this confirmation phrase? Still word for word (a different amount, shard or code is a
    different phrase), but forgiving about how it was typed. Shared by the app and the terminal helpers."""
    return bool(typed and str(typed).strip()) and _canon(typed) == _canon(phrase)


def require_terminal() -> None:
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        raise SystemExit("This command must be run by a person at a real terminal (stdin/stdout are not a TTY).")


def write_ack(data_dir: Path, limits: Limits, key_fp: str, now: float | None = None) -> dict:
    now = now or time.time()
    rec = {"limits_fingerprint": limits.fingerprint(), "limits": {k: str(v) for k, v in limits.model_dump().items()},
           "key_fingerprint": key_fp, "created_at": now, "expires_at": now + ACK_DAYS * 86400}
    data_dir.mkdir(parents=True, exist_ok=True)
    ack_path(data_dir).write_text(json.dumps(rec, indent=2), encoding="utf-8")
    return rec


def check_ack(data_dir: Path, limits: Limits, key_fp: str, now: float | None = None) -> tuple[bool, str]:
    now = now or time.time()
    p = ack_path(data_dir)
    if not p.exists():
        return False, "no live acknowledgement: run `python -m favbot ack-live` yourself at a terminal"
    try:
        rec = json.loads(p.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return False, "acknowledgement file unreadable"
    if rec.get("limits_fingerprint") != limits.fingerprint():
        return False, "live_limits changed since the acknowledgement: run ack-live again"
    if rec.get("key_fingerprint") != key_fp:
        return False, "API key changed since the acknowledgement: run ack-live again"
    if now > rec.get("expires_at", 0):
        return False, "acknowledgement older than 30 days: run ack-live again"
    return True, f"acknowledged, expires {time.strftime('%Y-%m-%d', time.gmtime(rec['expires_at']))}"


@dataclass
class Check:
    name: str
    ok: bool
    detail: str


async def preflight(md, trading, series: list[str], *, need_balance: bool, max_skew: float = 2.0) -> list[Check]:
    out: list[Check] = []
    shard = 2
    fee_ok, shards = True, set()
    for s in series:
        try:
            si = await md.get_series(s)
            shards.add(si.exchange_index)
            from .money import KNOWN_FEE_TYPES
            if si.fee_type not in KNOWN_FEE_TYPES:
                fee_ok = False
                out.append(Check(f"fee type {s}", False, f"unrecognised {si.fee_type!r}"))
        except (ApiError, TransportError) as e:
            fee_ok = False
            out.append(Check(f"series {s}", False, str(e)))
    if len(shards) == 1:
        shard = shards.pop()
    out.append(Check("fee types", fee_ok, "all recognised (maker fills free on 'quadratic')" if fee_ok else "see above"))
    try:
        st = await md.get_exchange_status(shard)
        out.append(Check("exchange open", st.trading_active, f"shard {shard} trading_active={st.trading_active}"))
    except (ApiError, TransportError) as e:
        out.append(Check("exchange open", False, str(e)))

    verified = []
    now = int(time.time())
    for s in series:
        try:
            for m in await md.list_markets(s, now - 120, now + 3600):
                c, _ = verify_market(m, s, shard)
                if c:
                    verified.append(c.ticker)
        except (ApiError, TransportError) as e:
            out.append(Check(f"markets {s}", False, str(e)))
    out.append(Check("verified contract", bool(verified), f"{len(verified)} verified: {', '.join(verified[:4])}"))

    skew = md.clock_skew_s
    out.append(Check("clock", skew is not None and abs(skew) <= max_skew,
                     "unknown" if skew is None else f"local clock {skew:+.2f}s vs exchange (limit {max_skew}s)"))

    if need_balance:
        try:
            if hasattr(trading, "exchange_index"):
                trading.exchange_index = shard
            b = await trading.get_balance()
            out.append(Check(f"balance on shard {shard}", b.balance >= d("1"),
                             f"${b.balance:.2f} available" + ("" if b.balance >= 1 else
                             " - move funds with `python -m favbot move-funds --amount N`")))
        except (ApiError, TransportError) as e:
            out.append(Check(f"balance on shard {shard}", False, str(e)))
    return out
