# Odds & Whiskers launcher for Windows (formerly Better Bot; the file keeps its name so shortcuts keep working). Starts the bot invisibly in the background if it isn't running,
# then opens the dashboard as an app window. There is no console window to keep open.
$ErrorActionPreference = 'Stop'
$app = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $app
# Which money this copy uses comes from config.yaml (mode: live / paper). A new copy starts in paper (practice).
$mode = 'paper'
$cfgFile = Join-Path $root 'config.yaml'
if (Test-Path $cfgFile) {
    $m = Select-String -Path $cfgFile -Pattern '^mode:\s*(\w+)' | Select-Object -First 1
    if ($m) { $mode = $m.Matches[0].Groups[1].Value }
}
$data = Join-Path $root "data\$mode"
$urlFile = Join-Path $data 'dashboard_url.txt'
$stopFile = Join-Path $data 'STOPPED'
$console = Join-Path $data 'console.log'
Add-Type -AssemblyName System.Windows.Forms

function Test-BotRunning {
    [bool](Get-CimInstance Win32_Process -Filter "Name='python.exe'" |
        Where-Object { $_.CommandLine -like "*$(Join-Path $root '.venv')*favbot*run --mode $mode*" })   # this copy's bot only
}
function Test-SupervisorRunning {
    [bool](Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" |
        Where-Object { $_.CommandLine -like "*$(Join-Path $app 'supervisor.ps1')*" -and
            ($_.CommandLine -like "*-Mode $mode*" -or ($mode -eq 'live' -and $_.CommandLine -notlike '*-Mode *')) })   # this copy's helper for this mode
}

if (-not (Test-BotRunning)) {
    $started = Get-Date
    if (Test-Path $stopFile) { Remove-Item $stopFile -Force }
    if (-not (Test-SupervisorRunning)) {
        Start-Process -FilePath "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe" -WindowStyle Hidden `
            -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', "`"$(Join-Path $app 'supervisor.ps1')`"", '-Mode', $mode
    }
    $deadline = $started.AddSeconds(90)
    $ready = $false
    while ((Get-Date) -lt $deadline) {
        if ((Test-Path $urlFile) -and ((Get-Item $urlFile).LastWriteTime -gt $started)) { $ready = $true; break }
        if (Test-Path $stopFile) { break }   # refused to start
        Start-Sleep -Milliseconds 500
    }
    if (-not $ready) {
        $why = ''
        if (Test-Path $console) { $why = (Get-Content $console -Tail 12 | Where-Object { $_ -match 'refused|FAIL|error|credentials' }) -join "`n" }
        if (-not $why) { $why = "No details yet. See data\$mode\console.log in the app folder." }
        [System.Windows.Forms.MessageBox]::Show("The bot didn't start.`n`n$why", 'Odds & Whiskers') | Out-Null
        exit 1
    }
}

$url = (Get-Content $urlFile -TotalCount 1).Trim()
$edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
          "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($edge) {
    Start-Process -FilePath $edge -ArgumentList "--app=$url", '--window-size=1240,940'
} else {
    Start-Process $url
}
