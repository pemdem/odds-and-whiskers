// ---- Recommended preset + Clump slider (Cat Corner home) -------------------------------------
let lastPreset = '', clump = null;
const pctS = v => `${Math.round(+v * 100)}%`;

function renderPresets(s) {
  const P = s.presets, lab = s.lab || {};
  if (!P) return;
  if (clump === null) clump = P.current.level || 3;
  const key = JSON.stringify([P, lab.candidate && lab.candidate.last_eval, clump, prefs.odds]);
  if (key === lastPreset) return;
  if (document.activeElement && document.activeElement.id === 'clump') return;      // mid-slide
  lastPreset = key;
  const R = P.recommended || {}, cand = lab.candidate;
  let left;
  if (R.ready) {
    const f = R.fresh || {}, o = R.original || {};
    left = `<div class="pre-tag pass">Recommended</div><div class="pre-name">${esc(R.label)}</div>` +
      `<div class="chips3">${(R.describe || []).map(t => `<span>${esc(t)}</span>`).join('')}</div>` +
      `<div class="facts">` +
        tile('On fresh markets', `${roiTxt(f)} per $`, (f.roi || 0) >= 0 ? 'pos' : 'neg') +
        tile('Original, same period', `${roiTxt(o)} per $`, (o.roi || 0) >= 0 ? 'pos' : 'neg') +
        tile('Biggest bankroll drop', money(R.max_drop || 0)) +
      `</div><div class="sub" style="margin-top:8px">${f.n} fake bets over ${R.days} days on markets that hadn’t happened yet when it was proposed. ` +
      `Fake money, paper fills and taker fees included — still an estimate.</div>` +
      `<div class="pre-act"><button class="primary" id="applyrec">Apply this strategy</button></div>`;
  } else {
    const ev = cand && cand.status === 'testing' ? cand.last_eval || {} : null;
    left = `<div class="pre-tag">No recommendation</div><div class="pre-name">Not enough evidence yet</div>` +
      `<div class="sub">A setting is only recommended after it beats your original strategy on <b>new</b> markets by more than luck, ` +
      `after fees and realistic fills — not because it looked best in the past.</div>` +
      (ev ? `<div class="pre-test"><b>Now testing: Candidate #${cand.id}</b> — ${esc(cand.label)}` +
        `<div class="progress"><i style="width:${Math.max(3, (ev.progress || 0) * 100)}%"></i></div>` +
        `<div class="sub" data-tip="A fair comparison needs enough fresh bets on BOTH sides: the candidate and the unchanged Original.">` +
        `Candidate ${(ev.candidate || {}).n || 0} · Original ${(ev.original || {}).n || 0} of ${ev.need || 300} fresh bets each · day ${(ev.age_days || 0).toFixed(1)} · ` +
        `candidate ${roiTxt(ev.candidate)} vs original ${roiTxt(ev.original)} so far</div></div>` :
        `<div class="sub" style="margin-top:10px">${R.tested ? `${R.tested} idea(s) tested so far, none good enough. ` : ''}` +
        `Turn on the Litter Box and let Backtrack run (it does every night) to start testing ideas.</div>`);
  }
  const cur = P.current;
  left += `<div class="pre-cur"><b>Your live strategy:</b> ${(cur.describe || []).map(esc).join(' · ')}` +
    (cur.is_original ? ' <span class="mut">(original)</span>' : ' <button id="applyorig">Back to original</button>') + `</div>`;
  const L = P.levels[clump - 1], cap = +L.capital_cap_usd;
  const right = `<div class="pre-tag" data-tip="How much your real bot risks: bet size, money at risk at once and bets open at once. The same slider is in Pick a version.">Clump slider</div>` +
    `<div class="pre-name">${esc(L.name)}${clump === P.current.level ? ' <span class="pill won" data-tip="Your bot uses this level now.">now</span>' : ''}</div>` +
    `<input type="range" min="1" max="5" step="1" value="${clump}" id="clump" aria-label="Risk level" class="clump">` +
    `<div class="clumpticks">${P.levels.map(l => `<span class="${l.level === P.current.level ? 'cur' : ''}">${l.name}</span>`).join('')}</div>` +
    `<div class="kv"><span>Most per bet</span><span>${money(L.max_loss_per_position_usd)}</span></div>` +
    `<div class="kv"><span>Most at risk at once</span><span>${pctS(L.max_total_exposure_pct)} · ${money(cap * L.max_total_exposure_pct)}</span></div>` +
    `<div class="kv"><span>Bets open at the same time</span><span>${L.max_open_positions}</span></div>` +
    `<div class="kv"><span>Daily stop (unchanged)</span><span>${pctS(L.daily_loss_pct)} · ${money(cap * L.daily_loss_pct)}</span></div>` +
    `<div class="sub" style="margin-top:6px">Changes only how much — never which bets. A higher level doesn’t buy lower-probability bets.</div>` +
    (P.pending_limits ? `<div class="tip2"><b>New limits waiting for your confirmation</b>Double-click <b>Confirm new limits</b> in your ` +
      `Odds & Whiskers folder and type the phrase. Until then the bot keeps its current limits.</div>` : '') +
    `<div class="pre-act"><button class="primary" id="applyclump" ${clump === P.current.level && !P.pending_limits ? 'disabled' : ''}>` +
    `Use “${esc(L.name)}” limits</button></div>`;
  $('presetbody').innerHTML = `<div class="pre-grid"><div class="pre-box">${left}</div><div class="pre-box">${right}</div></div>`;
}

$('presetbody').addEventListener('input', e => { if (e.target.id === 'clump') clump = +e.target.value; });
$('presetbody').addEventListener('change', e => { if (e.target.id === 'clump') { e.target.blur(); lastPreset = ''; lastPick = ''; load(); } });
$('presetbody').addEventListener('click', async e => {
  const id = e.target.id;
  let body = null, msg = '';
  if (id === 'applyrec') { body = {strategy: 'recommended'};
    msg = 'Switch your REAL-MONEY bot to the recommended strategy?\n\nIt takes effect after you restart the bot (banner: Restart now). Your limits stay the same. You can go back to the original any time.'; }
  if (id === 'applyorig') { body = {strategy: 'original'}; msg = 'Put your real-money bot back on the original strategy? (Takes effect after a restart.)'; }
  if (id === 'applyclump') { body = {level: clump};
    msg = `Use the “${P_name()}” limits?\n\nFor real money, new limits only become active after you confirm them: double-click “Confirm new limits” in your Odds & Whiskers folder and type the phrase.`; }
  if (!body || !confirm(msg)) return;
  try { const r = await postJSON('/api/apply', body);
    alert(r.pending_limits ? 'Saved. Now double-click “Confirm new limits” in your Odds & Whiskers folder to make them live.' : 'Saved. Restart the bot (banner at the top) to use it.');
  } catch (err) { alert(err.message); }
  lastPreset = ''; load();
});
function P_name() { const s = window._state; return s && s.presets ? s.presets.levels[clump - 1].name : ''; }
