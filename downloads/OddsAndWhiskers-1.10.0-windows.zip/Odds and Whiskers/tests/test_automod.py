"""The Automod update: the fake-money twin follows your real settings; per-person app flags."""
import asyncio
import json
from decimal import Decimal as D
from types import SimpleNamespace

import pytest

from favbot import dashboard
from favbot import litterbox as lbx
from favbot.config import Config, Limits, StrategyCfg

LIM = Limits(capital_cap_usd="22", max_loss_per_position_usd="4", max_loss_per_position_pct="0.2",
             max_total_exposure_pct="0.4", daily_loss_pct="0.2", max_open_positions=2)


def test_twin_copies_your_real_strategy_coins_and_limits():
    cfg = Config(mode="live", live_limits=LIM, strategy=StrategyCfg(entry="ask", side="down"), series=["KXETH15M", "KXSOL15M"])
    t = lbx.twin_model(cfg)
    assert t.id == "twin" and t.role == "twin"
    assert lbx.model_strategy(t).entry == "ask" and lbx.model_strategy(t).side == "down"
    assert lbx.model_series(t) == ["KXETH15M", "KXSOL15M"]
    assert lbx.model_limits(t) == LIM and t.cash == D("22") and t.bet_usd == D("4")
    # a twin is never copied at other risk levels
    assert not lbx.variant_models([t], [{"base": "twin", "level": 5}])


def test_twin_starts_fresh_when_your_settings_change(tmp_path):
    root = tmp_path / "litterbox"
    a = lbx.twin_model(Config(mode="live", live_limits=LIM))
    assert lbx.prepare_dirs(root, [a]) == []
    (root / "twin" / "favbot.sqlite3").write_text("bets made with the old settings")
    assert lbx.prepare_dirs(root, [a]) == []                                   # same settings: kept
    b = lbx.twin_model(Config(mode="live", live_limits=LIM, series=["KXETH15M"]))
    assert a.mark != b.mark
    assert lbx.prepare_dirs(root, [b]) == ["twin"]                             # new settings: archived, fresh start
    assert not (root / "twin" / "favbot.sqlite3").exists() and any((root / "_old").iterdir())


def test_paper_copy_without_live_limits_uses_its_own_limits():
    cfg = Config(mode="paper", paper_limits=LIM)
    assert lbx.twin_model(cfg).limits == LIM
    assert lbx.twin_model(Config(mode="paper")) is None


class _Store:
    def __init__(self):
        self.meta = {}

    def set_meta(self, k, v):
        self.meta[k] = v


class _Req:
    headers = {"X-Token": "t"}

    def __init__(self, body):
        self.body = body

    async def json(self):
        return self.body


async def test_app_flags_are_whitelisted_and_kept_per_person(tmp_path):
    bot = SimpleNamespace(store=_Store())
    d = dashboard.Dashboard(bot, 0)
    d.token = "t"
    r = await d.ui_flag(_Req({"key": "katya", "value": True}))
    assert json.loads(r.body) == {"katya": True} and bot.store.meta["ui_katya"] is True
    from aiohttp import web
    with pytest.raises(web.HTTPBadRequest):
        await d.ui_flag(_Req({"key": "live_limits", "value": True}))


def test_changelog_has_the_automod_update():
    from favbot import release as R
    top = R.changelog()[0]
    assert top["version"] == R.installed_version() and top["title"] == "The Automod Update"
    assert asyncio.iscoroutinefunction(dashboard.Dashboard.ui_flag)
