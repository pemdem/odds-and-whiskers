"""Balance projections for the dashboard's box-and-whisker chart.

Monte Carlo over thousands of possible futures, using your own history:
- bets per day: measured from your settled bets;
- each bet: costs your average bet and, if it wins, pays $1 per contract — so the profit is (1 - c) / c of its
  cost, where c is what one contract really cost INCLUDING fees; else it loses its cost;
- win probability: unknown, so each simulated future draws its own from a Beta distribution that starts
  at the market's own odds (the research found these prices fair; worth PRIOR_BETS bets of evidence) and
  moves toward your real win rate as your record grows. Luck and uncertainty about the edge are both included.
Each simulated day also draws its own win chance (DAY_K), because the coins tend to move together: a bad day
for crypto hits several bets at once. Limits are fixed (no reinvesting); a balance can't go below $0.
All probabilities are estimates. It recomputes as results come in.
"""
from __future__ import annotations

import math
import random

PRIOR_BETS = 50
DAY_K = 150        # how tightly a day's win chance sticks to the average; lower = more correlated bad days
SIMS = 2000
MIN_BETS = 10
MIN_HOURS = 3.0
HORIZONS = (7, 30, 60, 90)
_cache: dict = {}


def _pct(sorted_vals: list[float], q: float) -> float:
    i = q * (len(sorted_vals) - 1)
    lo, hi = math.floor(i), math.ceil(i)
    return sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * (i - lo)


def beta_quantiles(a: float, b: float, rng: random.Random, n: int = 4000) -> tuple[float, float, float]:
    xs = sorted(rng.betavariate(a, b) for _ in range(n))
    return _pct(xs, 0.05), a / (a + b), _pct(xs, 0.95)


def simulate_path(rng: random.Random, p: float, equity: float, per_day: float, cost: float, gain: float,
                  price: float, days: int, daily_stop_pct: float | None, cap: float | None) -> list[float]:
    """Balance at the end of each day. Steps loss-to-loss (wins between losses are geometric), so it is fast.
    Stops for the day at the daily loss limit, and for good once a single contract can't be afforded."""
    bal, out = equity, []
    for _ in range(days):
        # related losses: the coins move together, so each day gets its own "mood" around the true win chance
        pd = rng.betavariate(p * DAY_K, (1 - p) * DAY_K) if DAY_K and 0 < p < 1 else p
        log_p = math.log(pd) if 0 < pd < 1 else None
        if bal >= price:
            remaining, pnl = int(per_day), 0.0
            stake = min(cost, bal)
            g = stake * gain / cost
            limit = daily_stop_pct * min(bal, cap if cap else bal) if daily_stop_pct else None
            while remaining > 0:
                if log_p is None:
                    k = remaining if pd >= 1 else 0
                else:
                    k = int(math.log(1.0 - rng.random()) / log_p)     # wins before the next loss
                if k >= remaining:
                    pnl += remaining * g
                    break
                pnl += k * g - stake
                remaining -= k + 1
                if limit is not None and pnl <= -limit:
                    break                                           # daily loss limit: done for today
                if bal + pnl < price:
                    break                                           # can't afford another contract
            bal = max(0.0, bal + pnl)
        out.append(bal)
    return out


def project(settled: list[dict], equity: float, now: float, horizons=HORIZONS, sims: int = SIMS,
            daily_stop_pct: float | None = None, cap: float | None = None) -> dict:
    """settled: [{"ts", "pnl", "cost", "price", "won"}] for every settled bet that filled."""
    n = len(settled)
    first = min((s["ts"] for s in settled if s["ts"]), default=None)
    hours = (now - first) / 3600 if first else 0.0
    out = {"ready": False, "bets": n, "hours": round(hours, 1), "need_bets": MIN_BETS, "need_hours": MIN_HOURS}
    if n < MIN_BETS or hours < MIN_HOURS:
        return out

    wins = sum(1 for s in settled if s.get("won", s["pnl"] > 0))
    avg_cost = sum(s["cost"] for s in settled) / n
    avg_price = min(max(sum(s["price"] for s in settled) / n, 0.5), 0.995)
    # What one contract really costs, fees included. A win pays $1 per contract, so this is also the win rate
    # needed to break even: a 93¢ contract with a 1¢ fee makes 6¢ on a win and needs 94% wins, not 93%.
    qty = sum(s.get("qty") or 0 for s in settled)
    unit = sum(s["cost"] for s in settled) / qty if qty else avg_price
    unit = min(max(unit, 0.5), 0.995)
    per_day = n / hours * 24
    gain = avg_cost * (1 - unit) / unit                     # profit on a win, after fees
    a = PRIOR_BETS * avg_price + wins
    b = PRIOR_BETS * (1 - avg_price) + (n - wins)

    key = (n, wins, round(equity, 2), round(per_day, 1), round(avg_cost, 4), round(avg_price, 4), round(unit, 4), sims,
           daily_stop_pct, cap, DAY_K)
    if key in _cache:
        return _cache[key]
    rng = random.Random(hash(key) & 0xFFFFFFFF)            # stable between refreshes until data changes
    p_lo, p_mid, p_hi = beta_quantiles(a, b, rng)
    horizon_max = max(horizons)
    paths = []
    for _ in range(sims):
        p = rng.betavariate(a, b)
        paths.append(simulate_path(rng, p, equity, per_day, avg_cost, gain, unit, horizon_max, daily_stop_pct, cap))
    rows = []
    for days in horizons:
        finals = sorted(path[days - 1] for path in paths)
        rows.append({
            "days": days, "bets": max(1, round(per_day * days)),
            "p5": round(_pct(finals, .05), 2), "p25": round(_pct(finals, .25), 2), "p50": round(_pct(finals, .5), 2),
            "p75": round(_pct(finals, .75), 2), "p95": round(_pct(finals, .95), 2),
            "min": round(finals[0], 2), "max": round(finals[-1], 2),
            "chance_up": round(sum(1 for f in finals if f > equity) / sims, 3),
            "chance_half": round(sum(1 for f in finals if f < equity / 2) / sims, 3),
        })
    out.update({"ready": True, "per_day": round(per_day, 1), "avg_cost": round(avg_cost, 2), "gain": round(gain, 3),
                "avg_price": round(avg_price, 3), "wins": wins, "losses": n - wins, "win_rate": wins / n,
                "breakeven_win_rate": unit, "unit_cost": round(unit, 4), "p_est": round(p_mid, 4), "p_low": round(p_lo, 4),
                "p_high": round(p_hi, 4), "prior_bets": PRIOR_BETS, "sims": sims, "equity": round(equity, 2),
                "rows": rows})
    if len(_cache) > 64:
        _cache.clear()
    _cache[key] = out
    return out
