"""Restore points for the bot's code.

`save` copies the code (not your settings, keys or trade data) into versions/NNN-label/.
`restore` first saves the current code as a new restore point, then copies the chosen one back,
so a restore can itself be undone.

Never included: config.yaml, .env, keys/, data/, .venv/, versions/.
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STORE = ROOT / "versions"
INCLUDE = ["favbot", "app", "tests", "README.md", "requirements.txt", "pytest.ini", "config.example.yaml",
           ".env.example", "*.bat"]
SKIP_PARTS = {"__pycache__", ".pytest_cache"}


def _files(root: Path | None = None) -> list[Path]:
    root = root or ROOT
    out: list[Path] = []
    for pat in INCLUDE:
        for p in sorted(root.glob(pat)):
            if p.is_dir():
                out += [f for f in sorted(p.rglob("*")) if f.is_file() and not SKIP_PARTS & set(f.parts)]
            elif p.is_file():
                out.append(p)
    return out


def code_hash(root: Path | None = None, pattern: str = "favbot/*.py") -> str:
    """Fingerprint of the bot's Python code (used to tell when a restart is needed)."""
    root = root or ROOT
    h = hashlib.sha256()
    for f in sorted(root.glob(pattern)) + sorted(root.glob("favbot/*/*.py")):
        h.update(f.relative_to(root).as_posix().encode())
        h.update(f.read_bytes())
    return h.hexdigest()[:12]


def list_points() -> list[dict]:
    if not STORE.exists():
        return []
    pts = []
    for d in sorted(STORE.iterdir()):
        m = d / "manifest.json"
        if d.is_dir() and m.exists():
            pts.append(json.loads(m.read_text(encoding="utf-8")) | {"dir": d.name})
    return pts


def save(label: str) -> dict:
    STORE.mkdir(exist_ok=True)
    n = max((int(p["dir"].split("-", 1)[0]) for p in list_points()), default=0) + 1
    slug = re.sub(r"[^a-z0-9]+", "-", label.lower()).strip("-")[:40] or "point"
    dest = STORE / f"{n:03d}-{slug}"
    files = _files()
    for f in files:
        rel = f.relative_to(ROOT)
        (dest / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(f, dest / rel)
    man = {"number": n, "label": label, "saved_at": time.strftime("%Y-%m-%d %H:%M"), "files": len(files),
           "code": code_hash()}
    (dest / "manifest.json").write_text(json.dumps(man, indent=2), encoding="utf-8")
    return man | {"dir": dest.name}


def restore(number: int) -> dict:
    pts = {p["number"]: p for p in list_points()}
    if number not in pts:
        raise SystemExit(f"no restore point #{number}")
    src = STORE / pts[number]["dir"]
    before = save(f"before restoring #{number}")
    # remove current code files that the restore point doesn't have (e.g. a file added by the update)
    keep = {f.relative_to(src) for f in src.rglob("*") if f.is_file() and f.name != "manifest.json"}
    for f in _files():
        if f.relative_to(ROOT) not in keep:
            f.unlink()
    for rel in keep:
        (ROOT / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src / rel, ROOT / rel)
    return {"restored": pts[number], "saved_current_as": before}
