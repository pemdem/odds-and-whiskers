"""The learning loop.

Learning means improving performance on NEW data after fees and realistic fills — not repeatedly choosing
whichever settings looked best in the past. So:

1. Propose: Backtrack picks the best configuration on all past data (with its walk-forward evidence).
2. Freeze: that proposal becomes the Litter Box "candidate". It never changes while it is tested.
3. Test on fresh markets: only bets on markets AFTER the proposal was made count, next to the unchanged
   Original strategy over exactly the same period (paper fills, taker fees included).
4. Conclude: once BOTH the candidate and the Original have LAB_MIN_BETS fresh bets and LAB_MIN_DAYS have passed
   (or LAB_MAX_DAYS at most) the candidate either graduates (beats the Original by more than luck AND makes
   money on its own) or is rejected. 400 candidate bets against 1 Original bet proves nothing about "better",
   so if either side is still short at LAB_MAX_DAYS the result is "inconclusive".
5. Remember: every result is saved to history.json. A rejected configuration (strategy AND coins) is not
   proposed again; an inconclusive or withdrawn one may be.
Only then is a new proposal made, so the experiments don't keep changing.
"""
from __future__ import annotations

import json
import math
import sqlite3
import time
from pathlib import Path

LAB_MIN_BETS = 300
LAB_MIN_DAYS = 3.0
LAB_MAX_DAYS = 21.0
RULES = 2          # version of the test rules; a test started under older rules is withdrawn


def strategy_from_params(p: dict) -> dict:
    return {"entry": p["mode"], "side": p["side"], "ask_min": f'{p["ask_min"]:.2f}', "ask_max": f'{p["ask_max"]:.2f}',
            "max_spread": f'{p["max_spread"]:.2f}', "window_start_s": int(p["window_s"]), "window_end_s": int(p["window_end_s"])}


def _read(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _write(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
    tmp.replace(path)


def bet_stats(db: Path, since: float, coins: list[str] | None = None) -> dict:
    """Results of one Litter Box model, counting only bets settled after `since` (fresh markets),
    optionally only on some coins (so a candidate on 3 coins is compared with the Original on those 3 coins)."""
    if not db.exists():
        return {"n": 0}
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    try:
        rows = con.execute("""SELECT pnl, fill_cost, fees, payout, price, coin FROM entries WHERE settled_result IS NOT NULL
                              AND CAST(filled_count AS REAL) > 0 AND settled_at >= ? ORDER BY settled_at""", (since,)).fetchall()
    finally:
        con.close()
    if coins:
        rows = [r for r in rows if r[5] in coins]
    n = len(rows)
    if not n:
        return {"n": 0}
    pnls = [float(r[0] or 0) for r in rows]
    costs = [float(r[1] or 0) + float(r[2] or 0) for r in rows]
    rets = [p / c for p, c in zip(pnls, costs) if c]
    mean = sum(rets) / len(rets) if rets else 0.0
    var = sum((x - mean) ** 2 for x in rets) / max(1, len(rets) - 1) if len(rets) > 1 else 0.0
    prices = [float(r[4]) for r in rows if r[4]]
    model_var = sum((1 - p) / p for p in prices) / len(prices) if prices else 0.0     # streaks still carry risk
    se = math.sqrt(max(var, model_var) / max(1, len(rets)))
    bal = peak = dd = 0.0
    for p in pnls:
        bal += p
        peak = max(peak, bal)
        dd = max(dd, peak - bal)
    return {"n": n, "wins": sum(1 for r in rows if float(r[3] or 0) > 0), "pnl": round(sum(pnls), 2), "roi": mean,
            "se": se, "max_drop": round(dd, 2), "staked": round(sum(costs), 2)}


def _same(a: dict, b: dict) -> bool:
    keys = ("entry", "side", "ask_min", "ask_max", "max_spread", "window_start_s", "window_end_s")
    return all(str(a.get(k)) == str(b.get(k)) for k in keys)


def _same_coins(a, b) -> bool:
    return sorted(a or []) == sorted(b or [])


def evaluate(cand: dict, data_root: Path, now: float | None = None) -> dict:
    now = now or time.time()
    lb = data_root / "litterbox"
    since = cand["created_at"]
    c = bet_stats(lb / f"candidate-{cand['id']}" / "favbot.sqlite3", since)
    # Compared with the Original as you'd run it (all coins, same period): the coin choice is part of the idea.
    o = bet_stats(lb / "original" / "favbot.sqlite3", since)
    age = (now - since) / 86400
    cn, on = c.get("n", 0), o.get("n", 0)
    out = {"candidate": c, "original": o, "age_days": round(age, 2), "need": LAB_MIN_BETS,
           # progress counts the side that is further behind: both need enough fresh bets
           "progress": min(1.0, cn / LAB_MIN_BETS, on / LAB_MIN_BETS)}
    if cand.get("coins"):
        out["original_same_coins"] = bet_stats(lb / "original" / "favbot.sqlite3", since, cand["coins"])
    if cn and on:
        diff = c["roi"] - o["roi"]
        noise = math.sqrt(c["se"] ** 2 + o["se"] ** 2)
        out.update(diff=diff, noise=noise)
    enough = cn >= LAB_MIN_BETS and on >= LAB_MIN_BETS
    if (enough and age >= LAB_MIN_DAYS) or age >= LAB_MAX_DAYS:
        if not enough:
            out["verdict"] = "inconclusive"       # not enough fresh bets on one side to compare fairly
        else:
            d, nz = out["diff"], out["noise"]
            out["verdict"] = "graduated" if d - 2 * nz > 0 and c["roi"] - 2 * c["se"] > 0 else "rejected"
    return out


def withdraw(data_root: Path, reason: str, now: float | None = None) -> bool:
    """Stop the current test without a verdict (e.g. the test rules changed). It may be proposed again."""
    lab = data_root / "lab"
    cand = _read(lab / "candidate.json", None)
    if not cand or cand.get("status") != "testing":
        return False
    history = _read(lab / "history.json", [])
    cand.update(status="withdrawn", concluded_at=now or time.time(), withdrawn_because=reason)
    history.append({k: cand.get(k) for k in ("id", "label", "strategy", "coins", "bet_usd", "created_at",
                                             "concluded_at", "status", "evidence")}
                   | {"result": cand.get("last_eval") or {}, "reason": reason})
    _write(lab / "history.json", history)
    _write(lab / "candidate.json", cand)
    return True


def step(data_root: Path, backtrack_results: dict | None, now: float | None = None) -> dict:
    """Advance the loop by one tick. Returns {"restart_litterbox": bool, "candidate": ..., "history": [...]}."""
    now = now or time.time()
    lab = data_root / "lab"
    cand_file, hist_file = lab / "candidate.json", lab / "history.json"
    cand = _read(cand_file, None)
    history = _read(hist_file, [])
    restart = False
    if cand and cand.get("status") == "testing" and cand.get("rules", 1) < RULES:
        withdraw(data_root, "The test rules changed (both sides now need enough fresh bets, and coins are part of "
                            "each idea), so this test was stopped without a verdict.", now)
        return {"restart_litterbox": True, "candidate": _read(cand_file, None), "history": _read(hist_file, [])}
    if cand and cand.get("status") == "testing":
        ev = evaluate(cand, data_root, now)
        cand["last_eval"] = ev
        if ev.get("verdict"):
            cand["status"], cand["concluded_at"] = ev["verdict"], now
            history.append({k: cand[k] for k in ("id", "label", "strategy", "coins", "bet_usd", "created_at",
                                                  "concluded_at", "status", "evidence")} | {"result": ev})
            _write(hist_file, history)
            restart = True                      # free the candidate slot
        _write(cand_file, cand)
    elif backtrack_results and backtrack_results.get("proposal") and "coins" in backtrack_results["proposal"]:
        prop = backtrack_results["proposal"]
        strat, coins = strategy_from_params(prop["params"]), prop.get("coins") or None
        # only a clear "no" closes an idea for good; inconclusive or withdrawn tests may run again
        tried = [h for h in history if _same(h["strategy"], strat) and _same_coins(h.get("coins"), coins)
                 and h["status"] in ("graduated", "rejected")]
        baseline = strategy_from_params({"mode": "bid", "side": "both", "ask_min": 0.88, "ask_max": 0.97,
                                         "max_spread": 0.03, "window_s": 300, "window_end_s": 60})
        if not tried and not (_same(strat, baseline) and not coins):
            label = prop["label"] + (f" · {', '.join(coins)}" if coins else "")
            cand = {"id": len(history) + 1, "label": label, "strategy": strat, "coins": coins, "bet_usd": 4, "rules": RULES,
                    "created_at": now, "status": "testing", "evidence": {"past": prop["past"],
                    "past_original": prop["past_current"], "walk_forward": prop["walk_forward"]},
                    "blurb": "Proposed from past data; now tested only on new markets."}
            _write(cand_file, cand)
            restart = True                      # Litter Box picks up the new candidate
    return {"restart_litterbox": restart, "candidate": cand, "history": history}


def recommendation(data_root: Path) -> dict:
    """The newest graduated configuration, or 'not enough evidence yet'."""
    history = _read(data_root / "lab" / "history.json", [])
    grads = [h for h in history if h["status"] == "graduated"]
    cand = _read(data_root / "lab" / "candidate.json", None)
    if not grads:
        return {"ready": False, "reason": "Not enough evidence yet", "testing": cand if cand and cand.get("status") == "testing" else None,
                "tested": len(history)}
    g = grads[-1]
    r = g["result"]
    return {"ready": True, "id": g["id"], "label": g["label"], "strategy": g["strategy"], "coins": g["coins"],
            "bet_usd": g["bet_usd"], "fresh": r["candidate"], "original": r["original"], "days": r["age_days"],
            "max_drop": r["candidate"].get("max_drop"), "evidence": g.get("evidence"), "tested": len(history)}
