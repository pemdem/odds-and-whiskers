from __future__ import annotations

import time
from datetime import datetime, timezone
from decimal import Decimal

import pytest

from favbot.config import Config, Limits
from favbot.models import Book, ExchangeStatus, SeriesInfo
from favbot.money import PriceGrid

T0 = 1_800_000_000.0  # fixed epoch for deterministic tests (a multiple of 900)
RULES = ("If the simple average of the sixty seconds of CF Benchmarks' ETHUSDRTI before 4:45 PM EDT is at least "
         "the simple average of the sixty seconds of CF Benchmarks' ETHUSDRTI before 4:30 PM EDT, then the market "
         "resolves to Yes.")


class Clock:
    def __init__(self, t: float = T0):
        self.t = t

    def __call__(self) -> float:
        return self.t

    def advance(self, s: float) -> None:
        self.t += s


def iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def market(series="KXETH15M", close_ts=T0 + 900, strike="greater_or_equal", status="active", **kw) -> dict:
    m = {
        "ticker": f"{series}-{int(close_ts)}", "market_type": "binary",
        "open_time": iso(close_ts - 900), "close_time": iso(close_ts),
        "settlement_bounds_type": "default", "strike_type": strike, "floor_strike": 2500.5,
        "rules_primary": RULES, "rules_secondary": "", "status": status, "exchange_index": 2,
        "price_ranges": PriceGrid.default().to_api(), "result": "",
    }
    m.update(kw)
    return m


def book(ticker, yes_bids, no_bids, fetched_at=None) -> Book:
    conv = lambda lv: [(Decimal(p), Decimal(q)) for p, q in lv]  # noqa: E731
    return Book(ticker, sorted(conv(yes_bids)), sorted(conv(no_bids)), fetched_at or time.time())


def limits(**kw) -> Limits:
    base = dict(capital_cap_usd="1000", max_loss_per_position_usd="25", max_loss_per_position_pct="0.05",
                max_total_exposure_pct="0.30", daily_loss_pct="0.10", max_open_positions=6)
    base.update(kw)
    return Limits(**base)


class FakeMD:
    """Market data with books you set by hand."""

    def __init__(self, clock: Clock, series=("KXETH15M",), fee_type="quadratic"):
        self.clock = clock
        self.clock_skew_s = 0.0
        self.markets: dict[str, list[dict]] = {s: [] for s in series}
        self.books: dict[str, tuple] = {}
        self.results: dict[str, dict] = {}
        self.fee_type = fee_type
        self.trading_active = True
        self.calls: list[str] = []

    async def get_exchange_status(self, exchange_index=2):
        return ExchangeStatus(True, self.trading_active, self.clock())

    async def get_series(self, series):
        return SeriesInfo(series, self.fee_type, Decimal(1), 2)

    async def list_markets(self, series, min_close_ts, max_close_ts):
        return [m for m in self.markets.get(series, []) if min_close_ts <= _close(m) <= max_close_ts]

    async def get_market(self, ticker):
        for ms in self.markets.values():
            for m in ms:
                if m["ticker"] == ticker:
                    return {**m, **self.results.get(ticker, {})}
        raise KeyError(ticker)

    async def get_orderbook(self, ticker):
        self.calls.append(ticker)
        y, n = self.books[ticker]
        return book(ticker, y, n, fetched_at=self.clock())

    async def close(self):
        pass


def _close(m):
    return datetime.fromisoformat(m["close_time"].replace("Z", "+00:00")).timestamp()


@pytest.fixture
def clock():
    return Clock()


@pytest.fixture
def cfg(tmp_path):
    return Config(data_dir=str(tmp_path), base_dir=str(tmp_path), series=["KXETH15M"], paper_limits=limits())
