# Odds & Whiskers installer for Windows (run by "Install Odds and Whiskers.bat"). Safe to run again: it never touches an existing
# config.yaml, .env, keys or data. It starts the copy in PRACTICE mode (paper: fake money, real prices).
param([switch]$NoDesktop)      # -NoDesktop: don't create the Desktop icon (used for test installs)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $root
Write-Host "Setting up Odds & Whiskers in $root`n"

# files from a downloaded zip are marked as "from the internet"; clear that so Windows doesn't block them
Get-ChildItem -Path $root -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue

function Find-Python {
    # Supported: Python 3.11 to 3.14 (every part the app needs has a ready-made Windows package for these)
    $check = 'import sys; print((3, 11) <= sys.version_info[:2] <= (3, 14), sys.executable)'
    $cands = @(
        @{ exe = 'py'; args = @('-3.12') }, @{ exe = 'py'; args = @('-3.13') }, @{ exe = 'py'; args = @('-3.14') },
        @{ exe = 'py'; args = @('-3.11') },
        @{ exe = "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe"; args = @() },
        @{ exe = "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe"; args = @() },
        @{ exe = "$env:LOCALAPPDATA\Programs\Python\Python314\python.exe"; args = @() },
        @{ exe = 'python'; args = @() })
    foreach ($c in $cands) {
        try {
            $out = & $c.exe @($c.args + @('-c', $check)) 2>$null
            if ($LASTEXITCODE -eq 0 -and "$out" -match '^True (.+)$') { return $Matches[1].Trim() }
        } catch { }
    }
    return $null
}

$py = Find-Python
if (-not $py) {
    Write-Host "Odds & Whiskers needs Python 3.12, 3.13 or 3.14." -ForegroundColor Yellow
    Write-Host "1. On the page that opens, find Python 3.14 (or 3.13) and download its 'Windows installer (64-bit)'."
    Write-Host "   Newer versions like 3.15 aren't supported yet; you can keep them, just add 3.14 alongside."
    Write-Host "2. Run it and TICK 'Add python.exe to PATH', then Install Now."
    Write-Host "3. Double-click 'Install Odds and Whiskers.bat' again."
    Start-Process 'https://www.python.org/downloads/windows/'
    exit 1
}
Write-Host "Using Python: $py"

$venvPy = Join-Path $root '.venv\Scripts\python.exe'
if (Test-Path $venvPy) {
    # an environment left by an earlier attempt with an unsupported Python is rebuilt
    $okVenv = & $venvPy -c 'import sys; print((3, 11) <= sys.version_info[:2] <= (3, 14))' 2>$null
    if ("$okVenv" -ne 'True') {
        Write-Host "Rebuilding the app's Python environment (it was made with an unsupported Python)..."
        Remove-Item -Recurse -Force (Join-Path $root '.venv')
    }
}
if (-not (Test-Path $venvPy)) {
    Write-Host "Creating the app's own Python environment..."
    & $py -m venv (Join-Path $root '.venv')
}
Write-Host "Installing the parts it needs (a minute or two)..."
& $venvPy -m pip install --disable-pip-version-check --prefer-binary -q -r (Join-Path $root 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw "Installing the parts failed. Check the internet connection and run it again. If it still fails, send a screenshot of this window to whoever shared Odds & Whiskers." }

if (-not (Test-Path (Join-Path $root 'config.yaml'))) { Copy-Item (Join-Path $root 'config.example.yaml') (Join-Path $root 'config.yaml') }
if (-not (Test-Path (Join-Path $root '.env'))) { Copy-Item (Join-Path $root '.env.example') (Join-Path $root '.env') }
New-Item -ItemType Directory -Force (Join-Path $root 'keys'), (Join-Path $root 'data') | Out-Null

$desktop = [Environment]::GetFolderPath('Desktop')
$ws = New-Object -ComObject WScript.Shell
$links = @((Join-Path $root 'Odds & Whiskers.lnk'))
if (-not $NoDesktop) {
    $links += (Join-Path $desktop 'Odds & Whiskers.lnk')
    $old = Join-Path $desktop 'Better Bot.lnk'          # the app's old name
    if ((Test-Path -LiteralPath $old) -and ($ws.CreateShortcut($old).Arguments -like "*$root*")) { Remove-Item -LiteralPath $old }
}
foreach ($lnkPath in $links) {
    $s = $ws.CreateShortcut($lnkPath)
    $s.TargetPath = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
    $s.Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$(Join-Path $root 'app\BetterBot.ps1')`""
    $s.WorkingDirectory = $root
    $s.IconLocation = "$(Join-Path $root 'app\BetterBot.ico'),0"
    $s.WindowStyle = 7
    $s.Save()
}

Write-Host "Checking the install..."
& $venvPy -m favbot --config config.yaml release status

Write-Host "`nDone! An 'Odds & Whiskers' icon is on your Desktop." -ForegroundColor Green
Write-Host "It starts in PRACTICE mode: fake money on real prices."
Write-Host "Real money, when you're ready:  1) Set up my Kalshi key.bat   2) Go live.bat"
Write-Host "Updates appear in the app by themselves when the shared updates folder is in your OneDrive."
