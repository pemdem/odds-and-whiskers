// ---- Tutorial: a short guided tour that spotlights each part of the app ------------------------------
// Starts from Settings → General → "Show me around", or is offered once to new people.
const TOUR = [
  {title: 'Welcome to Odds & Whiskers', text: 'A one-minute tour of the app. You can leave any time with Esc or Skip, and replay it from Settings → General.'},
  {sel: '#tabseg', title: 'Three screens', text: '<b>Cat Corner</b> is your home. <b>Statistics</b> has the charts, the future and Backtrack. <b>Litter Box</b> tests other ideas with fake money.'},
  {sel: '#conn', title: 'One clear status', text: '<b>Running</b>, <b>Watching</b>, <b>Paused</b>, <b>Offline</b> or <b>Needs attention</b>, with a plain reason. Click it to see each coin’s “Why no bet?”.'},
  {sel: '#helpbtn', title: 'Help', text: 'Ask the cats, see why there’s no bet, get the daily recap, replay this tour, export diagnostics, and learn the difference between closing the window and turning the bot off.'},
  {sel: '#sec-balance', home: true, title: 'Your money', text: 'Your total balance, profit for the period you pick (1D, 1W…), and what’s in bets right now.'},
  {sel: '#sec-sim', home: true, title: 'Real vs Simulated', text: 'Slide between your <b>real</b> bot and <b>Simulated you</b>: the same settings and coins with fake money, on the same live prices. A quick reality check.'},
  {sel: '#sec-preset', home: true, title: 'Recommended preset & Clump', text: 'Ideas only get recommended after they beat the original on <b>new</b> markets. The Clump slider sets how much to risk — never which bets.'},
  {sel: '#sec-picker', home: true, title: 'Pick a version', text: 'Mix a model, coins and a risk level. Each choice shows how the others did, with fake money and on past data.'},
  {sel: '#sec-cats', home: true, title: 'Cat Chat', text: 'Your sidekicks read your bets and Backtrack. Click a cat (or ⇄) to choose who presents each card, or <b>Ask</b> one a question.'},
  {sel: '#viewseg', title: 'Make it yours', text: '<b>Classic</b> shows everything, <b>Simple</b> just the essentials, <b>Custom</b> your own pick. ✎ Layout lets you move, resize and hide sections.'},
  {sel: '#pause', title: 'Pause and Kill switch', text: 'Pause stops new bets and cancels a waiting bid. The kill switch blocks new bets until you undo it. Bets that already filled always finish.'},
  {sel: '#cat', title: 'The Cat Council', text: 'Click your sidekick to ask anything: “What happened while I was away?”, “Why did trading stop?”, “Why did I lose?”. ' +
    'Answers come from your real data and say whether a number is real money, simulated, a past test or an estimate. (Rumour has it there’s a fourth cat somewhere…)'},
  {sel: '#gear', title: 'Settings', text: 'Text size, hover tips, sidekicks, coins, alerts, limits and the update history. Hover anything in the app for a short explanation.'},
  {title: 'That’s it!', text: 'Start in practice mode if you’re new, keep bets small, and let the cats keep you company. Have fun.'},
];
let tourIx = -1, tourBox = null, tourPlace = null, tourRaf = 0;
addEventListener('scroll', () => {                 // the spotlight follows the page while it scrolls
  if (!tourPlace || tourRaf) return;
  tourRaf = requestAnimationFrame(() => { tourRaf = 0; if (tourPlace) tourPlace(); });
}, {passive: true});
function tourEl() {
  if (tourBox) return tourBox;
  tourBox = document.createElement('div');
  tourBox.className = 'tour';
  tourBox.innerHTML = '<div class="tour-spot"></div><div class="tour-card" role="dialog" aria-modal="true" aria-labelledby="tourt">' +
    '<div class="tour-n"></div><h3 id="tourt"></h3><p></p><div class="tour-act"><button data-t="skip">Skip</button>' +
    '<span class="spacer"></span><button data-t="back">Back</button><button class="primary" data-t="next">Next</button></div></div>';
  document.body.appendChild(tourBox);
  tourBox.addEventListener('click', e => { const t = e.target.closest('[data-t]'); if (!t) return;
    if (t.dataset.t === 'next') tourGo(tourIx + 1); else if (t.dataset.t === 'back') tourGo(tourIx - 1); else tourEnd(); });
  return tourBox;
}
function tourTarget(st) {
  if (!st.sel) return null;
  const n = document.querySelector(st.sel);
  if (!n) return null;
  const r = n.getBoundingClientRect();
  return r.width && r.height ? n : null;                    // hidden sections are skipped
}
function tourGo(i) {
  if (i < 0) return;
  if (i >= TOUR.length) return tourEnd();
  const st = TOUR[i];
  if (st.home && prefs.tab !== 'home') { prefs.tab = 'home'; savePrefs(); applyPrefs(); }
  if (st.sel && !tourTarget(st)) return tourGo(i + (i >= tourIx ? 1 : -1));
  tourIx = i;
  const box = tourEl(), card = box.querySelector('.tour-card'), spot = box.querySelector('.tour-spot');
  box.classList.add('on');
  box.querySelector('.tour-n').textContent = `${i + 1} of ${TOUR.length}`;
  box.querySelector('h3').textContent = st.title;
  box.querySelector('p').innerHTML = st.text;
  box.querySelector('[data-t="back"]').disabled = i === 0;
  box.querySelector('[data-t="next"]').textContent = i === TOUR.length - 1 ? 'Done' : 'Next';
  const n = tourTarget(st);
  const place = () => {
    const z = pageScale(card), pad = 8;
    if (!n) { spot.classList.add('none'); card.classList.add('center'); card.style.left = card.style.top = ''; return; }
    spot.classList.remove('none'); card.classList.remove('center');
    const r = n.getBoundingClientRect();
    const R = {l: r.left / z - pad, t: r.top / z - pad, w: r.width / z + pad * 2, h: r.height / z + pad * 2};
    const vh = innerHeight / z, vw = innerWidth / z;
    R.h = Math.min(R.h, vh - 24);
    Object.assign(spot.style, {left: R.l + 'px', top: Math.max(4, R.t) + 'px', width: R.w + 'px', height: R.h + 'px'});
    const cw = card.offsetWidth, ch = card.offsetHeight;
    let top = R.t + R.h + 12; if (top + ch > vh - 12) top = Math.max(12, R.t - ch - 12);
    if (top + ch > vh - 12) top = Math.max(12, vh - ch - 12);
    const left = Math.max(12, Math.min(vw - cw - 12, R.l + R.w / 2 - cw / 2));
    card.style.left = left + 'px'; card.style.top = top + 'px';
  };
  if (n) {
    const r = n.getBoundingClientRect();
    if (r.top < 70 || r.bottom > innerHeight - 20) n.scrollIntoView({block: r.height > innerHeight * 0.6 ? 'start' : 'center', behavior: 'smooth'});
  }
  tourPlace = place; place(); setTimeout(place, 400);                    // and on every scroll, below
  setTimeout(() => {                    // if smooth scrolling didn't get there, jump straight to it
    if (!n || tourIx !== i) return;
    const r = n.getBoundingClientRect();
    if (r.top < 0 || r.top > innerHeight - 80) n.scrollIntoView({block: 'start'});
    place();
  }, 900);
  box.querySelector('[data-t="next"]').focus({preventScroll: true});
}
function tourStart() { tourIx = -1; $('scrim').classList.remove('open'); hideTourOffer(); tourGo(0); }
function tourEnd() {
  if (tourBox) tourBox.classList.remove('on');
  tourIx = -1; tourPlace = null;
  postJSON('/api/ui', {key: 'tour_done', value: true}).catch(() => {});
  prefs.tourDone = true; savePrefs();
}
addEventListener('keydown', e => { if (tourIx < 0) return;
  if (e.key === 'Escape') tourEnd(); else if (e.key === 'ArrowRight') tourGo(tourIx + 1); else if (e.key === 'ArrowLeft') tourGo(tourIx - 1); });
addEventListener('resize', () => { if (tourIx >= 0) tourGo(tourIx); });

// offered once: a small card in the corner (never on top of the What's new popup)
let tourOffered = false;
function maybeOfferTour(s) {
  if (tourOffered || prefs.tourDone || (s.ui || {}).tour_done || document.getElementById('wnscrim') || s.whats_new_seen !== (s.release || {}).installed) return;
  tourOffered = true;
  const n = document.createElement('div'); n.className = 'toast offer'; n.id = 'touroffer';
  n.innerHTML = '<b>New here?</b> Take the one-minute tour of Odds &amp; Whiskers.<div class="tour-act"><button data-o="no">Not now</button>' +
    '<button class="primary" data-o="yes">Show me around</button></div>';
  document.body.appendChild(n);
  n.addEventListener('click', e => { const b = e.target.closest('[data-o]'); if (!b) return;
    if (b.dataset.o === 'yes') tourStart(); else { hideTourOffer(); prefs.tourDone = true; savePrefs(); postJSON('/api/ui', {key: 'tour_done', value: true}).catch(() => {}); } });
}
function hideTourOffer() { const n = $('touroffer'); if (n) { n.classList.add('out'); setTimeout(() => n.remove(), 400); } }
document.addEventListener('click', e => { if (e.target.id === 'tourstart') tourStart(); });
