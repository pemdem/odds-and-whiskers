@echo off
cd /d "%~dp0"
title Better Bot - set up your Kalshi key
.venv\Scripts\python.exe -m favbot setup-key
echo.
pause
