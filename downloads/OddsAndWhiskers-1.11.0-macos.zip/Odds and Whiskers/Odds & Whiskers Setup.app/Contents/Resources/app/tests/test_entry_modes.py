"""'Buy at the ask' and side filters (used by Litter Box models; the live bot keeps bid/both)."""
from decimal import Decimal as D

from favbot.config import StrategyCfg
from favbot.models import OrderRequest
from favbot.providers.kalshi import verify_market
from favbot.providers.paper import PaperExchange
from favbot.strategy.favourite import decide

from .conftest import T0, book, market

CLOSE = T0 + 900


def contract():
    return verify_market(market(close_ts=CLOSE), "KXETH15M", 2)[0]


FAV_UP = book("t", [("0.91", "100")], [("0.07", "80")])         # UP bid .91 ask .93
FAV_DOWN = book("t", [("0.06", "40")], [("0.92", "60")])        # DOWN bid .92 ask .94


def test_ask_entry_prices_at_the_ask():
    d = decide(contract(), FAV_UP, CLOSE - 200, StrategyCfg(entry="ask"))
    assert d.bid and d.price == D("0.93")
    assert decide(contract(), FAV_UP, CLOSE - 200, StrategyCfg()).price == D("0.91")


def test_side_filter():
    assert not decide(contract(), FAV_UP, CLOSE - 200, StrategyCfg(side="down")).bid
    assert decide(contract(), FAV_DOWN, CLOSE - 200, StrategyCfg(side="down")).bid
    assert not decide(contract(), FAV_DOWN, CLOSE - 200, StrategyCfg(side="up")).bid


async def test_taker_fills_immediately_with_fee_and_half_depth(clock):
    sim = PaperExchange(None, D("100"), clock=clock)
    t = "T"
    sim.observe_book(book(t, [("0.91", "100")], [("0.07", "10"), ("0.06", "40")], fetched_at=clock()), clock())
    # asks: 0.93 x10 (5 real), 0.94 x40 (20 real); limit 0.93 -> only the 0.93 level counts
    ack = await sim.create_order(OrderRequest(t, "c1", "yes", D("0.93"), 8, int(clock() + 20), post_only=False))
    o = await sim.get_order(ack.order_id)
    assert o.status == "executed" or o.status == "canceled"
    assert o.fill_count == 5 and o.fees > 0                         # taker fee charged
    assert (await sim.get_balance()).balance == D(100) - D("4.65") - o.fees


async def test_taker_with_no_book_does_not_fill(clock):
    sim = PaperExchange(None, D("100"), clock=clock)
    ack = await sim.create_order(OrderRequest("T", "c1", "yes", D("0.93"), 5, int(clock() + 20), post_only=False))
    assert ack.fill_count == 0 and (await sim.get_balance()).balance == D(100)
