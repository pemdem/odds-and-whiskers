// ---- What's new popup (once per newly installed version) and Settings → Updates -------------------
const vnum = v => (v || '0.0.0').split('.').map(Number);
const vcmp = (a, b) => { const x = vnum(a), y = vnum(b); for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] - y[i]; return 0; };
const fdate = d => { try { return new Date(d + 'T12:00:00').toLocaleDateString(undefined, {month: 'short', day: 'numeric', year: 'numeric'}); } catch (e) { return d; } };
const entryHTML = (c, cur) => `<div class="updentry ${cur ? 'cur' : ''}"><div class="updhead"><b>${esc(c.version)}</b>` +
  `${c.title ? ` <span>${esc(c.title)}</span>` : ''}${cur ? ' <span class="pill won" data-tip="The version on this computer.">installed</span>' : ''}` +
  `<span class="upddate">${esc(fdate(c.date))}</span></div>` +
  ((c.added || []).length ? `<div class="updlbl">Added</div><ul>${c.added.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : '') +
  ((c.fixed || []).length ? `<div class="updlbl">Fixed</div><ul>${c.fixed.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : '') + `</div>`;

let wnShown = false;
function renderWhatsNew(s) {
  const rel = s.release || {}, log = rel.changelog || [], cur = rel.installed;
  if (wnShown || !cur || !log.length || s.whats_new_seen === cur || window._restarting) return;
  const seen = s.whats_new_seen;
  const items = log.filter(c => vcmp(c.version, cur) <= 0 && (seen ? vcmp(c.version, seen) > 0 : c.version === cur));
  if (!items.length) { postJSON('/api/whats_new_seen', {version: cur}).catch(() => {}); return; }
  wnShown = true;
  const box = document.createElement('div');
  box.className = 'scrim open wn'; box.id = 'wnscrim';
  box.innerHTML = `<div class="sheet wnsheet" role="dialog" aria-modal="true" aria-labelledby="wntitle">` +
    `<div class="wnhero"><span class="wnlogo">${logoSVG(LOGOS[prefs.cat] ? prefs.cat : 'classic')}</span>` +
    `<div><div class="pre-tag">What’s new</div><h2 id="wntitle">Odds &amp; Whiskers ${esc(cur)}</h2>` +
    `<div class="sub">${esc(items[0].title || '')}${items.length > 1 ? ` · plus ${items.length - 1} earlier update${items.length > 2 ? 's' : ''}` : ''}</div></div></div>` +
    `<div class="wnbody">${items.map(c => entryHTML(c, false)).join('')}</div>` +
    `<div class="pre-act" style="justify-content:flex-end"><button id="wnall">See all updates</button>` +
    `<button class="primary" id="wnok">Nice, got it</button></div></div>`;
  document.body.appendChild(box);
  const close = all => {
    postJSON('/api/whats_new_seen', {version: cur}).catch(() => {});
    box.classList.remove('open'); setTimeout(() => box.remove(), 300);
    if (all) { prefs.pane = 'updates'; savePrefs(); $('gear').click(); }
  };
  box.querySelector('#wnok').onclick = () => close(false);
  box.querySelector('#wnall').onclick = () => close(true);
  box.addEventListener('click', e => { if (e.target === box) close(false); });
}

let lastUpd = '';
function renderUpdates(s) {
  const rel = s.release || {}, key = JSON.stringify([rel.installed, rel.available, rel.changelog && rel.changelog.length, rel.folders, rel.publisher]);
  if (key === lastUpd) return; lastUpd = key;
  const up = rel.available;
  $('updstatus').innerHTML = `Installed: <b>Odds &amp; Whiskers ${esc(rel.installed || '?')}</b><br>` +
    (up ? `<span class="pos">Version ${esc(up.version)} is ready to install.</span> ${esc(up.notes || '')}<br>` +
          `<button class="primary" id="installupdate2" style="margin-top:8px">Install ${esc(up.version)}</button>`
        : rel.publisher ? 'This computer publishes updates for friends (signed with its own key).'
        : rel.folders && rel.folders.length ? `Up to date. Checking ${esc(rel.folders[0])} every 2 minutes.`
        : 'No shared updates folder found. Add the shared OneDrive folder to get updates automatically.') +
    ((rel.rejected || []).length ? `<br><span class="neg">An update file failed the safety check and was ignored.</span>` : '');
  $('updhistory').innerHTML = (rel.changelog || []).map(c => entryHTML(c, c.version === rel.installed)).join('') ||
    '<div class="sub">No update history in this version.</div>';
}

async function installUpdate(btn) {
  const up = ((window._state || {}).release || {}).available || {};
  if (!confirm(`Install Odds & Whiskers ${up.version}?\n\n${up.notes || ''}\n\nWhat happens: new bets pause, any waiting bid is cancelled, your history and ` +
               `settings are backed up, the update installs, and the bot restarts and re-checks every order with Kalshi before it bets again. ` +
               `Bets that already filled are not touched. Your settings, key, limits, layouts and history stay as they are.`)) return;
  if (btn) { btn.disabled = true; btn.textContent = 'Installing…'; }
  try {
    const r = await postJSON('/api/install_update', {});
    if (r.restarting) {
      window._restarting = true; setTimeout(() => { window._restarting = false; }, 60000);
      $('banners').innerHTML = `<div class="banner warn">Installed ${esc(r.version)}. Restarting and re-checking orders with Kalshi… this window reconnects by itself.</div>`;
      $('scrim').classList.remove('open');
      return;
    }
    alert(`Installed Odds & Whiskers ${r.version}. ` + (r.restart ? 'Press “Restart now” to start using it.' : 'The page reloads to show it.'));
    if (!r.restart) return location.reload();
  } catch (err) { alert(err.message); }
  lastUpd = ''; load();
}
document.addEventListener('click', e => { if (e.target.id === 'installupdate2') installUpdate(e.target); });
