# Runs the live bot invisibly in the background and restarts it if it stops on its own.
# It does NOT restart when the bot was turned off from the app (data\live\STOPPED exists),
# or when the bot refused to start (exit code 2: e.g. the live acknowledgement expired).
param([string]$Mode = 'live', [string]$Config = 'config.yaml', [string]$DataDir = '')
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$data = if ($DataDir) { $DataDir } else { Join-Path $root "data\$Mode" }
New-Item -ItemType Directory -Force $data | Out-Null
$pidFile = Join-Path $data 'supervisor.pid'
$stopFile = Join-Path $data 'STOPPED'
$log = Join-Path $data 'supervisor.log'
$console = Join-Path $data 'console.log'
$py = Join-Path $root '.venv\Scripts\python.exe'
$env:PYTHONUNBUFFERED = '1'
$env:PYTHONIOENCODING = 'utf-8'

function Write-Log($m) { Add-Content -Path $log -Value ("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m) -Encoding utf8 }

Set-Content -Path $pidFile -Value $PID
try {
    if ((Test-Path $console) -and ((Get-Item $console).Length -gt 5MB)) { Move-Item $console "$console.old" -Force }
    Write-Log 'supervisor started'
    while ($true) {
        if (Test-Path $stopFile) { Write-Log 'turned off from the app; not restarting'; break }
        Write-Log 'starting bot'
        Push-Location $root
        cmd /c "`"$py`" -m favbot --config `"$Config`" run --mode $Mode >> `"$console`" 2>&1"
        $code = $LASTEXITCODE
        Pop-Location
        Write-Log "bot exited (code $code)"
        if (Test-Path $stopFile) { Write-Log 'turned off from the app; not restarting'; break }
        if ($code -eq 2) {
            Set-Content -Path $stopFile -Value 'the bot refused to start; see data\live\console.log'
            Write-Log 'bot refused to start (code 2); not restarting'
            break
        }
        $restartFile = Join-Path $data 'RESTART'
        if (Test-Path $restartFile) {
            Remove-Item $restartFile -Force
            Write-Log 'restart requested from the app (update); restarting now'
            Start-Sleep -Seconds 2
            continue
        }
        Write-Log 'restarting in 30 seconds'
        Start-Sleep -Seconds 30
    }
} finally {
    Remove-Item $pidFile -ErrorAction SilentlyContinue
}
