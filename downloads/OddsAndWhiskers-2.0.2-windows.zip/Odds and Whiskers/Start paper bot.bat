@echo off
cd /d "%~dp0"
echo Starting the bot in PAPER mode (simulated, no real orders). Close this window or press Ctrl+C to stop.
echo The dashboard link appears below. Copy it into your browser.
.venv\Scripts\python.exe -m favbot run --mode paper
pause
