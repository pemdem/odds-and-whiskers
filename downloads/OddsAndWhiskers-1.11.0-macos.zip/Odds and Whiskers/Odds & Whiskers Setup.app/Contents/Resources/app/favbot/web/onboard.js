// ---- Welcome wizard + Settings → Kalshi account ------------------------------------------------------
// Everything a new person needs, inside the app: practice mode, connecting their own Kalshi key (stored
// encrypted on this computer, locked by the Mac Keychain / Windows Credential Manager), moving money to the
// crypto section and switching to real money — each money step needs a phrase they type themselves.
let obStep = 0, obBal = null, obOpen = false;
const obEl = () => $('obscrim');
const LEVEL_NAMES = ['Tiny', 'Light', 'Steady', 'Bold', 'Chonky'];

function obShell() {
  if (obEl()) return obEl();
  const n = document.createElement('div');
  n.className = 'scrim open wn'; n.id = 'obscrim';
  n.innerHTML = `<div class="sheet wnsheet ob" role="dialog" aria-modal="true" aria-labelledby="obtitle">
    <div class="obdots" aria-hidden="true"></div><div id="obbody"></div></div>`;
  document.body.appendChild(n);
  n.addEventListener('click', obClick);
  n.addEventListener('change', obChange);
  return n;
}
function obShow(step = 0) {
  obOpen = true; obShell(); obGo(step);
  const s = window._state || {};
  // a fresh install doesn't need the update notes on top of the welcome
  if (s.release && s.whats_new_seen !== s.release.installed) postJSON('/api/whats_new_seen', {version: s.release.installed}).catch(() => {});
}
function obClose(done = true) {
  const n = obEl(); if (!n) return;
  n.classList.remove('open'); setTimeout(() => n.remove(), 300); obOpen = false;
  if (done) postJSON('/api/ui', {key: 'onboarded', value: true}).catch(() => {});
}
const obMoney = v => money(+v || 0);
function obGo(step) {
  obStep = step;
  const s = window._state || {}, k = s.kalshi || {}, host = $('obbody');
  document.querySelector('.obdots').innerHTML = [0, 1, 2, 3].map(i => `<i class="${i <= step ? 'on' : ''}"></i>`).join('');
  const isMac = /Mac/i.test(navigator.platform || navigator.userAgent);
  const store = isMac ? 'your Mac’s Keychain' : 'Windows Credential Manager';
  if (step === 0) host.innerHTML = `
    <div class="wnhero"><span class="wnlogo">${logoSVG(LOGOS[prefs.cat] ? prefs.cat : 'classic')}</span>
      <div><div class="pre-tag">Welcome</div><h2 id="obtitle">Odds &amp; Whiskers is ready</h2></div></div>
    <p>You’re in <b>practice mode</b>: the bot trades real Kalshi prices with <b>fake money</b>, so you can watch how it behaves
      before anything real is at stake. Take your time.</p>
    <p class="sub">Next, if you like: connect your Kalshi account. Your key stays on this computer, encrypted and locked by ${store}.</p>
    <div class="pre-act" style="justify-content:flex-end"><button data-ob="close">Just practise for now</button>
      <button class="primary" data-ob="go1">Connect my Kalshi account</button></div>`;
  if (step === 1) host.innerHTML = `
    <div class="pre-tag">Step 1 of 3</div><h2 id="obtitle">Connect your Kalshi account</h2>
    ${k.source === 'vault' ? `<div class="tip2"><b>Connected ✓</b>Key …${esc(k.key_tail || '')} is saved on this computer. You can connect a different one below.</div>` : ''}
    <ol class="obhow"><li>On <b>kalshi.com</b>, open your account settings → <b>API keys</b> → <b>Create key</b>.</li>
      <li>Kalshi shows a <b>Key ID</b> and downloads a <b>private key file</b>. Keep that file private.</li></ol>
    <label class="obf"><span>Key ID</span><input id="obkeyid" autocomplete="off" spellcheck="false" placeholder="e.g. a1b2c3d4-…"></label>
    <label class="obf"><span>Private key file</span><input id="obkeyfile" type="file" accept=".key,.pem,.txt,text/plain"></label>
    <details class="obpaste"><summary>Paste the key instead</summary>
      <textarea id="obkeypem" rows="5" autocomplete="off" spellcheck="false" placeholder="-----BEGIN RSA PRIVATE KEY-----&#10;…&#10;-----END RSA PRIVATE KEY-----"></textarea></details>
    <p class="sub obsafe">🔒 Stored only on this computer: encrypted, and locked by ${store}. It’s never uploaded, never shown again,
      and only used to sign your own requests to Kalshi.</p>
    <div class="obmsg" aria-live="polite"></div>
    <div class="pre-act"><button data-ob="back0">Back</button><span class="spacer"></span><button data-ob="close">Skip for now</button>
      <button class="primary" data-ob="connect">Connect</button></div>`;
  if (step === 2) {
    const b = obBal || {}, crypto = +b.crypto || 0, other = +b.other || 0;
    host.innerHTML = `<div class="pre-tag">Step 2 of 3</div><h2 id="obtitle">Your money</h2>
      <div class="facts">${tile('Crypto section (where the bot trades)', obMoney(crypto), crypto >= 1 ? 'pos' : '')}${tile('Other sections', obMoney(other))}</div>
      ${crypto < 1 && other > 0 ? `<p>Kalshi keeps money in sections. Move some into the crypto section so the bot can use it. It stays in your account.</p>
        <label class="obf"><span>Amount to move</span><input id="obmove" inputmode="decimal" placeholder="$ e.g. 25"></label>
        <div id="obmovephrase"></div>`
      : crypto >= 1 ? '<p>Your crypto section has money, so the bot can use it. Nothing to move.</p>'
      : '<p>Your Kalshi account has no money yet. Add some on kalshi.com, then come back here (Settings → Kalshi account).</p>'}
      <div class="obmsg" aria-live="polite"></div>
      <div class="pre-act"><button data-ob="back1">Back</button><span class="spacer"></span>
        ${crypto < 1 && other > 0 ? '<button class="primary" data-ob="moveplan">Move money</button>' : ''}
        <button class="${crypto >= 1 ? 'primary' : ''}" data-ob="go3">Next</button></div>`;
  }
  if (step === 3) {
    const crypto = +((obBal || {}).crypto || 0), cap = Math.max(1, Math.floor(Math.min(crypto || 25, 25)));
    host.innerHTML = `<div class="pre-tag">Step 3 of 3</div><h2 id="obtitle">Practice or real money?</h2>
      <p>Most people practise for a while first. You can switch to real money any time from <b>Settings → Kalshi account</b>.</p>
      <div class="note2">Real money is your call. This strategy hasn’t been shown to be profitable. A win pays a few cents per contract;
        a loss costs the whole price. Start small.</div>
      <div id="oblive" hidden>
        <label class="obf"><span>Most money the bot may use</span><input id="obcap" inputmode="decimal" value="${cap}"></label>
        <label class="obf"><span>Risk level: <b id="oblvname">Tiny</b></span><input id="oblevel" type="range" min="1" max="5" step="1" value="1" class="clump"></label>
        <div id="oblivephrase"></div>
      </div>
      <div class="obmsg" aria-live="polite"></div>
      <div class="pre-act"><button data-ob="back2">Back</button><span class="spacer"></span>
        <button data-ob="practise">Keep practising</button><button class="primary" data-ob="liveplan">Use real money…</button></div>`;
  }
  if (step === 4) host.innerHTML = `<div class="wnhero"><span class="wnlogo">${logoSVG(LOGOS[prefs.cat] ? prefs.cat : 'classic')}</span>
      <div><div class="pre-tag">All set</div><h2 id="obtitle">You’re ready</h2></div></div>
    <p>Odds &amp; Whiskers keeps running in the background, even when this window is closed. Open it any time from the icon.</p>
    <div class="pre-act" style="justify-content:flex-end"><button data-ob="close">Close</button>
      <button class="primary" data-ob="tour">Show me around</button></div>`;
  if (step === 5) host.innerHTML = `<div class="pre-tag">Switching to real money</div><h2 id="obtitle">Reopening in real-money mode…</h2>
    <p>Practice mode is turning off and Odds &amp; Whiskers opens again in real-money mode in about 15 seconds.
      This window will stop updating — you can close it then.</p>`;
  const f = host.querySelector('input:not([type=file]):not([type=range])'); if (f) f.focus({preventScroll: true});
}
const obMsg = (t, bad) => { const m = document.querySelector('#obbody .obmsg'); if (m) { m.textContent = t; m.className = 'obmsg ' + (bad ? 'neg' : 'pos'); } };
function obChange(e) { if (e.target.id === 'oblevel') $('oblvname').textContent = LEVEL_NAMES[+e.target.value - 1]; }
async function obClick(e) {
  const b = e.target.closest('[data-ob]'); if (!b) return;
  const a = b.dataset.ob;
  if (a === 'close') return obClose(true);
  if (a === 'practise') return obGo(4);
  if (a === 'tour') { obClose(true); return tourStart(); }
  if (/^go\d$/.test(a)) return obGo(+a[2]);
  if (/^back\d$/.test(a)) return obGo(+a[4]);
  b.disabled = true;
  try {
    if (a === 'connect') {
      const keyId = $('obkeyid').value.trim(), file = $('obkeyfile').files[0];
      let pem = $('obkeypem').value.trim();
      if (file) pem = (await file.text()).trim();
      if (!keyId || !pem) { obMsg('Enter the Key ID and choose (or paste) the private key.', true); return; }
      $('obkeypem').value = ''; $('obkeyfile').value = '';                   // nothing left in the page, success or not
      obMsg('Checking with Kalshi…');
      const r = await postJSON('/api/kalshi/connect', {key_id: keyId, pem});
      pem = null;
      obBal = r.balances; await load(); obGo(2);
    }
    if (a === 'moveplan') {
      const plan = await postJSON('/api/kalshi/move', {amount: $('obmove').value});
      $('obmovephrase').innerHTML = `<p class="sub">To move <b>${obMoney(plan.amount)}</b> into the crypto section, type exactly:</p>
        <div class="phrase">${esc(plan.phrase)}</div><input id="obmovetyped" autocomplete="off" spellcheck="false" placeholder="Type the phrase">`;
      b.textContent = 'Confirm move'; b.dataset.ob = 'movedo'; $('obmovetyped').focus();
    }
    if (a === 'movedo') {
      await postJSON('/api/kalshi/move', {amount: $('obmove').value, phrase: $('obmovetyped').value});
      obMsg('Moved. It can take a moment to show up.');
      setTimeout(async () => { try { obBal = await postJSON('/api/kalshi/balances', {}); } catch (err) {} obGo(2); }, 2500);
    }
    if (a === 'liveplan') {
      if ((window._state.kalshi || {}).source == null) { obMsg('Connect your Kalshi account first (step 1).', true); return; }
      $('oblive').hidden = false;
      if (!obBal) obBal = await postJSON('/api/kalshi/balances', {});
      const plan = await postJSON('/api/golive', {cap: $('obcap').value, level: +$('oblevel').value});
      const L = plan.limits;
      $('oblivephrase').innerHTML = `<div class="kvlist"><div class="kv"><span>Most the bot may use</span><span>${obMoney(L.capital_cap_usd)}</span></div>
        <div class="kv"><span>Most per bet</span><span>${obMoney(L.max_loss_per_position_usd)}</span></div>
        <div class="kv"><span>Bets open at once</span><span>${L.max_open_positions}</span></div>
        <div class="kv"><span>Daily stop</span><span>${Math.round(L.daily_loss_pct * 100)}%</span></div></div>
        <p class="sub">To allow real-money betting with these limits (for 30 days), type exactly:</p>
        <div class="phrase">${esc(plan.phrase)}</div><input id="oblivetyped" autocomplete="off" spellcheck="false" placeholder="Type the phrase">`;
      b.textContent = 'Switch to real money'; b.dataset.ob = 'livedo'; b.classList.add('danger'); $('oblivetyped').focus();
    }
    if (a === 'livedo') {
      await postJSON('/api/golive', {cap: $('obcap').value, level: +$('oblevel').value, phrase: $('oblivetyped').value});
      postJSON('/api/ui', {key: 'onboarded', value: true}).catch(() => {});
      obGo(5);
    }
  } catch (err) { obMsg(err.message, true); }
  finally { b.disabled = false; }
}
// a new copy (practice mode, no key yet) gets the welcome once
let obChecked = false;
function maybeOnboard(s) {
  if (obChecked || obOpen) return;
  obChecked = true;
  const k = s.kalshi || {};
  if ((s.ui || {}).onboarded || s.mode === 'live' || k.source) return;
  tourOffered = true;                                  // the wizard offers the tour itself
  obShow(0);
}

// ---- Settings → Kalshi account ---------------------------------------------------------------------
let lastAcct = '';
function renderAccount(s) {
  const k = s.kalshi || {}, key = JSON.stringify(k);
  if (key === lastAcct || !$('acctstatus')) return; lastAcct = key;
  const store = /Mac/i.test(navigator.platform || navigator.userAgent) ? 'your Mac’s Keychain' : 'Windows Credential Manager';
  $('acctstatus').innerHTML =
    (k.source === 'env' ? '<b>Connected</b> · this computer uses a key file set up in <b>.env</b>.' :
     k.source === 'vault' ? `<b>Connected ✓</b> · key …${esc(k.key_tail || '')}, saved ${k.saved_at ? dt(k.saved_at) : ''}. ` +
       `Encrypted on this computer and locked by ${store}.` : '<b>Not connected</b> · the bot runs in practice mode with fake money.') +
    `<br>Mode: <b>${k.mode === 'live' ? 'real money' : k.mode === 'demo' ? 'Kalshi demo' : 'practice (fake money)'}</b>`;
  $('acctactions').innerHTML =
    (k.can_change ? `<button class="primary" data-acct="connect">${k.source ? 'Connect a different key' : 'Connect my Kalshi account'}</button>` : '') +
    (k.source ? '<button data-acct="money">Balances &amp; moving money</button>' : '') +
    (k.source && k.mode !== 'live' ? '<button data-acct="live">Use real money…</button>' : '') +
    (k.source === 'vault' && k.can_change ? '<button data-acct="remove" class="danger">Remove key</button>' : '');
}
document.addEventListener('click', async e => {
  const b = e.target.closest('[data-acct]'); if (!b) return;
  const a = b.dataset.acct;
  $('scrim').classList.remove('open');
  if (a === 'connect') return obShow(1);
  if (a === 'money' || a === 'live') {
    try { obBal = await postJSON('/api/kalshi/balances', {}); } catch (err) { return alert(err.message); }
    return obShow(a === 'money' ? 2 : 3);
  }
  if (a === 'remove') {
    if (!confirm('Remove the saved Kalshi key from this computer? The bot keeps working in practice mode.')) return;
    try { await postJSON('/api/kalshi/remove', {}); lastAcct = ''; load(); } catch (err) { alert(err.message); }
  }
});
