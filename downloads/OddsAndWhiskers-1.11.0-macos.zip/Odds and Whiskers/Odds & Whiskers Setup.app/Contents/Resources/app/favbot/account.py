"""Your Kalshi account from inside the app: connect a key, see where your money is, move it to the crypto
section, and switch this copy to real money — each money step needs a phrase typed by you, exactly like the
terminal helpers. Nothing here runs by itself."""
from __future__ import annotations

import os
import shlex
import subprocess
import sys
import uuid
from decimal import Decimal
from pathlib import Path

from .config import PROD_URL, Config, Credentials, Limits, credential_source

MIN_LIVE_BALANCE = Decimal("1")


async def balances(creds: Credentials, series: str) -> dict:
    """Read-only: balance of every section of the account, and which one the crypto contracts trade in."""
    from .money import d_or_zero
    from .providers.kalshi import KalshiAPI, KalshiTrading, Signer
    api = KalshiAPI(PROD_URL, signer=Signer(creds.key_id, creds.private_key), read_only=False)
    try:
        shard = (await api.get_series(series)).exchange_index
        raw = await KalshiTrading(api, exchange_index=2).get_all_balances()
    finally:
        await api.close()
    by = {int(b.get("exchange_index")): d_or_zero(b.get("balance")) for b in raw.get("balance_breakdown") or []}
    others = {k: v for k, v in by.items() if k != shard and v > 0}
    return {"crypto_shard": shard, "by_shard": {str(k): str(v) for k, v in sorted(by.items())},
            "crypto": str(by.get(shard, Decimal(0))), "other": str(sum(others.values(), Decimal(0))),
            "move_from": max(others, key=others.get) if others else None}


def move_phrase(amount: Decimal, shard: int) -> str:
    return f"MOVE {amount:.2f} TO SHARD {shard}"


async def move(creds: Credentials, amount: Decimal, source: int, shard: int) -> dict:
    from .providers.kalshi import KalshiAPI, KalshiTrading, Signer
    api = KalshiAPI(PROD_URL, signer=Signer(creds.key_id, creds.private_key), read_only=False)
    try:
        return await KalshiTrading(api, exchange_index=2).transfer_to_shard(amount, shard, str(uuid.uuid4()),
                                                                             source_shard=source)
    finally:
        await api.close()


def live_limits(cap: Decimal, level: int) -> Limits:
    """Real-money limits from a cap you choose and a Clump level (same rules as the Go live helper)."""
    from .presets import limits_for_level
    base = Limits(capital_cap_usd=cap, max_loss_per_position_usd=Decimal("1"), max_loss_per_position_pct=Decimal("0.1"),
                  max_total_exposure_pct=Decimal("0.1"), daily_loss_pct=Decimal("0.20"), max_open_positions=1)
    return limits_for_level(max(1, min(5, int(level))), base)


def switch_to_live(cfg: Config, lim: Limits, creds: Credentials) -> None:
    """Write the limits, the typed acknowledgement and `mode: live` (call only after the phrase matched)."""
    from .configedit import update_config
    from .liveguard import write_ack
    update_config(Path(cfg.config_path), {
        "live_limits": {k: (v if isinstance(v, int) else str(v)) for k, v in lim.model_dump().items()},
        "live_limits_pending": None, "mode": "live"})
    write_ack(cfg.data_path("live"), lim, creds.key_fingerprint())


def key_source(cfg: Config, mode: str = "live") -> str | None:
    """'env' (key file named in .env), 'vault' (saved in the app) or None."""
    from . import vault
    if credential_source(mode):
        return "env"
    return "vault" if vault.status(cfg.data_path(mode).parent, mode).get("stored") else None


def relaunch(root: Path, delay: int = 10) -> None:
    """Open the app again in a few seconds — after this copy has turned itself off — so it starts in the new mode."""
    if sys.platform == "win32":
        ps = str(root / "app" / "BetterBot.ps1").replace("'", "''")
        subprocess.Popen(["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-Command",
                          f"Start-Sleep -Seconds {delay}; & '{ps}'"],
                         creationflags=0x08000000 | 0x00000200, close_fds=True)
    else:
        sh = shlex.quote(str(root / "app" / "launch_mac.sh"))
        subprocess.Popen(["/bin/bash", "-c", f"sleep {delay}; /bin/bash {sh}"], start_new_session=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
                         cwd=str(root), env=dict(os.environ))
