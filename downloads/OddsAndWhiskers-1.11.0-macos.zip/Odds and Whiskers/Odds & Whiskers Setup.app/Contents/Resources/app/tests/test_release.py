"""Sharing with friends: signed releases, safe installs, nothing personal ever shipped or overwritten."""
import shutil
import zipfile

import pytest

from favbot import release as R


def make_copy(root, version="1.0.0", body="print('v1')\n"):
    (root / "favbot").mkdir(parents=True)
    (root / "app").mkdir()
    (root / "tests").mkdir()
    (root / "favbot" / "VERSION").write_text(version + "\n")
    (root / "favbot" / "core.py").write_text(body)
    (root / "favbot" / "old.py").write_text("gone in v2\n")
    (root / "app" / "BetterBot.ps1").write_text("# launcher\n")
    (root / "README.md").write_text("readme\n")
    (root / "requirements.txt").write_text("PyYAML==6.0.2\n")
    # personal things: never shipped, never touched
    (root / "config.yaml").write_text("mode: live\nlive_limits: mine\n")
    (root / ".env").write_text("KALSHI_API_KEY_ID=my-secret-id\n")
    (root / "keys").mkdir()
    (root / "keys" / "k.pem").write_text("my key\n")
    (root / "Move sports money to crypto.bat").write_text("personal\n")
    return root


@pytest.fixture()
def setup(tmp_path):
    pub = make_copy(tmp_path / "me")
    key = tmp_path / "appdata" / "release_signing.pem"
    R.init_signing(key, pub / "favbot" / "release_pubkey.txt")
    friend = tmp_path / "friend"
    shutil.copytree(pub, friend)
    (friend / "config.yaml").write_text("mode: paper\n# friend's own settings\n")
    (friend / ".env").write_text("KALSHI_API_KEY_ID=friend-id\n")
    folder = tmp_path / "OneDrive" / R.FOLDER_NAME
    return pub, friend, key, folder


def test_publish_ships_code_only_and_friend_installs_it(setup):
    pub, friend, key, folder = setup
    (pub / "favbot" / "core.py").write_text("print('v2')\n")
    (pub / "favbot" / "old.py").unlink()
    (pub / "favbot" / "new.py").write_text("new\n")
    r = R.publish(folder, "Faster cats", "1.1.0", root=pub, key_path=key)
    names = zipfile.ZipFile(r["path"]).namelist()
    assert "Better Bot/favbot/new.py" in names and "release.sig" in names
    assert not any(n.endswith(("config.yaml", ".env", "k.pem", "Move sports money to crypto.bat")) for n in names)
    assert (folder / "READ ME FIRST.txt").exists()

    (friend / "data").mkdir()
    (friend / "data" / "update_folder.txt").write_text(str(folder))
    info = R.check(friend)
    assert info["available"]["version"] == "1.1.0" and info["available"]["notes"] == "Faster cats"
    out = R.install(folder / "BetterBot-1.1.0.zip", friend, save_point=False, run_pip=False)
    assert out["version"] == "1.1.0" and out["removed"] == 1
    assert (friend / "favbot" / "core.py").read_text() == "print('v2')\n"
    assert (friend / "favbot" / "new.py").exists() and not (friend / "favbot" / "old.py").exists()
    assert R.installed_version(friend) == "1.1.0"
    assert (friend / "config.yaml").read_text().startswith("mode: paper")          # his settings untouched
    assert (friend / ".env").read_text() == "KALSHI_API_KEY_ID=friend-id\n"         # his key untouched
    assert (friend / "keys" / "k.pem").exists()
    assert R.check(friend)["available"] is None                                     # nothing newer now
    with pytest.raises(R.ReleaseError):                                              # no reinstall / downgrade
        R.install(folder / "BetterBot-1.1.0.zip", friend, save_point=False, run_pip=False)


def test_versions_count_up_and_old_zips_are_pruned(setup):
    pub, _, key, folder = setup
    for _ in range(5):
        R.publish(folder, "", root=pub, key_path=key)
    assert R.published_versions(folder) == [(1, 0, 2), (1, 0, 3), (1, 0, 4)]
    with pytest.raises(R.ReleaseError):
        R.publish(folder, "", "1.0.1", root=pub, key_path=key)


def test_update_signed_by_someone_else_is_ignored(setup, tmp_path):
    pub, friend, key, folder = setup
    other = make_copy(tmp_path / "stranger")
    okey = tmp_path / "stranger-key.pem"
    R.init_signing(okey, other / "favbot" / "release_pubkey.txt")
    (other / "favbot" / "core.py").write_text("steal()\n")
    R.publish(folder, "totally legit", "9.0.0", root=other, key_path=okey)
    (friend / "data").mkdir()
    (friend / "data" / "update_folder.txt").write_text(str(folder))
    info = R.check(friend)
    assert info["available"] is None and info["rejected"]
    with pytest.raises(R.ReleaseError):
        R.install(folder / "BetterBot-9.0.0.zip", friend, save_point=False, run_pip=False)
    assert (friend / "favbot" / "core.py").read_text() == "print('v1')\n"


def test_file_changed_after_signing_installs_nothing(setup, tmp_path):
    pub, friend, key, folder = setup
    (pub / "favbot" / "core.py").write_text("print('v2')\n")
    r = R.publish(folder, "", "1.1.0", root=pub, key_path=key)
    bad = tmp_path / "BetterBot-1.1.0.zip"
    with zipfile.ZipFile(r["path"]) as zin, zipfile.ZipFile(bad, "w") as zout:
        for n in zin.namelist():
            data = zin.read(n)
            zout.writestr(n, b"evil()\n" if n.endswith("core.py") else data)
    with pytest.raises(R.ReleaseError, match="changed after it was signed"):
        R.install(bad, friend, save_point=False, run_pip=False)
    assert (friend / "favbot" / "core.py").read_text() == "print('v1')\n" and R.installed_version(friend) == "1.0.0"


def test_updates_can_only_write_code_files():
    assert R.allowed("favbot/engine.py") and R.allowed("app/BetterBot.ps1") and R.allowed("Go live.bat")
    for bad in ("config.yaml", ".env", "keys/k.pem", "data/live/favbot.sqlite3", "favbot/../config.yaml",
                "/etc/x", "C:/Windows/x", "Move sports money to crypto.bat", "versions/001/x.py"):
        assert not R.allowed(bad), bad


def test_never_publishes_a_key(setup):
    pub, _, key, folder = setup
    (pub / "favbot" / "oops.py").write_text("K = '''-----BEGIN PRIVATE KEY-----\n" + "A" * 80 + "\n-----END PRIVATE KEY-----'''\n")
    with pytest.raises(R.ReleaseError, match="private key"):
        R.publish(folder, "", "1.1.0", root=pub, key_path=key)
    assert not R.published_versions(folder)


def test_publishing_needs_the_matching_signing_key(setup, tmp_path):
    pub, _, _, folder = setup
    with pytest.raises(R.ReleaseError, match="init"):
        R.publish(folder, "", "1.1.0", root=pub, key_path=tmp_path / "missing.pem")


def test_real_app_release_has_no_personal_files():
    files = R.release_files()
    assert "favbot/release.py" in files and "favbot/CHANGELOG.json" in files
    for helper in ("app/install.ps1", "Install Odds and Whiskers.bat", "app/install_mac.sh", "Install Odds and Whiskers.command"):
        assert (helper in files) == (R.ROOT / helper).exists(), helper     # a platform package has only its own helpers
    assert not any(f in files for f in ("config.yaml", ".env", "Move sports money to crypto.bat"))
    assert not any(f.startswith(("data/", "keys/", "versions/", ".venv/")) for f in files)
