@echo off
cd /d "%~dp0"
title Better Bot - confirm new real-money limits
echo This shows the new limits you picked in the app and asks you to type a phrase to accept them.
echo Your bot keeps using its current limits until you do.
echo.
.venv\Scripts\python.exe -m favbot ack-live
echo.
pause
