"""Page scripts must be well formed: one stray backtick blanked the whole app window in 2.0.0."""
from pathlib import Path

import pytest

from favbot import release
from favbot.webcheck import check_js, check_web

WEB = Path(__file__).resolve().parents[1] / "favbot" / "web"


def test_every_page_script_is_well_formed():
    assert check_web(WEB) == {}


def test_catches_the_2_0_0_stray_backtick():
    good = (WEB / "catnap.js").read_text(encoding="utf-8")
    fixed = "<p>${esc(S.detail)}</p>${step}\n"
    assert fixed in good
    bad = good.replace(fixed, "<p>${esc(S.detail)}</p>${step}`\n", 1)
    assert check_js(bad)


@pytest.mark.parametrize("src", [
    "const a = `x ${b ? `y ${c}` : '}'} z`;",
    "s.replace(/[-:T]/g, '').split('/')",
    "const r = a / b / c; if (x) { y(); }",
    "// a ` in a comment\n/* and a ' here */ f();",
    "const t = 'it\\'s'; const u = \"a \\\" b\";",
    "return /\\d+[/]x/.test(v)",
    "const o = {a: [1, 2, {b: (3)}]};",
    "x = y ?? z?.w;",
])
def test_well_formed(src):
    assert check_js(src) == []


@pytest.mark.parametrize("src", [
    "const a = `open template;",
    "f(1, 2;",
    "const o = {a: 1;",
    "g(]);",
    "const s = 'never closed;\nnext();",
    "/* never closed",
    "const a = `${b`;",
])
def test_broken(src):
    assert check_js(src)


def test_publish_refuses_a_broken_script(tmp_path):
    web = tmp_path / "favbot" / "web"
    web.mkdir(parents=True)
    (web / "bad.js").write_text("const a = `oops;", encoding="utf-8")
    key = tmp_path / "k.pem"
    key.write_text("x", encoding="utf-8")
    with pytest.raises(release.ReleaseError, match="bad.js"):
        release.publish(tmp_path / "out", root=tmp_path, key_path=key)
