@echo off
cd /d "%~dp0"
title Odds and Whiskers - install
if not exist "%~dp0app\install.ps1" (
  echo.
  echo  This needs the whole folder, not just this file.
  echo  Right-click the downloaded zip, choose "Extract All...", click Extract,
  echo  then double-click "Install Odds and Whiskers" in the folder that opens.
  echo.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\install.ps1" %*
if errorlevel 1 (
  echo.
  echo  Something went wrong - the message above says what. Nothing of yours was changed.
  echo.
  pause
  exit /b 1
)
echo.
echo  This window closes by itself in 20 seconds.
timeout /t 20 >nul
