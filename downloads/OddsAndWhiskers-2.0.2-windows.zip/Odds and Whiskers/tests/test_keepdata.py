"""Updates keep every bit of a person's data: key, settings, history, Litter Box, layouts (2.0.1)."""
import json
import sqlite3
from types import SimpleNamespace

import pytest
from aiohttp import web

from favbot import dashboard
from favbot import release as R
from tests.test_release import make_copy


def _db(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE t(x)")
    con.execute("INSERT INTO t VALUES (?)", (value,))
    con.commit()
    return con


def _personal_data(root):
    data = root / "data"
    cons = [_db(data / "live" / "favbot.sqlite3", "real history"),
            _db(data / "litterbox" / "original" / "favbot.sqlite3", "fake bets"),
            _db(data / "litterbox" / "twin" / "favbot.sqlite3", "twin bets")]
    (data / "litterbox" / "original" / "season.txt").write_text("season-3")
    (data / "litterbox" / "variants.json").write_text('[{"base": "original", "level": 5}]')
    (data / "litterbox" / "summary.json").write_text('{"models": []}')
    (data / "litterbox" / "bot.log.jsonl").write_text("log line\n")
    (data / "litterbox" / "_old" / "season-2-original").mkdir(parents=True)
    (data / "lab").mkdir()
    (data / "lab" / "history.json").write_text("[1]")
    (data / "vault").mkdir()
    (data / "vault" / "kalshi-live.vault").write_bytes(b"encrypted")
    (data / "live" / "live_ack.json").write_text("{}")
    return data, cons


def test_backup_before_an_update_includes_the_litter_box_lab_and_vault(tmp_path):
    data, cons = _personal_data(tmp_path)
    cfg = tmp_path / "config.yaml"
    cfg.write_text("mode: live\n")
    dest = R.backup_data(data / "live", cfg, "before-2.0.1")
    q = lambda p: sqlite3.connect(p).execute("SELECT x FROM t").fetchone()[0]        # noqa: E731
    assert q(dest / "favbot.sqlite3") == "real history"
    assert q(dest / "litterbox" / "original" / "favbot.sqlite3") == "fake bets"
    assert q(dest / "litterbox" / "twin" / "favbot.sqlite3") == "twin bets"
    assert (dest / "litterbox" / "original" / "season.txt").read_text() == "season-3"
    assert json.loads((dest / "litterbox" / "variants.json").read_text())[0]["level"] == 5
    assert (dest / "lab" / "history.json").read_text() == "[1]"
    assert (dest / "vault" / "kalshi-live.vault").read_bytes() == b"encrypted"         # still encrypted
    assert not (dest / "litterbox" / "bot.log.jsonl").exists()                         # logs aren't data
    for c in cons:
        c.close()


def test_installing_an_update_never_touches_personal_data(tmp_path):
    me = make_copy(tmp_path / "me")
    friend = make_copy(tmp_path / "friend")
    key = tmp_path / "key.pem"
    R.init_signing(key, me / "favbot" / "release_pubkey.txt")
    (friend / "favbot" / "release_pubkey.txt").write_text((me / "favbot" / "release_pubkey.txt").read_text())
    data, cons = _personal_data(friend)
    for c in cons:
        c.close()
    before = {p.relative_to(friend).as_posix(): p.read_bytes() for p in data.rglob("*") if p.is_file()}
    before.update({n: (friend / n).read_bytes() for n in ("config.yaml", ".env", "keys/k.pem")})
    (me / "favbot" / "core.py").write_text("print('v2')\n")
    R.publish(tmp_path / "share", "", "1.1.0", root=me, key_path=key, packages=False)
    R.install(tmp_path / "share" / "BetterBot-1.1.0.zip", friend, save_point=False, run_pip=False)
    assert (friend / "favbot" / "core.py").read_text() == "print('v2')\n"              # the update arrived
    after = {k: (friend / k).read_bytes() for k in before}
    assert after == before                                                             # and nothing personal moved


class _Store:
    def __init__(self):
        self.meta = {}

    def set_meta(self, k, v):
        self.meta[k] = v

    def get_meta(self, k, default=None):
        return self.meta.get(k, default)


class _Req:
    headers = {"X-Token": "t"}

    def __init__(self, method, body=b""):
        self.method, self.body = method, body

    async def read(self):
        return self.body


async def test_layout_and_display_choices_are_kept_in_your_own_data():
    bot = SimpleNamespace(store=_Store())
    d = dashboard.Dashboard(bot, 0)
    d.token = "t"
    r = await d.prefs(_Req("GET"))
    assert json.loads(r.body) == {"prefs": None}
    mine = {"layout": {"order": ["balance", "litter"]}, "textSize": "L", "chat": {"risk": "chonk"}}
    await d.prefs(_Req("POST", json.dumps({"prefs": mine}).encode()))
    assert json.loads((await d.prefs(_Req("GET"))).body) == {"prefs": mine}
    with pytest.raises(web.HTTPBadRequest):
        await d.prefs(_Req("POST", b'{"prefs": "nope"}'))
    with pytest.raises(web.HTTPRequestEntityTooLarge):
        await d.prefs(_Req("POST", b'{"prefs": {"x": "' + b"a" * 70_000 + b'"}}'))
