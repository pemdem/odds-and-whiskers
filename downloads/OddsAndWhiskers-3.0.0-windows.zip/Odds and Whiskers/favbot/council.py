"""Cat Council: your sidekick answers questions from the app's real data.

The sidekick the person chose answers everything; each one only has its own voice around the same facts. Every
answer is built from "lookups" (tools) that read the real balances, bets, settings, logs, Litter Box and Backtrack
results. Questions are understood with typos fixed, and follow-ups ("why?", "what about SOL?", "compare it to ETH")
use the previous answer's context, which the app sends back with the next question. A question that isn't clear
gets a short "did you mean…?" instead of the introduction again. Each fact block is labelled — real money, practice/simulated, historical test, estimate, live market, app
status — with the time it was read. If something isn't available, the answer says so rather than guessing.

Answers can offer actions (open a screen, preview a Clump change, start a fake-money experiment, resume). The
app only carries them out when the person clicks, through the same endpoints and confirmations as before; no
lookup here can trade or change a setting. Credentials never appear in any lookup result.

Works fully offline. An optional AI mode (council_ai.py) may rephrase and reason over the same lookups.
"""
from __future__ import annotations

import math
import re
import time
from decimal import Decimal

from . import catnap
from .money import d_or_zero

CATS = ("biscuit", "chonk", "chill", "katya")
NAMES = {"biscuit": "Biscuit", "chonk": "Le Chonk", "chill": "Le Chill", "katya": "Katya"}
COINS = ("ETH", "SOL", "XRP", "DOGE", "BNB", "ZEC", "HYPE", "NEAR", "BTC")
LEVEL_NAMES = ("tiny", "light", "steady", "bold", "chonky")

# labels on every fact block
REAL, PRACTICE, SIM, HIST, EST, LIVE, APP = ("Real money", "Practice money", "Simulated (fake money)",
                                             "Historical test", "Estimate", "Live market", "App status")


def _c(p) -> str:
    try:
        return f"{float(p) * 100:.0f}¢"
    except (TypeError, ValueError):
        return "–"


def _m(v, sign=False) -> str:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return "–"
    s = f"${abs(x):,.2f}"
    return (("+" if x > 0 else "−" if x < 0 else "") + s) if sign else ("−" + s if x < 0 else s)


def _pct(v, digits=1) -> str:
    try:
        return f"{float(v) * 100:+.{digits}f}%"
    except (TypeError, ValueError):
        return "–"


def _ago(ts, now) -> str:
    if not ts:
        return "unknown time"
    s = now - ts
    if s < 90:
        return "just now"
    if s < 3600:
        return f"{int(s // 60)} min ago"
    if s < 86400:
        return f"{s / 3600:.1f} h ago"
    return f"{s / 86400:.1f} days ago"


def block(label: str, items: list[str], as_of: float | None = None, note: str | None = None) -> dict:
    return {"label": label, "items": [i for i in items if i], "as_of": as_of, "note": note}


# ---- the lookups (the only way an answer gets facts) ---------------------------------------------
class Ctx:
    """Everything a lookup may read. Built per question by the dashboard."""
    def __init__(self, bot, state: dict, since: float | None = None):
        self.bot, self.s, self.now = bot, state, bot.clock()
        self.money = REAL if bot.mode == "live" else PRACTICE
        self.since = since


def look_account(x: Ctx) -> dict:
    a = x.s.get("account")
    if not a:
        return {"unavailable": "The account balance hasn't been read from Kalshi yet (the bot may still be starting)."}
    return {"label": x.money, "as_of": x.now, "equity": a["equity"], "cash": a["balance"], "in_bets": a["positions_value"],
            "reserved": a.get("reserved"), "open_positions": a["open_positions"], "today_pnl": a.get("daily_pnl"),
            "cap": x.s.get("limits", {}).get("capital_cap_usd")}


def look_positions(x: Ctx) -> dict:
    ob = x.s.get("open_bets") or []
    pend = [e for e in (x.s.get("pending") or []) if e.get("state") == "resting"]
    return {"label": x.money, "as_of": x.now,
            "holding": [{"coin": b["coin"], "side": b["outcome"], "qty": b["qty"], "price": b["price"], "cost": b["cost"],
                         "worth_now": b.get("value"), "pays_if_win": b["if_win"],
                         "result_in_s": (b["closes_at"] - x.now) if b.get("closes_at") else None} for b in ob],
            "waiting_bids": [{"coin": e["coin"], "side": e["outcome"], "price": e["price"], "count": e["count"]} for e in pend]}


def look_activity(x: Ctx, since: float | None = None) -> dict:
    since = since or x.since or (x.now - 86400)
    ser = [p for p in (x.s.get("series") or []) if (p.get("ts") or 0) >= since]
    wins = sum(1 for p in ser if p["pnl"] > 0)
    ev = [e for e in (x.s.get("errors") or []) if (e.get("ts") or 0) >= since]
    kinds = {}
    for e in ev:
        kinds[e["kind"]] = kinds.get(e["kind"], 0) + 1
    return {"label": x.money, "since": since, "as_of": x.now, "settled": len(ser), "wins": wins, "losses": len(ser) - wins,
            "pnl": round(sum(p["pnl"] for p in ser), 2), "fees": None,
            "last": [{"coin": p["coin"], "side": p["outcome"], "pnl": p["pnl"], "ts": p["ts"]} for p in ser[-5:]][::-1],
            "notable_events": [{"ts": e["ts"], "kind": e["kind"], "message": catnap.scrub(e["message"])[:160]} for e in ev[:6]],
            "event_counts": kinds}


def look_status(x: Ctx) -> dict:
    st = catnap.status(x.bot)
    return {"label": APP, "as_of": x.now, **{k: st[k] for k in ("level", "title", "headline", "detail", "next_step", "action")}}


def look_why_no_bet(x: Ctx) -> dict:
    return {"label": APP, "as_of": x.now, "coins": catnap.why_no_bet(x.bot)}


def look_stop_history(x: Ctx) -> dict:
    """The last things that stopped or paused trading, from the bot's own event log."""
    kinds = ("kill", "daily_loss", "halt", "pause", "turned_off", "restart", "recovering", "recovered", "update",
             "engine_error", "shutdown", "settings", "go_live", "unkill", "resume")
    rows = x.bot.store._q(f"SELECT ts, level, kind, message FROM events WHERE kind IN ({','.join('?' * len(kinds))}) "
                          "ORDER BY id DESC LIMIT 8", kinds)
    return {"label": APP, "as_of": x.now, "events": [{"ts": r["ts"], "kind": r["kind"], "level": r["level"],
                                                    "message": catnap.scrub(r["message"])[:200]} for r in rows]}


def look_risk(x: Ctx) -> dict:
    lim, a, p = x.s.get("limits") or {}, x.s.get("account") or {}, x.s.get("presets") or {}
    cur = (p.get("current") or {})
    lv = cur.get("level")
    names = [l["name"] for l in p.get("levels", [])]
    return {"label": x.money, "as_of": x.now, "level": names[lv - 1] if lv and names else None, "level_n": lv,
            "per_bet": lim.get("max_loss_per_position_usd"), "cap": lim.get("capital_cap_usd"),
            "max_open": lim.get("max_open_positions"), "exposure_pct": lim.get("max_total_exposure_pct"),
            "daily_stop_pct": lim.get("daily_loss_pct"), "exposure_now": a.get("exposure"), "open_now": a.get("open_positions"),
            "today_pnl": a.get("daily_pnl"), "pending_limits": bool(p.get("pending_limits")),
            "kill": x.s.get("killed"), "paused": x.s.get("paused"), "daily_loss_hit": x.s.get("daily_loss_hit")}


def look_strategy(x: Ctx) -> dict:
    p = x.s.get("presets") or {}
    cur, rec = p.get("current") or {}, p.get("recommended") or {}
    lab = (x.s.get("lab") or {}).get("candidate") or {}
    ev = lab.get("last_eval") or {}
    return {"label": APP, "as_of": x.now, "live_strategy": cur.get("describe"), "is_original": cur.get("is_original"),
            "recommended": ({"label": rec.get("label"), "fresh_roi": (rec.get("fresh") or {}).get("roi"),
                             "fresh_bets": (rec.get("fresh") or {}).get("n"), "days": rec.get("days")} if rec.get("ready") else None),
            "testing": ({"id": lab.get("id"), "label": lab.get("label"), "cand_bets": (ev.get("candidate") or {}).get("n", 0),
                         "orig_bets": (ev.get("original") or {}).get("n", 0), "need": ev.get("need", 300),
                         "cand_roi": (ev.get("candidate") or {}).get("roi"), "orig_roi": (ev.get("original") or {}).get("roi"),
                         "days": ev.get("age_days")} if lab.get("status") == "testing" else None),
            "ideas_tested": rec.get("tested", 0)}


def _lb_models(x: Ctx) -> list[dict]:
    return ((x.s.get("litterbox") or {}).get("summary") or {}).get("models") or []


def look_litterbox(x: Ctx) -> dict:
    lb = x.s.get("litterbox") or {}
    ms = _lb_models(x)
    if not ms:
        return {"unavailable": "The Litter Box isn't running, so there are no fake-money results yet."}
    ranked = sorted((m for m in ms if m.get("bets", 0) >= 10), key=lambda m: -(m.get("roi") or 0))
    fmt = lambda m: {"id": m["id"], "name": m["name"], "bets": m.get("bets", 0), "roi": m.get("roi"),  # noqa: E731
                     "se": m.get("se"), "pnl": m.get("pnl"), "group": m.get("group")}
    twin = next((m for m in ms if m["id"] == "twin"), None)
    return {"label": SIM, "as_of": (lb.get("summary") or {}).get("ts"), "running": lb.get("running"), "models": len(ms),
            "fake_bets": sum(m.get("bets", 0) for m in ms), "top": [fmt(m) for m in ranked[:3]],
            "bottom": [fmt(m) for m in ranked[-2:]] if len(ranked) > 3 else [],
            "too_few": [m["name"] for m in ms if m.get("bets", 0) < 10][:6], "twin": fmt(twin) if twin else None}


def look_backtrack(x: Ctx) -> dict:
    r = ((x.s.get("backtrack") or {}).get("results")) or None
    if not r:
        return {"unavailable": "Backtrack hasn't been run yet (it runs every night at 3 AM, or press Run Backtrack)."}
    c, wf = r["current"]["all"], r.get("walk_forward") or {}
    return {"label": HIST, "as_of": r.get("generated_at"), "days": r.get("days"), "contracts": r.get("contracts"),
            "yours": {"bets": c.get("n"), "win_rate": c.get("win_rate"), "roi": c.get("roi"), "se": c.get("se"),
                      "uncertain_fills": c.get("uncertain_fills")},
            "walk_forward": {"verdict": wf.get("verdict"), "chosen_roi": (wf.get("chosen_overall") or {}).get("roi"),
                             "current_roi": (wf.get("current_overall") or {}).get("roi")},
            "proposal": (r.get("proposal") or {}).get("label")}


def look_scorecard(x: Ctx) -> dict:
    sc = x.s.get("scorecard") or {}
    if not sc.get("n"):
        return {"unavailable": "No settled bets yet, so there's no record to judge."}
    return {"label": x.money, "as_of": x.now, "bets": sc["n"], "win_rate": sc.get("win_rate"), "low": sc.get("low"),
            "high": sc.get("high"), "breakeven": sc.get("breakeven"), "net": sc.get("net"), "verdict": sc.get("verdict"),
            "roi": sc.get("roi"), "roi_se": sc.get("roi_se")}


def look_losses(x: Ctx, coin: str | None = None) -> dict:
    ser = [p for p in (x.s.get("series") or []) if not coin or p.get("coin") == coin]
    if not ser:
        return {"unavailable": "No settled bets yet" + (f" on {coin}" if coin else "") + "."}
    losses = [p for p in ser if p["pnl"] < 0]
    n, w = len(ser), len(ser) - len(losses)
    by_coin: dict[str, list] = {}
    for p in losses:
        by_coin.setdefault(p["coin"], []).append(p["pnl"])
    run = best_run = 0
    for p in ser:
        run = run + 1 if p["pnl"] < 0 else 0
        best_run = max(best_run, run)
    recent = ser[-20:]
    rl = sum(1 for p in recent if p["pnl"] < 0)
    q = max(0.01, min(0.99, len(losses) / n))            # the loss rate so far
    # how surprising are the recent losses, if the long-run loss rate held? (binomial tail)
    tail = sum(math.comb(len(recent), k) * q ** k * (1 - q) ** (len(recent) - k) for k in range(rl, len(recent) + 1))
    prices = [p.get("price") for p in losses if p.get("price")]
    return {"label": x.money, "as_of": x.now, "bets": n, "wins": w, "losses": len(losses),
            "lost_total": round(sum(p["pnl"] for p in losses), 2), "avg_loss": round(sum(p["pnl"] for p in losses) / len(losses), 2) if losses else 0,
            "avg_win": round(sum(p["pnl"] for p in ser if p["pnl"] > 0) / w, 2) if w else 0,
            "by_coin": sorted(((k, len(v), round(sum(v), 2)) for k, v in by_coin.items()), key=lambda t: t[2])[:5],
            "longest_losing_run": best_run, "recent_losses": rl, "recent_n": len(recent), "recent_tail_prob": tail,
            "avg_loss_price": (sum(prices) / len(prices)) if prices else None,
            "last_losses": [{"coin": p["coin"], "side": p["outcome"], "pnl": p["pnl"], "ts": p["ts"]} for p in losses[-4:]][::-1]}


def look_market(x: Ctx, coin: str | None = None) -> dict:
    rows = [c for c in (x.s.get("coins") or []) if not coin or c.get("coin") == coin]
    if not rows:
        return {"unavailable": f"I'm not watching {coin} — it isn't one of your coins." if coin else "No prices yet."}
    return {"label": LIVE, "as_of": max((c.get("book_ts") or 0) for c in rows) or x.now,
            "coins": [{"coin": c["coin"], "up_ask": c.get("up_ask"), "down_ask": c.get("down_ask"),
                       "closes_in_s": c.get("secs_left"), "book_ts": c.get("book_ts")} for c in rows]}


def look_compare(x: Ctx, a: str | None, b: str | None) -> dict:
    ms = _lb_models(x)
    find = lambda q: next((m for m in ms if q and (q.lower() in m["name"].lower() or q.lower() == m["id"])), None)  # noqa: E731
    ma, mb = find(a), find(b)
    if not ma or not mb:
        return {"unavailable": "I need two Litter Box models to compare (for example “compare Ask Buyer and Down Dog”)."}
    diff = (ma.get("roi") or 0) - (mb.get("roi") or 0)
    noise = math.sqrt((ma.get("se") or 0) ** 2 + (mb.get("se") or 0) ** 2) or None
    return {"label": SIM, "as_of": ((x.s.get("litterbox") or {}).get("summary") or {}).get("ts"),
            "a": {k: ma.get(k) for k in ("name", "bets", "roi", "se", "pnl")}, "b": {k: mb.get(k) for k in ("name", "bets", "roi", "se", "pnl")},
            "diff": diff, "noise": noise, "clear": bool(noise and abs(diff) > 2 * noise)}


def look_recap(x: Ctx, day: str = "today") -> dict:
    r = catnap.recap(x.bot, day, (x.s.get("litterbox") or {}).get("summary"))
    return {"label": x.money, **r}


def _coin_stats(series: list[dict]) -> list[dict]:
    by: dict[str, dict] = {}
    for p in series:
        c = by.setdefault(p["coin"], {"coin": p["coin"], "bets": 0, "wins": 0, "pnl": 0.0, "staked": 0.0, "_price": 0.0})
        c["bets"] += 1
        c["wins"] += p["pnl"] > 0
        c["pnl"] += p["pnl"]
        c["staked"] += p.get("cost") or 0
        c["_price"] += p.get("price") or 0
    out = []
    for c in by.values():
        out.append({"coin": c["coin"], "bets": c["bets"], "wins": c["wins"], "pnl": round(c["pnl"], 2),
                    "staked": round(c["staked"], 2), "roi": (c["pnl"] / c["staked"]) if c["staked"] else None,
                    "avg_price": (c["_price"] / c["bets"]) if c["_price"] else None})
    return out


def look_coins(x: Ctx, coin: str | None = None) -> dict:
    """How each coin has done: your settled bets, the Litter Box's one-coin models (fake money) and Backtrack."""
    real = _coin_stats(x.s.get("series") or [])
    lbs = (x.s.get("litterbox") or {}).get("summary") or {}
    sim = [{"coin": m["coins"][0], "name": m["name"], "bets": m.get("bets", 0), "roi": m.get("roi"), "se": m.get("se"),
            "pnl": m.get("pnl")} for m in _lb_models(x)
           if str(m.get("id", "")).startswith("solo-") and len(m.get("coins") or []) == 1]
    bt = ((x.s.get("backtrack") or {}).get("results")) or {}
    hist = [{"coin": r["key"], "bets": r.get("n", 0), "wins": r.get("wins"), "win_rate": r.get("win_rate"), "roi": r.get("roi"),
             "se": r.get("se"), "avg_price": r.get("avg_price")} for r in bt.get("by_coin") or []]
    if coin:
        real, sim, hist = ([r for r in rows if r["coin"] == coin] for rows in (real, sim, hist))
    if not (real or sim or hist):
        return {"unavailable": (f"No results for {coin} yet." if coin else "No per-coin results yet: no settled bets, "
                                "Litter Box results or Backtrack run.")}
    return {"label": x.money, "as_of": x.now, "real": real, "sim": sim, "sim_as_of": lbs.get("ts"), "hist": hist,
            "hist_as_of": bt.get("generated_at"), "hist_days": bt.get("days")}


LOOKUPS = {"account": look_account, "positions": look_positions, "activity": look_activity, "status": look_status,
           "why_no_bet": look_why_no_bet, "stop_history": look_stop_history, "risk": look_risk, "strategy": look_strategy,
           "litterbox": look_litterbox, "backtrack": look_backtrack, "scorecard": look_scorecard, "losses": look_losses,
           "market": look_market, "compare": look_compare, "recap": look_recap, "coins": look_coins}


async def refresh_market(bot, coin: str | None = None) -> None:
    """Fetch current prices from Kalshi now (read-only) for the contract each coin shows, so a market answer is
    fresh even outside the betting window. Only fills in the price fields the app already shows."""
    from .engine import _s
    for e in bot.engines:
        if coin and e.coin != coin:
            continue
        t = e.status.get("contract")
        c = e.contracts.get(t) if t else None
        if not c:
            continue
        try:
            book = await bot.md.get_orderbook(t)
        except Exception:  # noqa: BLE001 - keep whatever the engine last saw
            continue
        up, dn = c.leg_of("UP"), c.leg_of("DOWN")
        e.status.update({"up_bid": _s(book.best_bid(up)), "up_ask": _s(book.best_ask(up)),
                         "down_bid": _s(book.best_bid(dn)), "down_ask": _s(book.best_ask(dn)), "book_ts": book.fetched_at})


# ---- understanding the question --------------------------------------------------------------------
INTENTS = [
    # intent, phrases (the longer the phrase that matches, the stronger the match)
    ("stopped", ["why did trading stop", "why did it stop", "why stopped", "trading stop", "stopped trading",
                 "not trading", "why is it off", "why paused", "kill switch", "halted", "why stop", "stopped"]),
    ("nobet", ["why no bet", "why not bet", "why isn't it betting", "why isnt it betting", "no bets", "not betting",
               "why no trade", "isn't trading", "no trades", "why hasn't it", "why hasnt it"]),
    ("away", ["while i was away", "what happened", "since i left", "catch me up", "what did i miss",
              "while away", "overnight", "since last", "anything happen"]),
    ("recap", ["recap", "daily summary", "today's results", "todays results", "how did i do", "how was today",
               "how did today", "yesterday"]),
    ("coins", ["best coin", "worst coin", "which coin", "what coin", "top coin", "coin performing", "performing best",
               "best performing", "performing worst", "worst performing", "doing best", "doing worst", "best coins",
               "by coin", "each coin", "per coin", "coins doing", "coin doing", "most profitable coin", "favorite coin",
               "favourite coin", "coin is best", "coins are", "rank the coins", "ranking"]),
    ("experiment", ["create an experiment", "create experiment", "start an experiment", "paper experiment",
                    "test it at", "try it at", "with fake money", "fake money test", "make a copy"]),
    ("clump", ["set clump", "change clump", "clump to", "switch to bold", "switch to tiny", "risk level to",
               "preview", "lower my risk", "less risk", "more risk", "raise my risk", "change risk"]),
    ("compare", ["compare", " vs ", "versus", "difference between", "better than"]),
    ("unusual", ["unusual", "weird", "strange", "odd", "anomal", "suspicious", "doesn't make sense", "not normal"]),
    ("losses", ["why did i lose", "losing", "loss", "lost", "losses", "bad day", "drawdown", "down money"]),
    ("recommend", ["recommend", "should i switch", "should i change", "better strategy", "which strategy",
                   "best model", "does it support", "is it proven", "worth switching"]),
    ("backtrack", ["backtrack", "backtest", "past data", "historical", "history test"]),
    ("litterbox", ["litter box", "litterbox", "experiment", "models", "leaderboard", "simulated", "fake money", "twin"]),
    ("strategy", ["strategy", "how does it work", "how does the bot", "what does it bet", "favourite", "favorite", "rule"]),
    ("risk", ["risk", "exposure", "limit", "clump", "how much can i lose", "safe", "daily stop", "per bet", "cap"]),
    ("working", ["is it working", "making money", "profitable", "scorecard", "edge", "win rate", "winning"]),
    ("market", ["price", "market", "odds", "right now on", "how much is", "quote"]),
    ("positions", ["position", "open bet", "holding", "in play", "waiting bid", "current bet"]),
    ("balance", ["balance", "how much money", "how much do i have", "cash", "equity", "funds", "account", "worth", "my money"]),
    ("activity", ["recent", "activity", "last bets", "trades", "history", "fills", "today"]),
    ("status", ["status", "is it running", "is it on", "what's it doing", "whats it doing", "doing now", "alive"]),
    ("help", ["help", "what can you", "what do you know", "hello", "hi ", "hey", "who are you"]),
]
# a typical question for each topic: offered when a question isn't clear
EXAMPLE = {"stopped": "Why did trading stop?", "nobet": "Why no bet?", "away": "What happened while I was away?",
           "recap": "Daily recap", "coins": "Which coin is doing best?", "experiment": "Create an experiment at Tiny",
           "clump": "Preview Bold", "compare": "Compare ETH and SOL", "unusual": "Is anything unusual?",
           "losses": "Why did I lose?", "recommend": "Should I switch strategies?", "backtrack": "What did Backtrack find?",
           "litterbox": "How is the Litter Box doing?", "strategy": "How does the strategy work?",
           "risk": "How much risk am I taking?", "working": "Is it working?", "market": "ETH price now?",
           "positions": "What am I holding?", "balance": "What's my balance?", "activity": "Recent bets",
           "status": "Is it running?"}
COIN_WORDS = {"eth": "ETH", "ethereum": "ETH", "ether": "ETH", "sol": "SOL", "solana": "SOL", "xrp": "XRP", "ripple": "XRP",
              "doge": "DOGE", "dogecoin": "DOGE", "bnb": "BNB", "binance": "BNB", "zec": "ZEC", "zcash": "ZEC",
              "hype": "HYPE", "hyperliquid": "HYPE", "near": "NEAR", "btc": "BTC", "bitcoin": "BTC"}
_AMBIGUOUS_COINS = {"near", "hype"}         # ordinary words too: only a coin when written in capitals or asked about alone
# everyday words are never "corrected" into something else
_COMMON = set("""a about above after again against all am an and any are as at be because been before being below between
both but by can could did do does doing done down during each few for from further had has have having he her here hers him
his how i if in into is it its itself just me more most my myself no nor not now of off on once only or other our ours out
over own same she should so some such than that the their them then there these they this those through to too under until
up very was we were what when where which while who whom why will with would you your yours make made making much many
much money good bad best worst better worse well right left last next first time times day days week month hour hours
minute minutes today yesterday tomorrow tell show give explain about again also still even ever never always really
thing things think know want need like look see said says say going goes gone went come came take took get got
coin coins bet bets betting doing performing performance profit profits result results number numbers going happen
happened happening anything something nothing everything again please thanks thank okay ok yes yeah nope sure maybe
compare compared versus between against same other others take takes taking taken give gives giving keep keeps
keeping kept let lets put puts run runs running ran start starts started starting stop stops try tries tried trying
use used using work works worked help helps call called ask asked asking feel felt seem seems turn turned move moved
live lives play played pay paid paying buy bought sell sold hold held win wins won lose loses lost losing
mean means meant find found leave left talk talked show showed shown read write wrote change changed check checked
able back big small high low long short new old great little own real fake full half late early hard easy
sure true wrong part place point case fact way week year life world hand head home house room night morning evening
man woman people person friend family number name word words line side kind sort type lot lots bit
one two three four five six seven ten hundred thousand zero once twice every each both either neither
dont doesnt didnt isnt arent wasnt werent cant couldnt wont wouldnt shouldnt im ive youre theyre thats whats
heres theres hows whys wheres""".split())
_TOPIC = ({w for _, ps in INTENTS for p in ps for w in re.findall(r"[a-z]+", p)} | {w for w in COIN_WORDS if len(w) > 5}
          | set(LEVEL_NAMES) | {"performing", "performance", "profitable", "working", "coin", "coins", "best", "worst"})
_VOCAB = sorted(_TOPIC | _COMMON)


def _dist(a: str, b: str, cap: int) -> int:
    """Edit distance with swapped letters counting as one edit ("waht" → "what" is 1)."""
    if abs(len(a) - len(b)) > cap:
        return cap + 1
    prev2, prev = None, list(range(len(b) + 1))
    for i in range(1, len(a) + 1):
        cur = [i] + [0] * len(b)
        for j in range(1, len(b) + 1):
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] != b[j - 1]))
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                cur[j] = min(cur[j], prev2[j - 2] + 1)
        prev2, prev = prev, cur
    return prev[-1]


def _fix_word(w: str) -> str:
    if len(w) < 4 or not w.isalpha() or w in _VOCAB or w in COIN_WORDS:
        return w
    cap = 1 if len(w) <= 5 else 2
    best = None
    for v in _VOCAB:
        if len(w) <= 5 and v[0] != w[0]:
            continue
        d = _dist(w, v, cap)
        if d <= cap:
            # closest first; then swapped letters ("waht" → "what"), then a word the cats know about
            key = (d, sorted(v) != sorted(w), v not in _TOPIC, abs(len(v) - len(w)))
            if best is None or key < best[0]:
                best = (key, v)
    return best[1] if best else w


def fix_typos(q: str) -> str:
    """The question with likely typos corrected ("waht coin is perfoming best" → "what coin is performing best")."""
    return re.sub(r"[a-z]+", lambda m: _fix_word(m.group(0)), q.lower().replace("’", "'"))


def _coins_in(original: str, t: str) -> list[str]:
    found: list[tuple[int, str]] = []
    short = len(t.split()) <= 4
    for w, c in COIN_WORDS.items():
        for m in re.finditer(rf"\b{w}\b", t):
            if w in _AMBIGUOUS_COINS and not (re.search(rf"\b{w.upper()}\b", original) or short):
                continue
            found.append((m.start(), c))
    out: list[str] = []
    for _, c in sorted(found):
        if c not in out:
            out.append(c)
    return out


_WHY = re.compile(r"^(why|how come|how so|explain|really|what do you mean|why is that|why's that|whys that|"
                  r"and why|but why|what makes|how do you know|show me why|why tho|why though)\b")
_ABOUT = re.compile(r"^(what about|how about|and|what of|same for|now|ok|okay)\b")
_THAT = re.compile(r"\b(it|that|this|that one|this one|that coin|this coin|the same)\b")
COIN_AWARE = ("market", "losses", "coins", "coin", "coin_compare", "nobet")


def understand(q: str, context: dict | None = None) -> tuple[str, dict]:
    """(intent, details). Details: coin(s), level, day, order, and for follow-ups what it follows.
    `context` is the previous answer's context, so "why?", "what about SOL?" and "compare it to ETH" work."""
    ctx = context if isinstance(context, dict) else {}
    original = q
    t = " " + re.sub(r"\s+", " ", fix_typos(q)).strip(" ?!.") + " "
    words = t.split()
    best, score = None, 0
    for intent, phrases in INTENTS:
        s = sum(len(p) for p in phrases if p in t)
        if s > score:
            best, score = intent, s
    det: dict = {"day": "yesterday" if "yesterday" in t else "today"}
    coins = _coins_in(original, t)
    if not coins and ctx.get("coin") and _THAT.search(t):
        coins = [ctx["coin"]]
    if coins:
        det["coin"], det["coins"] = coins[0], coins
    for i, n in enumerate(LEVEL_NAMES):
        if re.search(rf"\b{n}\b", t):
            det["level"] = i + 1
    m = re.search(r"\blevel (\d)\b", t)
    if m:
        det["level"] = int(m.group(1))
    det["order"] = "worst" if re.search(r"\b(worst|lowest|least|losing|lost|bad|weakest|bottom)\b", t) else "best"
    prev = ctx.get("intent")
    if prev == "why":
        prev = ctx.get("about")

    # follow-ups: "why?", "compare it to ETH", "what about SOL?", "and yesterday?"
    if _WHY.match(t.strip()) and len(words) <= 6 and (score < 9 or best in ("help", None)) and prev:
        det.update(about=prev, coin=det.get("coin") or ctx.get("coin"), coins=det.get("coins") or ctx.get("coins") or [])
        return "why", det
    if "compare" in t or " vs " in t or "versus" in t or " against " in t:
        pool = coins if len(coins) >= 2 else ([ctx["coin"]] + coins if ctx.get("coin") and coins and ctx["coin"] not in coins else coins)
        if len(pool) >= 2:
            det["coins"], det["coin"] = pool[:2], pool[0]
            return "coin_compare", det
    if prev and (_ABOUT.match(t.strip()) or len(words) <= 3) and (score == 0 or best in ("help", prev)):
        if coins and prev in COIN_AWARE:
            if prev == "coin_compare":
                det["coins"] = [(ctx.get("coins") or [coins[0]])[0], coins[0]] if (ctx.get("coins") or [None])[0] != coins[0] else ctx["coins"]
                return "coin_compare", det
            return ("coin" if prev == "coins" else prev), det
        if "yesterday" in t or "today" in t:
            return (prev if prev in ("recap", "activity", "away") else "recap"), det
        if det["order"] == "worst" and prev == "coins":
            return "coins", det

    if best is None or score == 0:
        if coins and re.search(r"\b(doing|do|did|bets?|going|perform|performing|performance|results?|profit|made|earn|earned|"
                               r"win|winning|record)\b", t):
            return "coin", det
        if coins:
            return "market", det
        return "clarify", det
    if best == "coins" and coins and not re.search(r"\b(best|worst|which|what coin|rank|ranking|top|each|per)\b", t):
        return "coin", det
    if best == "risk" and det.get("level") and re.search(r"\b(set|change|switch|use|preview|go to|move to|try)\b", t):
        best = "clump"
    return best, det


def _closest(q: str, n: int = 3) -> list[str]:
    """The topics a muddled question is most likely about, for a short "Did you mean…?"."""
    import difflib
    t = fix_typos(q)
    tw = {w for w in re.findall(r"[a-z]+", t) if len(w) > 4 or w not in _COMMON}
    scored = []
    for intent, phrases in INTENTS:
        if intent == "help":
            continue
        r = max(difflib.SequenceMatcher(None, t, p).ratio() for p in phrases)
        overlap = max(len(tw & set(re.findall(r"[a-z]+", p))) for p in phrases)
        scored.append((overlap + r, intent))
    scored.sort(reverse=True)
    if not scored or scored[0][0] < 1:                       # nothing in common: offer the most useful questions
        return ["away", "coins", "working"][:n]
    picks = [i for _, i in scored[:n]]
    for i in ("away", "coins", "nobet"):                      # always useful
        if len(picks) < n and i not in picks:
            picks.append(i)
    return picks


# ---- personalities (same facts, different voice) -----------------------------------------------------
VOICE = {
    "biscuit": {"hi": "Biscuit here!", "good": "Good news, fish for dinner!",
                "bad": "Not our best day, but the bets were small.", "neutral": "Here's what I see:",
                "unknown": "Hmm, I don't have that one. I'd rather say so than make it up.", "away": "Welcome back! While you were gone:",
                "huh": "Hmm, I'm not sure what you mean."},
    "chonk": {"hi": "Le Chonk here. Bid, don't chase.", "good": "Clean lift. Form looks good.",
              "bad": "Heavy set. Here's what's on the bar.", "neutral": "Spotting it now:",
              "unknown": "No data on the bar for that. I won't guess.", "away": "Recovery report:",
              "huh": "Didn't catch that rep."},
    "chill": {"hi": "Le Chill. No rush.", "good": "Nice. Very nice. But let's not get excited.",
              "bad": "Eh. Not great, not a disaster.", "neutral": "Okay, here's the deal:",
              "unknown": "I don't know that one, and I'm too relaxed to make it up.", "away": "While you were out, nothing rattled me. Here:",
              "huh": "Hm. Not sure I follow."},
    "katya": {"hi": "Privet, I am Katya.", "good": "Is good. No mystery here.",
              "bad": "Something to investigate. Let us look calmly.", "neutral": "Let us look at the evidence:",
              "unknown": "This I cannot know from what the app has. I will not invent it.", "away": "While you were away, I kept notes:",
              "huh": "This I do not understand yet."},
}


def _act(kind: str, label: str, **kw) -> dict:
    return {"type": kind, "label": label, **kw}


def _rt(x: Ctx, ts) -> str:
    return time.strftime("%H:%M", time.localtime(ts)) if ts else "–"


def _who(state: dict, cat: str | None) -> str:
    """The sidekick the person chose answers everything. The secret one only once it has been found."""
    if cat == "katya" and not (state.get("ui") or {}).get("katya"):
        return "biscuit"
    return cat if cat in CATS else "biscuit"


def _coin_line(r: dict) -> str:
    return (f"{r['coin']}: {_m(r['pnl'], True)} over {r['bets']} bet{'s' if r['bets'] != 1 else ''}, {r['wins']} won"
            + (f" ({_pct(r['roi'])} per $)" if r.get("roi") is not None else ""))


def _sim_line(r: dict) -> str:
    return (f"{r['coin']}: {_pct(r['roi'])} per $ (± {float(r['se'] or 0) * 200:.1f}%) over {r['bets']} fake bets")


def _hist_line(r: dict) -> str:
    return (f"{r['coin']}: {_pct(r['roi'])} per $ over {r['bets']:,} past bets, won {float(r['win_rate']) * 100:.1f}%"
            + (f" at about {_c(r['avg_price'])}" if r.get("avg_price") else ""))


def _rank(rows: list[dict], order: str) -> list[dict]:
    rows = [r for r in rows if r.get("roi") is not None and r.get("bets")]
    return sorted(rows, key=lambda r: r["roi"], reverse=(order != "worst"))


# ---- composing answers ---------------------------------------------------------------------------------
def answer(bot, state: dict, question: str, cat: str | None = None, since: float | None = None,
           context: dict | None = None) -> dict:
    x = Ctx(bot, state, since)
    intent, det = understand(question, context)
    who = _who(state, cat)
    v = VOICE[who]
    blocks, actions, unavailable, tone, text, uncertainty = [], [], [], "neutral", "", None
    used: list[str] = []

    def L(name, *a):
        used.append(name)
        r = LOOKUPS[name](x, *a)
        if "unavailable" in r:
            unavailable.append(r["unavailable"])
        return r

    explain = intent == "why"
    if explain:
        intent = det.get("about") or "clarify"
        if intent == "coins" and det.get("coin"):
            intent = "coin"

    if intent in ("coins", "coin", "coin_compare"):
        order = det.get("order", "best")
        pick = det.get("coins") if intent == "coin_compare" else ([det["coin"]] if intent == "coin" and det.get("coin") else None)
        c = L("coins")
        if "unavailable" not in c:
            want = (lambda rows: [r for r in rows if r["coin"] in pick]) if pick else (lambda rows: rows)  # noqa: E731
            real, sim, hist = _rank(want(c["real"]), order), _rank(want(c["sim"]), order), _rank(want(c["hist"]), order)
            if pick and intent == "coin_compare":                     # keep the order the person asked in
                real, sim, hist = ([r for p in pick for r in rows if r["coin"] == p] for rows in (real, sim, hist))
            if real:
                blocks.append(block(c["label"], [_coin_line(r) for r in real[:8]], c["as_of"],
                                    "Your settled bets" + ("" if pick else (", best first" if order == "best" else ", worst first"))))
            if sim:
                blocks.append(block(SIM, [_sim_line(r) for r in sim[:8]], c["sim_as_of"], "Litter Box: one fake-money model per coin"))
            if hist:
                blocks.append(block(HIST, [_hist_line(r) for r in hist[:8]], c["hist_as_of"],
                                    f"Backtrack, past {c['hist_days']:g} days" if c.get("hist_days") else "Backtrack"))
            if not (real or sim or hist):
                unavailable.append(f"No results for {' or '.join(pick)} yet." if pick else "No per-coin results yet.")
            lead = real or sim or hist
            src = ("with " + x.money.lower()) if real else "in the Litter Box (fake money)" if sim else "on past prices (Backtrack)"
            if intent == "coins" and lead:
                top = lead[0]
                word = "Best" if order == "best" else "Worst"
                text = (f"{word} so far {src}: {top['coin']}, " +
                        (f"{_m(top['pnl'], True)} over {top['bets']} bet{'s' if top['bets'] != 1 else ''} ({_pct(top['roi'])} per $)." if real else
                         f"{_pct(top['roi'])} per $ over {top['bets']:,} bets."))
                if real and sim and sim[0]["coin"] != top["coin"]:
                    text += f" In the Litter Box it's {sim[0]['coin']} instead."
                tone = "good" if (order == "best" and top["roi"] > 0) else "bad" if top["roi"] < 0 else "neutral"
                if len(lead) > 1:
                    actions.append(_act("ask", f"Compare {lead[0]['coin']} to {lead[1]['coin']}", text=f"Compare {lead[0]['coin']} and {lead[1]['coin']}"))
                det["coin"] = top["coin"]
            elif intent == "coin" and lead:
                r = lead[0]
                text = f"{r['coin']} {src}: " + (f"{_m(r['pnl'], True)} over {r['bets']} bet{'s' if r['bets'] != 1 else ''}, {r['wins']} won." if real else
                                                  f"{_pct(r['roi'])} per $ over {r['bets']:,} bets.")
                tone = "good" if r["roi"] > 0 else "bad" if r["roi"] < 0 else "neutral"
            elif intent == "coin_compare" and pick and len(pick) >= 2:
                a, b = pick[:2]
                parts = []
                for name, rows in ((x.money.lower(), real), ("the Litter Box", sim), ("Backtrack", hist)):
                    ra, rb = next((r for r in rows if r["coin"] == a), None), next((r for r in rows if r["coin"] == b), None)
                    if ra and rb:
                        hi, lo = (ra, rb) if ra["roi"] >= rb["roi"] else (rb, ra)
                        parts.append(f"{hi['coin']} is ahead in {name} ({hi['coin']} {_pct(hi['roi'])} vs {lo['coin']} {_pct(lo['roi'])} per $)")
                text = (f"{a} vs {b}: " + "; ".join(parts) + ".") if parts else f"I don't have results for both {a} and {b} yet."
            if lead and not explain:
                n = lead[0]["bets"]
                uncertainty = ("Per-coin results are small samples: one loss costs about ten wins, so a single bet can flip the order."
                               if real and n < 50 else "The ± ranges show how much of each result could be luck.")
            actions.append(_act("ask", "Why?", text="Why?"))
            if real:
                actions.append(_act("open", "Open Each bet", target="section:sec-each"))
        if explain and "unavailable" not in c:
            focus = pick or ([det["coin"]] if det.get("coin") else [])
            items, said = [], []
            for p in focus[:2]:
                r = next((r for r in c["real"] if r["coin"] == p), None)
                if r and r["bets"]:
                    be = r.get("avg_price")
                    wr = r["wins"] / r["bets"]
                    items.append(f"{p}: won {r['wins']} of {r['bets']} ({wr * 100:.0f}%), paying about {_c(be)} a contract, "
                                 f"so it needs about {be * 100:.0f}% wins to break even" if be else f"{p}: won {r['wins']} of {r['bets']}")
                    said.append(f"{p} won {wr * 100:.0f}% of its bets" + (f" while it needed about {be * 100:.0f}% to break even" if be else ""))
                h = next((r for r in c["hist"] if r["coin"] == p), None)
                if h:
                    items.append(f"{p} on past prices: won {float(h['win_rate']) * 100:.1f}% at about {_c(h.get('avg_price'))}")
            if items:
                blocks.insert(0, block(c["label"], items, c["as_of"], "Why: win rate vs the price paid"))
            text = ("Because " + " and ".join(said) + ". Each win pays only a few cents a contract, while a loss costs the whole price, "
                    "so the win rate compared with the price paid decides it.") if said else (
                    "It comes down to win rate vs the price paid: each win pays a few cents a contract and a loss costs the whole price. "
                    "There aren't enough real bets yet to say more, so here are the fake-money and past-price results.")
            uncertainty = "With few bets per coin, one loss moves the result a lot, so treat differences as luck until they hold up."
    elif intent in ("stopped", "status"):
        st = L("status")
        hist = L("stop_history")
        stopped = st["level"] in ("paused", "offline", "attention")
        tone = "bad" if stopped else "good"
        text = (f"{st['headline']}. {st['detail']}" if intent == "stopped" or stopped else
                f"It's {st['title'].lower()}: {st['detail']}")
        if intent == "stopped" and not stopped:
            text = f"Trading hasn't stopped: it's {st['title'].lower()}. {st['detail']}"
            day0 = time.mktime(time.localtime(x.now)[:3] + (0, 0, 0, 0, 0, -1))
            earlier = next((e for e in hist["events"] if e["ts"] >= day0 and e["kind"] in
                            ("daily_loss", "kill", "halt", "pause", "turned_off", "recovering", "engine_error")), None)
            if earlier:
                what = {"daily_loss": "hit the daily loss limit", "kill": "had the kill switch on", "halt": "paused itself to check an order",
                        "pause": "was paused", "turned_off": "was turned off", "recovering": "re-checked with Kalshi after a gap",
                        "engine_error": "had an error"}[earlier["kind"]]
                text += f" Earlier today, at {_rt(x, earlier['ts'])}, it {what}."
        if explain:
            text = "Here's what the bot's own log says, newest first. " + text
        blocks.append(block(APP, [f"Status: {st['title']} — {st['headline']}", st["detail"],
                                  st["next_step"] and f"Next step: {st['next_step']}"], x.now))
        ev = [f"{_rt(x, e['ts'])} · {e['message']}" for e in hist["events"][:8 if explain else 5]]
        if ev:
            blocks.append(block("From the bot's log", ev, x.now))
        if st.get("action"):
            a = st["action"]
            actions.append(_act(a["type"], {"resume": "Resume betting", "whynobet": "Why no bet?"}.get(a["type"], "Open it"),
                                **{k: v2 for k, v2 in a.items() if k != "type"}))
        actions.append(_act("open", "Open Warnings", target="section:sec-warn"))
    elif intent == "nobet":
        w = L("why_no_bet")
        st = L("status")
        rows = [c for c in w["coins"] if not det.get("coin") or c["coin"] == det["coin"]] or w["coins"]
        blocks.append(block(APP, [f"{c['coin']}: {c['plain']}" + (f" (the bot's own words: {c['raw']})" if explain and c.get("raw") else "")
                                  for c in rows], x.now))
        kinds = {c["kind"] for c in rows}
        text = ("Right now no coin is ready for a bet. " if "betting" not in kinds else "One is in play right now. ") + \
               ("Mostly it's timing: bets only open near the end of each 15-minute contract." if kinds <= {"timing"} else
                "The reasons are listed per coin below, straight from the strategy and the risk checks.")
        if explain:
            text = ("Each coin is checked every couple of seconds: the price must be a favourite in your range, the spread tight, "
                    "it must be the last few minutes, and the risk limits must allow it. Here's the check that said no for each.")
        if st["level"] in ("paused", "attention", "offline"):
            text = f"{st['headline']}: {st['detail']} " + text
        actions.append(_act("open", "Open Right now", target="section:sec-now"))
    elif intent in ("balance", "positions"):
        a = L("account")
        pz = L("positions")
        if "unavailable" not in a:
            blocks.append(block(a["label"], [f"Total balance {_m(a['equity'])} (cash {_m(a['cash'])}, in bets {_m(a['in_bets'])})",
                                             a.get("today_pnl") and f"Today so far {_m(a['today_pnl'], True)}",
                                             f"Bot may use up to {_m(a['cap'])}" if a.get("cap") else None], a["as_of"]))
            text = f"You have {_m(a['equity'])} in total" + (f", {_m(a['today_pnl'], True)} today" if a.get("today_pnl") else "") + "."
        hold = [f"{h['coin']} {h['side'].title()}: {h['qty']} × {_c(h['price'])} = {_m(h['cost'])}, pays {_m(h['pays_if_win'])} if it wins"
                + (f", result in {int(h['result_in_s'] // 60)}:{int(h['result_in_s'] % 60):02d}" if h.get("result_in_s") and h["result_in_s"] > 0 else "")
                for h in pz["holding"]]
        hold += [f"Waiting bid: {w2['coin']} {w2['side'].title()} at {_c(w2['price'])} × {w2['count']}" for w2 in pz["waiting_bids"]]
        blocks.append(block(pz["label"], hold or ["No open bets or waiting bids right now."], pz["as_of"]))
        if pz["holding"]:
            text += f" {len(pz['holding'])} bet{'s' if len(pz['holding']) > 1 else ''} in play."
        if explain:
            act = L("activity", x.now - 86400)
            blocks.append(block(act["label"], [f"Last 24 hours: {act['settled']} bets settled, {_m(act['pnl'], True)}"]
                                + [f"{_rt(x, p['ts'])} · {p['coin']} {p['side'].title()} {_m(p['pnl'], True)}" for p in act["last"]], x.now))
            text = "Your balance moves with each settled bet. " + text
    elif intent in ("activity", "away"):
        since = since or (x.now - (12 * 3600 if intent == "away" else 86400))
        a = L("activity", since)
        st = L("status")
        tone = "good" if a["pnl"] > 0 else "bad" if a["pnl"] < 0 else "neutral"
        items = [f"{a['settled']} bets settled: {a['wins']} won, {a['losses']} lost, {_m(a['pnl'], True)}"]
        items += [f"{_rt(x, p['ts'])} · {p['coin']} {p['side'].title()} {_m(p['pnl'], True)}" for p in a["last"]]
        blocks.append(block(a["label"], items, x.now, f"Since {time.strftime('%a %H:%M', time.localtime(since))}"))
        if a["notable_events"]:
            blocks.append(block("From the bot's log", [f"{_rt(x, e['ts'])} · {e['message']}" for e in a["notable_events"]], x.now))
        blocks.append(block(APP, [f"Now: {st['title']} — {st['detail']}"], x.now))
        text = (v["away"] + " " if intent == "away" else "") + \
               (f"{a['settled']} bets settled for {_m(a['pnl'], True)}." if a["settled"] else "No bets settled in that time.")
        actions.append(_act("recap", "Open today's recap"))
    elif intent == "recap":
        r = L("recap", det.get("day", "today"))
        tone = "good" if float(r["pnl"]) > 0 else "bad" if float(r["pnl"]) < 0 else "neutral"
        items = [f"{r['bets']} bets: {r['wins']} won, {r['losses']} lost", f"Profit/loss {_m(r['pnl'], True)} (fees {_m(r['fees'])})",
                 r["best_coin"] and f"Best coin {r['best_coin'][0]} {_m(r['best_coin'][1], True)}",
                 r["worst_coin"] and f"Worst coin {r['worst_coin'][0]} {_m(r['worst_coin'][1], True)}",
                 f"Open now: {len(r['open_positions'])}"]
        blocks.append(block(r["label"], items, r["as_of"], r["day"]))
        if r["litterbox"]:
            lb = r["litterbox"]
            blocks.append(block(SIM, [f"{lb['models']} models, {lb['fake_bets']} fake bets so far",
                                      lb["leader"] and f"Leader: {lb['leader']['name']} {_pct(lb['leader']['roi'])} per $ over {lb['leader']['bets']} bets",
                                      lb["twin"] and f"Simulated you: {_m(lb['twin']['pnl'], True)} over {lb['twin']['bets']} bets"], lb["as_of"]))
        text = f"{r['day']}: {r['bets']} bets, {_m(r['pnl'], True)} after fees."
        if r.get("best_coin"):
            det["coin"] = r["best_coin"][0]
        actions.append(_act("recap", "Open the full recap", day=det.get("day", "today")))
    elif intent == "risk" or intent == "clump":
        r = L("risk")
        blocks.append(block(r["label"], [r["level"] and f"Clump level: {r['level']}",
                                         f"Most per bet {_m(r['per_bet'])}; up to {r['max_open']} bets open at once",
                                         r["exposure_pct"] and f"Most at risk at once: {float(r['exposure_pct']) * 100:.0f}% of {_m(r['cap'])}",
                                         r["daily_stop_pct"] and f"Daily stop: {float(r['daily_stop_pct']) * 100:.0f}% of the cap",
                                         r["exposure_now"] is not None and f"At risk right now: {_m(r['exposure_now'])} in {r['open_now']} bet(s)",
                                         r["pending_limits"] and "New limits are waiting for your typed confirmation"], x.now))
        text = f"You're on {r['level'] or 'custom'} limits: up to {_m(r['per_bet'])} a bet, {r['max_open']} at once."
        if explain:
            text = ("These come from your Clump level and the cap you chose; the bot checks them before every bid. " + text)
        if r["kill"] or r["paused"] or r["daily_loss_hit"]:
            text += " Trading is stopped right now (" + ", ".join(k for k, on in (("kill switch", r["kill"]), ("paused", r["paused"]),
                                                                                   ("daily stop", r["daily_loss_hit"])) if on) + ")."
        if intent == "clump" or det.get("level"):
            lv = det.get("level")
            if lv:
                actions.append(_act("preview_clump", f"Preview {LEVEL_NAMES[lv - 1].title()}", level=lv))
                text += f" Here's a preview of {LEVEL_NAMES[lv - 1].title()}; nothing changes until you apply it."
            else:
                actions += [_act("preview_clump", f"Preview {n.title()}", level=i + 1) for i, n in enumerate(LEVEL_NAMES)]
        uncertainty = "Limits cap how much you can lose; they don't change which bets are taken or the odds."
    elif intent == "working":
        sc = L("scorecard")
        if "unavailable" not in sc:
            blocks.append(block(sc["label"], [f"{sc['bets']} bets, win rate {float(sc['win_rate']) * 100:.1f}% "
                                              f"(likely range {float(sc['low']) * 100:.1f}–{float(sc['high']) * 100:.1f}%)",
                                              f"Needed to break even (fees in): {float(sc['breakeven']) * 100:.1f}%",
                                              f"Net {_m(sc['net'], True)}"], sc["as_of"]))
            verdict = {"ahead": "ahead of break-even by more than luck", "behind": "behind break-even",
                       "early": "too early to tell", "unclear": "too close to call"}.get(sc.get("verdict"), "not clear yet")
            tone = "good" if sc.get("verdict") == "ahead" else "bad" if sc.get("verdict") == "behind" else "neutral"
            text = f"Honest answer: it's {verdict}."
            if explain:
                text = (f"It wins {float(sc['win_rate']) * 100:.1f}% of bets, and paying ~{float(sc['breakeven']) * 100:.0f}¢ a contract it needs "
                        f"{float(sc['breakeven']) * 100:.1f}% to break even. Luck alone could put the true rate anywhere from "
                        f"{float(sc['low']) * 100:.1f}% to {float(sc['high']) * 100:.1f}%, so it's {verdict}.")
            uncertainty = "The likely range is the span luck alone could explain; it shrinks as more bets settle."
        bt = L("backtrack")
        if "unavailable" not in bt:
            blocks.append(block(HIST, [f"Your rule on {bt['contracts']:,} past contracts: {_pct(bt['yours']['roi'])} per $ "
                                       f"(± {float(bt['yours']['se'] or 0) * 200:.1f}%)",
                                       bt["yours"].get("uncertain_fills") and "Fills at the bid are estimates in past data"], bt["as_of"]))
        actions.append(_act("ask", "Which coin is doing best?", text="Which coin is doing best?"))
    elif intent in ("strategy", "recommend", "backtrack"):
        s = L("strategy")
        blocks.append(block(APP, [s["live_strategy"] and "Your bot: " + " · ".join(s["live_strategy"]),
                                  "That's the original strategy" if s["is_original"] else "Not the original strategy"], x.now))
        if intent in ("recommend", "strategy"):
            if s["recommended"]:
                r = s["recommended"]
                blocks.append(block(SIM, [f"Recommended: {r['label']}", f"On new markets: {_pct(r['fresh_roi'])} per $ over {r['fresh_bets']} fake bets in {r['days']} days"]))
                text = "There is a recommendation, and it earned it on markets it hadn't seen."
                uncertainty = "Fake fills can be kinder than real ones; a recommendation is evidence, not a promise."
            else:
                t2 = s["testing"]
                items = [f"{s['ideas_tested']} idea(s) tested so far; none proven yet"]
                if t2:
                    items.append(f"Testing #{t2['id']}: {t2['label']}")
                    items.append(f"Fresh bets: candidate {t2['cand_bets']}, original {t2['orig_bets']} of {t2['need']} each needed")
                    if t2["cand_roi"] is not None and t2["orig_roi"] is not None:
                        items.append(f"So far: candidate {_pct(t2['cand_roi'])} vs original {_pct(t2['orig_roi'])} per $")
                blocks.append(block(SIM, items))
                text = "No — nothing has earned a recommendation yet. Results so far don't support switching."
                uncertainty = "An idea needs enough fresh bets on both sides and must beat the original by more than luck."
            if explain:
                text = ("An idea only gets recommended after it beats the original on new markets it was never tuned on, with enough "
                        "fake bets on both sides that luck can't explain the gap. " + text)
            actions.append(_act("open", "Open Recommended preset", target="section:sec-preset"))
        bt = L("backtrack")
        if "unavailable" not in bt:
            blocks.append(block(HIST, [f"{bt['days']:g} days, {bt['contracts']:,} contracts: yours {_pct(bt['yours']['roi'])} per $",
                                       bt["walk_forward"]["verdict"] and f"Fair test (walk-forward): picked settings {_pct(bt['walk_forward']['chosen_roi'])} "
                                       f"vs yours {_pct(bt['walk_forward']['current_roi'])} → {bt['walk_forward']['verdict']}",
                                       bt["proposal"] and f"Next idea to test: {bt['proposal']}"], bt["as_of"]))
            if intent == "backtrack":
                text = text or f"Backtrack replayed {bt['contracts']:,} real past contracts. Past results are estimates, not promises."
                actions.append(_act("open", "Open Backtrack", target="section:sec-backtrack"))
        if intent == "strategy" and not text:
            text = "It waits at the bid for the favourite in the last few minutes of each 15-minute contract, then holds to the result."
    elif intent in ("litterbox", "experiment"):
        lb = L("litterbox")
        if "unavailable" not in lb:
            items = [f"{lb['models']} models, {lb['fake_bets']} fake bets"]
            items += [f"#{i + 1} {m['name']}: {_pct(m['roi'])} per $ (± {float(m['se'] or 0) * 200:.1f}%) over {m['bets']} bets"
                      for i, m in enumerate(lb["top"])]
            if lb["twin"]:
                items.append(f"Simulated you: {_m(lb['twin']['pnl'], True)} over {lb['twin']['bets']} bets")
            blocks.append(block(SIM, items, lb["as_of"]))
            lead = lb["top"][0] if lb["top"] else None
            text = (f"{lead['name']} leads, but " + ("that's within luck." if lead["se"] and abs(lead["roi"]) < 2 * lead["se"] else "check the ± range.")
                    if lead else "Too early to rank the models (they need 10+ bets each).")
            if explain and lead:
                text = (f"The ± after each result is the luck range: {lead['name']}'s {_pct(lead['roi'])} could really be anywhere "
                        f"within ± {float(lead['se'] or 0) * 200:.1f}%. " + text)
            uncertainty = "Litter Box uses fake money and simulated fills on live prices; a few days of results can be luck."
        actions.append(_act("open", "Open Litter Box", target="tab:litter"))
        if intent == "experiment":
            ms = _lb_models(x)
            base = next((m for m in ms if not m.get("base") and m["name"].lower() in question.lower()), None) \
                or next((m for m in ms if m["id"] == "original"), None)
            lv = det.get("level") or 1
            if base:
                actions.insert(0, _act("experiment", f"Create: {base['name']} at {LEVEL_NAMES[lv - 1].title()} (fake money)",
                                       base=base["id"], level=lv))
                text = (f"I can start a fake-money copy of {base['name']} at the {LEVEL_NAMES[lv - 1].title()} risk level. "
                        "Click the button to create it; it runs in the Litter Box next to the original.")
    elif intent == "losses":
        lo = L("losses", det.get("coin"))
        if "unavailable" not in lo:
            tone = "bad" if lo["losses"] else "good"
            items = [f"{lo['losses']} losses in {lo['bets']} bets, {_m(lo['lost_total'], True)} lost in total",
                     f"Average loss {_m(lo['avg_loss'])} vs average win {_m(lo['avg_win'])}",
                     f"Longest losing run: {lo['longest_losing_run']}"]
            items += [f"{c}: {n} loss(es), {_m(t, True)}" for c, n, t in lo["by_coin"]]
            items += [f"{_rt(x, p['ts'])} · {p['coin']} {p['side'].title()} {_m(p['pnl'], True)}" for p in lo["last_losses"]]
            blocks.append(block(lo["label"], items, lo["as_of"]))
            ratio = abs(lo["avg_loss"] / lo["avg_win"]) if lo["avg_win"] else None
            text = (f"Each loss costs about {ratio:.0f} wins — that's the shape of this strategy: many small wins, rare big losses. "
                    if ratio else "") + (f"The last {lo['recent_n']} bets had {lo['recent_losses']} loss(es)." if lo["recent_n"] else "")
            if explain and lo.get("avg_loss_price"):
                text = (f"The losing bets were bought at about {_c(lo['avg_loss_price'])}: the favourite was very likely to win, and when it "
                        "didn't, the whole price was lost. " + text)
            uncertainty = (f"If your long-run loss rate held, {lo['recent_losses']}+ losses in {lo['recent_n']} bets would happen "
                           f"about {lo['recent_tail_prob'] * 100:.0f}% of the time — " +
                           ("not unusual." if lo["recent_tail_prob"] > 0.1 else "unusual enough to keep an eye on."))
            if lo["by_coin"] and not det.get("coin"):
                det["coin"] = lo["by_coin"][0][0]
        actions.append(_act("open", "Open Each bet", target="section:sec-each"))
        actions.append(_act("ask", "Is it working overall?", text="Is it working?"))
    elif intent == "unusual":
        lo = L("losses")
        sc = L("scorecard")
        lb = L("litterbox")
        items = []
        if "unavailable" not in lo:
            items.append(f"Recent losses: {lo['recent_losses']} of the last {lo['recent_n']} "
                         f"({lo['recent_tail_prob'] * 100:.0f}% chance by luck alone at your usual loss rate)")
        if "unavailable" not in lb and lb["twin"] and "unavailable" not in sc:
            items.append(f"Simulated you vs real over its run: {_m(lb['twin']['pnl'], True)} simulated — "
                         "a big gap usually means fills differ (the sim guesses whether a waiting bid was hit)")
        w = L("why_no_bet")
        errs = [c for c in w["coins"] if c["kind"] == "attention"]
        if errs:
            items.append("Coins with trouble right now: " + ", ".join(c["coin"] for c in errs))
        blocks.append(block("Investigation", items or ["Nothing stands out in the data I can see."], x.now))
        text = "I checked the loss rate, the simulated twin and each coin's status." + (
            " Something looks off — details below." if any("unusual" in i or "trouble" in i for i in items) else " Nothing looks out of the ordinary.")
    elif intent == "compare":
        names = re.split(r"\b(?:vs\.?|versus|and|with|to|against)\b", question, flags=re.I)
        ms = _lb_models(x)
        found = [m["name"] for m in ms if m["name"].lower() in question.lower()]
        a, b = (found + [None, None])[:2] if len(found) >= 2 else ((names[0].replace("compare", "").strip(" ?") if names else None),
                                                                  (names[1].strip(" ?") if len(names) > 1 else None))
        c = L("compare", a, b)
        if "unavailable" not in c:
            items = [f"{c['a']['name']}: {_pct(c['a']['roi'])} per $ over {c['a']['bets']} bets ({_m(c['a']['pnl'], True)})",
                     f"{c['b']['name']}: {_pct(c['b']['roi'])} per $ over {c['b']['bets']} bets ({_m(c['b']['pnl'], True)})",
                     f"Difference {_pct(c['diff'])} per $" + (f", luck range ± {c['noise'] * 200:.1f}%" if c["noise"] else "")]
            blocks.append(block(SIM, items, c["as_of"]))
            leader = c["a"]["name"] if c["diff"] > 0 else c["b"]["name"]
            text = f"{leader} is ahead" + (" by more than luck." if c["clear"] else ", but within luck — not a real difference yet.")
            uncertainty = "Both are fake-money results with simulated fills."
        else:
            unavailable[-1] = "I need two coins (“Compare ETH and SOL”) or two Litter Box models (“Compare Ask Buyer and Down Dog”)."
    elif intent == "market":
        mk = L("market", det.get("coin"))
        if "unavailable" not in mk:
            items = [f"{c['coin']}: Up {_c(c['up_ask'])} · Down {_c(c['down_ask'])}" +
                     (f" · closes in {int(c['closes_in_s'] // 60)}:{int(c['closes_in_s'] % 60):02d}" if c.get("closes_in_s") else "")
                     for c in mk["coins"]]
            have = [c for c in mk["coins"] if c.get("up_ask") or c.get("down_ask")]
            blocks.append(block(LIVE, items, mk["as_of"] if have else None, "Ask prices for the contract closing next"))
            text = (("Prices from Kalshi" + (f", read {_ago(mk['as_of'], x.now)}" if mk["as_of"] else "") + ":") if have else
                    "Kalshi isn't showing prices for that contract right now (no offers yet, or it's between contracts).")
            if explain and have:
                text = ("These are the cheapest offers on Kalshi's order book for each side; a price of 93¢ means the market gives it "
                        "about a 93% chance. " + text)
            if not have:
                unavailable.append("No current prices.")
    elif intent == "help":
        text = (f"{v['hi']} Ask me anything about your bot, like “What happened while I was away?”, “Which coin is doing best?”, "
                "“Why did trading stop?” or “Is it working?”. Follow-ups like “why?” or “compare it to ETH” work too.")
        actions += [_act("ask", q2, text=q2) for q2 in ("What happened while I was away?", "Which coin is doing best?", "Why no bet?", "Is it working?")]
    else:  # clarify: a short question back, not the introduction again
        if explain:
            text = f"{v['huh']} Why what? Ask me something first, or pick one:"
        else:
            short = question.strip() if len(question.strip()) <= 40 else ""
            text = f"{v['huh']} " + (f"By “{short}”, did you mean one of these?" if short else "Did you mean one of these?")
        actions += [_act("ask", EXAMPLE[i], text=EXAMPLE[i]) for i in _closest(question)]
        intent = "clarify"

    if not blocks and unavailable and intent != "clarify":
        text = v["unknown"] + " " + " ".join(unavailable)
        tone = "neutral"
    intro = v["good"] if tone == "good" else v["bad"] if tone == "bad" else v["neutral"]
    if intent in ("help", "clarify") or explain:
        intro = ""
    final_intent = "why" if explain else intent
    context = {"intent": final_intent, "about": intent if explain else None, "coin": det.get("coin"),
               "coins": det.get("coins") or ([det["coin"]] if det.get("coin") else []), "day": det.get("day"),
               "q": question[:200], "a": text.strip()[:400]}
    return {"cat": who, "name": NAMES[who], "intent": final_intent, "intro": intro, "text": text.strip(), "blocks": blocks,
            "uncertainty": uncertainty, "unavailable": unavailable, "actions": actions[:5], "lookups": used,
            "asked_at": x.now, "mode": "local", "context": context}
