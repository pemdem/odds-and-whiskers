// ---- Litter Box: fake-money models side by side ------------------------------------------
const lbOpen = new Set();
let lastLb = '';
const roiPct = (roi, se) => roi == null ? '–' :
  `${roi >= 0 ? '+' : ''}${(roi * 100).toFixed(1)}%` + (se ? ` <span class="mut">±${(2 * se * 100).toFixed(1)}</span>` : '');

function lbRank(models) {
  // rank by return per $; models with few bets go to the bottom (too early to judge)
  return models.slice().sort((a, b) => (b.bets >= 10) - (a.bets >= 10) || (b.roi || 0) - (a.roi || 0));
}

function lbLeader(models) {
  const ranked = lbRank(models).filter(m => m.bets >= 10);
  if (!ranked.length) return null;
  const top = ranked[0], copy = models.find(m => m.role === 'baseline' || m.id === 'copycat');
  const runner = ranked.find(m => m.id !== top.id);
  const sep = (a, b) => b && a.se != null && b.se != null ? (a.roi - b.roi) / Math.sqrt(a.se ** 2 + b.se ** 2) : 0;
  return {top, copy, clear: sep(top, runner) > 2, beatsCopy: copy && copy !== top ? sep(top, copy) > 2 : false,
          profitable: top.bets >= 100 && top.se != null && top.roi - 2 * top.se > 0};
}

function spark(curve, start, w = 120, h = 34) {
  if (!curve || curve.length < 2) return `<svg viewBox="0 0 ${w} ${h}"><line x1="0" x2="${w}" y1="${h / 2}" y2="${h / 2}" stroke="var(--line)" stroke-dasharray="3 3"/></svg>`;
  const ys = curve.map(p => p[1]).concat([start]), lo = Math.min(...ys), hi = Math.max(...ys), span = hi - lo || 1;
  const pts = [[0, start], ...curve.map((p, i) => [i + 1, p[1]])];
  const X = i => i / (pts.length - 1) * (w - 4) + 2, Y = v => h - 3 - (v - lo) / span * (h - 6);
  const col = curve[curve.length - 1][1] >= start ? 'var(--pos)' : 'var(--neg)';
  return `<svg viewBox="0 0 ${w} ${h}" aria-hidden="true"><line x1="0" x2="${w}" y1="${Y(start)}" y2="${Y(start)}" stroke="var(--line)" stroke-dasharray="3 3"/>` +
    `<polyline points="${pts.map(([i, v]) => `${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join(' ')}" fill="none" stroke="${col}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/></svg>`;
}

// Clump levels for the fake-money models (same as the real Clump slider: stake, bets open at once)
const LEVELS = [{n: 'Tiny', bet: 1, open: 1}, {n: 'Light', bet: 2, open: 1}, {n: 'Steady', bet: 4, open: 2},
                {n: 'Bold', bet: 6, open: 3}, {n: 'Chonky', bet: 8, open: 4}];
function settingsChips(m) {
  const st = m.settings || {}, lv = LEVELS[(m.level || 3) - 1], lim = m.limits || {};
  return [st.entry === 'ask' ? 'Buys at the ask' : 'Waits at the bid', `${Math.round(st.ask_min * 100)}–${Math.round(st.ask_max * 100)}¢`,
    st.side === 'both' ? 'Up & Down' : `${(st.side || '').toUpperCase()} only`,
    st.window_end_s > 60 ? `${st.window_start_s / 60}–${st.window_end_s / 60} min left` : `last ${st.window_start_s / 60} min`,
    m.coins && m.coins.length ? m.coins.join(', ') : 'all coins',
    `${lv.n}: $${(+m.bet_usd).toFixed(0)} bets · up to ${lim.max_open || lv.open} open`, `started with $${(+m.cash_start).toFixed(0)}`]
    .map(t => `<span>${esc(t)}</span>`).join('');
}
// the small Clump slider on each model: test the same strategy and coins at another risk level, fake money only
function miniClump(m, models) {
  const lv = m.level || 3, copies = models.filter(x => x.base === m.id).map(x => x.level);
  if (m.base) return `<div class="mclump" data-tip="This is a copy of ${esc(m.name.split(' · ')[0])} at the ${LEVELS[lv - 1].n} risk level: same strategy and coins, different bet size and limits.">` +
    `<input type="range" min="1" max="5" value="${lv}" disabled aria-label="Risk level"><span>${LEVELS[lv - 1].n} copy</span></div>`;
  return `<div class="mclump" data-tip="Clump: slide to test this exact model at another risk level with fake money. A copy runs next to it so you can compare.">` +
    `<input type="range" min="1" max="5" step="1" value="${lv}" data-base="${esc(m.id)}" data-own="${lv}" aria-label="Test ${esc(m.name)} at another risk level">` +
    `<span>${LEVELS[lv - 1].n}${copies.length ? ` · also ${copies.sort().map(l => LEVELS[l - 1].n).join(', ')}` : ''}</span></div>`;
}

function renderLitter(s) {
  const lb = s.litterbox || {}, sum = lb.summary, bt = ((s.backtrack || {}).results || {}).models || {};
  $('lbchip').textContent = lb.running ? '● Running' : lb.enabled ? 'Starting…' : 'Stopped';
  $('lbchip').className = 'chip ' + (lb.running ? 'sim' : '');
  $('lbstart').disabled = !!lb.running; $('lbstop').disabled = !lb.running && !lb.enabled; $('lbreset').disabled = !!lb.running;
  const key = JSON.stringify([sum && sum.ts && Math.floor(sum.ts / 5), [...lbOpen], prefs.odds, lb.running]);
  if (key === lastLb) return;
  if (document.activeElement && document.activeElement.closest && document.activeElement.closest('.mclump')) return;  // mid-slide
  lastLb = key;
  if (!sum || !sum.models) {
    $('lbtiles').innerHTML = '';
    $('lbboard').innerHTML = '<div class="empty" style="height:110px;margin-top:14px">Press <b>Start</b> to let the models loose. They trade live prices with fake money, around the clock, while the app is open or closed.</div>';
    $('lbverdict').innerHTML = '';
    return;
  }
  const models = sum.models, ranked = lbRank(models), L = lbLeader(models);
  const totalBets = models.reduce((t, m) => t + m.bets, 0);
  // compare everyone with the fixed Original, not with each other's lucky streaks
  const orig = models.find(m => m.role === 'baseline' || m.id === 'copycat');
  $('lbtiles').innerHTML = tile('Models', models.length) + tile('Fake bets settled', totalBets.toLocaleString()) +
    tile('Running since', dt(sum.started_at)) + tile('Experiment set', esc(sum.season || 'season 1') + ' · fixed');
  $('lbboard').innerHTML = `<div class="lbrow head"><span>#</span><span>Model</span><span class="hide-s">Bets</span><span class="hide-s">W–L</span>` +
    `<span>Profit</span><span>Return per $</span><span class="hide-s">Backtrack</span><span class="hide-s">Balance</span></div>` +
    ranked.map((m, i) => {
      const b = bt[m.id] && bt[m.id].all;
      return `<div class="lbrow" data-id="${m.id}" role="button" tabindex="0" aria-expanded="${lbOpen.has(m.id)}">` +
        `<span class="rk">${m.bets >= 10 ? i + 1 : '–'}</span>` +
        `<span><div class="nm">${esc(m.name)}${m.role === 'baseline' ? ' <span class="pill wait">fixed yardstick</span>' : ''}` +
        `${m.role === 'candidate' ? ' <span class="pill open">being tested</span>' : ''}</div>` +
        `<div class="bl">${esc(m.group ? m.group + ' · ' : '')}${esc(m.blurb)}</div>${miniClump(m, models)}</span>` +
        `<span class="hide-s">${m.bets}${m.open ? ` <span class="mut">+${m.open} open</span>` : ''}</span>` +
        `<span class="hide-s">${m.wins}–${m.losses}</span>` +
        `<span class="${m.pnl >= 0 ? 'pos' : 'neg'}">${money(m.pnl, true)}</span>` +
        `<span>${m.bets ? roiPct(m.roi, m.se) : '–'}</span>` +
        `<span class="hide-s">${b && b.n ? roiPct(b.roi) : '–'}</span>` +
        `<span class="hide-s">${spark(m.curve, +m.cash_start)}</span></div>` +
        `<div class="lbmore ${lbOpen.has(m.id) ? 'open' : ''}"><div class="chips3">${settingsChips(m)}</div>` +
        `<div class="kv"><span>Fake balance</span><span>${money(m.equity)}</span></div>` +
        `<div class="kv"><span>Total staked</span><span>${money(m.staked)}</span></div>` +
        (b && b.n ? `<div class="kv"><span>Same settings on ${((s.backtrack || {}).results || {}).days} days of past data</span>` +
          `<span>${b.n.toLocaleString()} bets · ${pct(b.win_rate)} won · ${roiPct(b.roi, b.se)}</span></div>` : '') +
        `<div class="kv"><span>Doing now</span><span>${esc((m.status || [])[0] || '')}</span></div>` +
        (m.last && m.last.length ? `<div class="sub" style="margin:8px 0 2px">Latest results</div>` + m.last.map(x =>
          `<div class="kv"><span>${esc(x.coin)} ${x.outcome === 'UP' ? '↑ Up' : '↓ Down'} @ ${cents(x.price)} · ${tm(x.ts)}</span>` +
          `<span class="${x.pnl >= 0 ? 'pos' : 'neg'}">${money(x.pnl, true)}</span></div>`).join('') : '') +
        (m.base ? `<div class="pre-act"><button class="unvariant" data-id="${esc(m.id)}" data-tip="Stops this fake-money copy. Its results are kept in the archive.">Remove this copy</button></div>` : '') +
        `</div>`;
    }).join('');
  let v;
  if (!L) v = `<div class="say">The models need at least 10 settled bets each before anyone gets ranked. Check back in a few hours.</div>`;
  else {
    v = `<ul class="lbsay">` +
      `<li><b>${esc(L.top.name)}</b> leads with ${roiPct(L.top.roi, L.top.se)} per $ over ${L.top.bets} bets.</li>` +
      (L.copy ? `<li><b>Original</b> (the fixed yardstick) is at ${roiPct(L.copy.roi, L.copy.se)}.</li>` : '') +
      `<li>${L.profitable ? 'Strong evidence the leader is profitable — still an estimate, and fake fills can be kinder than real ones.' :
          L.clear ? 'The leader is clearly ahead of the pack, but its own profit could still be luck.' :
          'The leaders are still within luck of each other — keep them running.'}</li>` +
      (L.beatsCopy ? `<li>It clearly beats your real settings. If it keeps this up for a week or two, ask Claude about switching your real bot to it.</li>` : '') +
      `</ul><p class="note">Fake money, real prices, same fill rules as your real bot. A few days of results can still be luck — ` +
      `the ± range shows how much. Backtrack checks the same settings on past data.</p>`;
  }
  $('lbverdict').innerHTML = v;
}

// one tip for Cat Corner
function litterTip(s) {
  const sum = (s.litterbox || {}).summary;
  if (!sum || !sum.models) return `<div class="tip2"><b>Litter Box</b>Not running yet — start it in the Litter Box tab to test other settings with fake money.</div>`;
  const L = lbLeader(sum.models);
  if (!L) return `<div class="tip2"><b>Litter Box</b>${sum.models.length} models are collecting results. Too early to rank them.</div>`;
  return `<div class="tip2"><b>Litter Box leader: ${esc(L.top.name)}</b>${roiPct(L.top.roi, L.top.se)} per $ over ${L.top.bets} fake bets` +
    (L.copy && L.copy !== L.top ? ` vs your settings ${roiPct(L.copy.roi, L.copy.se)}` : '') + '. ' +
    (L.profitable ? 'Strong evidence of profit (an estimate).' : L.beatsCopy ? 'Beating yours, profit still within luck.' : 'Still within luck.') + `</div>`;
}

$('lbboard').addEventListener('change', async e => {
  const inp = e.target.closest('.mclump input'); if (!inp || !inp.dataset.base) return;
  const level = +inp.value, own = +inp.dataset.own, row = inp.closest('.lbrow');
  const name = row ? row.querySelector('.nm').firstChild.textContent.trim() : inp.dataset.base, L = LEVELS[level - 1];
  inp.blur();
  if (level === own) { lastLb = ''; return load(); }
  if (!confirm(`Test ${name} at the ${L.n} risk level?\n\nA fake-money copy starts next to it: same strategy and coins, $${L.bet} bets, ` +
               `up to ${L.open} open at once. The Litter Box restarts (about 30 seconds). No real money is used.`)) { inp.value = own; return; }
  try { await postJSON('/api/litterbox', {action: 'variant', base: inp.dataset.base, level}); }
  catch (err) { alert(err.message); }
  lastLb = ''; setTimeout(load, 1500);
});
$('lbboard').addEventListener('click', async e => {
  if (e.target.closest('.mclump')) { e.stopPropagation(); return; }          // sliding isn't a click on the row
  const un = e.target.closest('.unvariant');
  if (un) {
    if (!confirm('Remove this fake-money copy? The Litter Box restarts (about 30 seconds); its results so far are archived.')) return;
    try { await postJSON('/api/litterbox', {action: 'unvariant', id: un.dataset.id}); } catch (err) { alert(err.message); }
    lastLb = ''; setTimeout(load, 1500); return;
  }
  const r = e.target.closest('.lbrow:not(.head)'); if (!r) return;
  const id = r.dataset.id; if (lbOpen.has(id)) lbOpen.delete(id); else lbOpen.add(id);
  lastLb = ''; load();
});
$('lbboard').addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target.closest('.lbrow')) { e.preventDefault(); e.target.click(); } });
const lbAct = async action => {
  if (action === 'reset' && !confirm('Reset the Litter Box? Current fake-money results are archived and every model starts fresh.')) return;
  try { await postJSON('/api/litterbox', {action}); } catch (err) { alert(err.message); }
  lastLb = ''; setTimeout(load, 1500);
};
$('lbstart').onclick = () => lbAct('start');
$('lbstop').onclick = () => lbAct('stop');
$('lbreset').onclick = () => lbAct('reset');

// ---- Live / Litter Box tabs -----------------------------------------------------------------
$('tabseg').onclick = e => { const b = e.target.closest('button'); if (!b) return; prefs.tab = b.dataset.tab; savePrefs(); applyPrefs(); load(); };

// ---- App logo: classic, or one of the sidekicks ------------------------------------------------
const LOGOS = {
  classic: `<path d="M15 27 L19 9 L30 20 Z M49 27 L45 9 L34 20 Z" fill="#ffb347"/><ellipse cx="32" cy="35" rx="20" ry="17" fill="#ffb347"/>
    <ellipse cx="25" cy="33" rx="2.6" ry="3.3" fill="#2b2118"/><ellipse cx="39" cy="33" rx="2.6" ry="3.3" fill="#2b2118"/>
    <path d="M30 39 h4 l-2 2.4z" fill="#e8737a"/>`,
  biscuit: `<path d="M13 30 L12 10 L28 20 Z M51 30 L52 10 L36 20 Z" fill="#ffd2a3" stroke="#1d1d1f" stroke-width="2.4" stroke-linejoin="round"/>
    <path d="M8 58 C7 34 18 20 32 20 C46 20 57 34 56 58 Z" fill="#ffd2a3" stroke="#1d1d1f" stroke-width="2.4" stroke-linejoin="round"/>
    <path d="M28 24 v4 M32 23 v5 M36 24 v4" stroke="#f0974a" stroke-width="2" stroke-linecap="round"/>`,
  chonk: `<path d="M13 30 L12 10 L28 20 Z M51 30 L52 10 L36 20 Z" fill="#fff" stroke="#1d1d1f" stroke-width="2.4" stroke-linejoin="round"/>
    <path d="M8 58 C7 34 18 20 32 20 C46 20 57 34 56 58 Z" fill="#fff" stroke="#1d1d1f" stroke-width="2.4" stroke-linejoin="round"/>
    <path d="M12 33 C20 25 44 25 52 33" stroke="#ff3b30" stroke-width="4.5" fill="none" stroke-linecap="round"/>`,
  chill: `<path d="M13 34 L12 14 L28 24 Z M51 34 L52 14 L36 24 Z" fill="#fff3df" stroke="#1d1d1f" stroke-width="2.4" stroke-linejoin="round"/>
    <path d="M6 58 C6 38 18 26 32 26 C46 26 58 38 58 58 Z" fill="#fff3df" stroke="#1d1d1f" stroke-width="2.4" stroke-linejoin="round"/>`,
};
const LOGO_FACE = {
  classic: '',
  biscuit: `<circle cx="25" cy="41" r="2.3" fill="#1d1d1f"/><circle cx="39" cy="41" r="2.3" fill="#1d1d1f"/><path d="M29 46 q1.5 2 3 0 q1.5 2 3 0" stroke="#1d1d1f" stroke-width="1.6" fill="none" stroke-linecap="round"/>`,
  chill: `<rect x="17" y="38" width="12" height="7" rx="3" fill="#1d1d1f"/><rect x="35" y="38" width="12" height="7" rx="3" fill="#1d1d1f"/><path d="M29 41 h6" stroke="#1d1d1f" stroke-width="1.6"/><path d="M29 50 q1.5 2 3 0 q1.5 2 3 0" stroke="#1d1d1f" stroke-width="1.6" fill="none" stroke-linecap="round"/>`,
};
LOGO_FACE.chonk = LOGO_FACE.biscuit.replace(/cy="41"/g, 'cy="43"').replace('M29 46', 'M29 48');
function logoSVG(kind) {
  return `<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="lgx" x1="0" y1="0" x2="0" y2="1">` +
    `<stop offset="0" stop-color="#2997ff"/><stop offset="1" stop-color="#0060df"/></linearGradient></defs>` +
    `<rect width="64" height="64" rx="15" fill="url(#lgx)"/>${LOGOS[kind]}${LOGO_FACE[kind]}</svg>`;
}
let lastLogo = '';
function applyLogo() {
  let kind = prefs.logo || 'classic';
  if (kind === 'sidekick') kind = LOGOS[prefs.cat] ? prefs.cat : 'classic';
  if (kind === lastLogo) return; lastLogo = kind;
  const svg = logoSVG(kind);
  $('logo').innerHTML = svg;
  let link = document.querySelector('link[rel=icon]');
  if (!link) { link = document.createElement('link'); link.rel = 'icon'; document.head.appendChild(link); }
  link.href = 'data:image/svg+xml,' + encodeURIComponent(svg);     // also the window / taskbar icon of the app window
}

// ---- Experiment results: the learning loop's saved history ---------------------------------------
let lastHist = '';
function renderLabHistory(s) {
  const lab = s.lab || {}, key = JSON.stringify(lab);
  if (key === lastHist) return; lastHist = key;
  const rows = (lab.history || []).slice().reverse();
  const c = lab.candidate;
  const ev = (c && c.last_eval) || {}, need = ev.need || 300;
  const testing = c && c.status === 'testing' ? `<div class="kv"><span><b>#${c.id}</b> ${esc(c.label)}</span>` +
    `<span data-tip="Both sides need ${need} fresh bets before anything is decided — a fair comparison needs evidence on both."><span class="pill open">testing</span> ` +
    `candidate ${(ev.candidate || {}).n || 0} / original ${(ev.original || {}).n || 0} of ${need} fresh bets</span></div>` : '';
  const PILL = {graduated: 'won', rejected: 'lost', inconclusive: 'wait', withdrawn: 'wait'};
  const TIP = {graduated: 'Beat the Original on new markets by more than luck, and made money on its own.',
    rejected: 'Did not beat the Original by more than luck on new markets. Not proposed again.',
    inconclusive: 'Ran out of time before both sides had enough bets to compare. It may be tested again.',
    withdrawn: 'Stopped without a verdict because the test rules changed. It may be tested again.'};
  $('lbhistory').innerHTML = (testing + rows.map(h => { const r = h.result || {}, rc = r.candidate || {};
    return `<div class="kv"><span><b>#${h.id}</b> ${esc(h.label)} · ${dt(h.created_at).split(',')[0]}` +
    ` – ${dt(h.concluded_at).split(',')[0]}</span><span><span class="pill ${PILL[h.status] || 'wait'}" data-tip="${esc(TIP[h.status] || '')}">${h.status}</span> ` +
    `${roiTxt(rc)} vs original ${roiTxt(r.original)} · ${rc.n || 0} bets</span></div>`; }).join('')) ||
    '<div class="empty" style="height:80px;margin-top:10px">No experiments finished yet. The first one starts after Backtrack runs with the Litter Box switched on.</div>';
}
