@echo off
cd /d "%~dp0"
title Better Bot - move money to crypto
echo This moves REAL money inside your own Kalshi account, into the crypto section where the bot trades.
echo Nothing leaves your account. It asks how much, then asks you to type a phrase to confirm.
echo.
.venv\Scripts\python.exe -m favbot move-funds --mode live
pause
