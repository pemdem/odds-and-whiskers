#!/bin/bash
# Odds & Whiskers installer for macOS (run by "Install Odds and Whiskers.command"). Safe to run again: it never
# touches an existing config.yaml, .env, keys or data. A new copy starts in PRACTICE mode (fake money, real prices).
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
echo "Setting up Odds & Whiskers in $ROOT"
echo

# files from a downloaded zip are quarantined by macOS; clear that for this folder so the helpers can run
xattr -dr com.apple.quarantine "$ROOT" 2>/dev/null || true
chmod +x "$ROOT"/*.command "$ROOT"/app/*.sh 2>/dev/null || true

PY=""
for c in python3.13 python3.12 python3.11 /Library/Frameworks/Python.framework/Versions/3.12/bin/python3 python3; do
    if command -v "$c" > /dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)' 2>/dev/null; then
        PY="$(command -v "$c")"; break
    fi
done
if [ -z "$PY" ]; then
    echo "Python 3.12 is needed first."
    echo "1. On the page that opens, download the macOS 64-bit universal2 installer for Python 3.12."
    echo "2. Open it and click through the installer."
    echo "3. Double-click 'Install Odds and Whiskers.command' again."
    open "https://www.python.org/downloads/macos/"
    exit 1
fi
echo "Using Python: $PY"

if [ ! -x "$ROOT/.venv/bin/python" ]; then
    echo "Creating the app's own Python environment..."
    "$PY" -m venv "$ROOT/.venv"
fi
echo "Installing the parts it needs (a minute or two)..."
"$ROOT/.venv/bin/python" -m pip install --disable-pip-version-check -q -r "$ROOT/requirements.txt"

[ -f "$ROOT/config.yaml" ] || cp "$ROOT/config.example.yaml" "$ROOT/config.yaml"
[ -f "$ROOT/.env" ] || cp "$ROOT/.env.example" "$ROOT/.env"
mkdir -p "$ROOT/keys" "$ROOT/data"
chmod 700 "$ROOT/keys"

# a Desktop app that opens Odds & Whiskers (falls back to a double-clickable file)
DESK="$HOME/Desktop"
if [ "${1:-}" != "--no-desktop" ]; then
    rm -rf "$DESK/Odds & Whiskers.app"
    if ! osacompile -o "$DESK/Odds & Whiskers.app" \
        -e "do shell script \"/bin/bash \" & quoted form of \"$ROOT/app/launch_mac.sh\"" > /dev/null 2>&1; then
        cp "$ROOT/Open Odds and Whiskers.command" "$DESK/Odds & Whiskers.command"
        chmod +x "$DESK/Odds & Whiskers.command"
    fi
fi

echo "Checking the install..."
"$ROOT/.venv/bin/python" -m favbot --config config.yaml release status

echo
echo "Done! Odds & Whiskers is on your Desktop."
echo "It starts in PRACTICE mode: fake money on real prices."
echo "Real money, when you're ready:  1) Set up my Kalshi key.command   2) Go live.command"
echo "Updates appear in the app by themselves when the shared updates folder is in your OneDrive."
