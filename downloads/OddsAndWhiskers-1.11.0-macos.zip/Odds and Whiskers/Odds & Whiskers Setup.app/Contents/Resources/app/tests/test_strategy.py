"""The favourite rule: window, band, spread, side, joins the bid; and when to cancel."""
from decimal import Decimal as D

import pytest

from favbot.config import StrategyCfg
from favbot.providers.kalshi import verify_market
from favbot.strategy.favourite import decide, should_keep

from .conftest import T0, book, market

P = StrategyCfg()
CLOSE = T0 + 900


def contract(strike="greater_or_equal"):
    c, _ = verify_market(market(close_ts=CLOSE, strike=strike), "KXETH15M", 2)
    return c


def yes_fav(bid="0.91", ask="0.93"):
    # YES ask = 1 - best NO bid
    return book("t", [("0.50", "10"), (bid, "100")], [("0.02", "10"), (str(1 - D(ask)), "80")])


@pytest.mark.parametrize("secs_left,bids", [(301, False), (300, True), (200, True), (61, True), (60, False), (10, False)])
def test_window(secs_left, bids):
    d = decide(contract(), yes_fav(), CLOSE - secs_left, P)
    assert d.bid is bids


@pytest.mark.parametrize("ask,bids", [("0.87", False), ("0.88", True), ("0.95", True), ("0.97", True), ("0.98", False)])
def test_band_is_on_the_ask(ask, bids):
    bid = str(D(ask) - D("0.02"))
    d = decide(contract(), yes_fav(bid=bid, ask=ask), CLOSE - 200, P)
    assert d.bid is bids


def test_spread_limit():
    assert decide(contract(), yes_fav(bid="0.90", ask="0.93"), CLOSE - 200, P).bid          # 0.03 ok
    d = decide(contract(), yes_fav(bid="0.89", ask="0.93"), CLOSE - 200, P)                 # 0.04 too wide
    assert not d.bid and "spread" in d.reason


def test_locked_book_skipped():
    b = book("t", [("0.93", "5")], [("0.07", "5")])  # yes bid 0.93, yes ask 0.93
    d = decide(contract(), b, CLOSE - 200, P)
    assert not d.bid and "crossed" in d.reason


def test_joins_the_bid_never_the_ask():
    d = decide(contract(), yes_fav(bid="0.915", ask="0.93"), CLOSE - 200, P)
    assert d.bid and d.leg == "yes" and d.outcome == "UP" and d.price == D("0.915") and d.ask == D("0.93")


def test_no_side_favourite_bids_no_leg():
    # NO ask = 1 - yes bid(0.06) = 0.94 ; NO bid = 0.92
    b = book("t", [("0.06", "40")], [("0.92", "60")])
    d = decide(contract(), b, CLOSE - 200, P)
    assert d.bid and d.leg == "no" and d.outcome == "DOWN" and d.price == D("0.92")


def test_correct_side_on_inverted_contract():
    b = book("t", [("0.06", "40")], [("0.92", "60")])
    d = decide(contract(strike="less"), b, CLOSE - 200, P)
    assert d.leg == "no" and d.outcome == "UP"   # YES means DOWN here, so NO means UP


def test_both_sides_in_band_is_ambiguous():
    b = book("t", [("0.05", "1")], [("0.05", "1")])  # both asks 0.95
    assert not decide(contract(), b, CLOSE - 200, P).bid


def test_empty_book():
    assert not decide(contract(), book("t", [], []), CLOSE - 200, P).bid


def test_expiration_20s_and_never_into_last_60s():
    d = decide(contract(), yes_fav(), CLOSE - 200, P)
    assert d.expiration_ts == int(CLOSE - 200) + 20
    d = decide(contract(), yes_fav(), CLOSE - 70, P)
    assert d.expiration_ts == int(CLOSE - 60)


def test_cancel_when_favourite_weakens():
    placed = decide(contract(), yes_fav(bid="0.91"), CLOSE - 200, P)
    assert should_keep("yes", placed.price, placed)
    assert should_keep("yes", D("0.91"), decide(contract(), yes_fav(bid="0.92", ask="0.94"), CLOSE - 198, P))
    assert not should_keep("yes", D("0.91"), decide(contract(), yes_fav(bid="0.90", ask="0.93"), CLOSE - 198, P))  # bid fell
    assert not should_keep("yes", D("0.91"), decide(contract(), yes_fav(bid="0.96", ask="0.98"), CLOSE - 198, P))  # left band
    assert not should_keep("yes", D("0.91"), decide(contract(), yes_fav(bid="0.89", ask="0.93"), CLOSE - 198, P))  # spread
    assert not should_keep("yes", D("0.91"), decide(contract(), yes_fav(), CLOSE - 60, P))                        # window
    flipped = decide(contract(), book("t", [("0.06", "40")], [("0.92", "60")]), CLOSE - 198, P)
    assert not should_keep("yes", D("0.91"), flipped)                                                            # other side
