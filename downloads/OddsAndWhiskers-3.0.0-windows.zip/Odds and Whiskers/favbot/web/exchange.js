// ---- Exchanges: Kalshi and Polymarket US, one app ------------------------------------------------------------
// Each exchange is its own workspace (its own money, bets, history and fake-money tests); the layout, sidekick,
// text size and shortcuts are shared. The switcher sits on the left or right edge (Settings → Exchanges), opens
// with a click or the shortcut, and always shows which exchange you're looking at, real or practice, and what
// each bot is doing.
const EX_ORDER = ['kalshi', 'polymarket_us'];
const EX = {
  kalshi: {name: 'Kalshi', mark: 'K', color: '#00DD94', light: '#00B67A', note: 'Real-money trading with your limits'},
  polymarket_us: {name: 'Polymarket US', mark: 'P', color: '#2E5CFF', light: '#2E5CFF', note: 'Practice: market browsing and fake-money testing'},
};
const DEFAULT_SHORTCUT = 'Alt+X';
let exInfo = {}, exOpen = false;

const exMark = (id, cls = '') => `<span class="exmark ${cls}" style="--ex:${EX[id].color};--exl:${EX[id].light}" aria-hidden="true">${EX[id].mark}</span>`;
function exModeText(b, id) {
  if (!b) return id === 'polymarket_us' ? 'Practice' : '';
  return b.label === 'REAL-MONEY' ? 'Real money' : b.label === 'DEMO-MONEY' ? 'Demo money' : id === 'polymarket_us' ? 'Practice' : 'Simulated';
}
function exStatus(id) {
  const w = exInfo[id];
  if (!w) return {level: 'offline', text: '…'};
  if (!w.enabled) return {level: 'off', text: 'Off'};
  if (!w.running) return {level: 'offline', text: w.starting ? 'Starting…' : 'Not running'};
  const b = w.brief || {};
  return {level: b.killed ? 'attention' : b.level || 'watching', text: b.killed ? 'Kill switch on' : b.title || 'Running'};
}

// ---- the rail ----------------------------------------------------------------------------------------------------
function exRail() {
  let n = $('exrail');
  if (n) return n;
  n = document.createElement('nav');
  n.id = 'exrail'; n.className = 'exrail'; n.setAttribute('aria-label', 'Exchange');
  n.innerHTML = `<button class="exhandle" id="exhandle" aria-expanded="false" aria-controls="expanel"></button>
    <div class="expanel" id="expanel" role="listbox" aria-label="Choose an exchange" tabindex="-1"></div>`;
  document.body.appendChild(n);
  $('exhandle').onclick = e => { e.stopPropagation(); exToggle(); };
  $('expanel').addEventListener('click', e => { const b = e.target.closest('[data-ex]'); if (b) { setWorkspace(b.dataset.ex); exToggle(false); } });
  $('expanel').addEventListener('keydown', exKeys);
  return n;
}
function renderRail() {
  const n = exRail(), cur = ws();
  // redraw only what changed, and keep keyboard focus where it was (this runs on every refresh)
  const focused = document.activeElement && document.activeElement.closest && document.activeElement.closest('#exrail [data-ex]');
  const keep = focused ? focused.dataset.ex : null;
  n.dataset.side = document.body.dataset.exside = prefs.exSide === 'right' ? 'right' : 'left';
  n.classList.toggle('open', exOpen);
  const sc = prefs.exShortcut || DEFAULT_SHORTCUT;
  $('exhandle').h = EX_ORDER.map(id => `<span class="exslot ${id === cur ? 'cur' : ''}">${exMark(id)}` +
    `<i class="exdot ${exStatus(id).level}"></i></span>`).join('');
  $('exhandle').setAttribute('aria-label', `Exchange: ${EX[cur].name}. Switch exchange (${sc})`);
  $('exhandle').dataset.tip = `Viewing ${EX[cur].name}. Click to switch, or press ${sc}.`;
  $('exhandle').setAttribute('aria-expanded', String(exOpen));
  $('expanel').h = `<div class="exhead">Exchange</div>` + EX_ORDER.map(id => {
    const st = exStatus(id), w = exInfo[id] || {}, b = w.brief;
    return `<button role="option" class="exrow ${id === cur ? 'on' : ''}" data-ex="${id}" aria-selected="${id === cur}" tabindex="${id === cur ? 0 : -1}"
        style="--ex:${EX[id].color};--exl:${EX[id].light}">${exMark(id)}
        <span class="extext"><b>${EX[id].name}</b><span>${esc(exModeText(b, id) || EX[id].note)} · <i class="exdot ${st.level}"></i>${esc(st.text)}</span></span>
        ${id === cur ? '<span class="excheck" aria-hidden="true">✓</span>' : ''}</button>`;
  }).join('') + `<div class="exfoot"><kbd>${esc(sc)}</kbd> switches · <button class="link" data-exsettings>Settings</button></div>`;
  const s = $('expanel').querySelector('[data-exsettings]');
  if (s) s.onclick = () => { exToggle(false); prefs.pane = 'exchanges'; savePrefs(); $('gear').click(); };
  if (keep && exOpen && !(document.activeElement && document.activeElement.closest && document.activeElement.closest('#exrail [data-ex]'))) {
    const again = $('expanel').querySelector(`[data-ex="${keep}"]`); if (again) again.focus({preventScroll: true});
  }
}
function exToggle(open) {
  exOpen = open ?? !exOpen;
  renderRail();
  if (exOpen) { pollWorkspaces(); setTimeout(() => { const on = $('expanel').querySelector('.exrow.on'); if (on) on.focus({preventScroll: true}); }, 30); }
}
function exKeys(e) {
  const rows = [...$('expanel').querySelectorAll('.exrow')], i = rows.indexOf(document.activeElement);
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    e.preventDefault(); const j = (i + (e.key === 'ArrowDown' ? 1 : -1) + rows.length) % rows.length; rows[j].focus();
  } else if (e.key === 'Home' || e.key === 'End') { e.preventDefault(); rows[e.key === 'Home' ? 0 : rows.length - 1].focus(); }
  else if (e.key === 'Escape') { exToggle(false); $('exhandle').focus(); }
  else if (/^[1-9]$/.test(e.key) && rows[+e.key - 1]) { rows[+e.key - 1].click(); }
}
document.addEventListener('click', e => { if (exOpen && !e.target.closest('#exrail')) exToggle(false); });

// ---- switching -------------------------------------------------------------------------------------------------
function resetRenderCaches() {
  // every panel redraws for the other exchange's data
  lastSeries = ''; lastTrades = ''; lastProj = ''; lastLb = ''; lastHist = ''; lastScore = ''; lastCorner = ''; lastBt = '';
  lastSim = ''; lastPreset = ''; lastUpd = ''; lastMarkets = ''; lastCompat = '';
  if (typeof tradePage !== 'undefined') tradePage = 0;
}
async function setWorkspace(id) {
  if (!EX[id] || id === ws()) { applyWorkspace(); return; }
  prefs.workspace = id; savePrefs();
  document.body.classList.add('ws-switching');
  window._state = null; resetRenderCaches();
  if (typeof councilCtx !== 'undefined') councilCtx = null;           // the conversation belongs to one exchange
  if (typeof closeCouncil === 'function') closeCouncil();
  applyWorkspace();
  await load();
  setTimeout(() => document.body.classList.remove('ws-switching'), 60);
  exToast(`Now viewing <b>${EX[id].name}</b> · ${esc(exModeText((exInfo[id] || {}).brief, id))}`);
}
function applyWorkspace() {
  const cur = ws();
  document.body.dataset.ws = cur;
  document.documentElement.style.setProperty('--ex', EX[cur].color);
  document.documentElement.style.setProperty('--exl', EX[cur].light);
  const badge = $('exbadge');
  if (badge) { badge.innerHTML = `${exMark(cur, 'sm')}<span>${EX[cur].name}</span>`;
    badge.dataset.tip = `You're viewing ${EX[cur].name}. Click to switch exchange (${prefs.exShortcut || DEFAULT_SHORTCUT}).`; }
  const tag = $('extag');
  if (tag) { tag.innerHTML = exMark(cur, 'sm'); tag.dataset.tip = `Pause and the kill switch control the ${EX[cur].name} bot only.`; }
  document.querySelectorAll('[data-exname]').forEach(n => { n.textContent = EX[cur].name; });
  const pane = document.querySelector(`.pane[data-pane="${prefs.pane}"]`);
  if (pane && pane.dataset.ws && pane.dataset.ws !== cur) prefs.pane = 'general';
  renderRail();
}
function exToast(html) {
  const n = document.createElement('div'); n.className = 'toast extoast'; n.innerHTML = html;
  document.body.appendChild(n); setTimeout(() => n.classList.add('out'), 1800); setTimeout(() => n.remove(), 2300);
}

// ---- status of both exchanges, for the rail ---------------------------------------------------------------
async function pollWorkspaces() {
  try {
    const r = await fetch('/api/workspaces', {headers: H});        // always the Kalshi app (it watches both)
    if (r.ok) { exInfo = await r.json(); window._mainInfo = (exInfo.kalshi || {}).main || window._mainInfo; renderRail(); }
  } catch (e) { /* offline: the main status banner explains */ }
}
setInterval(pollWorkspaces, 10000);

// ---- shortcut ---------------------------------------------------------------------------------------------------
function comboOf(e) {
  const k = e.key.length === 1 ? e.key.toUpperCase() : e.key;
  if (['Control', 'Alt', 'Shift', 'Meta'].includes(k)) return null;
  return [e.ctrlKey && 'Ctrl', e.altKey && 'Alt', e.shiftKey && 'Shift', e.metaKey && 'Meta', k === ' ' ? 'Space' : k].filter(Boolean).join('+');
}
let recordingShortcut = false;
addEventListener('keydown', e => {
  if (recordingShortcut) return;
  const t = e.target;
  if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
  if (comboOf(e) !== (prefs.exShortcut || DEFAULT_SHORTCUT)) return;
  e.preventDefault();
  const next = EX_ORDER[(EX_ORDER.indexOf(ws()) + 1) % EX_ORDER.length];
  setWorkspace(next);
});

// ---- motion -----------------------------------------------------------------------------------------------------
const reduceMotion = () => prefs.motion === 'reduced' || matchMedia('(prefers-reduced-motion: reduce)').matches;
function applyMotion() { document.body.classList.toggle('reduce-motion', reduceMotion()); }
matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change', applyMotion);

// ---- Settings → Exchanges -------------------------------------------------------------------------------------
function renderExchangeSettings() {
  const box = $('exset'); if (!box) return;
  const sc = prefs.exShortcut || DEFAULT_SHORTCUT, pm = exInfo.polymarket_us || {};
  box.innerHTML = `<div class="group">
      <div class="opt"><span>Switcher on the</span><div class="seg" id="exsideseg"><button data-v="left" class="${prefs.exSide !== 'right' ? 'on' : ''}">Left edge</button>
        <button data-v="right" class="${prefs.exSide === 'right' ? 'on' : ''}">Right edge</button></div></div>
      <div class="opt"><span>Switch shortcut</span><span><kbd id="exsc">${esc(sc)}</kbd> <button id="exscrec">Change…</button>
        ${sc !== DEFAULT_SHORTCUT ? '<button id="exscreset">Reset</button>' : ''}</span></div>
      <div class="opt"><span>Motion</span><div class="seg" id="exmotion">${[['system', 'Like Windows'], ['reduced', 'Reduced']]
        .map(([v, t]) => `<button data-v="${v}" class="${(prefs.motion || 'system') === v ? 'on' : ''}">${t}</button>`).join('')}</div></div>
    </div>
    <h3>Polymarket US <span class="pill ${pm.running ? 'won' : 'wait'}">${pm.running ? 'Running' : pm.enabled ? 'Starting' : 'Off'}</span></h3>
    <div class="sub">Practice only in this version: market browsing and fake-money testing on Polymarket US’s real prices.
      It has its own balance, bets and history, kept apart from Kalshi. No account is connected and no orders are sent.</div>
    <div class="pre-act">${pm.enabled ? '<button id="pmstop">Stop practice</button>' : '<button class="primary" id="pmstart">Start practice</button>'}
      <button id="pmview">View Polymarket US</button><button id="pmcompat">What works there</button></div>`;
}
document.addEventListener('click', async e => {
  const id = e.target.id;
  const side = e.target.closest('#exsideseg [data-v]'), mo = e.target.closest('#exmotion [data-v]');
  if (side) { prefs.exSide = side.dataset.v; savePrefs(); renderExchangeSettings(); renderRail(); return; }
  if (mo) { prefs.motion = mo.dataset.v; savePrefs(); applyMotion(); renderExchangeSettings(); return; }
  if (id === 'exscreset') { prefs.exShortcut = DEFAULT_SHORTCUT; savePrefs(); renderExchangeSettings(); renderRail(); return; }
  if (id === 'exscrec') {
    recordingShortcut = true; $('exsc').textContent = 'Press keys…'; e.target.textContent = 'Esc to cancel';
    const rec = ev => {
      ev.preventDefault(); ev.stopPropagation();
      if (ev.key === 'Escape') { done(); return; }
      const c = comboOf(ev);
      if (!c) return;
      if (!/^(Ctrl|Alt|Meta)\+/.test(c)) { $('exsc').textContent = 'Add Ctrl or Alt'; return; }
      prefs.exShortcut = c; savePrefs(); done();
    };
    const done = () => { recordingShortcut = false; removeEventListener('keydown', rec, true); renderExchangeSettings(); renderRail(); };
    addEventListener('keydown', rec, true);
    return;
  }
  if (id === 'pmstart' || id === 'wsstart') {
    e.target.disabled = true;
    try { await postJSON('/api/workspace', {exchange: 'polymarket_us', action: 'start'}); exToast('Starting Polymarket US practice… about 20 seconds'); }
    catch (err) { alert(err.message); }
    await pollWorkspaces(); renderExchangeSettings(); if (ws() === 'polymarket_us') load();
    return;
  }
  if (id === 'pmstop') {
    if (!confirm('Stop Polymarket US practice?\n\nIts fake-money bot and Litter Box stop. Nothing is deleted; start it again any time.')) return;
    try { await postJSON('/api/workspace', {exchange: 'polymarket_us', action: 'stop'}); } catch (err) { alert(err.message); }
    await pollWorkspaces(); renderExchangeSettings(); if (ws() === 'polymarket_us') load();
    return;
  }
  if (id === 'pmview') { $('scrim').classList.remove('open'); setWorkspace('polymarket_us'); return; }
  if (id === 'pmcompat') { $('scrim').classList.remove('open'); openCompat(); return; }
  if (id === 'wskalshi') { setWorkspace('kalshi'); }
});

// ---- the Polymarket US workspace when its practice bot isn't running ------------------------------------------------
function renderWorkspaceOff(j) {
  document.body.classList.add('ws-off');
  let n = $('wsoff');
  if (!n) { n = document.createElement('section'); n.id = 'wsoff'; n.className = 'card wsoff'; $('banners').after(n); }
  const starting = j && (j.starting || (exInfo.polymarket_us || {}).enabled);
  n.h = `<div class="wsoff-hero">${exMark('polymarket_us', 'xl')}<div><div class="pre-tag">Polymarket US · Practice</div>
      <h2>${starting ? 'Starting Polymarket US practice…' : 'Try your strategy on Polymarket US'}</h2></div></div>
    <p>${starting ? 'Loading live prices from Polymarket US. This takes about 20 seconds.' :
      'Browse Polymarket US’s 15-minute crypto markets and test your strategy and Litter Box models there with <b>fake money</b>, ' +
      'on its real prices. It runs next to your Kalshi bot without touching it, with its own balance and history.'}</p>
    <ul class="wsfacts"><li>Same 15-minute windows and the same CF Benchmarks price index as Kalshi</li>
      <li>Coins there: BTC, ETH, SOL and XRP (your strategy leaves BTC out)</li>
      <li>No account, no real money, no orders sent</li></ul>
    <div class="pre-act">${starting ? '<span class="dots"><i></i><i></i><i></i></span>' : '<button class="primary" id="wsstart">Start practice</button>'}
      <button id="wskalshi">Back to Kalshi</button><button onclick="openCompat()">What works there</button></div>`;
  $('mode').textContent = 'Practice'; $('mode').className = 'chip sim';
  if (typeof statusOffline === 'function') { $('conn').innerHTML = `<span class="stdot ${starting ? 'paused' : 'offline'}"></span>${starting ? 'Starting' : 'Off'}`; }
  setBanners([]);
  if (starting) setTimeout(load, 3000);
}
function clearWorkspaceOff() { document.body.classList.remove('ws-off'); }

// ---- Markets (browse Polymarket US) ------------------------------------------------------------------------------
let lastMarkets = '', marketsAt = 0;
const lastGood = {};                       // per coin: the last prices we saw, shown (marked) while Polymarket is busy
async function renderMarkets(s) {
  if (ws() !== 'polymarket_us' || !$('pmmarkets') || Date.now() - marketsAt < 10000) return;
  marketsAt = Date.now();
  let j;
  try { const r = await fetch('/api/markets', {headers: H}); j = await r.json().catch(() => ({}));
    if (!r.ok) { if (!lastMarkets) $('pmmarkets').h = `<div class="sub">${esc(j.error || 'Prices aren’t available right now.')} Retrying…</div>`; return; }
  } catch (e) { return; }
  for (const m of j.markets || []) {
    if (m.available && (m.up_ask || m.down_ask)) lastGood[m.coin] = {...m, _at: j.as_of};
    else if (m.error && lastGood[m.coin] && lastGood[m.coin].window && lastGood[m.coin].window[1] > Date.now() / 1000) {
      Object.assign(m, lastGood[m.coin], {stale: lastGood[m.coin]._at, error: null});
    }
  }
  const key = JSON.stringify(j.markets) + prefs.odds;
  if (key === lastMarkets) return; lastMarkets = key;
  $('pmmarkets').h = (j.markets || []).map(m => {
    if (!m.available) return `<div class="mkt off"><b>${esc(m.coin)}</b><div class="sub">${m.error ? 'Prices loading — Polymarket US is busy' : 'No market right now'}</div></div>`;
    const left = m.window ? m.window[1] - Date.now() / 1000 : null;
    const fav = m.up_ask && m.down_ask ? (+m.up_ask >= +m.down_ask ? 'up' : 'down') : null;
    return `<div class="mkt" data-tip="${esc(m.rules || '')}">
      <div class="mkthead"><b>${esc(m.coin)}</b><span class="mut">${esc(m.index || '')}</span>
        ${m.tested ? '<span class="pill won" data-tip="Your strategy is testing this coin with fake money">Testing</span>'
          : m.coin === 'BTC' ? '<span class="pill wait" data-tip="Your strategy leaves Bitcoin out on purpose">Left out</span>'
          : '<span class="pill wait" data-tip="Turned off in Settings → Coins, or not one of your coins">Watching</span>'}</div>
      <div class="mktprices"><span class="${fav === 'up' ? 'fav' : ''}">Up <b>${cents(m.up_ask)}</b></span><span class="${fav === 'down' ? 'fav' : ''}">Down <b>${cents(m.down_ask)}</b></span></div>
      <div class="sub">${m.price_to_beat ? `Price to beat $${(+m.price_to_beat).toLocaleString(undefined, {maximumFractionDigits: 4})} · ` : ''}${
        left != null && left > 0 ? `ends in ${mmss(left)}` : esc(m.status || '')}${
        m.stale ? ` · <span class="mut" data-tip="Polymarket US is busy; these are the prices from ${tm(m.stale)}">updating…</span>` : ''}</div></div>`;
  }).join('') + `<div class="sub mktfoot">Live from Polymarket US · as of ${tm(j.as_of)} · prices are the cheapest offer for each side</div>`;
}

// ---- What works on Polymarket US ---------------------------------------------------------------------------------
let lastCompat = '', compatData = null;
async function getCompat() {
  if (compatData && Date.now() - compatData._t < 60000) return compatData;
  const r = await fetch('/api/equivalence', {headers: H});        // the Kalshi app knows both rule books
  if (!r.ok) throw new Error(await r.text());
  compatData = await r.json(); compatData._t = Date.now();
  return compatData;
}
const ST_LABEL = {available: ['won', 'Works'], partial: ['open', 'Partly'], unavailable: ['lost', 'Not available']};
function compatHTML(c, full) {
  const strat = c.strategies.map(x => `<div class="crow"><span class="pill ${ST_LABEL[x.status][0]}">${ST_LABEL[x.status][1]}</span>` +
    `<b>${esc(x.name)}</b><span class="sub">${esc(x.why)}</span></div>`).join('');
  const coins = c.coins.map(x => `<span class="coinchip ${x.testable ? 'ok' : 'no'}" data-tip="${esc(x.why)}">${esc(x.coin)}` +
    `<i>${x.kalshi ? 'K' : '–'}·${x.polymarket_us ? 'P' : '–'}</i></span>`).join('');
  const tools = c.tools.map(x => `<div class="crow"><span class="pill ${ST_LABEL[x.status][0]}">${ST_LABEL[x.status][1]}</span>` +
    `<b>${esc(x.name)}</b><span class="sub">${esc(x.why)}</span></div>`).join('');
  const rules = `<table class="rules"><thead><tr><th></th><th>${exMark('kalshi', 'sm')} Kalshi</th><th>${exMark('polymarket_us', 'sm')} Polymarket US</th></tr></thead><tbody>` +
    c.rules.map(r => `<tr class="${r.same ? 'same' : ''}"><th>${esc(r.topic)}</th><td>${esc(r.kalshi)}</td><td>${esc(r.polymarket_us)}${r.same ? ' <span class="pos">✓ same</span>' : ''}</td></tr>`).join('') +
    `</tbody></table>`;
  return `<div class="coinchips" aria-label="Coins on each exchange">${coins}</div>` +
    (full ? `<h3>Strategies</h3>${strat}<h3>Tools</h3>${tools}<h3>Market rules side by side</h3>${rules}` :
      `<details class="more"><summary>Strategies (${c.strategies.filter(x => x.status !== 'unavailable').length} of ${c.strategies.length} can be tested)</summary>${strat}</details>` +
      `<details class="more"><summary>Tools</summary>${tools}</details><details class="more"><summary>Market rules side by side</summary>${rules}</details>`) +
    `<div class="sub" style="margin-top:8px">Checked against both exchanges’ published market rules on ${esc(c.checked)}.</div>`;
}
async function renderCompat() {
  if (ws() !== 'polymarket_us' || !$('pmcompatbox')) return;
  try { const c = await getCompat(); const key = JSON.stringify(c.strategies) + c.checked; if (key === lastCompat) return; lastCompat = key;
    $('pmcompatbox').innerHTML = compatHTML(c, false); } catch (e) { /* try again next refresh */ }
}
async function openCompat() {
  try { const c = await getCompat();
    sheet('compatscrim', `<div class="pre-tag">${exMark('polymarket_us', 'sm')} Polymarket US</div><h2 style="margin:4px 0 10px">What works there</h2>` +
      `<p class="sub">Coins: K = on Kalshi, P = on Polymarket US. Green ones can be tested with fake money.</p>${compatHTML(c, true)}` +
      `<div class="pre-act" style="justify-content:flex-end"><button data-close>Close</button></div>`, 'wide');
  } catch (err) { alert(err.message); }
}

// called by load() on every refresh
function renderExchange(s) {
  applyWorkspace();
  renderMarkets(s);
  renderCompat();
  const lab = `${exMark(ws(), 'sm')} ${EX[ws()].name} · ${s.label === 'REAL-MONEY' ? 'Real money' : ws() === 'polymarket_us' ? 'Practice money' : 'Simulated money'}`;
  document.querySelectorAll('.balex').forEach(n => { if (n.innerHTML !== lab) n.innerHTML = lab; });
}
// Settings → Exchanges draws when it's opened (not on every refresh, so recording a shortcut isn't interrupted)
document.addEventListener('click', e => { if (e.target.closest('#gear, [data-pane="exchanges"]')) setTimeout(renderExchangeSettings, 0); });
applyMotion();
applyWorkspace();
pollWorkspaces();
