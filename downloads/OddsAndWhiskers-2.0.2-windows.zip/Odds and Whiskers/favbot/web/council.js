// ---- Cat Council: ask the sidekicks about your app — answers come from your real data ----------------------
const COUNCIL_CATS = ['biscuit', 'chonk', 'chill', 'katya'];
const LABEL_CLASS = {'Real money': 'real', 'Practice money': 'practice', 'Simulated (fake money)': 'sim', 'Historical test': 'hist',
  'Estimate': 'est', 'Live market': 'live', 'App status': 'app', "From the bot's log": 'log', 'Investigation': 'app'};
const LABEL_TIP = {real: 'Your actual money on Kalshi.', practice: 'Fake money: this copy runs in practice mode.',
  sim: 'Fake-money simulation on live prices (Litter Box). Fills are simulated.', hist: 'Replayed on past prices (Backtrack). Bid fills there are estimates.',
  est: 'A calculation with uncertainty, not a record.', live: 'Current prices read from Kalshi.', app: 'What the app itself is doing.',
  log: 'Straight from the bot’s own log, with IDs removed.'};
const SUGGEST = {
  auto: ['What happened while I was away?', 'Why did trading stop?', 'Why no bet?', 'Is it working?'],
  biscuit: ['What happened while I was away?', 'What’s my balance?', 'What am I holding?', 'Daily recap'],
  chonk: ['Why did trading stop?', 'How much risk am I taking?', 'Why no bet?', 'Preview Bold'],
  chill: ['Should I switch strategies?', 'How is the Litter Box doing?', 'What did Backtrack find?', 'Create an experiment at Tiny'],
  katya: ['Why did I lose?', 'Is anything unusual?', 'Compare Ask Buyer and Down Dog', 'Why did I lose on ETH?'],
};
let councilCat = 'auto', councilOpen = false, councilBusy = false;
const councilLog = [];

function councilEl() {
  let n = $('council');
  if (n) return n;
  n = document.createElement('aside');
  n.id = 'council'; n.className = 'council'; n.setAttribute('role', 'dialog'); n.setAttribute('aria-label', 'Cat Council');
  n.innerHTML = `<div class="chead"><div><h3>Cat Council</h3><div class="sub" id="cmodeline"></div></div>
      <button class="cx" id="cclose" aria-label="Close Cat Council" data-tip="Close (Esc)">✕</button></div>
    <div class="cpick" id="cpick" role="radiogroup" aria-label="Who answers"></div>
    <div class="clog" id="clog" role="log" aria-live="polite"></div>
    <div class="csug" id="csug"></div>
    <form class="cform" id="cform"><input id="cq" autocomplete="off" maxlength="500" placeholder="Ask the cats…" aria-label="Your question">
      <button class="primary" id="csend" type="submit">Ask</button></form>`;
  document.body.appendChild(n);
  $('cclose').onclick = closeCouncil;
  $('cform').onsubmit = e => { e.preventDefault(); const q = $('cq').value.trim(); if (q) { $('cq').value = ''; askCouncil(q); } };
  $('cpick').onclick = e => { const b = e.target.closest('[data-c]'); if (!b) return; councilCat = b.dataset.c; renderCouncilChrome(); };
  $('csug').onclick = e => { const b = e.target.closest('[data-q]'); if (b) askCouncil(b.dataset.q); };
  $('clog').addEventListener('click', councilAction);
  return n;
}
function councilCats() { return COUNCIL_CATS.filter(k => k !== 'katya' || katyaFound()); }
function catFace(k, cls = 'cav') { return `<span class="${cls}" aria-hidden="true">${(CATS[k] || CATS.biscuit).svg}</span>`; }
function renderCouncilChrome() {
  const s = window._state || {}, ai = ((s.council || {}).ai) || {};
  $('cpick').innerHTML = `<button data-c="auto" role="radio" aria-checked="${councilCat === 'auto'}" class="${councilCat === 'auto' ? 'on' : ''}"
      data-tip="The right cat for each question answers">Auto</button>` +
    councilCats().map(k => `<button data-c="${k}" role="radio" aria-checked="${councilCat === k}" class="${councilCat === k ? 'on' : ''}"
      data-tip="${esc(CATS[k].name)} answers">${catFace(k, 'cmini')}${esc(CATS[k].name)}</button>`).join('');
  $('csug').innerHTML = (SUGGEST[councilCat] || SUGGEST.auto).map(q => `<button data-q="${esc(q)}">${esc(q)}</button>`).join('');
  $('cmodeline').innerHTML = ai.enabled ? `Answers from your app’s data · <b>AI on</b> (${esc((ai.models || {})[ai.model] || ai.model)})`
    : 'Answers from your app’s data, on this computer · <span data-tip="Optional: Settings → Cat Council">AI off</span>';
}
function openCouncil(cat, question) {
  councilEl(); councilOpen = true;
  if (cat) councilCat = cat;
  renderCouncilChrome();
  requestAnimationFrame(() => $('council').classList.add('open'));
  document.body.classList.add('council-open');
  if (!councilLog.length) {
    const k = councilCat === 'auto' ? (prefs.cat in CATS ? prefs.cat : 'biscuit') : councilCat;
    pushMsg({who: k, text: `Hi! Ask me about your balance, why the bot did (or didn’t) bet, risk, experiments or losses. ` +
      `I answer from your app’s real data, and I’ll say when I don’t know.`});
  }
  if (question) askCouncil(question); else setTimeout(() => $('cq').focus(), 220);
}
function closeCouncil() {
  councilOpen = false; const n = $('council'); if (!n) return;
  n.classList.remove('open'); document.body.classList.remove('council-open');
}
function pushMsg(m) { councilLog.push(m); renderMsg(m); }
function renderMsg(m) {
  const log = $('clog'), d = document.createElement('div');
  if (m.me) { d.className = 'cmsg me'; d.textContent = m.text; }
  else if (m.typing) { d.className = 'cmsg them typing'; d.innerHTML = `${catFace(m.who)}<div class="cbody"><span class="dots"><i></i><i></i><i></i></span></div>`; }
  else d.className = 'cmsg them', d.innerHTML = msgHTML(m);
  log.appendChild(d); log.scrollTop = log.scrollHeight;
  return d;
}
const asOf = ts => ts ? `<span class="casof" data-tip="When this was read">as of ${new Date(ts * 1000).toLocaleTimeString([], {hour: 'numeric', minute: '2-digit', second: '2-digit'})}</span>` : '';
function msgHTML(m) {
  if (!m.answer) return `${catFace(m.who)}<div class="cbody"><div class="cname">${esc(CATS[m.who].name)}</div><p>${esc(m.text)}</p></div>`;
  const a = m.answer, k = a.cat in CATS ? a.cat : 'biscuit';
  return `${catFace(k)}<div class="cbody"><div class="cname">${esc(a.name)}${a.mode === 'ai' ? ' <span class="pill open" data-tip="Written with Claude from the same app data shown below">AI</span>' : ''}</div>` +
    `<p>${a.intro ? `<span class="cintro">${esc(a.intro)}</span> ` : ''}${esc(a.text)}</p>` +
    (a.blocks || []).map(b => { const c = LABEL_CLASS[b.label] || 'app';
      return `<div class="cblock ${c}"><div class="clabel"><span class="ctag ${c}" data-tip="${esc(LABEL_TIP[c] || '')}">${esc(b.label)}</span>` +
        `${b.note ? `<span class="mut">${esc(b.note)}</span>` : ''}${asOf(b.as_of)}</div>` +
        `<ul>${b.items.map(i => `<li>${esc(i)}</li>`).join('')}</ul></div>`; }).join('') +
    (a.uncertainty ? `<div class="cunc" data-tip="How sure this is">ℹ︎ ${esc(a.uncertainty)}</div>` : '') +
    ((a.unavailable || []).length && (a.blocks || []).length ? `<div class="cunc">Not available: ${esc(a.unavailable.join(' '))}</div>` : '') +
    (a.note ? `<div class="cnote">${esc(a.note)}</div>` : '') +
    ((a.actions || []).length ? `<div class="cacts">${a.actions.map((x, i) => `<button data-act="${i}" data-msg="${m.id}">${esc(x.label)}</button>`).join('')}</div>` : '') +
    `<div class="cpreview" id="cprev-${m.id}"></div></div>`;
}
let msgId = 0;
async function askCouncil(q) {
  if (councilBusy) return;
  if (!councilOpen) return openCouncil(null, q);
  councilBusy = true; $('csend').disabled = true;
  pushMsg({me: true, text: q});
  const who = councilCat === 'auto' ? (prefs.cat in CATS ? prefs.cat : 'biscuit') : councilCat;
  const t = renderMsg({typing: true, who});
  try {
    const since = prefs.lastSeen && Date.now() / 1000 - prefs.lastSeen > 600 ? prefs.lastSeen : null;
    const a = await postJSON('/api/council', {question: q, cat: councilCat === 'auto' ? null : councilCat, since});
    t.remove(); const m = {who: a.cat, answer: a, id: ++msgId}; pushMsg(m);
  } catch (err) {
    t.remove(); pushMsg({who, text: `I couldn’t reach the bot to look that up (${err.message || 'offline'}). If it’s turned off, open it with the icon.`});
  } finally { councilBusy = false; $('csend').disabled = false; $('cq').focus(); }
}
function councilAction(e) {
  const b = e.target.closest('[data-act]'); if (!b) return;
  const m = councilLog.find(x => String(x.id) === b.dataset.msg); if (!m) return;
  runAction(m.answer.actions[+b.dataset.act], $('cprev-' + m.id));
}
// actions from the cats: everything goes through the existing endpoints and confirmations
async function runAction(x, previewBox) {
  if (!x) return;
  const s = window._state || {};
  if (x.type === 'ask') return askCouncil(x.text);
  if (x.type === 'whynobet') return openCatNap();
  if (x.type === 'recap') return openRecap(x.day || 'today');
  if (x.type === 'open') return openTarget(x.target);
  if (x.type === 'resume') {
    if (!confirm('Resume new bets?')) return;
    try { await fetch('/api/resume', {method: 'POST', headers: H}); load(); } catch (err) { alert(err.message); }
    return;
  }
  if (x.type === 'preview_clump') {
    const P = s.presets; if (!P || !previewBox) return;
    const cur = P.levels[(P.current.level || 3) - 1] || {}, nw = P.levels[x.level - 1];
    const row = (k, f) => `<div class="kv"><span>${k}</span><span>${f(cur)} → <b>${f(nw)}</b></span></div>`;
    previewBox.innerHTML = `<div class="cblock app"><div class="clabel"><span class="ctag est">Preview — nothing changed yet</span></div>` +
      row('Most per bet', L => money(L.max_loss_per_position_usd)) + row('Bets open at once', L => L.max_open_positions) +
      row('Most at risk at once', L => Math.round(L.max_total_exposure_pct * 100) + '%') +
      `<div class="cacts"><button class="primary" data-apply="${x.level}">Apply ${esc(nw.name)}…</button></div>` +
      `<div class="sub">${s.mode === 'live' ? 'For real money you’ll also type a confirmation (Confirm new limits) before it’s used.' : 'Applies after a restart.'}</div></div>`;
    previewBox.querySelector('[data-apply]').onclick = async () => {
      if (!confirm(`Use the “${nw.name}” limits?` + (s.mode === 'live' ? '\n\nFor real money, new limits only become active after you confirm them: double-click “Confirm new limits” and type the phrase.' : ''))) return;
      try { const r = await postJSON('/api/apply', {level: x.level});
        previewBox.innerHTML = `<div class="cnote">${r.pending_limits ? 'Saved. Now double-click “Confirm new limits” to make them live.' : 'Saved. Restart the bot (banner at the top) to use it.'}</div>`;
        load(); } catch (err) { alert(err.message); }
    };
    return;
  }
  if (x.type === 'experiment') {
    if (!confirm(`Create a fake-money experiment: ${x.label.replace(/^Create: /, '')}?\n\nIt runs in the Litter Box next to the original. No real money is used. The Litter Box restarts (about 30 seconds).`)) return;
    try { await postJSON('/api/litterbox', {action: 'variant', base: x.base, level: x.level});
      if (previewBox) previewBox.innerHTML = '<div class="cnote">Created. It shows up in the Litter Box within a minute.</div>'; }
    catch (err) { alert(err.message); }
  }
}
function openTarget(t) {
  if (!t) return;
  const [kind, id] = t.split(':');
  if (kind === 'tab') { prefs.tab = id; savePrefs(); applyPrefs(); load(); closeCouncil(); return; }
  if (kind === 'settings') { prefs.pane = id; savePrefs(); closeCouncil(); $('gear').click(); return; }
  if (kind === 'section') {
    if (prefs.tab !== 'home' && prefs.tab !== 'stats') { prefs.tab = 'home'; savePrefs(); applyPrefs(); }
    let n = $(id);
    if (n && !n.getBoundingClientRect().height && prefs.tab === 'home') { prefs.tab = 'stats'; savePrefs(); applyPrefs(); n = $(id); }
    closeCouncil();
    if (n) setTimeout(() => { n.scrollIntoView({behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start'});
      n.classList.remove('flash'); void n.offsetWidth; n.classList.add('flash'); }, 120);
  }
}
addEventListener('keydown', e => { if (e.key === 'Escape' && councilOpen) closeCouncil(); });
// remember when the person was last here, for "What happened while I was away?"
document.addEventListener('visibilitychange', () => { if (document.hidden) { prefs.lastSeen = Date.now() / 1000; savePrefs(); } });
addEventListener('pagehide', () => { prefs.lastSeen = Date.now() / 1000; savePrefs(); });

// ---- Settings → Cat Council: the optional AI, with everything disclosed before it can be turned on --------------
let lastAiSet = '';
function renderCouncilSettings(s) {
  const ai = ((s.council || {}).ai) || {}, key = JSON.stringify(ai);
  if (!$('aiset') || key === lastAiSet) return; lastAiSet = key;
  $('aistate').textContent = ai.enabled ? 'On' : 'Off'; $('aistate').className = 'pill ' + (ai.enabled ? 'won' : 'wait');
  const u = ai.usage || {}, models = ai.models || {};
  $('aiset').innerHTML = `<div class="aidisc">
      <div class="kv"><span>Provider</span><span>Anthropic (the Claude API)</span></div>
      <div class="kv"><span>Model</span><span><select id="aimodel">${Object.entries(models).map(([k, v]) =>
        `<option value="${esc(k)}" ${k === ai.model ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></span></div>
      <div class="kv"><span>Cost</span><span>Billed by Anthropic to <b>your own</b> Anthropic account, per question (tokens in + out at
        Anthropic’s published prices). Nothing is billed through this app.${u.month ? ` This month: ${u.questions || 0} question(s),
        ${((u.input_tokens || 0) + (u.output_tokens || 0)).toLocaleString()} tokens.` : ''}</span></div>
      <div class="kv"><span>What is sent</span><span>Your question, and the app data the cat looks up to answer it: balances, open bets, recent results,
        settings and limits, Litter Box and Backtrack results, and recent log messages (with IDs and emails removed).</span></div>
      <div class="kv"><span>Never sent</span><span>Your Kalshi key or Key ID, your Anthropic key, passwords or tokens. The AI can’t trade or change settings.</span></div>
      <div class="kv"><span>Privacy</span><span>Anthropic handles the data under its own terms. Read them before turning this on:
        anthropic.com/legal/privacy and anthropic.com/legal/commercial-terms.</span></div>
      <div class="kv"><span>If it’s unavailable</span><span>The cats answer on their own, as they do with AI off. Trading is never affected.</span></div>
    </div>
    ${ai.enabled ? `<div class="pre-act"><button id="aioff">Turn AI off</button><button class="danger" id="aidel">Remove API key</button></div>`
      : `<label class="obf"><span>Anthropic API key ${ai.has_key ? '(one is saved; leave empty to keep it)' : ''}</span>
          <input id="aikey" type="password" autocomplete="off" spellcheck="false" placeholder="sk-ant-…"></label>
        <label class="aiconsent"><input type="checkbox" id="aiok"> I understand what is sent to Anthropic and that my Anthropic account is billed.</label>
        <div class="pre-act"><button class="primary" id="aion">Turn on smarter answers</button>${ai.has_key ? '<button class="danger" id="aidel">Remove API key</button>' : ''}</div>
        <div class="sub">The key is stored like your Kalshi key: encrypted on this computer, locked by the Keychain / Credential Manager.</div>`}
    <div class="obmsg" id="aimsg"></div>`;
}
document.addEventListener('click', async e => {
  const id = e.target.id;
  if (id === 'councilopen') { $('scrim').classList.remove('open'); return openCouncil(); }
  if (!['aion', 'aioff', 'aidel'].includes(id)) return;
  const msg = t => { $('aimsg').textContent = t; };
  try {
    if (id === 'aion') {
      if (!$('aiok').checked) return msg('Tick the box to confirm you’ve read what’s sent and what it costs.');
      const key = $('aikey').value; $('aikey').value = '';
      await postJSON('/api/council_ai', {action: 'enable', consent: true, key, model: $('aimodel').value});
    } else if (id === 'aioff') await postJSON('/api/council_ai', {action: 'disable'});
    else if (confirm('Remove the saved Anthropic API key from this computer?')) await postJSON('/api/council_ai', {action: 'remove_key'});
    lastAiSet = ''; load();
  } catch (err) { msg(err.message); }
});
document.addEventListener('change', async e => {
  if (e.target.id !== 'aimodel') return;
  const ai = ((window._state || {}).council || {}).ai || {};
  if (ai.enabled) { try { await postJSON('/api/council_ai', {action: 'enable', consent: true, model: e.target.value}); load(); } catch (err) { alert(err.message); } }
});
