"""2.1 Your sidekick: one chosen sidekick answers, understands typos, remembers the conversation, asks when unsure,
and public material doesn't give away hidden sidekicks."""
import json
import re
from pathlib import Path

import pytest

from favbot import council, council_ai, vault
from favbot.dashboard import _council_context, build_state
from tests.conftest import T0
from tests.test_bigfatcat import FakeKR
from tests.test_execution_engine import make_bot

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize("q,intent", [
    ("what coin is performing best", "coins"), ("waht coin is perfoming best?", "coins"), ("whcih coin is best", "coins"),
    ("which coin made the most money", "coins"), ("which coin is the worst", "coins"),
    ("whats my balence", "balance"), ("is it workign", "working"), ("why did tradng stop", "stopped"),
    ("how is the litterbox doign", "litterbox"), ("how did my etherium bets do", "coin"), ("how is ETH doing", "coin"),
    ("compre eth and sol", "coin_compare"), ("how much risk am i taking", "risk"),
])
def test_everyday_wording_and_typos(q, intent):
    assert council.understand(q)[0] == intent


def test_typo_fixing_leaves_real_words_and_coins_alone():
    assert council.fix_typos("waht coin is perfoming best") == "what coin is performing best"
    assert council.fix_typos("how much risk am i taking") == "how much risk am i taking"
    assert council.fix_typos("and doge") == "and doge"


async def _state(tmp_path, clock, series=True):
    bot, md, store, sim = make_bot(tmp_path, clock)
    await bot.startup()
    await bot.engines[0].tick()
    await bot.portfolio.snapshot()
    st = build_state(bot)
    if series:
        rows = [("ETH", 0.06), ("ETH", 0.05), ("ETH", 0.07), ("SOL", 0.06), ("SOL", -0.92), ("SOL", 0.05), ("XRP", 0.04)]
        st["series"] = [{"ts": T0 - 3600 + i * 60, "coin": c, "pnl": p, "outcome": "UP", "price": 0.93, "cost": 0.94,
                         "status": "won" if p > 0 else "lost"} for i, (c, p) in enumerate(rows)]
        st["litterbox"] = {"summary": {"ts": T0, "models": [
            {"id": "solo-eth", "name": "ETH only", "coins": ["ETH"], "bets": 40, "roi": 0.03, "se": 0.02, "pnl": 1.2},
            {"id": "solo-sol", "name": "SOL only", "coins": ["SOL"], "bets": 38, "roi": -0.04, "se": 0.03, "pnl": -1.5}]}}
        st["backtrack"] = {"results": {"generated_at": T0 - 7200, "days": 7, "contracts": 1780,
                                       "current": {"all": {"n": 1780, "win_rate": 0.92, "roi": -0.008, "se": 0.007}},
                                       "by_coin": [{"key": "ETH", "n": 900, "wins": 840, "win_rate": 0.933, "roi": 0.004, "se": 0.01, "avg_price": 0.92},
                                                   {"key": "SOL", "n": 880, "wins": 800, "win_rate": 0.909, "roi": -0.02, "se": 0.01, "avg_price": 0.92}]}}
    return bot, st


async def test_best_coin_uses_real_results_with_labels_and_times(tmp_path, clock):
    bot, st = await _state(tmp_path, clock)
    a = council.answer(bot, st, "what coin is performing best", "biscuit")
    assert a["intent"] == "coins" and "ETH" in a["text"] and "+$0.18" in a["text"]
    labels = {b["label"]: b for b in a["blocks"]}
    assert set(labels) == {"Practice money", "Simulated (fake money)", "Historical test"}
    assert all(b["as_of"] for b in a["blocks"])                                       # when each was read
    assert labels["Practice money"]["items"][0].startswith("ETH:")                    # best first
    assert a["uncertainty"]
    w = council.answer(bot, st, "which coin is the worst", "biscuit")
    assert "SOL" in w["text"] and w["blocks"][0]["items"][0].startswith("SOL:")


async def test_remembers_the_conversation(tmp_path, clock):
    bot, st = await _state(tmp_path, clock)
    a = council.answer(bot, st, "which coin is doing best?", "chonk")
    assert a["context"]["coin"] == "ETH"
    why = council.answer(bot, st, "why?", "chonk", context=a["context"])
    assert why["intent"] == "why" and "ETH" in why["text"] and "won 100%" in why["text"]
    assert "Why: win rate vs the price paid" in [b["note"] for b in why["blocks"]]
    cmp_ = council.answer(bot, st, "compare it to SOL", "chonk", context=why["context"])
    assert cmp_["intent"] == "coin_compare" and cmp_["text"].startswith("ETH vs SOL")
    assert all("ETH" in " ".join(b["items"]) and "SOL" in " ".join(b["items"]) for b in cmp_["blocks"])
    about = council.answer(bot, st, "what about XRP?", "chonk", context=a["context"])
    assert about["intent"] == "coin" and about["text"].startswith("XRP")


async def test_asks_a_short_question_when_unsure(tmp_path, clock):
    bot, st = await _state(tmp_path, clock)
    a = council.answer(bot, st, "blorp the zibble", "chill")
    assert a["intent"] == "clarify" and a["intro"] == "" and "did you mean" in a["text"]
    assert "Ask me anything" not in a["text"] and len(a["text"]) < 120               # not the introduction again
    assert a["actions"] and all(x["type"] == "ask" for x in a["actions"])
    hi = council.answer(bot, st, "hello", "chill")
    assert hi["intent"] == "help"


async def test_your_chosen_sidekick_answers_everything(tmp_path, clock):
    bot, st = await _state(tmp_path, clock)
    for q in ("what's my balance", "why did trading stop", "should I switch strategies", "why did I lose", "which coin is best"):
        a = council.answer(bot, st, q, "chill")
        assert a["cat"] == "chill" and "area" not in a["intro"]
    assert council.answer(bot, st, "hi", "katya")["cat"] == "biscuit"                 # only once found
    st["ui"] = {"katya": True}
    assert council.answer(bot, st, "hi", "katya")["cat"] == "katya"


def test_context_from_the_page_is_cleaned():
    c = _council_context({"intent": "coins", "coin": "ETH", "coins": ["ETH", "SOL", "X", "Y", "Z"], "q": "x" * 999,
                          "evil": {"a": 1}, "a": 5})
    assert c == {"intent": "coins", "coin": "ETH", "coins": ["ETH", "SOL", "X", "Y"], "q": "x" * 200}
    assert _council_context("nope") is None


async def test_ai_gets_the_previous_turn(tmp_path, clock, monkeypatch):
    monkeypatch.setattr(vault, "_keyring", lambda kr=FakeKR(): kr)
    bot, st = await _state(tmp_path, clock)
    vault.save_secret(tmp_path, council_ai.SECRET, "sk-ant-test-0000000000000000000000")
    council_ai.save_settings(bot.store, enabled=True, model="claude-haiku-5-5", consented_at=1)
    sent = []

    async def fake_post(key, body):
        sent.append(body)
        return {"stop_reason": "end_turn", "usage": {}, "content": [{"type": "text", "text": "Because ETH won every bet."}]}
    ctx = {"intent": "coins", "coin": "ETH", "q": "which coin is best?", "a": "Best so far: ETH."}
    a = await council_ai.ask(bot, st, "why?", "biscuit", None, tmp_path, post=fake_post, context=ctx)
    msgs = sent[0]["messages"]
    assert [m["role"] for m in msgs] == ["user", "assistant", "user"] and msgs[1]["content"] == "Best so far: ETH."
    assert a["mode"] == "ai" and a["blocks"]                                        # facts still from the app
    assert "Never mention other sidekicks" in sent[0]["system"]
    assert any(t["name"] == "coins" for t in sent[0]["tools"])


def test_public_material_keeps_the_secret():
    from favbot import release
    texts = {
        "update history": (ROOT / "favbot" / "CHANGELOG.json").read_text(encoding="utf-8"),
        "website": (ROOT / "website" / "site.template.html").read_text(encoding="utf-8"),
        "README": (ROOT / "README.md").read_text(encoding="utf-8"),
        "tours": (ROOT / "favbot" / "web" / "tour.js").read_text(encoding="utf-8"),
        "hover tips": (ROOT / "favbot" / "web" / "tips.js").read_text(encoding="utf-8"),
        "start texts": release.START_WINDOWS + release.START_MAC + release.FRIEND_README,
    }
    for where, t in texts.items():
        assert not re.search(r"katya|ushanka|secret sidekick|hidden sidekick|fourth cat|very persistent", t, re.I), where
    # the website shows the three sidekicks as pictures
    site = texts["website"]
    assert site.count('<figure class="kit">') == 3 and all(n in site for n in ("Biscuit", "Le Chonk", "Le Chill"))
    assert json.loads(texts["update history"])[0]["version"] == release.installed_version()
