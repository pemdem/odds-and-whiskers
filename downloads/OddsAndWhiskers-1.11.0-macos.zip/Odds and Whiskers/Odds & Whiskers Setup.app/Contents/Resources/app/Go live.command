#!/bin/bash
cd "$(dirname "$0")"
echo 'This switches Odds & Whiskers from practice to REAL money, step by step. You choose the limits'
echo 'and type the confirmation yourself. Close this window to cancel.'
echo
.venv/bin/python -m favbot go-live
echo
read -n 1 -s -r -p "Press any key to close this window."
echo
