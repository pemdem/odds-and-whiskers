// ---- Sidekicks: Biscuit, Le Chonk, Le Chill ------------------------------------------------
// Every cat shares the same parts so the moods work for all: .tail .body .eyes(.open .happy .sleep) .brows .zzz
const CATS = {
  biscuit: {
    name: 'Biscuit', tagline: 'A fat, friendly ginger. Loves a win, loves a nap more.',
    svg: '',   // drawn below in the sketch-art section
    say: {
      off: "The bot's off, so I'm napping. Wake us both with the Odds & Whiskers icon.",
      killed: 'Kill switch is on. Paws off everything until you turn it back off.',
      paused: 'Paused. Taking a well-earned nap.', halted: 'Something didn’t add up, so I stopped new bets. Check the banner.',
      dailyloss: 'Rough day. We hit the daily loss limit, so no more bets until tomorrow.',
      won: (a, c) => `We won ${a} on ${c}! Fish for dinner.`, lost: (a, c) => `Lost ${a} on ${c}. It happens — that's why the bets are small.`,
      guard: (c, sd, t) => `Guarding our ${c} ${sd} bet. ${t}`, stalk: (c, sd, p) => `Stalking ${c} ${sd} at ${p}…`,
      nap: t => `Napping until ${t}, when the next bets open.`, watch: 'Watching prices. Nothing worth a bet yet.',
      quips: ['I only ever buy at the bid. Never the ask.', 'Fees on our bets? Zero. I checked.',
        'One loss costs about 13 wins. I count every one.', 'I don’t predict prices. I just follow the favourite.',
        'Kill switch stops new bets. It can’t un-fill one that already filled.']},
  },
  chonk: {
    name: 'Le Chonk', tagline: 'A buff grey gym cat. Spots every bet, never skips leg day.',
    svg: '',   // drawn below in the sketch-art section
    say: {
      off: 'Bot’s off. Rest day. Hit the Odds & Whiskers icon when you’re ready to train.',
      killed: 'Kill switch is on. Benching everything.', paused: 'Paused. Hydrating between sets.',
      halted: 'Form check failed — new bets stopped. Look at the banner.',
      dailyloss: 'Daily loss limit hit. Even champions take a recovery day.',
      won: (a, c) => `${a} on ${c}! That’s a PR. Gains.`, lost: (a, c) => `Down ${a} on ${c}. No pain, no gain. Small sets keep us safe.`,
      guard: (c, sd, t) => `Spotting our ${c} ${sd} bet. ${t} Hold it…`, stalk: (c, sd, p) => `Loading the bar: ${c} ${sd} at ${p}.`,
      nap: t => `Resting between sets until ${t}.`, watch: 'Warming up. No clean lift on the board yet.',
      quips: ['Bid, don’t chase. Chasing is cardio.', 'Zero fees on our fills. Lean and mean.',
        'One loss = about 13 wins of work. Respect the weight.', 'Daily loss limit is my spotter. Never lift without it.',
        'Consistency beats intensity. Small bets, every window.']},
  },
  chill: {
    name: 'Le Chill', tagline: 'A round loaf of a cat in shades. Nothing rattles him.',
    svg: '',   // drawn below in the sketch-art section
    say: {
      off: 'Bot’s off. Honestly? Same energy. Tap Odds & Whiskers when you want back in.',
      killed: 'Kill switch is on. Fully unbothered, fully stopped.', paused: 'Paused. Peak loaf mode.',
      halted: 'Something looked off, so I stopped new bets. Banner has the details.',
      dailyloss: 'Daily loss limit hit. We chill till tomorrow.',
      won: (a, c) => `${a} on ${c}. Nice. Very nice.`, lost: (a, c) => `${a} gone on ${c}. Eh. Small bets, small worries.`,
      guard: (c, sd, t) => `Watching our ${c} ${sd} bet. ${t} No rush.`, stalk: (c, sd, p) => `Lazily bidding ${c} ${sd} at ${p}.`,
      nap: t => `Loafing until ${t}. Then bets.`, watch: 'Prices are moving. I’m not. Nothing worth it yet.',
      quips: ['Why pay the ask when you can wait at the bid?', 'Zero fees. Maximum chill.',
        'A loss costs about 13 wins. So I keep the bets tiny.', 'I don’t predict. I just lie here and follow the favourite.',
        'The best trade is sometimes no trade. Mostly I nap.']},
  },
};
// ---- Bongo-style sidekick art: soft round cats on a desk, simple and cute -------------------
const INK = '#1d1d1f';
const OL = `stroke="${INK}" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"`;
const face = (cx, cy) => `
  <ellipse cx="${cx - 24}" cy="${cy + 9}" rx="6.5" ry="3.6" fill="#ff9db0" opacity=".75"/>
  <ellipse cx="${cx + 24}" cy="${cy + 9}" rx="6.5" ry="3.6" fill="#ff9db0" opacity=".75"/>
  <g class="eyes">
    <g class="open"><circle cx="${cx - 14}" cy="${cy}" r="3.8" fill="${INK}"/><circle cx="${cx + 14}" cy="${cy}" r="3.8" fill="${INK}"/></g>
    <g class="happy"><path d="M${cx - 19} ${cy + 2} l5 -5 l5 5 M${cx + 9} ${cy + 2} l5 -5 l5 5" fill="none" ${OL} stroke-width="2.6"/></g>
    <g class="sleep"><path d="M${cx - 19} ${cy} h10 M${cx + 9} ${cy} h10" fill="none" ${OL} stroke-width="2.6"/></g>
  </g>
  <path class="brows" d="M${cx - 21} ${cy - 7} l8 -4 M${cx + 21} ${cy - 7} l-8 -4" fill="none" ${OL} stroke-width="2.4"/>
  <path d="M${cx - 6} ${cy + 8} q3 4 6 0 q3 4 6 0" fill="none" ${OL} stroke-width="2.4"/>`;
const desk = `<path d="M4 117 H136" ${OL}/>`;
const zzz = `<g class="zzz"><text x="108" y="24">z</text><text x="118" y="14">z</text></g>`;
const blob = (fill, extra = '') => `
  <path d="M33 66 L30 30 L60 49 Z M107 66 L110 30 L80 49 Z" fill="${fill}" ${OL}/>
  <path d="M37 57 L36 40 L51 50 Z M103 57 L104 40 L89 50 Z" fill="#ffc2cf"/>
  <path d="M16 117 C14 72 38 46 70 46 C102 46 126 72 124 117 Z" fill="${fill}" ${OL}/>${extra}`;
const paws = fill => `<ellipse class="paw l" cx="44" cy="115" rx="14" ry="7.5" fill="${fill}" ${OL}/>
  <ellipse class="paw r" cx="96" cy="115" rx="14" ry="7.5" fill="${fill}" ${OL}/>`;

CATS.biscuit.svg = `<svg viewBox="0 0 140 124" aria-hidden="true">
  <g class="tail"><path d="M118 108 C 136 104, 138 80, 126 72" fill="none" stroke="${INK}" stroke-width="11" stroke-linecap="round"/>
    <path d="M118 108 C 136 104, 138 80, 126 72" fill="none" stroke="#ffc896" stroke-width="5" stroke-linecap="round"/></g>
  <g class="body">${blob('#ffd2a3', `<path d="M60 53 v8 M70 50 v10 M80 53 v8" fill="none" stroke="#f0974a" stroke-width="3.4" stroke-linecap="round"/>`)}
    ${face(70, 82)}</g>
  ${desk}${paws('#ffd2a3')}${zzz}</svg>`;

CATS.chonk.svg = `<svg viewBox="0 0 140 124" aria-hidden="true">
  <g class="tail"><path d="M118 108 C 136 104, 138 80, 126 72" fill="none" ${OL}/></g>
  <g class="body">${blob('#ffffff', `
    <path d="M27 76 C 42 56, 98 56, 113 76" fill="none" stroke="#ff3b30" stroke-width="7" stroke-linecap="round"/>
`)}
    ${face(70, 86)}
    <g class="arm"><path d="M24 104 C 8 102, 2 84, 10 70 C 15 60, 28 62, 27 72 C 26 80, 30 88, 38 90" fill="#fff" ${OL}/>
      <path d="M12 82 q6 -6 12 0" fill="none" ${OL} stroke-width="2.2"/><circle cx="17" cy="64" r="8" fill="#fff" ${OL}/></g>
    <g class="arm r"><path d="M116 104 C 132 102, 138 84, 130 70 C 125 60, 112 62, 113 72 C 114 80, 110 88, 102 90" fill="#fff" ${OL}/>
      <path d="M116 82 q6 -6 12 0" fill="none" ${OL} stroke-width="2.2"/><circle cx="123" cy="64" r="8" fill="#fff" ${OL}/></g></g>
  ${desk}${zzz}</svg>`;

CATS.chill.svg = `<svg viewBox="0 0 140 124" aria-hidden="true">
  <g class="tail"><path d="M126 112 q14 -2 10 -18" fill="none" ${OL}/></g>
  <g class="body">
    <path d="M34 86 L33 58 L58 74 Z M106 86 L107 58 L82 74 Z" fill="#fff3df" ${OL}/>
    <path d="M38 78 L38 65 L50 73 Z M102 78 L102 65 L90 73 Z" fill="#ffc2cf"/>
    <path d="M8 117 C 8 86, 30 70, 70 70 C 110 70, 132 86, 132 117 Z" fill="#fff3df" ${OL}/>
    <path d="M100 82 q12 6 20 18" fill="none" stroke="#d9b98c" stroke-width="3.4" stroke-linecap="round"/>
    ${face(70, 98)}
    <g class="shades"><rect x="45" y="91" width="20" height="12" rx="5" fill="${INK}"/><rect x="75" y="91" width="20" height="12" rx="5" fill="${INK}"/>
      <path d="M65 95 h10" ${OL} stroke-width="2.4"/><path d="M49 95 l6 -1.5" stroke="#fff" stroke-width="1.8" opacity=".7" stroke-linecap="round"/></g></g>
  ${desk}${zzz}</svg>`;
CATS.biscuit.tagline = 'A round ginger. Taps the desk while your bets play out.';
CATS.chonk.tagline = 'Same cute cat, unreasonably buff arms. Motto: “Bid, don’t chase. Chasing is cardio.”';
CATS.chill.tagline = 'A loaf in sunglasses. Nothing rattles him.';

const CAT_ORDER = ['biscuit', 'chonk', 'chill'];
const curCat = () => CATS[prefs.cat] || CATS.biscuit;
let catMsg = '', catMood = '', catQuipUntil = 0, catHide = 0, renderedCat = '';
function renderCat() {
  if (prefs.cat === 'on') prefs.cat = 'biscuit';            // older setting
  const c = $('cat');
  c.classList.toggle('hidden', prefs.cat === 'off');
  if (prefs.cat === 'off' || renderedCat === prefs.cat) return;
  renderedCat = prefs.cat;
  $('catsvg').innerHTML = curCat().svg;
  c.dataset.cat = prefs.cat; c.removeAttribute('title');
  c.dataset.tip = prefs.cat === 'chonk' ? 'Le Chonk: “Bid, don’t chase. Chasing is cardio.” Click me.' : `${curCat().name} — click me`;
  catMsg = ''; catMood = '';
}
function showBubble(ms = 8000) {   // like a notification: appears, then tucks itself away
  const cat = $('cat'); cat.classList.remove('quiet'); clearTimeout(catHide);
  catHide = setTimeout(() => cat.classList.add('quiet'), ms);
}
function catSay(mood, msg) {
  const cat = $('cat');
  if (mood !== catMood) { cat.classList.remove('sleep', 'happy', 'sad', 'watch', 'idle'); cat.classList.add(mood); catMood = mood; }
  if (msg !== catMsg) {
    const sameKind = catMsg.replace(/[\d:]+/g, '') === msg.replace(/[\d:]+/g, '');
    catMsg = msg; const b = $('catsay'); b.textContent = msg;
    if (!sameKind) { b.classList.remove('pop'); void b.offsetWidth; b.classList.add('pop'); showBubble(); }
  }
}
function updateCat(s) {
  renderCat();
  if (prefs.cat === 'off' || Date.now() < catQuipUntil) return;
  const say = curCat().say, last = s.series[s.series.length - 1], fresh = last && s.now - last.ts < 180;
  const resting = s.pending.find(e => e.state === 'resting'), open = s.open_bets[0];
  const left = s.coins.map(c => c.secs_left).filter(v => v != null), nextClose = left.length ? Math.min(...left) : null;
  const side = o => o === 'UP' ? 'Up' : 'Down';
  if (s.killed) return catSay('sad', say.killed);
  if (s.paused) return catSay('sleep', say.paused);
  if (Object.keys(s.halts).length) return catSay('sad', say.halted);
  if (s.daily_loss_hit) return catSay('sad', say.dailyloss);
  if (fresh && last.pnl > 0) return catSay('happy', say.won(money(last.pnl, true), last.coin));
  if (fresh && last.pnl < 0) return catSay('sad', say.lost(money(-last.pnl), last.coin));
  if (open) return catSay('watch', say.guard(open.coin, side(open.outcome), open.closes_at ? `Result in ${mmss(open.closes_at - s.now)}.` : ''));
  if (resting) return catSay('watch', say.stalk(resting.coin, side(resting.outcome), cents(resting.price)));
  if (nextClose != null && nextClose > 300) return catSay('sleep', say.nap(tm(s.now + nextClose - 300)));
  catSay('idle', say.watch);
}
function catOffline() { renderCat(); if (prefs.cat !== 'off') catSay('sleep', curCat().say.off); }
$('cat').onclick = () => {
  const c = $('cat'); c.classList.remove('boop'); void c.offsetWidth; c.classList.add('boop');
  if (c.classList.contains('quiet')) { showBubble(); return; }        // first click: show what's going on
  catQuipUntil = Date.now() + 7000;                                    // next clicks: a tip
  const qs = curCat().say.quips;
  let q; do { q = qs[Math.floor(Math.random() * qs.length)]; } while (q === catMsg && qs.length > 1);
  catSay(catMood === 'sleep' ? 'idle' : catMood || 'idle', q); showBubble(7000);
};
function renderCatPick() {
  const cards = CAT_ORDER.map(k => `<button class="catcard ${prefs.cat === k ? 'on' : ''}" data-cat="${k}">` +
    `<div class="pv">${CATS[k].svg.replace(/id="(fur|belly)(\w)"/g, 'id="pv$1$2"').replace(/url\(#(fur|belly)(\w)\)/g, 'url(#pv$1$2)')}</div>` +
    `<div><b>${CATS[k].name}</b><span>${CATS[k].tagline}</span></div></button>`).join('') +
    `<button class="catcard ${prefs.cat === 'off' ? 'on' : ''}" data-cat="off"><div class="pv" style="font-size:34px;text-align:center">🚫</div>` +
    `<div><b>No sidekick</b><span>Just the numbers.</span></div></button>`;
  $('catpick').innerHTML = cards;
}
$('catpick').onclick = e => { const b = e.target.closest('.catcard'); if (!b) return;
  prefs.cat = b.dataset.cat; savePrefs(); renderedCat = ''; renderCat(); renderCatPick();
  if (prefs.cat !== 'off') { catQuipUntil = 0; catSay('happy', `Hi, I'm ${curCat().name}!`); showBubble(5000); setTimeout(load, 5000); } };
