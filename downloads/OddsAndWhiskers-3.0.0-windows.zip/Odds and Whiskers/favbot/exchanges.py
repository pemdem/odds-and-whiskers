"""Exchange workspaces: Kalshi and Polymarket US.

Each exchange is its own workspace with its own data folder (credentials, balances, positions, history and
simulation results never mix). Kalshi is the bot you already run. Polymarket US runs as a separate helper process
with its own database under data/polymarket_us/, in practice mode only: market browsing and fake-money testing
on Polymarket US's real public prices. It never places an order (its market-data client is read-only and its
trading side is the paper simulator).

This module also answers "which strategies work on Polymarket US?" from facts checked against both exchanges'
published market rules (2026-10-17):
- both list 15-minute "Up or Down" crypto markets on the same :00/:15/:30/:45 windows;
- both settle on CF Benchmarks' Real-Time Index for the coin: the simple average of the 60 prices in the last
  minute before the window opens and before it closes; Up (Kalshi's "Yes") wins when the close is at least the open;
- Polymarket US lists BTC, ETH, SOL and XRP. Kalshi's other coins (DOGE, BNB, ZEC, HYPE, NEAR …) have no
  Polymarket US market. BTC is listed, but the strategy leaves Bitcoin out by design (as it does on Kalshi);
- prices: Kalshi goes down to 0.1¢ near 0 and 100¢, Polymarket US uses whole cents (bids are rounded down);
- fees: Kalshi's taker fee is 7% × p × (1 − p) per contract (rounded up); Polymarket US's is 6.95% × p × (1 − p)
  (rounded to the cent). Polymarket US may pay makers a small rebate; the simulation leaves it out.
"""
from __future__ import annotations

from pathlib import Path

from .config import Config
from .providers import polymarket_us as pm

KALSHI, POLYMARKET_US = "kalshi", "polymarket_us"
EXCHANGES = {
    KALSHI: {"id": KALSHI, "name": "Kalshi", "mark": "K", "color": "#00DD94", "color_light": "#00B67A",
             "real_money": True, "practice_only": False},
    POLYMARKET_US: {"id": POLYMARKET_US, "name": "Polymarket US", "mark": "P", "color": "#2E5CFF", "color_light": "#2E5CFF",
                    "real_money": False, "practice_only": True},
}
PORT_OFFSET = 100                     # Polymarket US workspace dashboard: Kalshi's port + 100 (127.0.0.1 only)
LEFT_OUT = {"BTC"}                   # the strategy leaves Bitcoin out by design (KXBTC15M is forbidden in config.py)

RULES = [
    {"topic": "Time window", "kalshi": "15 minutes, on :00, :15, :30 and :45", "polymarket_us": "15 minutes, on :00, :15, :30 and :45",
     "same": True},
    {"topic": "Price source", "kalshi": "CF Benchmarks Real-Time Index (e.g. ETHUSDRTI)",
     "polymarket_us": "CF Benchmarks Real-Time Index (e.g. ETHUSD_RTI)", "same": True},
    {"topic": "Settlement", "kalshi": "Average of 60 index prices in the last minute; Up if close ≥ open",
     "polymarket_us": "Average of 60 index prices in the last minute; Up if close ≥ open", "same": True},
    {"topic": "Coins", "kalshi": "ETH, SOL, XRP, DOGE, BNB, ZEC, HYPE, NEAR (+ others)", "polymarket_us": "BTC, ETH, SOL, XRP",
     "same": False},
    {"topic": "Price steps", "kalshi": "1¢, and 0.1¢ near 0¢ and 100¢", "polymarket_us": "1¢ everywhere (bids round down)",
     "same": False},
    {"topic": "Taker fee", "kalshi": "7% × p × (1 − p) per contract", "polymarket_us": "6.95% × p × (1 − p) per contract",
     "same": False},
    {"topic": "Waiting at the bid", "kalshi": "No maker fee on these markets", "polymarket_us": "No fee (a small rebate on some tiers, not counted)",
     "same": False},
    {"topic": "Order book", "kalshi": "Separate Yes and No bids", "polymarket_us": "One book for Up; Down is its mirror image",
     "same": False},
    {"topic": "Real money in this app", "kalshi": "Yes, with your limits and typed confirmation",
     "polymarket_us": "Not yet: practice (fake money) only", "same": False},
]


def coin_table(kalshi_coins: list[str]) -> list[dict]:
    """Every coin either exchange offers for the strategy, and whether it can be tested on Polymarket US."""
    rows = []
    for c in sorted(set(kalshi_coins) | set(pm.COINS), key=lambda c: (c not in pm.COINS, c)):
        on_k, on_p = c in kalshi_coins, c in pm.COINS
        if c in LEFT_OUT:
            why, ok = ("Polymarket US lists it, but the strategy leaves Bitcoin out on purpose (as it does on Kalshi)."
                       if on_p else "The strategy leaves Bitcoin out on purpose."), False
        elif on_p:
            why, ok = "Same 15-minute window, CF Benchmarks index and settlement rule on both.", True
        else:
            why, ok = f"Polymarket US has no 15-minute {c} market.", False
        rows.append({"coin": c, "kalshi": on_k, "polymarket_us": on_p, "testable": ok, "why": why})
    return rows


def testable_coins(coins: list[str]) -> list[str]:
    return [c for c in coins if c in pm.COINS and c not in LEFT_OUT]


def strategy_status(name: str, coins: list[str], strategy: dict | None = None, extra: str = "") -> dict:
    """available / partial / unavailable on Polymarket US, with a one-line reason."""
    here = testable_coins(coins)
    missing = [c for c in coins if c not in here]
    if not here:
        why = (f"Polymarket US has no 15-minute {', '.join(missing)} market." if len(missing) <= 3 else
               "None of its coins has a 15-minute market on Polymarket US.")
        return {"name": name, "status": "unavailable", "coins": [], "missing": missing, "why": why + extra}
    if missing:
        return {"name": name, "status": "partial", "coins": here, "missing": missing,
                "why": f"Runs on {', '.join(here)} only; {', '.join(missing)} {'has' if len(missing) == 1 else 'have'} "
                       f"no Polymarket US market." + extra}
    entry = (strategy or {}).get("entry", "bid")
    how = "buys at the ask (taker fee applies)" if entry == "ask" else "waits at the bid (no fee)"
    return {"name": name, "status": "available", "coins": here, "missing": [],
            "why": f"Same markets and rules; on Polymarket US it {how}, with prices in whole cents." + extra}


def equivalence(cfg: Config, models: list | None = None) -> dict:
    """What can be tested on Polymarket US: coins, your own strategy, every Litter Box model, and other tools."""
    from .litterbox import MODELS, ORIGINAL_COINS
    from .presets import strategy_dict
    kalshi_coins = [s[2:-3] for s in cfg.series]
    rows = [strategy_status("Your strategy", kalshi_coins, strategy_dict(cfg.strategy))]
    for m in models if models is not None else MODELS:
        rows.append({**strategy_status(m.name, m.coins or ORIGINAL_COINS, {**m.strategy}), "id": m.id})
    tools = [
        {"name": "Market browsing", "status": "available", "why": "Live prices for BTC, ETH, SOL and XRP from Polymarket US's public data."},
        {"name": "Fake-money testing", "status": "available", "why": "Your strategy and the Litter Box models on Polymarket US's real prices."},
        {"name": "Real-money trading", "status": "unavailable",
         "why": "Not in this version. Polymarket US starts with browsing and fake money; no account is connected and no orders are sent."},
        {"name": "Backtrack", "status": "unavailable",
         "why": "Backtrack replays Kalshi's price history; Polymarket US history isn't loaded yet."},
        {"name": "Learning loop & Recommended preset", "status": "unavailable", "why": "These are built on Backtrack, so they stay on Kalshi."},
    ]
    return {"coins": coin_table(sorted(set(kalshi_coins) | set(ORIGINAL_COINS))), "strategies": rows, "tools": tools,
            "rules": RULES, "checked": "2026-10-17"}


def workspace_root(cfg: Config) -> Path:
    """data/polymarket_us — next to data/live, data/litterbox … but never shared with them."""
    return cfg.data_path("live").parent / POLYMARKET_US


def workspace_config(cfg: Config) -> Config:
    """The Polymarket US workspace's settings: your strategy and limits, the coins Polymarket US lists, practice
    mode, its own data folder and its own local port. config.yaml itself is never changed by this workspace."""
    lim = cfg.live_limits or cfg.limits_for(cfg.mode) or cfg.paper_limits
    coins = testable_coins([s[2:-3] for s in cfg.series]) or testable_coins(list(pm.COINS))
    paper = cfg.paper.model_copy(update={"starting_cash_usd": lim.capital_cap_usd}) if lim is not None else cfg.paper
    return cfg.model_copy(update={
        "mode": "paper", "data_dir": str(workspace_root(cfg)), "series": [pm.series_for(c) for c in coins],
        "paper_limits": lim, "paper": paper,
        "dashboard": cfg.dashboard.model_copy(update={"port": cfg.dashboard.port + PORT_OFFSET}),
    })
