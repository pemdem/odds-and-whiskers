"""Paper fill model, risk limits (including resting bids and unconfirmed orders)."""
from decimal import Decimal as D

import pytest

from favbot.models import BalanceInfo, OrderRequest
from favbot.money import maker_fee
from favbot.portfolio import Portfolio
from favbot.providers.paper import PaperExchange
from favbot.risk import RiskInputs, evaluate
from favbot.store import Store

from .conftest import book, limits


def ask_book(ticker, yes_ask_levels, yes_bid="0.90", t=None):
    """Book where YES asks are given as [(price, size)] (stored as NO bids at 1-price)."""
    return book(ticker, [(yes_bid, "50")], [(str(D(1) - D(p)), q) for p, q in yes_ask_levels], fetched_at=t)


# ---- paper fills ---------------------------------------------------------------------------
async def test_fill_only_on_trade_through_never_on_touch(clock):
    sim = PaperExchange(None, D("100"), clock=clock)
    ack = await sim.create_order(OrderRequest("T", "c1", "yes", D("0.91"), 10, int(clock() + 20)))
    assert await sim.get_balance() == BalanceInfo(D("90.90"), D(0))
    clock.advance(0.5)
    sim.observe_book(ask_book("T", [("0.93", "100")], t=clock()), clock())     # arrival: no cross
    clock.advance(2)
    sim.observe_book(ask_book("T", [("0.91", "100")], t=clock()), clock())     # touch
    assert (await sim.get_order(ack.order_id)).fill_count == 0
    clock.advance(2)
    sim.observe_book(ask_book("T", [("0.90", "8"), ("0.91", "100")], t=clock()), clock())  # through, 8 shown
    o = await sim.get_order(ack.order_id)
    assert o.fill_count == 4 and o.status == "resting"                         # only half the depth is real
    assert (await sim.get_positions())[0].position == 4
    await sim.cancel_order(ack.order_id, "T")
    assert (await sim.get_balance()).balance == D("100") - D("3.64")
    await sim.settle("T", "yes")
    assert (await sim.get_balance()).balance == D("100.36")


async def test_latency_blocks_immediate_match(clock):
    sim = PaperExchange(None, D("100"), clock=clock)
    ack = await sim.create_order(OrderRequest("T", "c1", "yes", D("0.91"), 10, int(clock() + 20)))
    sim.observe_book(ask_book("T", [("0.85", "100")], t=clock()), clock())     # 0 ms later
    o = await sim.get_order(ack.order_id)
    assert o.fill_count == 0 and o.status == "resting"


async def test_post_only_that_would_cross_is_cancelled(clock):
    sim = PaperExchange(None, D("100"), clock=clock)
    ack = await sim.create_order(OrderRequest("T", "c1", "yes", D("0.91"), 10, int(clock() + 20)))
    clock.advance(0.5)
    sim.observe_book(ask_book("T", [("0.90", "100")], t=clock()), clock())
    o = await sim.get_order(ack.order_id)
    assert o.status == "canceled" and o.fill_count == 0
    assert (await sim.get_balance()).balance == D("100")


async def test_expiry_and_no_leg(clock):
    sim = PaperExchange(None, D("100"), clock=clock)
    ack = await sim.create_order(OrderRequest("T", "c1", "no", D("0.92"), 2, int(clock() + 20)))
    clock.advance(21)
    assert (await sim.get_order(ack.order_id)).status == "canceled"


async def test_duplicate_client_order_id_rejected(clock):
    sim = PaperExchange(None, D("100"), clock=clock)
    await sim.create_order(OrderRequest("T", "same", "yes", D("0.91"), 1, int(clock() + 20)))
    with pytest.raises(Exception):
        await sim.create_order(OrderRequest("T", "same", "yes", D("0.91"), 1, int(clock() + 20)))


async def test_insufficient_balance(clock):
    sim = PaperExchange(None, D("5"), clock=clock)
    with pytest.raises(Exception, match="insufficient"):
        await sim.create_order(OrderRequest("T", "c", "yes", D("0.91"), 10, int(clock() + 20)))


# ---- risk ---------------------------------------------------------------------------------
def inputs(**kw):
    base = dict(limits=limits(), equity=D(1000), available_cash=D(1000), exposure=D(0), open_positions=0,
                daily_pnl=D(0), price=D("0.91"), fee_fn=lambda q, p: D(0), trading_active=True, clock_skew_s=0.1,
                book_age_s=0.5)
    base.update(kw)
    return RiskInputs(**base)


def test_sizing_formula():
    r = evaluate(inputs())
    assert r.ok and r.budget == D(25) and r.quantity == 27 and r.max_loss == D("24.57")


def test_capital_cap_bounds_equity():
    r = evaluate(inputs(limits=limits(capital_cap_usd="100")))   # 5% of min(1000, 100) = 5
    assert r.quantity == 5


def test_total_exposure_and_cash_limits():
    assert evaluate(inputs(exposure=D(290))).quantity == 10          # 30% of 1000 - 290 = 10
    assert evaluate(inputs(available_cash=D("3"))).quantity == 3
    assert not evaluate(inputs(exposure=D(300))).ok
    assert not evaluate(inputs(available_cash=D("0.50"))).ok        # less than one contract


def test_maker_fee_included_in_max_loss():
    fee = lambda q, p: maker_fee("quadratic_with_maker_fees", 1, q, p)  # noqa: E731
    r = evaluate(inputs(fee_fn=fee))
    assert r.ok and r.max_loss <= r.budget and r.max_loss == r.quantity * D("0.91") + fee(r.quantity, D("0.91"))


@pytest.mark.parametrize("kw,why", [
    ({"open_positions": 6}, "max open positions"),
    ({"unknown_orders": 1}, "unknown outcome"),
    ({"killed": True}, "kill"),
    ({"paused": True}, "paused"),
    ({"halts": ("position_mismatch",)}, "halted"),
    ({"book_age_s": 7.0}, "stale"),
    ({"book_age_s": None}, "stale"),
    ({"clock_skew_s": None}, "skew unknown"),
    ({"clock_skew_s": -3.0}, "skew"),
    ({"trading_active": False}, "trading"),
    ({"trading_active": None}, "trading"),
    ({"daily_pnl": D("-100")}, "daily loss"),
])
def test_blocks(kw, why):
    r = evaluate(inputs(**kw))
    assert not r.ok and why in r.reason


class FakeAccount:
    def __init__(self, balance, positions=()):
        self.b = BalanceInfo(D(balance), D(0))
        self.p = list(positions)

    async def balance(self):
        return self.b

    async def positions(self):
        return self.p


async def test_exposure_counts_resting_bids_and_unconfirmed_orders(tmp_path):
    s = Store(tmp_path / "db.sqlite3")
    kw = dict(mode="paper", series="KXETH15M", coin="ETH", leg="yes", outcome="UP", expiration_ts=1, max_attempts=20)
    a = s.insert_intent(ticker="A", price=D("0.90"), count=10, max_loss=D("9.00"), client_order_id="a", **kw)
    s.mark_resting(a, "o-a")
    b = s.insert_intent(ticker="B", price=D("0.92"), count=5, max_loss=D("4.60"), client_order_id="b", **kw)
    s.mark_unknown(b, "timeout")
    snap = await Portfolio(s, "paper", FakeAccount("100"), {}).snapshot()
    assert snap.exposure == D("13.60")
    assert snap.open_positions == 2                    # resting bid and unconfirmed order both count
    assert snap.available_cash == D("95.40")           # unconfirmed worst case is held back
    assert snap.equity == D("109.00")                  # cash reserved behind the resting bid is still ours
    r = evaluate(inputs(limits=limits(capital_cap_usd="100", max_open_positions=2), equity=snap.equity,
                        available_cash=snap.available_cash, exposure=snap.exposure,
                        open_positions=snap.open_positions))
    assert not r.ok and "max open positions" in r.reason
