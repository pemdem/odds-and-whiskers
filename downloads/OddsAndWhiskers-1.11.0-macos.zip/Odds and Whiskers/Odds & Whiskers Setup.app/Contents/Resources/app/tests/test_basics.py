"""Outcome mapping, order payload translation, fees, price grid, signing."""
import base64
from decimal import Decimal as D

import pytest
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ed25519, padding, rsa

from favbot.models import OrderRequest
from favbot.money import PriceGrid, UnknownFeeType, maker_fee, taker_fee
from favbot.providers.base import ApiError, OrderOutcomeUnknown, TransportError
from favbot.providers.kalshi import KalshiTrading, Signer, verify_market

from .conftest import T0, market


# ---- outcome mapping -------------------------------------------------------------------
def test_greater_or_equal_means_yes_is_up():
    c, why = verify_market(market(strike="greater_or_equal"), "KXETH15M", 2)
    assert why == "ok" and c.yes_is_up
    assert c.outcome_of("yes") == "UP" and c.outcome_of("no") == "DOWN"
    assert c.leg_of("UP") == "yes"


def test_inverted_contract_maps_yes_to_down():
    for strike in ("less_or_equal", "less"):
        c, why = verify_market(market(strike=strike), "KXETH15M", 2)
        assert why == "ok" and not c.yes_is_up
        assert c.outcome_of("yes") == "DOWN" and c.outcome_of("no") == "UP"
        assert c.leg_of("UP") == "no"


@pytest.mark.parametrize("change,reason", [
    ({"strike_type": None}, "strike_type not set yet"),
    ({"strike_type": "between"}, "unsupported strike_type"),
    ({"market_type": "scalar"}, "market_type"),
    ({"settlement_bounds_type": "floor"}, "settlement_bounds_type"),
    ({"status": "initialized"}, "status"),
    ({"rules_primary": "Resolves on Coinbase spot"}, "rule text"),
    ({"exchange_index": 0}, "exchange_index"),
])
def test_verification_rejects(change, reason):
    c, why = verify_market(market(**change), "KXETH15M", 2)
    assert c is None and reason in why


def test_verification_rejects_wrong_duration():
    m = market(close_ts=T0 + 900)
    m["open_time"] = market(close_ts=T0)["open_time"]  # opens at T0-900: a 30-minute contract
    c, why = verify_market(m, "KXETH15M", 2)
    assert c is None


def test_verification_rejects_other_series():
    c, why = verify_market(market(series="KXSOL15M"), "KXETH15M", 2)
    assert c is None and "series" in why


# ---- payload translation ---------------------------------------------------------------
def test_payload_buy_yes():
    p = OrderRequest("T", "fb-1", "yes", D("0.91"), 5, 1234).to_payload()
    assert p == {"ticker": "T", "client_order_id": "fb-1", "side": "bid", "count": "5.00", "price": "0.9100",
                 "time_in_force": "good_till_canceled", "post_only": True, "expiration_time": 1234,
                 "cancel_order_on_pause": True, "self_trade_prevention_type": "taker_at_cross"}


def test_payload_buy_no_is_ask_at_complement():
    p = OrderRequest("T", "fb-2", "no", D("0.935"), 3, 99).to_payload()
    assert p["side"] == "ask" and p["price"] == "0.0650" and p["count"] == "3.00"


def test_payload_rejects_zero_count():
    with pytest.raises(ValueError):
        OrderRequest("T", "x", "yes", D("0.9"), 0, 1).to_payload()


# ---- fees ------------------------------------------------------------------------------
def test_taker_fee_published_example():
    assert taker_fee("quadratic", 1, 100, D("0.55")) == D("1.74")


def test_maker_fee_zero_on_quadratic():
    assert maker_fee("quadratic", 1, 100, D("0.55")) == D("0")


def test_maker_fee_when_series_charges_makers():
    # 0.0175 * 100 * 0.55 * 0.45 = 0.433125 -> 0.44
    assert maker_fee("quadratic_with_maker_fees", 1, 100, D("0.55")) == D("0.44")


def test_fee_rounds_up_to_cent():
    assert taker_fee("quadratic", 1, 1, D("0.93")) == D("0.01")  # 0.004557 -> 0.01


def test_unknown_fee_type_refuses():
    with pytest.raises(UnknownFeeType):
        maker_fee("flat", 1, 1, D("0.9"))
    with pytest.raises(UnknownFeeType):
        taker_fee("something_new", 1, 1, D("0.9"))


# ---- price grid ------------------------------------------------------------------------
def test_price_grid():
    g = PriceGrid.default()
    assert g.is_valid(D("0.935")) and g.is_valid(D("0.05")) and g.is_valid(D("0.55"))
    assert not g.is_valid(D("0.555")) and not g.is_valid(D("1")) and not g.is_valid(D("0"))
    assert g.snap_down(D("0.555")) == D("0.55")
    assert g.snap_down(D("0.9355")) == D("0.935")


# ---- signing ---------------------------------------------------------------------------
def test_rsa_pss_signature_over_path_without_query():
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    h = Signer("kid", key).headers("get", "/trade-api/v2/portfolio/orders?limit=5", ts_ms=1700000000000)
    assert h["KALSHI-ACCESS-KEY"] == "kid" and h["KALSHI-ACCESS-TIMESTAMP"] == "1700000000000"
    key.public_key().verify(base64.b64decode(h["KALSHI-ACCESS-SIGNATURE"]),
                            b"1700000000000GET/trade-api/v2/portfolio/orders",
                            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.DIGEST_LENGTH),
                            hashes.SHA256())


def test_ed25519_signature():
    key = ed25519.Ed25519PrivateKey.generate()
    h = Signer("kid", key).headers("POST", "/trade-api/v2/portfolio/events/orders", ts_ms=5)
    key.public_key().verify(base64.b64decode(h["KALSHI-ACCESS-SIGNATURE"]), b"5POST/trade-api/v2/portfolio/events/orders")
    assert "kid" not in repr(Signer("kid", key))


# ---- ambiguous outcomes on the real adapter --------------------------------------------
class _Api:
    read_only = False

    def __init__(self, exc):
        self.exc = exc

    async def request(self, *a, **k):
        raise self.exc


@pytest.mark.parametrize("exc,expected", [
    (TransportError("read timeout", maybe_sent=True), OrderOutcomeUnknown),
    (ApiError(503, "unavailable"), OrderOutcomeUnknown),
    (ApiError(500, "boom"), OrderOutcomeUnknown),
    (TransportError("connect refused", maybe_sent=False), ApiError),
    (ApiError(400, "insufficient shard balance"), ApiError),
])
async def test_create_order_ambiguity_classification(exc, expected):
    t = KalshiTrading(_Api(exc), 2)
    with pytest.raises(expected) as ei:
        await t.create_order(OrderRequest("T", "c", "yes", D("0.9"), 1, 10))
    if expected is ApiError:
        assert not isinstance(ei.value, OrderOutcomeUnknown)
