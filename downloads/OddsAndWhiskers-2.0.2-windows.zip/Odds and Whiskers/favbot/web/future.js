// ---- The future: box-and-whisker chart -------------------------------------------------
let lastProj = '';
function renderProjection(p, eq) {
  if (!p) return;
  const key = JSON.stringify(p) + prefs.odds + prefs.theme;
  if (key === lastProj) return; lastProj = key;
  if (!p.ready) {
    const prog = Math.min(p.bets / p.need_bets, p.hours / p.need_hours, 1);
    $('proj').innerHTML = `<div class="pj" style="margin-top:16px"><div class="d">Collecting data</div>` +
      `<div class="progress"><i style="width:${Math.max(prog * 100, 3)}%"></i></div>` +
      `<div class="s">${p.bets} of ${p.need_bets} settled bets · ${p.hours} of ${p.need_hours} hours running.</div></div>`;
    return;
  }
  if (!p.rows || p.rows[0].p5 === undefined || p.p_est === undefined) {   // page is newer than the running bot
    $('proj').innerHTML = '<div class="empty" style="height:90px;margin-top:14px">Restart the bot (banner above) to see the new chart.</div>';
    return;
  }
  $('proj').innerHTML =
    `<div class="oddsline">` +
      tile('Real chance a bet wins (best guess)', `${pct(p.p_est)}`) +
      tile('Likely range', `${pct(p.p_low)} – ${pct(p.p_high)}`) +
      tile('Needed to break even', `${pct(p.breakeven_win_rate)}`, p.p_est >= p.breakeven_win_rate ? 'pos' : 'neg') +
    `</div>` +
    `<div class="boxwrap" id="boxwrap"></div>` +
    `<div class="chips">${p.rows.map(r => `<div class="chip2"><b>${r.days} days</b>` +
      `Low ${money(r.p5)} · High ${money(r.p95)}<br>Typical ${money(r.p50)}<br>` +
      `<span class="${r.chance_up >= 0.5 ? 'pos' : 'neg'}">${Math.round(r.chance_up * 100)}% chance you're up</span><br>` +
      `${Math.round(r.chance_half * 100)}% chance below ${money(p.equity / 2)}</div>`).join('')}</div>` +
    `<p class="note">How to read it: each row is ${p.sims.toLocaleString()} simulated futures. The <b>whiskers</b> reach the low and high ` +
    `that 90% of them land between; the <b>box</b> is the middle half; the <b>line</b> is the typical result; the dashed line is today. ` +
    `Uses your real numbers — about ${p.per_day} bets a day at ${money(p.avg_cost)} each, winning ${money(p.gain)} or losing ` +
    `${money(p.avg_cost)} — your ${p.wins}–${p.losses} record blended with the market's own odds (worth ${p.prior_bets} bets), ` +
    `your daily loss limit, no reinvesting, and bad days where several coins lose together. ` +
    `All chances shown are <b>estimates</b> from a model, not guarantees. It updates as every bet settles.</p>`;
  drawBox($('boxwrap'), p.rows, p.equity);
}

function drawBox(box, rows, eq) {
  if (box.clientWidth < 60) { lastProj = ''; return; }
  const w = box.clientWidth || 600, rowH = 54, m = {l: 64, r: 16, t: 26, b: 30}, h = m.t + rows.length * rowH + m.b;
  box.innerHTML = '';
  const svg = el('svg', {viewBox: `0 0 ${w} ${h}`, height: h}, box);
  const tip = document.createElement('div'); tip.className = 'tip'; box.appendChild(tip);
  // square-root axis so the 7-day box and the 90-day box are both readable; ticks are labelled in dollars
  // (just after startup the balance can still read $0: never divide by zero)
  const hi = Math.max(1, eq * 1.2, ...rows.map(r => r.p95 || 0)) * 1.05, S = v => Math.sqrt(Math.max(0, v || 0));
  const x = v => m.l + S(v) / S(hi) * (w - m.l - m.r);
  const nice = [0, 1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 2500, 5000, 10000, 20000, 50000];
  let ticks = nice.filter(t => t <= hi), lastX = -99;
  ticks = ticks.filter(t => { const X = x(t); if (X - lastX < 46) return false; lastX = X; return true; });
  for (const t of ticks) {
    el('line', {x1: x(t), x2: x(t), y1: m.t - 6, y2: h - m.b, stroke: css('--line')}, svg);
    el('text', {x: x(t), y: h - m.b + 16, class: 'axis', 'text-anchor': 'middle'}, svg).textContent = '$' + t.toLocaleString();
  }
  const ex = x(eq);
  el('line', {x1: ex, x2: ex, y1: m.t - 14, y2: h - m.b, stroke: css('--fg'), 'stroke-width': 1.5, 'stroke-dasharray': '4 4'}, svg);
  el('text', {x: ex, y: m.t - 16, class: 'axis', 'text-anchor': 'middle', style: 'fill:var(--fg);font-weight:600'}, svg)
    .textContent = 'Today ' + money(eq);
  rows.forEach((r, i) => {
    const cy = m.t + i * rowH + rowH / 2, up = r.p50 >= eq, col = up ? css('--pos') : css('--neg');
    el('text', {x: m.l - 12, y: cy + 4, 'text-anchor': 'end', style: 'fill:var(--fg);font-size:13px;font-weight:600'}, svg)
      .textContent = `${r.days} days`;
    const g = el('g', {class: 'bx-wh'}, svg); g.style.animationDelay = (i * 0.08) + 's';
    el('line', {x1: x(r.p5), x2: x(r.p25), y1: cy, y2: cy, stroke: css('--fg3'), 'stroke-width': 1.5}, g);
    el('line', {x1: x(r.p75), x2: x(r.p95), y1: cy, y2: cy, stroke: css('--fg3'), 'stroke-width': 1.5}, g);
    for (const v of [r.p5, r.p95]) el('line', {x1: x(v), x2: x(v), y1: cy - 9, y2: cy + 9, stroke: css('--fg3'), 'stroke-width': 1.5}, g);
    const bx = el('rect', {x: x(r.p25), y: cy - 14, width: Math.max(3, x(r.p75) - x(r.p25)), height: 28, rx: 8,
      fill: up ? css('--pos-soft') : css('--neg-soft'), stroke: col, 'stroke-width': 1.5, class: 'bx-box'}, svg);
    bx.style.animationDelay = (i * 0.08) + 's';
    el('line', {x1: x(r.p50), x2: x(r.p50), y1: cy - 14, y2: cy + 14, stroke: col, 'stroke-width': 3, 'stroke-linecap': 'round',
      class: 'bx-wh'}, svg);
    const hit = el('rect', {x: 0, y: cy - rowH / 2, width: w, height: rowH, fill: 'transparent'}, svg);
    hit.addEventListener('mousemove', () => placeTip(tip, x(r.p50), cy - 16, w,
      `<b>In ${r.days} days</b> (≈${r.bets.toLocaleString()} bets)<br>High ${money(r.p95)} · Low ${money(r.p5)}<br>` +
      `Middle half ${money(r.p25)} – ${money(r.p75)}<br>Typical ${money(r.p50)}<br>${Math.round(r.chance_up * 100)}% chance you're up`));
    hit.addEventListener('mouseleave', () => { tip.style.opacity = 0; });
  });
}
