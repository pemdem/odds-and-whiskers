"""Easy setup: the Kalshi key kept securely in the app, and the in-app money steps that need a typed phrase."""
import json
from decimal import Decimal as D
from types import SimpleNamespace

import pytest
from aiohttp import web
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

from favbot import account, dashboard, vault
from favbot.config import Config, CredentialError, Limits, load_credentials
from favbot.liveguard import ack_phrase, check_ack


class FakeKeyring:
    """Stands in for the macOS Keychain / Windows Credential Manager."""
    def __init__(self):
        self.items = {}

    def set_password(self, s, a, p):
        self.items[(s, a)] = p

    def get_password(self, s, a):
        return self.items.get((s, a))

    def delete_password(self, s, a):
        self.items.pop((s, a))


@pytest.fixture()
def kr(monkeypatch):
    k = FakeKeyring()
    monkeypatch.setattr(vault, "_keyring", lambda: k)
    for v in ("KALSHI_API_KEY_ID", "KALSHI_PRIVATE_KEY_FILE", "KALSHI_PRIVATE_KEY_COMMAND"):
        monkeypatch.delenv(v, raising=False)
    return k


def pem() -> bytes:
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    return key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL,
                             serialization.NoEncryption())


KEY_ID = "a1b2c3d4-e5f6-4711-8899-aabbccddeeff"


def test_key_is_encrypted_on_disk_and_locked_by_the_os_store(tmp_path, kr):
    p = pem()
    st = vault.save(tmp_path, "live", KEY_ID, p)
    assert st == {"stored": True, "key_tail": "eeff", "saved_at": st["saved_at"]}
    raw = (tmp_path / "vault" / "kalshi-live.vault").read_bytes()
    assert b"PRIVATE KEY" not in raw and KEY_ID.encode() not in raw and p[40:80] not in raw   # nothing readable
    assert len(kr.items) == 1                                                                 # the unlock key is in the OS store
    assert vault.load(tmp_path, "live") == (KEY_ID, p.strip() + b"\n")
    # the file alone is useless: without the OS-store entry it can't be opened
    kr.items.clear()
    with pytest.raises(vault.VaultError, match="connect your Kalshi key again"):
        vault.load(tmp_path, "live")


def test_tampered_vault_is_refused(tmp_path, kr):
    vault.save(tmp_path, "live", KEY_ID, pem())
    f = tmp_path / "vault" / "kalshi-live.vault"
    rec = json.loads(f.read_text())
    rec["ct"] = rec["ct"][:-8] + ("A" * 8 if rec["ct"][-8:] != "A" * 8 else "B" * 8)
    f.write_text(json.dumps(rec))
    with pytest.raises(vault.VaultError):
        vault.load(tmp_path, "live")


def test_bad_inputs_are_refused_before_anything_is_saved(tmp_path, kr):
    with pytest.raises(vault.VaultError, match="valid private key"):
        vault.save(tmp_path, "live", KEY_ID, b"not a key")
    with pytest.raises(vault.VaultError, match="Key ID"):
        vault.save(tmp_path, "live", "x", pem())
    assert not kr.items and not (tmp_path / "vault").exists()


def test_bot_uses_the_app_key_unless_dot_env_names_a_key_file(tmp_path, kr, monkeypatch):
    with pytest.raises(CredentialError, match="connect it in the app"):
        load_credentials("live", str(tmp_path), tmp_path)
    vault.save(tmp_path, "live", KEY_ID, pem())
    assert load_credentials("live", str(tmp_path), tmp_path).key_id == KEY_ID
    keyfile = tmp_path / "k.pem"
    keyfile.write_bytes(pem())
    monkeypatch.setenv("KALSHI_API_KEY_ID", "envkey-1234")
    monkeypatch.setenv("KALSHI_PRIVATE_KEY_FILE", str(keyfile))
    assert load_credentials("live", str(tmp_path), tmp_path).key_id == "envkey-1234"       # .env always wins
    vault.remove(tmp_path, "live")
    assert not kr.items and vault.status(tmp_path, "live") == {"stored": False}


def test_switch_to_live_writes_limits_ack_and_mode(tmp_path, kr):
    cfgf = tmp_path / "config.yaml"
    cfgf.write_text("mode: paper\ndata_dir: data\n")
    from favbot.config import load_config
    cfg = load_config(cfgf)
    lim = account.live_limits(D("25"), 1)
    assert lim.capital_cap_usd == D("25") and lim.max_loss_per_position_usd == D("1") and lim.max_open_positions == 1
    creds = SimpleNamespace(key_fingerprint=lambda: "fp123")
    account.switch_to_live(cfg, lim, creds)
    new = load_config(cfgf)
    assert new.mode == "live" and new.live_limits == lim
    assert check_ack(new.data_path("live"), lim, "fp123")[0]


# ---- the app's endpoints -------------------------------------------------------------------------
class _Store:
    def __init__(self):
        self.events = []

    def log_event(self, level, kind, msg, *a):
        self.events.append(msg)


class _Req:
    headers = {"X-Token": "t"}

    def __init__(self, body):
        self.body = body

    async def json(self):
        return self.body


def _dash(tmp_path, mode="paper"):
    cfgf = tmp_path / "config.yaml"
    cfgf.write_text(f"mode: {mode}\ndata_dir: {tmp_path / 'data'}\n")
    from favbot.config import load_config
    cfg = load_config(cfgf)
    data = cfg.data_path(mode)
    data.mkdir(parents=True)
    bot = SimpleNamespace(mode=mode, cfg=cfg, store=_Store(), data_dir=data, stop=__import__("asyncio").Event())
    d = dashboard.Dashboard(bot, 0)
    d.token = "t"
    return d, bot


async def test_connect_checks_the_key_with_kalshi_then_saves_it(tmp_path, kr, monkeypatch):
    d, bot = _dash(tmp_path)
    seen = {}

    async def fake_balances(creds, series):
        seen["key_id"] = creds.key_id
        return {"crypto_shard": 2, "by_shard": {"2": "0", "3": "40"}, "crypto": "0", "other": "40", "move_from": 3}
    monkeypatch.setattr(account, "balances", fake_balances)
    p = pem().decode()
    r = json.loads((await d.kalshi_connect(_Req({"key_id": KEY_ID, "pem": p}))).body)
    assert r["ok"] and r["key_tail"] == "eeff" and seen["key_id"] == KEY_ID and r["balances"]["other"] == "40"
    assert not any(p[30:60] in e for e in bot.store.events)                   # the key never reaches the log
    assert dashboard._kalshi_state(bot)["source"] == "vault"
    with pytest.raises(web.HTTPBadRequest):
        await d.kalshi_connect(_Req({"key_id": KEY_ID, "pem": "garbage"}))


async def test_key_changes_are_refused_while_real_money_runs(tmp_path, kr):
    d, _ = _dash(tmp_path, mode="live")
    with pytest.raises(web.HTTPConflict):
        await d.kalshi_connect(_Req({"key_id": KEY_ID, "pem": pem().decode()}))
    with pytest.raises(web.HTTPConflict):
        await d.kalshi_remove(_Req({}))


async def test_go_live_needs_the_exact_phrase_then_reopens_live(tmp_path, kr, monkeypatch):
    d, bot = _dash(tmp_path)
    vault.save(tmp_path / "data", "live", KEY_ID, pem())

    async def fake_balances(creds, series):
        return {"crypto_shard": 2, "by_shard": {"2": "30"}, "crypto": "30", "other": "0", "move_from": None}
    monkeypatch.setattr(account, "balances", fake_balances)
    calls = []
    monkeypatch.setattr(account, "switch_to_live", lambda cfg, lim, creds: calls.append(("live", lim)))
    monkeypatch.setattr(account, "relaunch", lambda root, delay=10: calls.append(("relaunch",)))
    plan = json.loads((await d.go_live(_Req({"cap": "20", "level": 2}))).body)
    lim = account.live_limits(D("20.00"), 2)                                  # the app works in cents
    assert plan["phrase"] == ack_phrase(lim) and plan["limits"]["capital_cap_usd"] == "20.00" and not calls
    with pytest.raises(web.HTTPBadRequest, match=""):
        await d.go_live(_Req({"cap": "20", "level": 2, "phrase": "i accept"}))            # wrong phrase: nothing happens
    assert not calls
    r = json.loads((await d.go_live(_Req({"cap": "20", "level": 2, "phrase": plan["phrase"]}))).body)
    assert r["ok"] and calls == [("live", lim), ("relaunch",)] and (bot.data_dir / "STOPPED").exists()


async def test_go_live_needs_money_in_the_crypto_section(tmp_path, kr, monkeypatch):
    d, _ = _dash(tmp_path)
    vault.save(tmp_path / "data", "live", KEY_ID, pem())

    async def broke(creds, series):
        return {"crypto_shard": 2, "by_shard": {"2": "0", "3": "50"}, "crypto": "0", "other": "50", "move_from": 3}
    monkeypatch.setattr(account, "balances", broke)
    with pytest.raises(web.HTTPConflict, match=""):
        await d.go_live(_Req({"cap": "20", "level": 1}))


async def test_moving_money_needs_the_exact_phrase(tmp_path, kr, monkeypatch):
    d, _ = _dash(tmp_path)
    vault.save(tmp_path / "data", "live", KEY_ID, pem())

    async def bal(creds, series):
        return {"crypto_shard": 2, "by_shard": {"2": "0", "3": "50"}, "crypto": "0", "other": "50", "move_from": 3}
    moved = []

    async def fake_move(creds, amount, src, shard):
        moved.append((amount, src, shard))
        return {"transfer_id": "t1"}
    monkeypatch.setattr(account, "balances", bal)
    monkeypatch.setattr(account, "move", fake_move)
    plan = json.loads((await d.kalshi_move(_Req({"amount": "25"}))).body)
    assert plan["phrase"] == "MOVE 25.00 TO SHARD 2" and not moved
    with pytest.raises(web.HTTPBadRequest):
        await d.kalshi_move(_Req({"amount": "25", "phrase": "move it"}))
    with pytest.raises(web.HTTPBadRequest):
        await d.kalshi_move(_Req({"amount": "80"}))                                  # more than is there
    await d.kalshi_move(_Req({"amount": "25", "phrase": "MOVE 25.00 TO SHARD 2"}))
    assert moved == [(D("25.00"), 3, 2)]


def test_real_keyring_backend_is_available_on_this_computer():
    import keyring
    from keyring.backends.fail import Keyring as Fail
    assert not isinstance(keyring.get_keyring(), Fail)
    assert Limits  # (imported for the go-live helpers)
