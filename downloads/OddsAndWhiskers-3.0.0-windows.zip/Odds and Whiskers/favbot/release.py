"""Sharing Odds & Whiskers (formerly Better Bot): signed releases, one-click updates and fresh downloads.

Publisher (the PC that owns the signing key): `favbot release publish` packs the CODE ONLY into
BetterBot-<version>.zip (the update feed; the name stays so older copies keep finding it), signs its list of
files with a private key that never leaves this PC (%APPDATA%\\BetterBot\\release_signing.pem), and puts it in
the shared updates folder, together with fresh-download starter packages for Windows and macOS
(OddsAndWhiskers-<version>-windows.zip / -macos.zip). Starter packages need Python 3.11+; they are not
self-contained apps.

Friend: the app looks in the updates folder every few minutes. An update is offered only if it is newer than
what's installed AND its signature matches the public key that came with the friend's copy
(favbot/release_pubkey.txt), so nobody else with access to the folder can slip code into his bot.
Install: every file is checked against its fingerprint, a restore point is saved first, and only code files are
replaced. Never touched, never shipped: config.yaml, .env, keys/, data/, .venv/, versions/, personal .bat files.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VERSION_FILE = ROOT / "favbot" / "VERSION"
PUBKEY_FILE = ROOT / "favbot" / "release_pubkey.txt"
KEY_DIR = Path(os.environ.get("APPDATA") or Path.home()) / "BetterBot"
SIGNING_KEY = KEY_DIR / "release_signing.pem"
APP_NAME = "Odds & Whiskers"
APP_IDS = ("Better Bot", "Odds & Whiskers")      # manifests say "Better Bot" so copies from before the rename accept them
FOLDER_NAMES = ("Better Bot updates", "Odds and Whiskers updates")
FOLDER_NAME = FOLDER_NAMES[0]
PREFIX = "Better Bot/"                    # inside the update zip (older copies read files from this folder name)
PACKAGE_DIR = "Odds and Whiskers/"        # the folder a fresh download unzips to (no "&": it breaks Windows scripts)
CODE_DIRS = ("favbot", "app", "tests")
COMMON_TOP = ("README.md", "requirements.txt", "pytest.ini", "config.example.yaml", ".env.example")
WINDOWS_TOP = ("Install Odds and Whiskers.bat", "Set up my Kalshi key.bat", "Go live.bat", "Confirm new limits.bat",
               "Move money to crypto.bat", "Live report.bat", "Report.bat", "Start paper bot.bat")
MAC_TOP = ("Install Odds and Whiskers.command", "Open Odds and Whiskers.command", "Set up my Kalshi key.command",
           "Go live.command", "Move money to crypto.command", "Confirm new limits.command")
TOP_FILES = COMMON_TOP + WINDOWS_TOP + MAC_TOP
WINDOWS_ONLY = (".bat", ".ps1", ".ico", "python_windows.txt")
MAC_ONLY = (".command", ".sh")
SKIP_PARTS = {"__pycache__", ".pytest_cache"}
KEEP_ZIPS = 3
_NAME = re.compile(r"^BetterBot-(\d+)\.(\d+)\.(\d+)\.zip$")
_PKG = re.compile(r"^OddsAndWhiskers-(\d+)\.(\d+)\.(\d+)-(windows|macos)\.zip$")
_PEM = re.compile(rb"-----BEGIN [A-Z ]*PRIVATE KEY-----\r?\n[A-Za-z0-9+/=\r\n]{64,}")


class ReleaseError(Exception):
    pass


# ---- versions ------------------------------------------------------------------------------
def parse_version(v: str) -> tuple[int, int, int]:
    m = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)", (v or "").strip())
    if not m:
        raise ReleaseError(f"bad version {v!r} (use e.g. 1.8.0)")
    return tuple(int(x) for x in m.groups())


def installed_version(root: Path = ROOT) -> str:
    f = root / "favbot" / "VERSION"
    return f.read_text(encoding="utf-8").strip() if f.exists() else "0.0.0"


# ---- which files are the app ---------------------------------------------------------------
def release_files(root: Path = ROOT) -> list[str]:
    out = []
    for d in CODE_DIRS:
        for f in sorted((root / d).rglob("*")):
            if f.is_file() and not SKIP_PARTS & set(f.parts) and f.suffix != ".pyc":
                out.append(f.relative_to(root).as_posix())
    out += [n for n in TOP_FILES if (root / n).is_file()]
    return out


def allowed(rel: str) -> bool:
    """Only code files may ever be written by an update — never settings, keys or data."""
    if rel.startswith("/") or ":" in rel or "\\" in rel or ".." in rel.split("/"):
        return False
    return rel in TOP_FILES or rel.split("/", 1)[0] in CODE_DIRS


def _secret_scan(root: Path, files: list[str]) -> None:
    """Refuse to publish anything that looks like a key, or contains this PC's Kalshi key id."""
    ids = [v for k, v in os.environ.items() if k.endswith("API_KEY_ID") and len(v.strip()) >= 8]
    for rel in files:
        data = (root / rel).read_bytes()
        if _PEM.search(data):
            raise ReleaseError(f"{rel} looks like it contains a private key; not publishing")
        for i in ids:
            if i.strip().encode() in data:
                raise ReleaseError(f"{rel} contains your Kalshi key id; not publishing")


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# ---- signing (publisher only) ----------------------------------------------------------------
def init_signing(key_path: Path = SIGNING_KEY, pub_path: Path = PUBKEY_FILE) -> str:
    """Create this PC's signing key once (kept outside the app folder) and write its public half into the code."""
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    if key_path.exists():
        key = serialization.load_pem_private_key(key_path.read_bytes(), password=None)
    else:
        key = Ed25519PrivateKey.generate()
        key_path.parent.mkdir(parents=True, exist_ok=True)
        key_path.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                               serialization.NoEncryption()))
    pub = key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()
    pub_path.write_text(pub + "\n", encoding="utf-8")
    return pub


def is_publisher(key_path: Path = SIGNING_KEY) -> bool:
    return key_path.exists()


def _onedrive_roots() -> list[Path]:
    """OneDrive on Windows (environment variables) and on macOS (~/Library/CloudStorage, ~/OneDrive)."""
    roots = [Path(os.environ[k]) for k in ("OneDriveConsumer", "OneDrive", "OneDriveCommercial") if os.environ.get(k)]
    cloud = Path.home() / "Library" / "CloudStorage"
    if cloud.is_dir():
        try:
            roots += sorted(p for p in cloud.iterdir() if p.name.startswith("OneDrive"))
        except OSError:
            pass
    roots.append(Path.home() / "OneDrive")
    return [r for r in dict.fromkeys(roots) if r.is_dir()]


def default_folder() -> Path:
    """Where this PC publishes: the existing shared folder (any of its names), else a new one in OneDrive."""
    roots = _onedrive_roots() or [Path.home() / "Documents"]
    for r in roots:
        for n in FOLDER_NAMES:
            if (r / n).is_dir():
                return r / n
    return roots[0] / FOLDER_NAMES[0]


def published_versions(folder: Path) -> list[tuple[int, int, int]]:
    if not folder.exists():
        return []
    return sorted(tuple(int(x) for x in m.groups()) for f in folder.iterdir() if (m := _NAME.match(f.name)))


def changelog(root: Path = ROOT) -> list[dict]:
    f = root / "favbot" / "CHANGELOG.json"
    try:
        return json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def notes_for(version: str, root: Path = ROOT) -> str:
    e = next((c for c in changelog(root) if c.get("version") == version), None)
    if not e:
        return ""
    return (e.get("title", "") + ": " if e.get("title") else "") + " ".join(e.get("added", [])[:3])


def publish(folder: Path, notes: str = "", version: str | None = None, root: Path = ROOT,
            key_path: Path = SIGNING_KEY, packages: bool = True) -> dict:
    from cryptography.hazmat.primitives import serialization
    from .webcheck import check_web
    broken = check_web(root / "favbot" / "web")
    if broken:                                   # a broken page script can leave the app window blank
        raise ReleaseError("a page script looks broken, not publishing: " +
                           "; ".join(f"{name} {p[0]}" for name, p in broken.items()))
    if not key_path.exists():
        raise ReleaseError("this PC has no signing key yet: run `favbot release init` first")
    key = serialization.load_pem_private_key(key_path.read_bytes(), password=None)
    pub = key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()
    shipped = (root / "favbot" / "release_pubkey.txt")
    if not shipped.exists() or shipped.read_text(encoding="utf-8").strip() != pub:
        raise ReleaseError("favbot/release_pubkey.txt doesn't match this PC's signing key: run `favbot release init`")
    pubs = published_versions(folder)
    if version is None:                         # next patch number, unless the code already says something newer
        here = parse_version(installed_version(root))
        version = installed_version(root) if not pubs or here > pubs[-1] else f"{pubs[-1][0]}.{pubs[-1][1]}.{pubs[-1][2] + 1}"
    if pubs and parse_version(version) <= pubs[-1]:
        raise ReleaseError(f"version {version} is not newer than the last published one")
    (root / "favbot" / "VERSION").write_text(version + "\n", encoding="utf-8")
    notes = notes.strip() or notes_for(version, root)
    files = release_files(root)
    _secret_scan(root, files)
    blobs = {rel: (root / rel).read_bytes() for rel in files}
    manifest = {"app": APP_IDS[0], "name": APP_NAME, "version": version, "published_at": time.time(),
                "notes": notes, "files": {rel: _sha(b) for rel, b in blobs.items()}}
    mbytes = json.dumps(manifest, indent=1, sort_keys=True).encode()
    sig = key.sign(mbytes).hex()
    folder.mkdir(parents=True, exist_ok=True)
    name = f"BetterBot-{version}.zip"
    tmp = folder / (name + ".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("release.json", mbytes)
        z.writestr("release.sig", sig)
        for rel, b in blobs.items():
            _write_member(z, PREFIX + rel, b)
    os.replace(tmp, folder / name)
    pk = build_packages(folder, version, blobs) if packages else {}
    share = refresh_share_files(pk, root)
    (folder / "READ ME FIRST.txt").write_text(FRIEND_README, encoding="utf-8")
    for old in published_versions(folder)[:-KEEP_ZIPS]:                    # keep the folder small
        (folder / f"BetterBot-{old[0]}.{old[1]}.{old[2]}.zip").unlink(missing_ok=True)
    for f in folder.iterdir():                                             # only the newest fresh downloads
        m = _PKG.match(f.name)
        if m and tuple(int(x) for x in m.groups()[:3]) != parse_version(version):
            f.unlink()
    return {"version": version, "path": str(folder / name), "files": len(files), "packages": pk, "share": share}


# The share files in the app folder: hand one to a friend and they get the newest version. Rewritten by every publish.
SHARE_FILES = {"windows": "BetterBot-share.zip", "macos": "BetterBot-share-mac.zip"}


def refresh_share_files(packages: dict, root: Path = ROOT) -> dict:
    """Copy this version's fresh downloads over the share files, so they're never out of date."""
    out = {}
    for plat, src in packages.items():
        if plat in SHARE_FILES and Path(src).is_file():
            dest = root / SHARE_FILES[plat]
            tmp = dest.with_name(dest.name + ".tmp")
            shutil.copyfile(src, tmp)
            os.replace(tmp, dest)
            out[plat] = str(dest)
    return out


def _write_member(z: zipfile.ZipFile, name: str, data: bytes) -> None:
    """Mac helpers must stay double-clickable after unzipping, so they keep their 'executable' mark."""
    info = zipfile.ZipInfo(name, date_time=time.localtime()[:6])
    info.compress_type = zipfile.ZIP_DEFLATED
    info.create_system = 3                                             # unix, so the permissions are honoured
    runnable = name.endswith(MAC_ONLY) or "/Contents/MacOS/" in name
    info.external_attr = ((0o100755 if runnable else 0o100644) & 0xFFFF) << 16
    z.writestr(info, data)


def platform_files(rels, platform: str) -> list[str]:
    skip = MAC_ONLY if platform == "windows" else WINDOWS_ONLY
    return [r for r in rels if not r.endswith(skip)]


SETUP_APP = "Odds & Whiskers Setup.app/"


def icns_from_ico(ico: bytes) -> bytes | None:
    """A Mac icon (.icns) from the PNG images inside the Windows icon (.ico)."""
    import struct
    if len(ico) < 6:
        return None
    n = struct.unpack("<HHH", ico[:6])[2]
    pngs = {}
    for i in range(n):
        w, _h, _c, _r, _p, _b, size, off = struct.unpack("<BBBBHHII", ico[6 + i * 16: 22 + i * 16])
        data = ico[off:off + size]
        if data[:4] == b"\x89PNG":
            pngs[w or 256] = data
    types = {256: b"ic08", 128: b"ic07", 64: b"icp6", 32: b"icp5", 16: b"icp4"}
    chunks = b"".join(t + struct.pack(">I", len(pngs[px]) + 8) + pngs[px] for px, t in types.items() if px in pngs)
    return b"icns" + struct.pack(">I", len(chunks) + 8) + chunks if chunks else None


def setup_app_files(version: str, blobs: dict[str, bytes]) -> dict[str, bytes]:
    """The macOS 'Odds & Whiskers Setup.app': a double-clickable installer (no Terminal) carrying the app inside."""
    plist = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>setup</string>
<key>CFBundleIdentifier</key><string>io.github.pemdem.oddsandwhiskers.setup</string>
<key>CFBundleName</key><string>Odds &amp; Whiskers Setup</string>
<key>CFBundleDisplayName</key><string>Odds &amp; Whiskers Setup</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>{version}</string>
<key>CFBundleVersion</key><string>{version}</string>
<key>CFBundleIconFile</key><string>AppIcon</string>
<key>LSMinimumSystemVersion</key><string>11.0</string>
<key>NSHighResolutionCapable</key><true/>
</dict></plist>
""".encode()
    files = {SETUP_APP + "Contents/Info.plist": plist,
             SETUP_APP + "Contents/MacOS/setup": blobs["app/setup_mac.sh"]}
    icns = icns_from_ico(blobs.get("app/BetterBot.ico", b""))
    if icns:
        files[SETUP_APP + "Contents/Resources/AppIcon.icns"] = icns
    for rel in platform_files(blobs, "macos"):
        files[SETUP_APP + "Contents/Resources/app/" + rel] = blobs[rel]
    return files


def build_packages(out: Path, version: str, blobs: dict[str, bytes]) -> dict:
    """Fresh downloads. Windows: the app's code, example settings and an installer (.bat). macOS: one
    'Odds & Whiskers Setup' app that installs everything with clicks only. Neither ever contains anyone's
    settings, keys or history. Not code-signed, so Windows / macOS asks once before the first run."""
    made = {}
    for plat in ("windows", "macos"):
        name = f"OddsAndWhiskers-{version}-{plat}.zip"
        tmp = out / (name + ".tmp")
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
            if plat == "windows" or "app/setup_mac.sh" not in blobs:
                for rel in platform_files(blobs, plat):
                    _write_member(z, PACKAGE_DIR + rel, blobs[rel])
            else:
                for rel, data in setup_app_files(version, blobs).items():
                    _write_member(z, PACKAGE_DIR + rel, data)
            _write_member(z, PACKAGE_DIR + "START HERE.txt",
                          (START_WINDOWS if plat == "windows" else START_MAC).encode("utf-8"))
        os.replace(tmp, out / name)
        made[plat] = str(out / name)
    return made


START_WINDOWS = """Odds & Whiskers for Windows

1. Right-click the downloaded zip > Extract All... > Extract.
2. In the folder that opens, double-click  Install Odds and Whiskers
   If Windows says "Windows protected your PC": click More info, then Run anyway. (It isn't signed with a paid
   certificate; you only see this once.)
3. Wait 2 to 3 minutes. It installs everything by itself - no Python download, no settings to change - then
   opens Odds & Whiskers. If this PC has no Python, it fetches its own copy and checks its fingerprint first.
4. A short welcome walks you through the rest: practice mode (fake money, real prices), connecting your
   Kalshi account (your key is stored encrypted on this PC, locked by Windows Credential Manager) and, only if
   you want, real money.

It lives in your user folder (AppData\\Local\\Odds and Whiskers), so you can delete the download afterwards.
Open it any time from the Desktop or Start menu icon. It keeps running in the background while the PC is on.
Updates arrive in the app by themselves. Your settings, key, limits, layouts and history are never replaced.
To repair it, just run Install Odds and Whiskers again.
"""

START_MAC = """Odds & Whiskers for macOS

1. Double-click  Odds & Whiskers Setup
   macOS will probably say Apple can't check it for malicious software - it isn't signed with a paid Apple
   certificate. Click Done, open System Settings > Privacy & Security, scroll down, click Open Anyway next to
   "Odds & Whiskers Setup" and confirm with your password. You only do this once.
2. Click Install. Setup downloads its own Python and installs everything by itself (2 to 3 minutes, no Terminal).
3. Odds & Whiskers opens and appears on your Desktop and in Applications. It starts in PRACTICE mode
   (fake money, real prices). A short welcome guides you through connecting your Kalshi account - your key is
   stored encrypted on this Mac and locked by your Mac's Keychain - and, if you want, real money.

Keep the Mac awake and plugged in while it trades; the bot can't bet while the Mac sleeps.
Updates arrive in the app by themselves. Your settings, key, limits, layouts and history are never replaced.
To update or repair later, just open Odds & Whiskers Setup again.
"""

FRIEND_README = """Odds & Whiskers (formerly Better Bot)

First time? Download the starter package for your computer from this folder:
  - OddsAndWhiskers-<version>-windows.zip   for Windows
  - OddsAndWhiskers-<version>-macos.zip     for Mac
Unzip it and follow START HERE.txt inside. Nothing else to install first: both bring their own Python if needed.

Already installed? Keep this folder in your OneDrive. When a new version is here, the app shows
"Update available" - click Install. Your settings, key, limits, layouts and history are never replaced.
(The BetterBot-<version>.zip files are the signed updates the app installs by itself; you don't need to open them.)
"""


# ---- checking and installing (friends) -------------------------------------------------------
def _trusted_pub(root: Path) -> str | None:
    f = root / "favbot" / "release_pubkey.txt"
    return f.read_text(encoding="utf-8").strip() if f.exists() else None


def read_release(zip_path: Path, root: Path = ROOT) -> dict:
    """The release's manifest, if its signature is from the key this copy trusts. Raises ReleaseError otherwise."""
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    pub = _trusted_pub(root)
    if not pub:
        raise ReleaseError("this copy has no trusted update key")
    try:
        with zipfile.ZipFile(zip_path) as z:
            mbytes, sig = z.read("release.json"), z.read("release.sig").decode().strip()
    except (OSError, KeyError, zipfile.BadZipFile) as e:
        raise ReleaseError(f"not an Odds & Whiskers update: {e}") from e
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(pub)).verify(bytes.fromhex(sig), mbytes)
    except (InvalidSignature, ValueError) as e:
        raise ReleaseError("signature doesn't match — not from the person who shared the app; ignored") from e
    m = json.loads(mbytes)
    if m.get("app") not in APP_IDS:
        raise ReleaseError("not an Odds & Whiskers update")
    parse_version(m.get("version", ""))
    return m


FEED_MAX_BYTES = 50 * 1024 * 1024


def feed_url(root: Path = ROOT) -> str | None:
    """The website's update feed (favbot/update_feed.txt, shipped with the code). HTTPS only."""
    f = root / "favbot" / "update_feed.txt"
    try:
        url = f.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    return url.rstrip("/") + "/" if url.startswith("https://") else None


def fetch_feed(root: Path = ROOT, timeout: float = 15.0, opener=None) -> dict:
    """Mirror the newest update from the website into data/web_updates/, where check() finds it like any other
    update folder. The website is only a delivery route: the zip must still carry the publisher's signature,
    so a changed website can't push anyone else's code. Nothing is installed here."""
    import urllib.request
    url = feed_url(root)
    if not url:
        return {"ok": False, "reason": "no website feed in this version"}
    get = opener or (lambda u: urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "OddsAndWhiskers"}),
                                                      timeout=timeout).read(FEED_MAX_BYTES + 1))
    latest = json.loads(get(url + "latest.json"))
    version = str(latest.get("version", ""))
    if parse_version(version) <= parse_version(installed_version(root)):
        return {"ok": True, "newer": False, "version": version}
    name = f"BetterBot-{version}.zip"
    dest = root / "data" / "web_updates"
    dest.mkdir(parents=True, exist_ok=True)
    if (dest / name).exists():
        return {"ok": True, "newer": True, "version": version, "path": str(dest / name)}
    data = get(url + name)
    if len(data) > FEED_MAX_BYTES:
        raise ReleaseError("update file from the website is too large; ignored")
    tmp = dest / (name + ".download")
    tmp.write_bytes(data)
    try:
        read_release(tmp, root)                  # signature check before it's kept
    except ReleaseError:
        tmp.unlink(missing_ok=True)
        raise
    os.replace(tmp, dest / name)
    for f in dest.iterdir():                     # keep only the newest download
        if f.name != name and _NAME.match(f.name):
            f.unlink(missing_ok=True)
    return {"ok": True, "newer": True, "version": version, "path": str(dest / name)}


def update_folders(root: Path = ROOT) -> list[Path]:
    """Where updates may be: a folder named in data/update_folder.txt, the shared OneDrive folder (either name,
    at the top of OneDrive or one level down), updates/ inside the app folder, or data/web_updates/ (what
    fetch_feed brought down from the website)."""
    cands = [root / "data" / "web_updates"]
    f = root / "data" / "update_folder.txt"
    if f.exists():
        cands.append(Path(f.read_text(encoding="utf-8").strip()))
    for od in _onedrive_roots():
        cands += [od / n for n in FOLDER_NAMES]
        try:
            cands += [p / n for p in od.iterdir() if p.is_dir() and p.name not in FOLDER_NAMES for n in FOLDER_NAMES]
        except OSError:
            pass
    cands.append(root / "updates")
    out, seen = [], set()
    for c in cands:
        if c.is_dir() and str(c).lower() not in seen:
            seen.add(str(c).lower())
            out.append(c)
    return out


def check(root: Path = ROOT) -> dict:
    cur = parse_version(installed_version(root))
    best, rejected = None, []
    for folder in update_folders(root):
        for f in folder.iterdir():
            m = _NAME.match(f.name)
            if not m or tuple(int(x) for x in m.groups()) <= cur:
                continue
            try:
                man = read_release(f, root)
            except ReleaseError as e:
                rejected.append(f"{f.name}: {e}")
                continue
            if parse_version(man["version"]) > cur and (best is None or parse_version(man["version"]) > parse_version(best["version"])):
                best = {"version": man["version"], "notes": man.get("notes", ""), "published_at": man.get("published_at"),
                        "path": str(f), "files": len(man["files"])}
    return {"installed": installed_version(root), "available": best, "rejected": rejected,
            "folders": [str(f) for f in update_folders(root)]}


def this_platform() -> str:
    return "windows" if sys.platform == "win32" else "macos"


def install(zip_path: Path, root: Path = ROOT, save_point: bool = True, run_pip: bool = True,
            platform: str | None = None) -> dict:
    man = read_release(zip_path, root)
    if parse_version(man["version"]) <= parse_version(installed_version(root)):
        raise ReleaseError(f"{man['version']} is not newer than the installed {installed_version(root)}")
    plat = platform or this_platform()
    files = {rel: h for rel, h in man["files"].items() if allowed(rel) and rel in platform_files([rel], plat)}
    if not any(r.startswith("favbot/") for r in files):
        raise ReleaseError("update has no bot code")
    blobs = {}
    with zipfile.ZipFile(zip_path) as z:
        for rel, h in files.items():
            b = z.read(PREFIX + rel)
            if _sha(b) != h:
                raise ReleaseError(f"{rel} was changed after it was signed; nothing installed")
            blobs[rel] = b
    point = None
    if save_point:
        from . import versions
        point = versions.save(f"before update to {man['version']}")["number"]
    req_before = _sha((root / "requirements.txt").read_bytes()) if (root / "requirements.txt").exists() else ""
    for rel, b in blobs.items():
        dest = root / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_name(dest.name + ".new")
        tmp.write_bytes(b)
        os.replace(tmp, dest)
        if rel.endswith(MAC_ONLY) and os.name != "nt":
            dest.chmod(0o755)
    removed = 0
    for d in CODE_DIRS:                          # code files the new version no longer has
        for f in list((root / d).rglob("*")):
            rel = f.relative_to(root).as_posix()
            if f.is_file() and not SKIP_PARTS & set(f.parts) and f.suffix != ".pyc" and rel not in blobs:
                f.unlink()
                removed += 1
    pip = False
    if run_pip and req_before != _sha(blobs.get("requirements.txt", b"")) and "requirements.txt" in blobs:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-r", str(root / "requirements.txt")],
                       cwd=str(root), check=True, creationflags=0x08000000 if sys.platform == "win32" else 0)
        pip = True
    return {"version": man["version"], "files": len(blobs), "removed": removed, "restore_point": point, "pip": pip}


# ---- updating while the bot trades -----------------------------------------------------------
def _snapshot_db(db: Path, out_path: Path) -> None:
    """A consistent copy of a SQLite file, even while the bot or the Litter Box is writing to it."""
    import sqlite3
    out_path.parent.mkdir(parents=True, exist_ok=True)
    src = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    out = sqlite3.connect(out_path)
    try:
        src.backup(out)
    finally:
        out.close()
        src.close()


def backup_data(data_dir: Path, config_path: Path | None, label: str, keep: int = 5) -> Path:
    """Copy this person's data before an update: trade history (a consistent SQLite snapshot), settings,
    every Litter Box model's fake-money history, the learning loop's files and the encrypted key vault.
    The backup stays on this computer, in data/backups/. Logs aren't copied (they're only diagnostics)."""
    dest = data_dir.parent / "backups" / f"{time.strftime('%Y%m%d-%H%M%S')}-{re.sub(r'[^A-Za-z0-9.]+', '-', label)}"
    dest.mkdir(parents=True, exist_ok=True)
    db = data_dir / "favbot.sqlite3"
    if db.exists():
        _snapshot_db(db, dest / "favbot.sqlite3")
    for f in (config_path, data_dir / "live_ack.json"):
        if f and Path(f).is_file():
            shutil.copy2(f, dest / Path(f).name)
    lb = data_dir.parent / "litterbox"
    if lb.is_dir():
        for d in [lb] + sorted(p for p in lb.iterdir() if p.is_dir() and not p.name.startswith("_")):
            to = dest / "litterbox" / d.relative_to(lb)
            for f in d.iterdir():
                if not f.is_file():
                    continue
                try:
                    if f.name == "favbot.sqlite3":
                        _snapshot_db(f, to / f.name)
                    elif f.suffix in (".json", ".txt") or f.name == "ENABLED":
                        to.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(f, to / f.name)
                except Exception:               # one busy file mustn't stop the update's backup
                    pass
    for sub in ("lab", "vault"):                 # learning-loop files; the vault stays encrypted
        src = data_dir.parent / sub
        if src.is_dir():
            shutil.copytree(src, dest / sub, dirs_exist_ok=True)
    ws = data_dir.parent / "polymarket_us"       # the Polymarket US practice workspace: its own history and Litter Box
    if ws.is_dir():
        for f in ws.rglob("*"):
            if not f.is_file() or "_old" in f.parts:
                continue
            to = dest / "polymarket_us" / f.relative_to(ws)
            try:
                if f.name == "favbot.sqlite3":
                    _snapshot_db(f, to)
                elif f.suffix in (".json", ".txt") or f.name == "ENABLED":
                    to.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(f, to)
            except Exception:  # noqa: BLE001 - one busy file mustn't stop the update's backup
                pass
    olds = sorted(p for p in dest.parent.iterdir() if p.is_dir())
    for p in olds[:-keep]:
        shutil.rmtree(p, ignore_errors=True)
    return dest


def migrate_shortcut(root: Path = ROOT) -> bool:
    """Windows: rename a Desktop 'Better Bot' shortcut that opens THIS copy to 'Odds & Whiskers'."""
    if sys.platform != "win32":
        return False
    ps = ("$d=[Environment]::GetFolderPath('Desktop'); $o=Join-Path $d 'Better Bot.lnk'; "
          "if (Test-Path -LiteralPath $o) { $s=(New-Object -ComObject WScript.Shell).CreateShortcut($o); "
          f"if ($s.Arguments -like '*{str(root)}*') {{ Rename-Item -LiteralPath $o -NewName 'Odds & Whiskers.lnk'; 'renamed' }} }}")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=30,
                           creationflags=0x08000000)
        return "renamed" in r.stdout
    except (OSError, subprocess.SubprocessError):
        return False
