from favbot.alerts import Alerts
from favbot.config import AlertsCfg


def make(prefs, result_coins=()):
    sent = []
    cfg = AlertsCfg(enabled=True, smtp_host="smtp.example.com", recipients=["me@example.com"],
                    result_coins=list(result_coins))
    a = Alerts(cfg, "live", sender_fn=lambda s, b: sent.append((s, b)), prefs_fn=lambda: prefs)
    a.send = lambda subject, body: sent.append((subject, body))   # synchronous for the test
    return a, sent


def test_losses_on_wins_off_by_default():
    a, sent = make({})
    a.result("ETH", "T", True, "+0.28", "won")
    a.result("ETH", "T", False, "-3.72", "lost")
    assert [s for s, _ in sent] == ["LOST ETH -3.72"]


def test_wins_when_chosen_and_forced_coins():
    a, sent = make({"wins": True, "losses": False})
    a.result("SOL", "T", True, "+0.30", "won")
    a.result("SOL", "T", False, "-3.70", "lost")
    assert [s for s, _ in sent] == ["Won SOL +0.30"]
    a, sent = make({"wins": False, "losses": False}, result_coins=["XRP"])
    a.result("XRP", "T", True, "+0.30", "won")
    assert len(sent) == 1


def test_problems_toggle_silences_problem_emails():
    a, sent = make({"problems": False})
    a.kill("x"); a.daily_loss("-4", "-4.4"); a.shutdown("bye"); a.error("k", "m")
    assert sent == []
    a, sent = make({})
    a.kill("x")
    assert sent and "Kill switch" in sent[0][0]


def test_label_on_every_subject():
    sent = []
    cfg = AlertsCfg(enabled=True, smtp_host="h", recipients=["r@x"])
    a = Alerts(cfg, "live", sender_fn=lambda s, b: sent.append(s))
    a.send_now("Test", "body")
    assert sent == ["[Odds & Whiskers REAL-MONEY] Test"]
