"""Local dashboard on 127.0.0.1. Every /api call needs the per-process token."""
from __future__ import annotations

import asyncio
import logging
import secrets
import subprocess
import time
from pathlib import Path

from aiohttp import web

from .alerts import LABELS
from .money import d_or_zero
from .projection import project
from .report import build_report
from .insights import build as build_insights
from .scorecard import scorecard

logger = logging.getLogger("favbot.dashboard")


_heavy_cache: dict = {"key": None, "val": None}


def _heavy(bot) -> dict:
    """History-based stats. Recomputed only when entries or fills change (not on every 2-second refresh)."""
    store, mode = bot.store, bot.mode
    r = store._q("""SELECT COUNT(*) n, COALESCE(MAX(id),0) mx, COALESCE(MAX(settled_at),0) st,
                    COALESCE(SUM(CAST(filled_count AS REAL)),0) f, COALESCE(MAX(ended_at),0) en FROM entries WHERE mode=?""",
                 (mode,))[0]
    key = (r["n"], r["mx"], r["st"], r["f"], r["en"], store._q("SELECT COUNT(*) c FROM fills")[0]["c"])
    if key == _heavy_cache["key"]:
        return _heavy_cache["val"]
    trades = []
    for e in store._q("SELECT * FROM entries WHERE mode=? AND CAST(filled_count AS REAL) > 0 ORDER BY id DESC LIMIT 500",
                      (mode,)):
        e = dict(e)
        cost = d_or_zero(e["fill_cost"]) + d_or_zero(e["fees"])
        c = store.contract(e["ticker"])
        filled_at = store._q("SELECT MIN(ts) t FROM fills WHERE entry_id=?", (e["id"],))[0]["t"]
        trades.append({
            "id": e["id"], "ask": e["ask_at_entry"], "bids_on_contract": store.attempts(mode, e["ticker"]),
            "attempt": e["attempt"], "filled_at": filled_at, "payout": e["payout"],
            "opens_at": c.open_ts if c else None, "closes_at": c.close_ts if c else None,
            "strike": str(c.floor_strike) if c and c.floor_strike is not None else None,
            "order_id": e["order_id"], "ticker": e["ticker"], "coin": e["coin"], "outcome": e["outcome"],
            "qty": f"{d_or_zero(e['filled_count']).normalize():f}", "price": f"{d_or_zero(e['price']):.3f}",
            "cost": f"{cost:.2f}", "fees": f"{d_or_zero(e['fees']):.2f}",
            "placed_at": e["created_at"], "settled_at": e["settled_at"], "result": e["settled_result"], "pnl": e["pnl"],
            "status": "open" if not e["settled_result"] else ("won" if d_or_zero(e["payout"]) > 0 else "lost"),
        })
    # Profit history comes from EVERY settled bet in the database; only the on-screen trade list is limited.
    settled_rows = [dict(x) for x in store._q("""SELECT settled_at, pnl, fill_cost, fees, price, payout, filled_count, coin, outcome
                               FROM entries WHERE mode=? AND settled_result IS NOT NULL AND CAST(filled_count AS REAL) > 0
                               ORDER BY settled_at""", (mode,))]
    series, cum = [], 0
    for x in settled_rows:
        cum += float(d_or_zero(x["pnl"]))
        series.append({"ts": x["settled_at"], "pnl": float(d_or_zero(x["pnl"])), "cum": round(cum, 4),
                       "coin": x["coin"], "outcome": x["outcome"], "price": float(d_or_zero(x["price"])),
                       "cost": round(float(d_or_zero(x["fill_cost"]) + d_or_zero(x["fees"])), 4),
                       "status": "won" if d_or_zero(x["payout"]) > 0 else "lost"})
    card = scorecard([{"won": d_or_zero(x["payout"]) > 0, "contracts": float(d_or_zero(x["filled_count"])),
                       "cost": float(d_or_zero(x["fill_cost"]) + d_or_zero(x["fees"])), "pnl": float(d_or_zero(x["pnl"]))}
                      for x in settled_rows], build_report(store, mode)["picked_off_test"])
    n_sent = store._q("SELECT COUNT(*) n FROM entries WHERE mode=? AND order_id IS NOT NULL", (mode,))[0]["n"]
    wins = sum(1 for s in series if s["pnl"] > 0)
    stats = {"settled": len(series), "wins": wins, "losses": len(series) - wins,
             "win_rate": (wins / len(series)) if series else None, "net": round(cum, 2),
             "open": sum(1 for t in trades if t["status"] == "open"),
             "bids_sent": n_sent, "fill_rate": (store._q("SELECT COUNT(*) c FROM entries WHERE mode=? AND CAST(filled_count AS REAL) > 0",
                                                     (mode,))[0]["c"] / n_sent) if n_sent else None,
             "trades_total": store._q("SELECT COUNT(*) c FROM entries WHERE mode=? AND CAST(filled_count AS REAL) > 0", (mode,))[0]["c"]}
    val = {"trades": trades, "series": series, "stats": stats, "scorecard": card,
           "insights": build_insights(store, mode), "settled_rows": settled_rows}
    _heavy_cache.update(key=key, val=val)
    return val


def build_state(bot) -> dict:
    snap = bot.portfolio.last
    store, mode = bot.store, bot.mode
    h = _heavy(bot)
    pending = store.entries(mode, states=("intent", "resting", "unknown"))
    holding = [e for e in store.entries(mode, unsettled_slot=True) if d_or_zero(e["filled_count"]) > 0]
    # Open bets valued at what they could be sold for right now (best bid), and what they pay if they win.
    open_bets = []
    for e in holding:
        qty = d_or_zero(e["filled_count"])
        cost = d_or_zero(e["fill_cost"]) + d_or_zero(e["fees"])
        bid = bot.portfolio.mark(e["ticker"], e["leg"])
        c = store.contract(e["ticker"])
        open_bets.append({
            "coin": e["coin"], "outcome": e["outcome"], "qty": f"{qty.normalize():f}", "price": f"{d_or_zero(e['price']):.3f}",
            "cost": f"{cost:.2f}", "value": f"{qty * bid:.2f}" if bid is not None else None,
            "if_win": f"{qty:.2f}", "closes_at": c.close_ts if c else None})
    projection = project([{"ts": x["settled_at"], "pnl": float(x["pnl"]), "won": d_or_zero(x["payout"]) > 0,
                           "cost": float(d_or_zero(x["fill_cost"]) + d_or_zero(x["fees"])), "price": float(x["price"]),
                           "qty": float(d_or_zero(x["filled_count"]))}
                          for x in h["settled_rows"]], float(snap.equity) if snap else 0.0, time.time(),
                         daily_stop_pct=float(bot.limits.daily_loss_pct), cap=float(bot.limits.capital_cap_usd))
    return {
        "mode": mode, "label": LABELS[mode], "now": time.time(), "started_at": bot.started_at,
        "killed": bot.killed(), "paused": bot.paused, "halts": store.halts(),
        "daily_loss_hit": bot.daily_loss_hit(),
        "trading_active": bot.trading_active(), "clock_skew_s": bot.md.clock_skew_s,
        "limits": {k: str(v) for k, v in bot.limits.model_dump().items()},
        "account": None if snap is None else {
            "balance": f"{snap.balance:.2f}", "equity": f"{snap.equity:.2f}", "exposure": f"{snap.exposure:.2f}",
            "open_positions": snap.open_positions, "daily_pnl": f"{snap.daily_pnl:.2f}",
            "realized_today": f"{snap.realized_today:.2f}", "unrealized": f"{snap.unrealized:.2f}",
            "positions_value": f"{snap.portfolio_value:.2f}", "reserved": f"{snap.reserved:.2f}",
            "foreign_positions": snap.foreign_positions},
        "coins": [dict(e.status, disabled=e.disabled, on=e.coin not in bot.coins_off()) for e in bot.engines],
        "pending": pending, "positions": holding, "history": store.entries(mode, limit=60),
        "trades": h["trades"], "series": h["series"], "stats": h["stats"], "open_bets": open_bets,
        "projection": projection, "scorecard": h["scorecard"], "insights": h["insights"],
        "alerts": bot.alerts.status() if bot.alerts else {"configured": False, "prefs": {}},
        "supervised": bool(bot.data_dir and (bot.data_dir / "supervisor.pid").exists()),
        "version": _version_info(bot),
        "backtrack": _backtrack_state(bot),
        "litterbox": _litterbox_state(bot),
        "presets": _presets(bot), "lab": _lab_state(bot), "picker": _picker(bot), "release": _release_state(),
        "whats_new_seen": store.get_meta("whats_new_seen"),
        "ui": {k: bool(store.get_meta("ui_" + k)) for k in UI_FLAGS},
        "network": {"down": bool(bot.alerts and bot.alerts._net_down),
                    "since": getattr(bot.alerts, "net_since", None) if bot.alerts else None},
        "errors": store.recent_events(30),
    }


_lb_cache: dict = {"mtime": None, "data": None}


def litterbox_dir(bot) -> Path | None:
    return bot.data_dir.parent / "litterbox" if bot.data_dir else None


def _litterbox_state(bot) -> dict:
    d = litterbox_dir(bot)
    if d is None:
        return {"enabled": False, "running": False, "summary": None}
    f = d / "summary.json"
    if f.exists():
        m = f.stat().st_mtime
        if m != _lb_cache["mtime"]:
            import json
            try:
                _lb_cache.update(mtime=m, data=json.loads(f.read_text(encoding="utf-8")))
            except ValueError:
                pass
    s = _lb_cache["data"]
    return {"enabled": (d / "ENABLED").exists(), "running": bool(s and time.time() - s.get("ts", 0) < 30),
            "summary": s}


WEB_DIR = Path(__file__).with_name("web")
PAGE_FILE = WEB_DIR / "index.html"
_version_cache: dict = {"t": 0.0, "v": None}


_bt_cache: dict = {"mtime": None, "data": None}


def backtrack_dir(bot) -> Path | None:
    return bot.data_dir.parent / "backtrack" if bot.data_dir else None


def _backtrack_state(bot) -> dict:
    d = backtrack_dir(bot)
    if d is None:
        return {"results": None, "status": None}
    res_file, st_file = d / "results.json", d / "status.json"
    if res_file.exists():
        m = res_file.stat().st_mtime
        if m != _bt_cache["mtime"]:
            import json
            _bt_cache.update(mtime=m, data=json.loads(res_file.read_text(encoding="utf-8")))
    status = None
    if st_file.exists():
        import json
        try:
            status = json.loads(st_file.read_text(encoding="utf-8"))
        except ValueError:
            status = None
    return {"results": _bt_cache["data"], "status": status}


def _presets(bot) -> dict:
    from .lab import recommendation
    from .presets import ORIGINAL, RISK_LEVELS, describe, level_of, limits_for_level, strategy_dict
    cur_lim, pend = bot.limits, bot.cfg.live_limits_pending if bot.mode == "live" else None
    rec = recommendation(bot.data_dir.parent) if bot.data_dir else {"ready": False}
    if rec.get("ready"):
        rec["describe"] = describe(rec["strategy"], rec.get("coins"))
    cur_st = strategy_dict(bot.cfg.strategy)
    coins = [s[2:-3] for s in bot.cfg.series]
    return {
        "current": {"strategy": cur_st, "describe": describe(cur_st, coins), "coins": coins,
                    "is_original": all(str(cur_st.get(k)) == str(v) for k, v in ORIGINAL.items()),
                    "level": level_of(cur_lim), "limits": {k: str(v) for k, v in cur_lim.model_dump().items()}},
        "pending_limits": {k: str(v) for k, v in pend.model_dump().items()} if pend else None,
        "original": {"strategy": ORIGINAL, "describe": describe(ORIGINAL)},
        "recommended": rec,
        "levels": [{"level": lv, "name": nm, **{k: str(v) for k, v in limits_for_level(lv, cur_lim).model_dump().items()}}
                   for lv, nm, *_ in RISK_LEVELS],
    }


_rel_cache: dict = {"t": 0.0, "v": None}
UI_FLAGS = ("tour_done", "katya")          # small per-person app flags kept in this person's own database


def _release_state(force: bool = False) -> dict:
    """Shared updates: this copy's version, and a newer signed version in the updates folder (checked every 2 min)."""
    from . import release
    now = time.time()
    if force or _rel_cache["v"] is None or now - _rel_cache["t"] > 120:
        try:
            info = release.check()
        except Exception as e:  # noqa: BLE001 - a half-synced folder must never break the page
            info = {"installed": release.installed_version(), "available": None, "rejected": [f"{type(e).__name__}"],
                    "folders": []}
        info["publisher"] = release.is_publisher()
        info["changelog"] = release.changelog()
        _rel_cache.update(t=now, v=info)
    return _rel_cache["v"]


def _picker(bot) -> dict:
    from . import picker
    from .lab import recommendation
    from .presets import strategy_dict
    rec = recommendation(bot.data_dir.parent) if bot.data_dir else None
    return picker.build(_litterbox_state(bot).get("summary"), (_backtrack_state(bot) or {}).get("results"),
                        strategy_dict(bot.cfg.strategy), [s[2:-3] for s in bot.cfg.series], rec)


def _lab_state(bot) -> dict:
    if not bot.data_dir:
        return {}
    import json
    d = bot.data_dir.parent / "lab"
    try:
        cand = json.loads((d / "candidate.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        cand = None
    try:
        hist = json.loads((d / "history.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        hist = []
    return {"candidate": cand, "history": hist[-10:]}


def _version_info(bot) -> dict:
    """Is newer bot code on disk than the code this process is running? (checked at most every 10 s)"""
    from .versions import code_hash, list_points
    now = time.time()
    if now - _version_cache["t"] > 10:
        pts = list_points()
        _version_cache.update(t=now, v={"disk": code_hash(), "latest_point": pts[-1] if pts else None})
    running = getattr(bot, "code_version", None)
    v = _version_cache["v"]
    cfg_changed = False
    if getattr(bot, "config_fp", None) and bot.cfg.config_path:
        try:
            from .config import load_config
            from .presets import fingerprint
            cfg_changed = fingerprint(load_config(bot.cfg.config_path), bot.mode) != bot.config_fp
        except Exception:  # noqa: BLE001 - a half-written file shouldn't break the page
            cfg_changed = False
    code_changed = bool(running and running != v["disk"])
    return {"running": running, "disk": v["disk"], "update_ready": code_changed or cfg_changed,
            "code_changed": code_changed, "settings_changed": cfg_changed, "latest_point": v["latest_point"]}


class Dashboard:
    def __init__(self, bot, port: int, token_file: Path | None = None):
        self.bot = bot
        self.port = port
        # Reuse the token across restarts so an open app window reconnects by itself.
        token = None
        if token_file and token_file.exists():
            token = token_file.read_text(encoding="utf-8").strip() or None
        self.token = token or secrets.token_urlsafe(24)
        if token_file and not token:
            token_file.write_text(self.token, encoding="utf-8")
        self.runner: web.AppRunner | None = None

    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}/?token={self.token}"

    def _auth(self, request: web.Request) -> None:
        sent = request.headers.get("X-Token", "")
        if not secrets.compare_digest(sent, self.token):
            raise web.HTTPForbidden(text="bad token")

    async def page(self, request):
        # Read on every load so design updates apply with a refresh, no bot restart needed.
        html = PAGE_FILE.read_text(encoding="utf-8")
        for f in WEB_DIR.iterdir():          # cache-bust each file by its modification time
            html = html.replace(f"/static/{f.name}\"", f"/static/{f.name}?v={int(f.stat().st_mtime)}\"")
        return web.Response(text=html, content_type="text/html",
                            headers={"Cache-Control": "no-store", "Referrer-Policy": "no-referrer"})

    async def state(self, request):
        self._auth(request)
        return web.json_response(build_state(self.bot), dumps=lambda o: __import__("json").dumps(o, default=str))

    async def pause(self, request):
        self._auth(request)
        self.bot.paused = True
        self.bot.store.log_event("warning", "pause", "paused from dashboard: no new bids, resting bids cancelled")
        return web.json_response({"paused": True})

    async def resume(self, request):
        self._auth(request)
        self.bot.paused = False
        self.bot.store.log_event("info", "resume", "resumed from dashboard")
        return web.json_response({"paused": False})

    async def kill(self, request):
        self._auth(request)
        self.bot.store.set_kill("dashboard kill switch")
        kf = self.bot.kill_file()
        if kf:
            kf.write_text("dashboard kill switch\n", encoding="utf-8")
        return web.json_response({"killed": True})

    async def coin(self, request):
        """Switch one coin off or on. Off only ever stops new bids (and cancels that coin's waiting bid)."""
        self._auth(request)
        body = await request.json()
        coin = str(body.get("coin", "")).upper()
        if coin not in {e.coin for e in self.bot.engines}:
            raise web.HTTPBadRequest(text="unknown coin")
        off = set(self.bot.coins_off())
        if body.get("on"):
            off.discard(coin)
        else:
            off.add(coin)
        self.bot.store.set_meta("coins_off", sorted(off))
        self.bot.store.log_event("warning" if not body.get("on") else "info", "coin_setting",
                                 f"{coin} turned {'on' if body.get('on') else 'off'} from the dashboard", coin)
        return web.json_response({"coins_off": sorted(off)})

    async def alert_prefs(self, request):
        """Choose which emails to get. Values are validated; unknown keys are ignored."""
        self._auth(request)
        body = await request.json()
        prefs = dict(self.bot.store.get_meta("alert_prefs") or {})
        for k in ("losses", "wins", "summary", "problems"):
            if k in body:
                prefs[k] = bool(body[k])
        if "summary_hour" in body:
            h = int(body["summary_hour"])
            if not 0 <= h <= 23:
                raise web.HTTPBadRequest(text="hour must be 0-23")
            prefs["summary_hour"] = h
        self.bot.store.set_meta("alert_prefs", prefs)
        return web.json_response(prefs)

    async def alert_test(self, request):
        self._auth(request)
        if not self.bot.alerts:
            raise web.HTTPBadRequest(text="alerts are not set up")
        try:
            await asyncio.to_thread(self.bot.alerts.send_now, "Test alert",
                                    "If you can read this, Odds & Whiskers alerts are working.")
        except Exception as e:  # noqa: BLE001
            return web.json_response({"ok": False, "error": f"{type(e).__name__}: {e}"[:300]})
        return web.json_response({"ok": True})

    async def apply(self, request):
        """Explicit 'Apply' from the app. Strategy/coins are written to config.yaml (used after a restart).
        Real-money limit changes are saved as live_limits_pending and only become live after ack-live."""
        self._auth(request)
        from .configedit import update_config
        from .lab import recommendation
        from .presets import ORIGINAL, limits_for_level, series_for, strategy_dict
        body = await request.json()
        cfg, changes = self.bot.cfg, {}
        if not cfg.config_path:
            raise web.HTTPBadRequest(text="no config file to update")
        src = body.get("strategy")
        if src in ("original", "recommended"):
            if src == "recommended":
                rec = recommendation(self.bot.data_dir.parent)
                if not rec.get("ready"):
                    raise web.HTTPConflict(text="There is no recommendation yet")
                new_st, coins = rec["strategy"], rec.get("coins")
            else:
                new_st, coins = ORIGINAL, None
        elif src == "model":                       # version picker: a model's strategy + the coins you picked
            from .picker import COINS, find
            g = find(_picker(self.bot), str(body.get("key", "")))
            if g is None:
                raise web.HTTPBadRequest(text="unknown model")
            coins = [c for c in COINS if c in set(body.get("coins") or [])]
            if not coins:
                raise web.HTTPBadRequest(text="pick at least one coin")
            new_st, coins = g["strategy"], (None if len(coins) == len(COINS) else coins)
        if src in ("original", "recommended", "model"):
            merged = {**{k: (str(v) if not isinstance(v, (int, float, str)) else v)
                         for k, v in cfg.strategy.model_dump().items()}, **new_st}
            changes["strategy"] = merged
            changes["series"] = series_for(coins)
        level = body.get("level")
        pending = False
        if level:
            L = limits_for_level(int(level), self.bot.limits)
            block = {k: (v if isinstance(v, int) else str(v)) for k, v in L.model_dump().items()}
            if self.bot.mode == "live":
                changes["live_limits_pending"] = block          # needs your typed confirmation (ack-live)
                pending = True
            else:
                changes[f"{self.bot.mode}_limits"] = block
        if not changes:
            raise web.HTTPBadRequest(text="nothing to apply")
        backup = update_config(Path(cfg.config_path), changes)
        what = ", ".join(changes)
        self.bot.store.log_event("warning", "settings", f"settings changed from the app: {what} (backup {backup.name})")
        return web.json_response({"ok": True, "pending_limits": pending, "restart": True, "backup": backup.name})

    async def shutdown(self, request):
        """Turn the bot off from the app. A STOPPED marker tells the supervisor not to restart it.
        The Litter Box stops too (it restarts with the bot if it was switched on)."""
        self._auth(request)
        lbd = litterbox_dir(self.bot)
        if lbd and lbd.exists():
            (lbd / "STOP").write_text("bot turned off\n", encoding="utf-8")
        if self.bot.data_dir:
            (self.bot.data_dir / "STOPPED").write_text("turned off from the app\n", encoding="utf-8")
        self.bot.store.log_event("warning", "turned_off", "bot turned off from the app")
        asyncio.get_running_loop().call_later(0.5, self.bot.stop.set)
        return web.json_response({"stopping": True})

    async def restart(self, request):
        """Restart to load updated code. Only offered when the background helper will start it again."""
        self._auth(request)
        if not (self.bot.data_dir and (self.bot.data_dir / "supervisor.pid").exists()):
            raise web.HTTPBadRequest(text="restart from the app needs the bot to be started with the desktop icon")
        (self.bot.data_dir / "RESTART").write_text("restart requested from the app\n", encoding="utf-8")
        lbd = litterbox_dir(self.bot)
        vi = _version_info(self.bot)
        if vi.get("code_changed"):
            try:                                            # a copy of the history and settings before new code runs
                await asyncio.to_thread(self._backup, "before-restart")
            except OSError as e:
                logger.warning("backup before restart failed: %s", e)
        if (vi.get("code_changed") or vi.get("settings_changed")) and lbd and (lbd / "ENABLED").exists():
            # new code or new settings: the fake-money models restart too, so "Simulated you" follows your real
            # settings (the restarted bot starts them again within a minute)
            (lbd / "STOP").write_text("update\n", encoding="utf-8")
        self.bot.store.log_event("info", "restart", "restart requested from the app to apply an update")
        asyncio.get_running_loop().call_later(0.5, self.bot.stop.set)
        return web.json_response({"restarting": True})

    def _backup(self, label: str):
        from . import release
        if not self.bot.data_dir:
            return None
        cfg_path = Path(self.bot.cfg.config_path) if self.bot.cfg.config_path else None
        return release.backup_data(self.bot.data_dir, cfg_path, label)

    async def install_update(self, request):
        """Install the newer signed version safely, even while trading:
        1. pause new bets — the engines cancel waiting bids within a few seconds (filled bets are not touched);
        2. back up this person's trade history and settings (data/backups/);
        3. install the code (a restore point first; settings, key, limits, layouts and history are never replaced);
        4. restart — at startup the bot reconciles every order with Kalshi before it bets again."""
        self._auth(request)
        from . import release
        if getattr(self, "_installing", False):
            raise web.HTTPConflict(text="An update is already being installed")
        info = _release_state(force=True)
        if not info.get("available"):
            raise web.HTTPConflict(text="No newer version found")
        ver = info["available"]["version"]
        self._installing, was_paused = True, self.bot.paused
        self.bot.paused = True
        self.bot.store.log_event("warning", "update", f"pausing new bets to install Odds & Whiskers {ver}")
        try:
            for _ in range(40):                                  # let the engines cancel waiting bids
                if not self.bot.store.entries(self.bot.mode, states=("intent", "resting")):
                    break
                await asyncio.sleep(0.5)
            backup = await asyncio.to_thread(self._backup, f"before-{ver}")
            r = await asyncio.to_thread(release.install, Path(info["available"]["path"]))
            await asyncio.to_thread(release.migrate_shortcut)
        except (release.ReleaseError, OSError, subprocess.CalledProcessError) as e:
            self.bot.paused = was_paused                          # nothing changed: carry on as before
            self.bot.store.log_event("error", "update", f"update not installed: {e}")
            raise web.HTTPBadRequest(text=f"Not installed: {e}")
        finally:
            self._installing = False
        _release_state(force=True)
        _version_cache["t"] = 0
        r["backup"] = str(backup) if backup else None
        r["restart"] = _version_info(self.bot)["code_changed"]      # page-only changes need just a refresh
        self.bot.store.log_event("warning", "update", f"installed Odds & Whiskers {r['version']} from the shared folder "
                                                      f"(restore point #{r['restore_point']}, data backup {backup})")
        supervised = bool(self.bot.data_dir and (self.bot.data_dir / "supervisor.pid").exists())
        if r["restart"] and supervised:
            # restart into the new version; it reconciles with Kalshi at startup and only then bets again
            (self.bot.data_dir / "RESTART").write_text(f"update to {r['version']}\n", encoding="utf-8")
            lbd = litterbox_dir(self.bot)
            if lbd and (lbd / "ENABLED").exists():
                (lbd / "STOP").write_text("update\n", encoding="utf-8")
            asyncio.get_running_loop().call_later(1.0, self.bot.stop.set)
            r["restarting"] = True
        elif not r["restart"]:
            self.bot.paused = was_paused                          # nothing to restart: resume right away
        return web.json_response({"ok": True, **r})

    async def ui_flag(self, request):
        """Remember a small app flag (tutorial done, Katya found) for this person."""
        self._auth(request)
        body = await request.json()
        key = str(body.get("key", ""))
        if key not in UI_FLAGS:
            raise web.HTTPBadRequest(text="unknown setting")
        self.bot.store.set_meta("ui_" + key, bool(body.get("value", True)))
        return web.json_response({key: bool(body.get("value", True))})

    async def whats_new_seen(self, request):
        """Remember (in this person's own database) that the What's new popup for this version was shown."""
        self._auth(request)
        v = str((await request.json()).get("version", ""))[:20]
        self.bot.store.set_meta("whats_new_seen", v)
        return web.json_response({"seen": v})

    def _spawn(self, *args: str):
        """Start a read-only helper (Backtrack or Litter Box) as its own windowless process."""
        import subprocess
        import sys
        root = Path(__file__).resolve().parent.parent
        flags = 0x08000000 if sys.platform == "win32" else 0          # CREATE_NO_WINDOW
        cfg_file = Path(self.bot.cfg.config_path or Path(self.bot.cfg.base_dir) / "config.yaml")
        return subprocess.Popen([sys.executable, "-X", "utf8", "-m", "favbot", "--config", str(cfg_file), *args],
                                cwd=str(root), creationflags=flags, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def _backtrack_running(self) -> bool:
        proc = getattr(self, "_bt_proc", None)
        if proc is not None and proc.poll() is None:
            return True
        st = (_backtrack_state(self.bot) or {}).get("status") or {}
        return st.get("state") == "running" and time.time() - st.get("ts", 0) < 120

    def start_backtrack(self, days: float, why: str) -> None:
        self._bt_proc = self._spawn("backtrack", "--days", f"{days:g}")
        self.bot.store.log_event("info", "backtrack", f"Backtrack started for {days:g} days ({why})")

    async def run_backtrack(self, request):
        """Start Backtrack in its own read-only process (it never places orders)."""
        self._auth(request)
        body = await request.json()
        days = min(max(float(body.get("days", 7)), 1), 60)
        if self._backtrack_running():
            raise web.HTTPConflict(text="Backtrack is already running")
        self.start_backtrack(days, "from the app")
        return web.json_response({"started": True, "days": days})

    def _lb_alive(self) -> bool:
        proc = getattr(self, "_lb_proc", None)
        return (proc is not None and proc.poll() is None) or _litterbox_state(self.bot)["running"]

    def restart_litterbox(self, why: str) -> None:
        """Stop the Litter Box and start it again once it has stopped (if it's switched on)."""
        d = litterbox_dir(self.bot)
        if not d or not (d / "ENABLED").exists():
            return
        if self._lb_alive():
            (d / "STOP").write_text(why + "\n", encoding="utf-8")

        def ours_running() -> bool:
            proc = getattr(self, "_lb_proc", None)
            return proc is not None and proc.poll() is None

        async def again():
            for _ in range(90):                # it writes its summary every 5 s, so 8 s of silence = stopped
                await asyncio.sleep(1)
                summ = _litterbox_state(self.bot).get("summary") or {}
                if not ours_running() and time.time() - summ.get("ts", 0) > 8:
                    break
            if (d / "ENABLED").exists() and not ours_running():
                self._lb_proc = self._spawn("litterbox")       # it removes the STOP file itself on start
        asyncio.get_running_loop().create_task(again())

    async def litterbox(self, request):
        """Start, stop or reset the fake-money Litter Box models, or add/remove a risk-level copy of a model."""
        self._auth(request)
        body = await request.json()
        action = body.get("action")
        d = litterbox_dir(self.bot)
        d.mkdir(parents=True, exist_ok=True)
        if action in ("variant", "unvariant"):
            from .litterbox import MAX_VARIANTS, read_variants, write_variants
            vs = read_variants(d)
            if action == "variant":
                base, level = str(body.get("base", "")), int(body.get("level", 0))
                summ = (_litterbox_state(self.bot).get("summary") or {}).get("models", [])
                known = {m["id"]: m for m in summ}
                if base not in known or known[base].get("base") or not 1 <= level <= 5:
                    raise web.HTTPBadRequest(text="unknown model or level")
                if level == known[base].get("level", 3) or any(v["base"] == base and v["level"] == level for v in vs):
                    raise web.HTTPConflict(text="That model is already running at that level")
                if len(vs) >= MAX_VARIANTS:
                    raise web.HTTPConflict(text=f"At most {MAX_VARIANTS} risk-level copies; remove one first")
                vs.append({"base": base, "level": level})
            else:
                vid = str(body.get("id", ""))
                vs = [v for v in vs if f"{v['base']}-L{v['level']}" != vid]
            write_variants(d, vs)
            self.bot.store.log_event("info", "litterbox", f"Litter Box risk-level copies changed ({action})")
            self.restart_litterbox("risk-level copies changed")
            return web.json_response({"ok": True, "variants": vs})
        if action == "start":
            (d / "ENABLED").write_text("on\n", encoding="utf-8")
            if (d / "STOP").exists():
                (d / "STOP").unlink()
            if not self._lb_alive():
                self._lb_proc = self._spawn("litterbox")
        elif action == "stop":
            if (d / "ENABLED").exists():
                (d / "ENABLED").unlink()
            (d / "STOP").write_text("stop\n", encoding="utf-8")
        elif action == "reset":
            if self._lb_alive():
                raise web.HTTPConflict(text="Stop the Litter Box first")
            stamp = time.strftime("%Y%m%d-%H%M%S")      # fake-money history is archived, not deleted
            archive = d.parent / f"litterbox-archive-{stamp}"
            d.rename(archive)
            d.mkdir()
            _lb_cache.update(mtime=None, data=None)
        else:
            raise web.HTTPBadRequest(text="unknown action")
        self.bot.store.log_event("info", "litterbox", f"Litter Box {action}")
        return web.json_response({"ok": True, "action": action})

    async def maintenance(self) -> None:
        """Every minute: keep the Litter Box running if it's switched on; run a 30-day Backtrack nightly at 3 AM."""
        while True:
            try:
                d = litterbox_dir(self.bot)
                if d and (d / "ENABLED").exists() and not self._lb_alive():
                    self._lb_proc = self._spawn("litterbox")
                    self.bot.store.log_event("info", "litterbox", "Litter Box (re)started automatically")
                res = (_backtrack_state(self.bot) or {}).get("results") or {}
                if time.time() - getattr(self, "_lab_t", 0) > 300 and self.bot.data_dir:
                    self._lab_t = time.time()
                    from .lab import step
                    r = step(self.bot.data_dir.parent, res or None)
                    if r["restart_litterbox"] and d and self._lb_alive():
                        self.restart_litterbox("new candidate")                        # restarts with the new lineup
                        self.bot.store.log_event("info", "lab", "learning loop updated the candidate; Litter Box restarting")
                if time.time() - getattr(self, "_feed_t", 0) > 1800:          # the website's update feed, twice an hour
                    self._feed_t = time.time()
                    from . import release
                    try:
                        r = await asyncio.to_thread(release.fetch_feed)
                        if r.get("newer"):
                            _release_state(force=True)
                    except Exception as e:  # noqa: BLE001 - offline or a bad file: try again next time
                        logger.info("website update check: %s", e)
                age = time.time() - res.get("generated_at", 0)
                if time.localtime().tm_hour == 3 and age > 20 * 3600 and not self._backtrack_running():
                    self.start_backtrack(30, "nightly")
            except Exception:  # noqa: BLE001
                logger.exception("maintenance loop")
            await asyncio.sleep(60)

    async def start(self) -> None:
        app = web.Application()
        app.router.add_post("/api/backtrack", self.run_backtrack)
        app.router.add_post("/api/litterbox", self.litterbox)
        app.router.add_post("/api/apply", self.apply)
        app.router.add_post("/api/install_update", self.install_update)
        app.router.add_post("/api/whats_new_seen", self.whats_new_seen)
        app.router.add_post("/api/ui", self.ui_flag)
        app.router.add_static("/static/", Path(__file__).with_name("web"), append_version=False)
        app.router.add_post("/api/restart", self.restart)
        app.router.add_post("/api/coin", self.coin)
        app.router.add_post("/api/alert_prefs", self.alert_prefs)
        app.router.add_post("/api/alert_test", self.alert_test)
        app.router.add_post("/api/shutdown", self.shutdown)
        app.router.add_get("/", self.page)
        app.router.add_get("/api/state", self.state)
        app.router.add_post("/api/pause", self.pause)
        app.router.add_post("/api/resume", self.resume)
        app.router.add_post("/api/kill", self.kill)
        self.runner = web.AppRunner(app, access_log=None)
        await self.runner.setup()
        await web.TCPSite(self.runner, "127.0.0.1", self.port).start()
        self._maint = asyncio.create_task(self.maintenance())

    async def stop(self) -> None:
        if getattr(self, "_maint", None):
            self._maint.cancel()
        if self.runner:
            await self.runner.cleanup()
