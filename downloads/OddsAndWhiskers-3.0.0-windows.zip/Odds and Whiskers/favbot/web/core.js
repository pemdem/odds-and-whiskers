const token = new URLSearchParams(location.search).get('token') || '';
const H = {'X-Token': token};
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const money = (v, sign) => { const n = +v; const s = '$' + Math.abs(n).toFixed(2);
  return sign ? (n > 0 ? '+' : n < 0 ? '−' : '') + s : (n < 0 ? '−' : '') + s; };
// Odds as a price (93.5¢) or a percent chance (93.5%), per Settings. On Kalshi they're the same number.
const cents = p => p == null ? '–' : (Math.round(+p * 1000) / 10).toString().replace(/\.0$/, '') + (prefs.odds === 'pct' ? '%' : '¢');
const PERIODS = {'24h': 86400, '1d': 86400, '1w': 7 * 86400, '1m': 30 * 86400, '90d': 90 * 86400, all: Infinity};
const PERIOD_LABEL = {'1d': 'past day', '1w': 'past week', '1m': 'past month', '90d': 'past 90 days', all: 'all time',
  '24h': 'last 24 hours', };
const PREF_KEY = 'favbot.prefs';
const RESTARTING = 'Restarting… this window reconnects by itself, and the bot re-checks every order with Kalshi before betting again.';
const prefs = Object.assign({theme: 'auto', tz: 'local', refresh: '2', hide: [], odds: 'price', cat: 'biscuit', pane: 'general',
  pnl: '1d', range: 'all', tradesCollapsed: false, view: 'full', btDays: '7', layout: null, tab: 'live', width: 'wide', logo: 'sidekick', tips: 'on', textSize: 'M', chat: {}, simView: 'real'},
  (() => { try { return JSON.parse(localStorage.getItem(PREF_KEY)) || {}; } catch (e) { return {}; } })());
// ---- which exchange you're viewing: Kalshi, or the Polymarket US practice workspace ------------------------
// Requests about the bot (state, pause, the Litter Box, your sidekick…) go to that exchange's own workspace; the
// app's own things (layout, updates, settings, Kalshi account) always go to the Kalshi app.
const WS_API = new Set(['state', 'brief', 'pause', 'resume', 'kill', 'unkill', 'coin', 'council', 'recap', 'diagnostics',
  'litterbox', 'markets']);
const ws = () => prefs.workspace === 'polymarket_us' ? 'polymarket_us' : 'kalshi';
const _fetch = window.fetch.bind(window);
window.fetch = (url, opts) => {
  if (typeof url === 'string' && ws() !== 'kalshi') {
    const m = url.match(/^\/api\/([a-z_]+)(\?.*)?$/);
    if (m && WS_API.has(m[1])) url = `/x/${ws()}` + url;
  }
  return _fetch(url, opts);
};
let prefsTimer;
const savePrefs = () => { try { localStorage.setItem(PREF_KEY, JSON.stringify(prefs)); } catch (e) {}
  clearTimeout(prefsTimer);             // a copy in your own data folder too, so clearing the browser can't lose your layout
  prefsTimer = setTimeout(() => fetch('/api/prefs', {method: 'POST', headers: {...H, 'Content-Type': 'application/json'},
    body: JSON.stringify({prefs})}).catch(() => {}), 800); };
// This window's storage empty (cleared, or a new browser profile)? Bring back the copy from your data folder.
(() => {
  let had = false; try { had = !!localStorage.getItem(PREF_KEY); } catch (e) {}
  if (had) { savePrefs(); return; }
  fetch('/api/prefs', {headers: H}).then(r => r.ok ? r.json() : {}).then(j => {
    if (!j.prefs || !Object.keys(j.prefs).length) { savePrefs(); return; }
    let ok = false;
    try { localStorage.setItem(PREF_KEY, JSON.stringify(Object.assign(prefs, j.prefs))); ok = !!localStorage.getItem(PREF_KEY); } catch (e) {}
    if (ok) location.reload();          // start over with your layout (only when it stuck, so this can't loop)
  }).catch(() => {});
})();
const tzOpt = () => prefs.tz === 'utc' ? {timeZone: 'UTC'} : {};
const tzSuffix = () => prefs.tz === 'utc' ? ' UTC' : '';
const tm = ts => ts ? new Date(ts * 1000).toLocaleTimeString([], {hour:'numeric', minute:'2-digit', ...tzOpt()}) + tzSuffix() : '';
const dt = ts => { if (!ts) return ''; const o = tzOpt(), d = new Date(ts * 1000);
  const same = d.toLocaleDateString([], o) === new Date().toLocaleDateString([], o);
  return (same ? 'Today' : d.toLocaleDateString([], {month:'short', day:'numeric', ...o})) + ', ' + tm(ts); };
const pct = v => v == null ? '–' : Math.round(v * 1000) / 10 + '%';
const mmss = s => s <= 0 ? 'now' : Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');
const css = v => getComputedStyle(document.documentElement).getPropertyValue(v).trim();
const NS = 'http://www.w3.org/2000/svg';
const el = (tag, attrs, parent) => { const e = document.createElementNS(NS, tag);
  for (const k in attrs) e.setAttribute(k, attrs[k]); if (parent) parent.appendChild(e); return e; };
// node.h = html: like innerHTML, but only touches the page when the content really changed (no flicker)
Object.defineProperty(HTMLElement.prototype, 'h', {configurable: true, get() { return this._h; },
  set(v) { if (this._h !== v) { this._h = v; this.innerHTML = v; } }});

// ---- banners: each has a key; unchanged ones are left alone, new ones slide in, old ones fold away -------
function setBanners(list) {
  const box = $('banners'), keep = new Set(list.map(b => b.key));
  for (const n of [...box.children]) {
    if (keep.has(n.dataset.key) || n.classList.contains('leaving')) continue;
    n.style.height = n.offsetHeight + 'px'; n.classList.add('leaving');
    requestAnimationFrame(() => requestAnimationFrame(() => { n.style.height = '0px'; }));
    setTimeout(() => n.remove(), 360);
  }
  let prev = null;
  for (const b of list) {
    let n = [...box.children].find(x => x.dataset.key === b.key && !x.classList.contains('leaving'));
    const cls = 'banner' + (b.cls ? ' ' + b.cls : '');
    if (!n) { n = document.createElement('div'); n.dataset.key = b.key; box.insertBefore(n, prev ? prev.nextSibling : box.firstChild); }
    if (n.className !== cls) n.className = cls;
    n.h = b.html;
    prev = n;
  }
}
let netFails = 0;

function niceTicks(lo, hi, n) {
  const span = hi - lo || 1, raw = span / n, mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const step = [1, 2, 2.5, 5, 10].map(m => m * mag).find(s => span / s <= n) || mag * 10;
  const out = []; for (let v = Math.ceil(lo / step) * step; v <= hi + 1e-9; v += step) out.push(+v.toFixed(6));
  return out;
}

function frame(box) {
  box.innerHTML = '';
  const w = box.clientWidth, h = box.clientHeight;
  const svg = el('svg', {viewBox: `0 0 ${w} ${h}`}, box);
  const tip = document.createElement('div'); tip.className = 'tip'; box.appendChild(tip);
  return {svg, tip, w, h};
}

function yScale(vals, h, m) {
  let lo = Math.min(0, ...vals), hi = Math.max(0, ...vals);
  if (lo === hi) { hi += 1; }
  const pad = (hi - lo) * 0.12; lo = lo < 0 ? lo - pad : lo; hi = hi + pad;
  const ticks = niceTicks(lo, hi, 4);
  lo = Math.min(lo, ticks[0]); hi = Math.max(hi, ticks[ticks.length - 1]);
  return {f: v => m.t + (hi - v) / (hi - lo) * (h - m.t - m.b), ticks};
}

function grid(svg, y, w, m) {
  for (const t of y.ticks) {
    el('line', {x1: m.l, x2: w - m.r, y1: y.f(t), y2: y.f(t), stroke: css('--line'),
      'stroke-width': t === 0 ? 1.5 : 1}, svg);
    el('text', {x: m.l - 8, y: y.f(t) + 4, 'text-anchor': 'end', class: 'axis'}, svg).textContent =
      (t < 0 ? '−$' : '$') + Math.abs(t).toFixed(Math.abs(t) < 10 && t % 1 ? 2 : 0);
  }
}

function placeTip(tip, x, y, w, html) {
  tip.innerHTML = html; tip.style.opacity = 1;
  const tw = tip.offsetWidth; tip.style.left = Math.min(Math.max(x - tw / 2, 0), w - tw) + 'px';
  tip.style.top = Math.max(y - tip.offsetHeight - 12, 0) + 'px';
}

function drawCum(box, s) {
  if (box.clientWidth < 60) { lastSeries = ''; return; }      // hidden or minimized: draw when visible
  if (s.length < 1) { box.innerHTML = '<div class="empty">The chart starts after the first bet settles.</div>'; return; }
  const pts = [{cum: 0, ts: null}, ...s];
  const {svg, tip, w, h} = frame(box); const m = {l: 48, r: 12, t: 12, b: 24};
  const y = yScale(pts.map(p => p.cum), h, m); grid(svg, y, w, m);
  const x = i => m.l + (pts.length === 1 ? 0 : i / (pts.length - 1)) * (w - m.l - m.r);
  const end = pts[pts.length - 1].cum, color = end >= 0 ? css('--pos') : css('--neg');
  const defs = el('defs', {}, svg), g = el('linearGradient', {id: 'ag', x1: 0, x2: 0, y1: 0, y2: 1}, defs);
  el('stop', {offset: '0%', 'stop-color': color, 'stop-opacity': .22}, g);
  el('stop', {offset: '100%', 'stop-color': color, 'stop-opacity': 0}, g);
  const line = pts.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y.f(p.cum).toFixed(1)}`).join('');
  el('path', {d: `${line}L${x(pts.length - 1)},${y.f(0)}L${x(0)},${y.f(0)}Z`, fill: 'url(#ag)', class: 'fadein'}, svg);
  const path = el('path', {d: line, fill: 'none', stroke: color, 'stroke-width': 2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round'}, svg);
  path.style.setProperty('--len', Math.ceil(path.getTotalLength()) + 1); path.classList.add('draw');
  const enddot = el('circle', {cx: x(pts.length - 1), cy: y.f(end), r: 4, fill: color, stroke: css('--card'), 'stroke-width': 2, class: 'fadein'}, svg);
  enddot.style.animationDelay = '.9s';
  el('text', {x: m.l, y: h - 6, class: 'axis'}, svg).textContent = 'Start';
  el('text', {x: w - m.r, y: h - 6, class: 'axis', 'text-anchor': 'end'}, svg).textContent = `Bet ${pts.length - 1}`;
  const cross = el('line', {y1: m.t, y2: h - m.b, stroke: css('--fg3'), 'stroke-width': 1, opacity: 0}, svg);
  const dot = el('circle', {r: 5, fill: color, stroke: css('--card'), 'stroke-width': 2, opacity: 0}, svg);
  const hit = el('rect', {x: m.l, y: 0, width: w - m.l - m.r, height: h, fill: 'transparent'}, svg);
  hit.addEventListener('mousemove', ev => {
    const r = svg.getBoundingClientRect(), px = (ev.clientX - r.left) * w / r.width;
    const i = Math.max(0, Math.min(pts.length - 1, Math.round((px - m.l) / (w - m.l - m.r) * (pts.length - 1))));
    const p = pts[i]; cross.setAttribute('x1', x(i)); cross.setAttribute('x2', x(i)); cross.setAttribute('opacity', .5);
    dot.setAttribute('cx', x(i)); dot.setAttribute('cy', y.f(p.cum)); dot.setAttribute('opacity', 1);
    placeTip(tip, x(i), y.f(p.cum), w, i === 0 ? '<b>$0.00</b><br>Start' :
      `<b>${money(p.cum, true)}</b> total<br>Bet ${i}: ${esc(p.coin)} ${esc(p.outcome)} ${money(p.pnl, true)}<br>${dt(p.ts)}`);
  });
  hit.addEventListener('mouseleave', () => { tip.style.opacity = 0; cross.setAttribute('opacity', 0); dot.setAttribute('opacity', 0); });
}

function drawBars(box, s) {
  if (box.clientWidth < 60) { lastSeries = ''; return; }
  if (s.length < 1) { box.innerHTML = '<div class="empty">Wins and losses appear here as bets settle.</div>'; return; }
  const {svg, tip, w, h} = frame(box); const m = {l: 48, r: 8, t: 12, b: 24};
  const y = yScale(s.map(p => p.pnl), h, m); grid(svg, y, w, m);
  const slot = (w - m.l - m.r) / s.length, bw = Math.max(3, Math.min(28, slot - 2)), r = Math.min(4, bw / 2);
  s.forEach((p, i) => {
    const cx = m.l + slot * i + slot / 2, y0 = y.f(0), y1 = y.f(p.pnl), up = p.pnl >= 0;
    const top = Math.min(y0, y1), hgt = Math.max(Math.abs(y1 - y0), 1.5), x0 = cx - bw / 2, rr = Math.min(r, hgt);
    const d = up
      ? `M${x0},${y0}V${top + rr}Q${x0},${top} ${x0 + rr},${top}H${x0 + bw - rr}Q${x0 + bw},${top} ${x0 + bw},${top + rr}V${y0}Z`
      : `M${x0},${y0}V${top + hgt - rr}Q${x0},${top + hgt} ${x0 + rr},${top + hgt}H${x0 + bw - rr}Q${x0 + bw},${top + hgt} ${x0 + bw},${top + hgt - rr}V${y0}Z`;
    const bar = el('path', {d, fill: up ? css('--pos') : css('--neg'), class: 'grow ' + (up ? 'up' : 'dn')}, svg);
    bar.style.animationDelay = Math.min(i * 0.025, 0.6) + 's';
    const hit = el('rect', {x: m.l + slot * i, y: 0, width: slot, height: h, fill: 'transparent'}, svg);
    hit.addEventListener('mousemove', () => { bar.setAttribute('opacity', .75);
      placeTip(tip, cx, top, w, `<b>${money(p.pnl, true)}</b> · ${up ? 'Won' : 'Lost'}<br>${esc(p.coin)} ${esc(p.outcome)}<br>${dt(p.ts)}`); });
    hit.addEventListener('mouseleave', () => { bar.setAttribute('opacity', 1); tip.style.opacity = 0; });
  });
  el('text', {x: m.l, y: h - 6, class: 'axis'}, svg).textContent = 'Oldest';
  el('text', {x: w - m.r, y: h - 6, class: 'axis', 'text-anchor': 'end'}, svg).textContent = 'Newest';
}

function tile(label, value, cls) { return `<div class="tile"><span>${label}</span><b class="${cls || ''}">${value}</b></div>`; }

// Each part of the page draws on its own: one that fails, or whose file didn't load, can't blank the rest
// (your balance, account and updates always show).
function part(name, ...args) {
  const f = window[name];
  if (typeof f !== 'function') { console.error(`Odds & Whiskers: ${name} didn't load`); return; }
  try { return f(...args); } catch (e) { console.error(`Odds & Whiskers: ${name} failed`, e); }
}

async function post(path) { const r = await fetch(path, {method: 'POST', headers: H}); if (!r.ok) alert(await r.text()); load(); }
$('kill').onclick = () => { if (confirm('Turn on the kill switch?\n\nIt cancels waiting bids and blocks new ones. Bets that already filled still finish at their 15-minute result.\n\nUndo later with the unkill command.')) post('/api/kill'); };
$('pause').onclick = () => post(window._paused ? '/api/resume' : '/api/pause');

let lastSeries = '', lastTrades = '';
const TRADE_PAGE = 10;
let tradePage = 0, tradeAll = false;
// Count a number up/down to its new value, the way Apple's Stocks and Wallet do.
function countTo(node, to) {
  const from = node._v == null ? to * 0.96 : node._v; node._v = to;
  if (from === to || (typeof reduceMotion === 'function' ? reduceMotion() : matchMedia('(prefers-reduced-motion: reduce)').matches)) {
    node.textContent = money(to); return; }
  const t0 = performance.now(), dur = 900;
  cancelAnimationFrame(node._raf);
  const step = now => { const k = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - k, 3);
    node.textContent = money(from + (to - from) * e); if (k < 1) node._raf = requestAnimationFrame(step); };
  node._raf = requestAnimationFrame(step);
}
async function load() {
  let s;
  const want = ws();
  if (want !== 'kalshi' && typeof exInfo !== 'undefined' && exInfo[want] && !exInfo[want].enabled) {
    part('renderWorkspaceOff', {}); return;                    // switched off: nothing to ask for
  }
  try { const r = await fetch('/api/state', {headers: H});
    if (r.status === 503 && want !== 'kalshi') {                 // the Polymarket US practice bot isn't running
      let j = {}; try { j = await r.json(); } catch (e) {}
      if (ws() === want) part('renderWorkspaceOff', j);
      return;
    }
    if (!r.ok) { setBanners([{key: 'http', html: r.status === 403 ? 'This window is out of date. Close it and click the Odds & Whiskers icon on your Desktop.' : 'Error ' + r.status}]); return; }
    s = await r.json();
  } catch (e) {
    netFails++;
    // a restart or one missed refresh isn't news: keep the calm banner until it's clearly offline
    if (window._restarting) setBanners([{key: 'restart', cls: 'warn', html: RESTARTING}]);
    else if (netFails >= 2) setBanners([{key: 'offline', cls: 'warn', html: 'Can’t reach the bot. If you turned it off, double-click the <b>Odds & Whiskers</b> icon to start it. ' +
      'If you didn’t, it’s restarting by itself (up to 30 seconds). This window reconnects on its own.'}]);
    if (netFails >= 2 || window._restarting) { part('statusOffline'); part('catOffline'); }
    return; }
  netFails = 0;
  // a refresh that was already on its way when you switched exchange belongs to the other one: drop it
  if ((s.exchange || 'kalshi') !== ws()) return;
  part('clearWorkspaceOff');
  if (window._restarting && s.started_at > (window._restartAt || 0)) window._restarting = false;   // the new version is up
  // updates are about the whole app: in the Polymarket US view, use what the Kalshi app knows
  if (ws() !== 'kalshi' && window._mainInfo) Object.assign(s, {version: window._mainInfo.version, release: window._mainInfo.release,
    supervised: window._mainInfo.supervised});

  $('mode').textContent = s.label === 'REAL-MONEY' ? 'Real money' : ws() !== 'kalshi' ? 'Practice' : s.label === 'SIMULATED' ? 'Simulated' : 'Demo money';
  $('mode').className = 'chip ' + (s.label === 'REAL-MONEY' ? 'real' : 'sim');
  part('renderStatus', s);              // Cat Nap: one clear status (catnap.js)
  window._paused = s.paused; $('pause').textContent = s.paused ? 'Resume' : 'Pause';

  const B = [];
  if (s.killed) B.push({key: 'kill', html: `Kill switch is on — ${esc(s.killed)}`});
  if (s.daily_loss_hit) B.push({key: 'daily', html: 'Daily loss limit reached. No new bets until tomorrow (UTC).'});
  for (const [k, v] of Object.entries(s.halts)) B.push({key: 'halt-' + k, html: `Stopped (${esc(k)}): ${esc(v.detail)}`});
  if (s.paused) B.push({key: 'paused', cls: 'warn', html: 'Paused — no new bets.'});
  if (s.network && s.network.down) B.push({key: 'net', html: `Internet connection to Kalshi lost${s.network.since ? ' at ' + tm(s.network.since) : ''}. ` +
    'No new bets until it’s back — the bot keeps retrying by itself. Bets that already filled settle on Kalshi either way.'});
  if (s.version && s.version.update_ready) B.push(s.supervised
    ? {key: 'update', cls: 'warn row', html: '<span style="flex:1">' +
      (s.version.settings_changed && !s.version.code_changed ? 'Your settings changed. ' : 'An update is ready. ') +
      'Restart to apply it — about 10 seconds. A waiting bid is cancelled; filled bets aren\'t affected.</span>' +
      '<button id="restartnow" style="background:var(--accent);color:#fff">Restart now</button>'}
    : {key: 'update', cls: 'warn', html: 'An update is ready. Turn the bot off in Settings, then open it again with the Odds & Whiskers icon.'});
  const up = (s.release || {}).available;
  if (up && !(s.version && s.version.update_ready)) B.push({key: 'avail-' + up.version, cls: 'warn row', html:
    `<span style="flex:1" data-tip="From your shared updates folder or the website. It's signed by the Odds & Whiskers publisher, and a restore point is saved before installing.">` +
    `<b>Odds & Whiskers ${esc(up.version)} is available.</b> ${esc(up.notes || '')}</span>` +
    `<button id="installupdate" style="background:var(--accent);color:#fff">Install update</button>`});
  setBanners(window._restarting ? [{key: 'restart', cls: 'warn', html: RESTARTING}] : B);

  const a = s.account || {}, st = s.stats;
  if (a.equity != null) countTo($('equity'), +a.equity); else $('equity').textContent = '–';
  const tp = +(a.daily_pnl || 0);
  // Profit for the chosen period (settled bets), plus what open bets are worth right now.
  const since = s.now - PERIODS[prefs.pnl], inP = s.series.filter(p => (p.ts || 0) >= since);
  const pp = inP.reduce((t, p) => t + p.pnl, 0), ur = +(a.unrealized || 0);
  $('today').h = `<span class="${pp > 0 ? 'pos' : pp < 0 ? 'neg' : 'mut'}">${money(pp, true)}</span>` +
    `<span class="mut" style="font-weight:500"> ${PERIOD_LABEL[prefs.pnl]} · ${inP.length} bet${inP.length === 1 ? '' : 's'}` +
    (Math.abs(ur) >= 0.01 ? ` · open bets ${money(ur, true)}` : '') + `</span>`;
  document.querySelectorAll('#pnlseg button').forEach(b => b.classList.toggle('on', b.dataset.p === prefs.pnl));
  $('tiles').h =
    tile('Win rate', st.win_rate == null ? '–' : Math.round(st.win_rate * 100) + '%') +
    tile('Record', `${st.wins}–${st.losses}`) +
    tile('Open bets', `${st.open}`) +
    tile('At risk now', a.exposure != null ? money(a.exposure) : '–') +
    tile('Fill rate', st.fill_rate == null ? '–' : Math.round(st.fill_rate * 100) + '%') +
    tile('Cap', '$' + (+s.limits.capital_cap_usd).toFixed(0));

  // Balance breakdown: cash you can use, money in bets, cash held behind waiting bids.
  const eq = +a.equity || 0, cash = +a.balance || 0, inb = +a.positions_value || 0, res = +a.reserved || 0;
  $('split').h = tile('Available cash', money(cash)) + tile('In bets (worth now)', money(inb)) +
    tile('Held for waiting bids', money(res));
  const parts = [[cash, '--accent', 'Available cash'], [inb, '--purple', 'In bets'], [res, '--fg3', 'Waiting bids']];
  const tot = parts.reduce((t, p) => t + Math.max(p[0], 0), 0) || 1;
  $('bar3').h = parts.filter(p => p[0] > 0).map(p => `<i style="width:${p[0] / tot * 100}%;background:var(${p[1]})" title="${p[2]}"></i>`).join('');
  $('legend').h = parts.map(p => `<span style="--c:var(${p[1]})">${p[2]} ${money(p[0])}</span>`).join('');
  $('openbets').h = s.open_bets.length ? '<div class="sub" style="margin:14px 0 2px">Open bets</div>' + s.open_bets.map(b => {
    const up = b.outcome === 'UP';
    return `<div class="row"><div class="badge">${esc(b.coin)}</div>` +
      `<div><div class="t1">${esc(b.coin)} <span class="side ${up ? 'up' : 'dn'}">${up ? '↑ Up' : '↓ Down'}</span></div>` +
      `<div class="t2">${b.qty} × ${cents(b.price)} = ${money(b.cost)} · result in ${b.closes_at ? mmss(b.closes_at - s.now) : '–'}</div></div>` +
      `<div class="amt">${b.value != null ? money(b.value) : '–'}<div class="t2">pays ${money(b.if_win)} if it wins</div></div></div>`;
  }).join('') : '';

  window._state = s;
  part('renderProjection', s.projection, eq);
  part('renderScore', s.scorecard);
  part('updateCat', s);
  part('renderCatCorner', s);
  part('renderBacktrack', s.backtrack);
  part('renderSimple', s);
  part('renderLitter', s);
  part('renderPresets', s);
  part('renderPicker', s);
  part('renderLabHistory', s);
  part('renderUpdates', s);
  if (ws() === 'kalshi') part('renderWhatsNew', s);
  part('renderSim', s);
  part('renderAccount', s);
  part('renderCouncilSettings', s);
  if (ws() === 'kalshi') {                // first-run welcome and the tour offer are about the app, shown once
    part('maybeOnboard', s);
    part('maybeOfferTour', s);
  }
  part('renderExchange', s);
  part('applyTips');
  part('applyLogo');
  $('balmin').textContent = a.equity != null ? `Balance · ${money(a.equity)}` : 'Balance';
  if ($('scrim').classList.contains('open')) part('renderCoinToggles');

  const key = JSON.stringify(s.series) + prefs.theme;
  if (key !== lastSeries) { lastSeries = key; drawCum($('cum'), s.series); drawBars($('bars'), s.series); }

  $('coins').h = s.coins.map(c => {
    const active = /^bid /.test(c.decision || '') || c.position;
    const status = c.position || c.entry || c.blocked || c.disabled || c.decision || '';
    return `<div class="coin ${active ? 'active' : ''}"><div class="top"><span class="name">${esc(c.coin)}</span>` +
      `<span class="left">${c.secs_left != null ? Math.floor(c.secs_left / 60) + ':' + String(c.secs_left % 60).padStart(2, '0') : ''}</span></div>` +
      `<div class="px"><span><span class="side up">↑</span> ${cents(c.up_ask)}</span><span><span class="side dn">↓</span> ${cents(c.down_ask)}</span></div>` +
      `<div class="st" title="${esc(status)}">${esc(status)}</div></div>`;
  }).join('');

  // Trades for the chosen period.
  const tSince = s.now - PERIODS[prefs.range];
  const allShown = s.trades.filter(t => (t.placed_at || 0) >= tSince);
  // the summary counts every settled bet in the period (from the full history), not just the rows listed
  const inRange = s.series.filter(p => (p.ts || 0) >= tSince);
  const tp2 = inRange.reduce((t, x) => t + x.pnl, 0);
  const tw = inRange.filter(p => p.pnl > 0).length, tl = inRange.length - tw;
  const openN = allShown.filter(t => t.status === 'open').length;
  $('tradesub').textContent = inRange.length || openN
    ? `${inRange.length} settled${openN ? ` + ${openN} open` : ''} · ${tw}–${tl} · ${money(tp2, true)} · ${PERIOD_LABEL[prefs.range]}`
    : `No bets in the ${PERIOD_LABEL[prefs.range]}`;
  document.querySelectorAll('#rangeseg button').forEach(b => b.classList.toggle('on', b.dataset.r === prefs.range));
  const pages = Math.max(1, Math.ceil(allShown.length / TRADE_PAGE));
  tradePage = Math.min(tradePage, pages - 1);
  const shown = tradeAll ? allShown : allShown.slice(tradePage * TRADE_PAGE, (tradePage + 1) * TRADE_PAGE);
  $('tradepager').h = allShown.length > TRADE_PAGE ? (tradeAll
      ? `<span>All ${allShown.length} shown</span><button data-pg="less">Show fewer</button>`
      : `<button data-pg="prev" ${tradePage ? '' : 'disabled'}>‹ Newer</button><span>Page ${tradePage + 1} of ${pages}</span>` +
        `<button data-pg="next" ${tradePage < pages - 1 ? '' : 'disabled'}>Older ›</button><button data-pg="all">View all</button>`) +
      (s.stats.trades_total > s.trades.length ? `<span>(latest ${s.trades.length} of ${s.stats.trades_total} listed)</span>` : '') : '';
  window._tradeIds = shown.map(t => t.id);
  const tkey = JSON.stringify(shown) + prefs.tz + prefs.odds;
  if (tkey !== lastTrades) { lastTrades = tkey;
  $('trades').innerHTML = shown.length ? shown.map(t => {
    const up = t.outcome === 'UP';
    const amt = t.status === 'open' ? `<span class="mut">${money(t.cost)}</span>` :
      `<span class="${+t.pnl >= 0 ? 'pos' : 'neg'}">${money(t.pnl, true)}</span>`;
    const pill = {won: '<span class="pill won">Won</span>', lost: '<span class="pill lost">Lost</span>',
      open: '<span class="pill open">In progress</span>'}[t.status];
    const open = expanded.has(t.id);
    const kv = (k, v) => v == null || v === '' ? '' : `<div class="kv"><span>${k}</span><span>${v}</span></div>`;
    const spread = t.ask != null ? Math.round((+t.ask - +t.price) * 1000) / 10 + (prefs.odds === 'pct' ? ' pts' : '¢') : null;
    const result = t.status === 'open' ? `Result at ${tm(t.closes_at)} (in <span class="cd" data-t="${t.closes_at}"></span>)` :
      `${t.result === 'yes' || t.result === 'no' ? (t.status === 'won' ? 'Your side won' : 'Your side lost') : ''}`;
    const why = t.status === 'open'
      ? `If ${esc(t.coin)} finishes ${up ? 'at or above' : 'below'} where it started this 15 minutes, this pays ${money(t.qty)}. Otherwise the ${money(t.cost)} is lost.`
      : t.status === 'won' ? `Paid ${money(t.payout)} for a ${money(t.cost)} bet.` : `The ${money(t.cost)} bet was lost.`;
    return `<div class="trade ${open ? 'open' : ''}" data-id="${t.id}">` +
      `<div class="row" role="button" tabindex="0" aria-expanded="${open}"><div class="badge">${esc(t.coin)}</div>` +
      `<div><div class="t1">${esc(t.coin)} <span class="side ${up ? 'up' : 'dn'}">${up ? '↑ Up' : '↓ Down'}</span><span class="chev">›</span></div>` +
      `<div class="t2">${t.qty} × ${cents(t.price)} = ${money(t.cost)} · ${dt(t.placed_at)}</div></div>` +
      `<div class="amt">${amt}<br>${pill}</div></div>` +
      `<div class="more"><div class="in"><div class="box">` +
        kv('Status', result) +
        kv('Contract', esc(t.ticker)) +
        kv('15-minute window', t.opens_at ? `${tm(t.opens_at)} – ${tm(t.closes_at)}` : null) +
        kv('Starting price (strike)', t.strike ? '$' + (+t.strike).toLocaleString(undefined, {maximumFractionDigits: 6}) : null) +
        kv('Your bid / the asking price', `${cents(t.price)} / ${t.ask != null ? cents(t.ask) : '–'}${spread ? ' (saved ' + spread + ' per contract)' : ''}`) +
        kv('Bid placed', dt(t.placed_at)) +
        kv('Filled', t.filled_at ? dt(t.filled_at) : null) +
        kv('Contracts', t.qty) +
        kv('Cost', money(t.cost)) +
        kv('Fees', money(t.fees)) +
        kv(t.status === 'open' ? 'Pays if it wins' : 'Paid out', money(t.status === 'open' ? t.qty : (t.payout || 0))) +
        (t.pnl != null ? kv('Profit / loss', `<span class="${+t.pnl >= 0 ? 'pos' : 'neg'}">${money(t.pnl, true)}</span>`) : '') +
        kv('Bids tried on this contract', `${t.bids_on_contract} (this was #${t.attempt})`) +
        `<div class="why">${why}</div>` +
      `</div></div></div></div>`;
  }).join('') : `<div class="empty" style="height:90px">No bets in the ${PERIOD_LABEL[prefs.range]}.</div>`;
  }
  document.querySelectorAll('.cd').forEach(c => c.textContent = mmss(+c.dataset.t - s.now));

  const bids = s.history;
  $('bids').innerHTML = '<tr><th>Time</th><th>Coin</th><th>Side</th><th>Qty</th><th>Bid</th><th>Ask</th><th>Result</th></tr>' +
    bids.map(e => `<tr><td>${tm(e.created_at)}</td><td>${esc(e.coin)}</td><td>${esc(e.outcome)}</td><td>${e.count}</td>` +
      `<td>${cents(e.price)}</td><td>${cents(e.ask_at_entry)}</td><td>${+e.filled_count > 0 ? 'Filled ' + (+e.filled_count) :
        e.state === 'resting' ? 'Waiting' : 'Not filled'}</td></tr>`).join('');

  $('errsum').textContent = s.errors.length ? `Warnings (${s.errors.length}) ›` : 'No warnings ›';
  $('errors').innerHTML = s.errors.map(e => `<tr><td>${dt(e.ts)}</td><td>${esc(e.kind)}</td><td>${esc(e.message)}</td></tr>`).join('');
}

$('tradepager').addEventListener('click', e => {
  const a = e.target.dataset.pg; if (!a) return;
  if (a === 'prev') tradePage = Math.max(0, tradePage - 1);
  if (a === 'next') tradePage += 1;
  if (a === 'all') tradeAll = true;
  if (a === 'less') { tradeAll = false; tradePage = 0; }
  lastTrades = ''; load();
});
$('rangeseg').addEventListener('click', () => { tradePage = 0; });
