"""2.0 The Big Fat Cat Update: Cat Nap (status, why no bet, recovery, recap, diagnostics) and the Cat Council."""
import json
from decimal import Decimal as D

import pytest

from favbot import catnap, council, council_ai, vault
from favbot.dashboard import build_state
from tests.conftest import T0
from tests.test_execution_engine import CLOSE, make_bot


# ---- Why no bet? in plain words --------------------------------------------------------------------
@pytest.mark.parametrize("raw,kind,needle", [
    ("waiting (865s left)", "timing", "Too early"),
    ("final 60s: no new bids", "timing", "last minute"),
    ("no favourite in 0.88-0.97", "strategy", "88¢ and 97¢"),
    ("UP favourite, but this model only bets DOWN", "strategy", "only bet Down"),
    ("UP spread 0.05 > 0.03", "strategy", "wider than your limit (3¢)"),
    ("bid UP 0.91 (ask 0.93)", "betting", "Up at 91¢"),
    ("max open positions (2/2)", "risk", "2 of the 2"),
    ("daily loss limit reached (-4.40)", "risk", "loss limit"),
    ("stale book (8.2s)", "risk", "too old"),
    ("clock skew +3.10s exceeds 2.0s", "risk", "+3.10s"),
    ("recovering: the computer was asleep or busy for 600 s", "risk", "Re-checking"),
    ("turned off in settings", "off", "turned off"),
])
def test_reasons_in_plain_words(raw, kind, needle):
    plain, k = catnap.explain(raw)
    assert k == kind and needle in plain


# ---- one status --------------------------------------------------------------------------------------
async def test_status_goes_through_the_states(tmp_path, clock):
    clock.t = CLOSE - 600
    bot, md, store, sim = make_bot(tmp_path, clock)
    await bot.startup()
    await bot.engines[0].tick()
    s = catnap.status(bot)
    assert s["level"] == "watching" and "opens in" in s["detail"]
    bot.paused = True
    s = catnap.status(bot)
    assert s["level"] == "paused" and s["action"]["type"] == "resume"
    bot.paused = False
    bot.recovering = "the internet connection came back"
    assert catnap.status(bot)["headline"] == "Re-checking with Kalshi"
    bot.recovering = None
    store.set_kill("test")
    assert catnap.status(bot)["level"] == "attention"
    store.clear_kill()
    clock.t = CLOSE - 200
    await bot.refresh_exchange_status()                            # (the status loop does this every 15 s)
    await bot.engines[0].tick()                                    # a bid is placed
    s = catnap.status(bot)
    assert s["level"] == "running" and "bid is waiting" in s["detail"]
    w = catnap.why_no_bet(bot)
    assert w[0]["coin"] == "ETH" and w[0]["kind"] == "betting"


# ---- sleep/wake and connection recovery ---------------------------------------------------------------
async def test_recovery_blocks_bets_reconciles_then_resumes(tmp_path, clock):
    clock.t = CLOSE - 200
    bot, md, store, sim = make_bot(tmp_path, clock)
    await bot.startup()
    calls = []
    real = bot.execution.reconcile

    async def spy(series, now=None):
        calls.append((series, bot.cancel_reason()))                    # no new bets while re-checking
        return await real(series, now) if now else await real(series)
    bot.execution.reconcile = spy
    bot.marks["old"] = object()
    ok = await bot.recover("the computer was asleep or busy for 900 s")
    assert calls[0][1].startswith("recovering")
    calls = [c[0] for c in calls]
    assert ok and calls == ["KXETH15M"] and bot.recovering is None and bot.cancel_reason() is None
    assert "old" not in bot.marks                                       # old prices forgotten
    assert bot.last_recovery["why"].startswith("the computer was asleep")
    ev = [e["kind"] for e in store._q("SELECT kind FROM events ORDER BY id")]
    assert "recovering" in ev and "recovered" in ev


async def test_failed_recovery_keeps_trading_blocked(tmp_path, clock):
    from favbot.providers.base import TransportError
    bot, md, store, sim = make_bot(tmp_path, clock)
    await bot.startup()

    async def down(*a, **k):
        raise TransportError("no internet", False)
    bot.execution.reconcile = down
    assert not await bot.recover("the internet connection came back")
    assert bot.recovering and bot.cancel_reason().startswith("recovering")


# ---- recap and diagnostics --------------------------------------------------------------------------------
def _settle(store, i, won, ts, coin="ETH", fee="0.00"):
    eid = store.insert_intent(mode="paper", series=f"KX{coin}15M", coin=coin, ticker=f"KX{coin}15M-{i}", leg="yes", outcome="UP",
                              price=D("0.93"), count=4, max_loss=D("3.72"), expiration_ts=1, client_order_id=f"c{i}", max_attempts=20)
    store._x("UPDATE entries SET filled_count='4', fill_cost='3.72', fees=?, state='done', order_id=? WHERE id=?", (fee, f"o{i}", eid))
    pay = D(4) if won else D(0)
    store.settle_entry(eid, "yes" if won else "no", pay, pay - D("3.72") - D(fee), now=ts)


async def test_recap_counts_today(tmp_path, clock):
    import time as _t
    clock.t = _t.time()
    bot, md, store, sim = make_bot(tmp_path, clock)
    _settle(store, 1, True, clock.t - 60, fee="0.02")
    _settle(store, 2, False, clock.t - 30, coin="SOL")
    _settle(store, 3, True, clock.t - 3 * 86400)                       # not today
    r = catnap.recap(bot, "today", {"ts": clock.t, "models": [{"id": "twin", "name": "Simulated you", "bets": 12, "pnl": 1.5, "roi": 0.01}]})
    assert r["bets"] == 2 and r["wins"] == 1 and r["fees"] == "0.02"
    assert D(r["pnl"]) == D("0.28") - D("0.02") - D("3.72") and r["litterbox"]["twin"]["bets"] == 12
    assert r["best_coin"][0] == "ETH" and r["worst_coin"][0] == "SOL"


async def test_diagnostics_never_contain_secrets(tmp_path, clock, monkeypatch):
    bot, md, store, sim = make_bot(tmp_path, clock)
    await bot.startup()
    store.log_event("warning", "kalshi_key", "key a1b2c3d4-e5f6-4711-8899-aabbccddeeff refused for me@example.com, balance $123.45")
    (tmp_path / "console.log").write_text("ERROR token=SECRETTOKEN123 api_key=sk-ant-abcdef1234567890 failed\n")
    monkeypatch.setenv("KALSHI_API_KEY_ID", "a1b2c3d4-e5f6-4711-8899-aabbccddeeff")
    d = json.dumps(catnap.diagnostics(bot, {"installed": "2.0.0"}))
    for secret in ("a1b2c3d4-e5f6", "me@example.com", "123.45", "SECRETTOKEN123", "sk-ant-abcdef", "capital_cap_usd"):
        assert secret not in d, secret
    assert '"version": "2.0.0"' in d and "<email>" in d and "$<amount>" in d


# ---- Cat Council ------------------------------------------------------------------------------------------
@pytest.mark.parametrize("q,intent,home", [
    ("Why did trading stop?", "stopped", "chonk"), ("why isn't it betting on ETH", "nobet", "chonk"),
    ("What happened while I was away?", "away", "biscuit"), ("what's my balance", "balance", "biscuit"),
    ("How much risk am I taking?", "risk", "chonk"), ("set clump to bold", "clump", "chonk"),
    ("Should I switch strategies?", "recommend", "chill"), ("how is the litter box doing", "litterbox", "chill"),
    ("Why did I lose on SOL?", "losses", "katya"), ("compare Ask Buyer and Down Dog", "compare", "katya"),
    ("is anything unusual", "unusual", "katya"), ("ETH price now?", "market", "biscuit"), ("daily recap", "recap", "biscuit"),
    ("create an experiment at tiny", "experiment", "chill"), ("is it working", "working", "chonk"),
])
def test_understands_common_questions(q, intent, home):
    got, det = council.understand(q)
    assert got == intent and council.HOME[got] == home


async def _state(tmp_path, clock, **kw):
    bot, md, store, sim = make_bot(tmp_path, clock)
    await bot.startup()
    await bot.engines[0].tick()
    await bot.portfolio.snapshot()
    return bot, build_state(bot), store


async def test_why_did_trading_stop_explains_and_offers_the_next_step(tmp_path, clock):
    clock.t = CLOSE - 600
    bot, st, store = await _state(tmp_path, clock)
    bot.paused = True
    store.log_event("warning", "pause", "paused from dashboard: no new bids, resting bids cancelled")
    a = council.answer(bot, build_state(bot), "Why did trading stop?")
    assert a["cat"] == "chonk" and "Paused by you" in a["text"]
    assert any(b["label"] == "App status" for b in a["blocks"])
    assert any("paused from dashboard" in i for b in a["blocks"] for i in b["items"])          # from the bot's log
    assert {"type": "resume", "label": "Resume betting"}.items() <= a["actions"][0].items()


async def test_same_facts_any_cat_and_money_is_labelled(tmp_path, clock):
    bot, st, store = await _state(tmp_path, clock)
    a = council.answer(bot, st, "what's my balance", "biscuit")
    b = council.answer(bot, st, "what's my balance", "chill")
    assert a["blocks"] == b["blocks"] and a["text"] == b["text"]                # consistent facts
    assert a["intro"] != b["intro"]                                              # distinct personalities
    assert a["blocks"][0]["label"] == "Practice money" and a["blocks"][0]["as_of"]
    assert "Biscuit" in b["intro"]                                               # Chill points to whose area it is


async def test_says_unavailable_instead_of_inventing(tmp_path, clock):
    bot, st, store = await _state(tmp_path, clock)
    a = council.answer(bot, st, "how is the litter box doing")
    assert a["unavailable"] and "isn't running" in a["unavailable"][0]
    assert not any(b["label"] == "Simulated (fake money)" for b in a["blocks"])
    a = council.answer(bot, st, "Why did I lose?")
    assert "No settled bets yet" in a["text"]


async def test_actions_only_offer_previews_and_fake_money(tmp_path, clock):
    bot, st, store = await _state(tmp_path, clock)
    st["litterbox"] = {"summary": {"ts": T0, "models": [{"id": "original", "name": "Original", "bets": 30, "roi": -0.01, "se": 0.02, "pnl": -1}]}}
    a = council.answer(bot, st, "set clump to bold")
    assert a["actions"][0] == {"type": "preview_clump", "label": "Preview Bold", "level": 4}
    a = council.answer(bot, st, "create an experiment of Original at chonky with fake money")
    assert a["actions"][0]["type"] == "experiment" and a["actions"][0]["base"] == "original" and a["actions"][0]["level"] == 5
    kinds = {x["type"] for q in ("why did trading stop", "set clump to tiny", "why did I lose", "daily recap")
             for x in council.answer(bot, st, q)["actions"]}
    assert kinds <= {"open", "resume", "preview_clump", "experiment", "ask", "recap", "whynobet"}   # nothing that trades


async def test_market_answer_has_live_label_and_time(tmp_path, clock):
    clock.t = CLOSE - 200
    bot, st, store = await _state(tmp_path, clock)
    a = council.answer(bot, st, "ETH price now?")
    blk = a["blocks"][0]
    assert blk["label"] == "Live market" and blk["as_of"] and "ETH: Up" in blk["items"][0]
    a = council.answer(bot, st, "DOGE price now?")
    assert "isn't one of your coins" in " ".join(a["unavailable"])


# ---- optional AI: off by default, no secrets, falls back --------------------------------------------------------
class FakeKR:
    def __init__(self):
        self.d = {}

    def set_password(self, s, a, p):
        self.d[(s, a)] = p

    def get_password(self, s, a):
        return self.d.get((s, a))

    def delete_password(self, s, a):
        self.d.pop((s, a), None)


async def test_ai_mode_uses_lookups_never_sees_keys_and_falls_back(tmp_path, clock, monkeypatch):
    monkeypatch.setattr(vault, "_keyring", lambda kr=FakeKR(): kr)
    bot, st, store = await _state(tmp_path, clock)
    root = tmp_path
    # off by default: the built-in answer
    a = await council_ai.ask(bot, st, "what's my balance", None, None, root)
    assert a["mode"] == "local"
    vault.save_secret(root, council_ai.SECRET, "sk-ant-test-0000000000000000000000")
    council_ai.save_settings(store, enabled=True, model="claude-haiku-5-5", consented_at=1)
    sent = []

    async def fake_post(key, body):
        sent.append((key, json.dumps(body)))
        if len(sent) == 1:
            return {"stop_reason": "tool_use", "usage": {"input_tokens": 100, "output_tokens": 20},
                    "content": [{"type": "tool_use", "id": "t1", "name": "account", "input": {}}]}
        return {"stop_reason": "end_turn", "usage": {"input_tokens": 150, "output_tokens": 40},
                "content": [{"type": "text", "text": "You have $1000.00 of practice money, as of just now."}]}
    a = await council_ai.ask(bot, st, "what's my balance", None, None, root, post=fake_post)
    assert a["mode"] == "ai" and "practice money" in a["text"] and a["blocks"]               # facts still from the app
    assert all("sk-ant-test" not in body for _, body in sent)                                 # key only in the header
    assert '"tool_result"' in sent[1][1] and "Practice money" in sent[1][1]
    u = council_ai.settings(store)["usage"]
    assert u["input_tokens"] == 250 and u["output_tokens"] == 60 and u["questions"] == 1

    async def broken(key, body):
        raise TimeoutError()
    a = await council_ai.ask(bot, st, "what's my balance", None, None, root, post=broken)
    assert a["mode"] == "local" and "aren't available" in a["note"]                             # app carries on


async def test_watcher_notices_a_sleep_and_a_returning_connection(tmp_path, clock):
    import asyncio
    from types import SimpleNamespace
    bot, md, store, sim = make_bot(tmp_path, clock)
    await bot.startup()
    seen, steps = [], {"i": 0}

    async def fake_recover(why):
        seen.append(why)
        bot.stop.set()
        return True
    bot.recover = fake_recover

    async def fast_sleep(s):                       # one "second" per loop; the 3rd one is a 10-minute sleep
        steps["i"] += 1
        clock.advance(600 if steps["i"] == 3 else 1)
        await asyncio.sleep(0)
    bot._sleep = fast_sleep
    await asyncio.wait_for(bot.watch_loop(), 2)
    assert seen and "asleep" in seen[0] and "600" in seen[0]

    # the internet drops, then comes back: re-check before trading
    bot.stop.clear(); seen.clear(); steps["i"] = 0
    bot.alerts = SimpleNamespace(_net_down=True)

    async def fast_sleep2(s):
        steps["i"] += 1
        clock.advance(1)
        if steps["i"] == 3:
            bot.alerts._net_down = False
        await asyncio.sleep(0)
    bot._sleep = fast_sleep2
    await asyncio.wait_for(bot.watch_loop(), 2)
    assert seen == ["the internet connection came back"]
