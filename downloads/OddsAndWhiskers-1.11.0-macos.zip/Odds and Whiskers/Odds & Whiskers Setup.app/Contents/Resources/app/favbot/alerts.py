"""Optional SMTP email alerts. Every subject carries SIMULATED / DEMO-MONEY / REAL-MONEY.

What gets sent is chosen in the dashboard settings (stored in the database):
- losses / wins: a short email when a bet settles;
- summary: a morning summary at the chosen hour (local time);
- problems: errors (rate-limited per kind), kill switch, daily loss limit, bot stopped,
  and network outages (collapsed into one "lost" and one "restored" email).
`alerts.result_coins` in the config still forces win/loss emails for those coins.
"""
from __future__ import annotations

import logging
import os
import smtplib
import threading
import time
from email.message import EmailMessage

from .config import AlertsCfg

logger = logging.getLogger("favbot.alerts")

LABELS = {"paper": "SIMULATED", "demo": "DEMO-MONEY", "live": "REAL-MONEY"}
DEFAULT_PREFS = {"losses": True, "wins": False, "summary": True, "summary_hour": 8, "problems": True}


class Alerts:
    def __init__(self, cfg: AlertsCfg, mode: str, sender_fn=None, prefs_fn=None):
        self.cfg = cfg
        self.mode = mode
        self.label = LABELS[mode]
        self._last: dict[str, float] = {}
        self._net_down = False
        self._net_errors: list[float] = []
        self._lock = threading.Lock()
        self._send_fn = sender_fn or self._smtp_send
        self.prefs_fn = prefs_fn
        self.net_since = None
        self.enabled = bool(cfg.enabled and cfg.smtp_host and cfg.recipients)

    def prefs(self) -> dict:
        p = dict(DEFAULT_PREFS)
        if self.prefs_fn:
            try:
                p.update(self.prefs_fn() or {})
            except Exception:  # noqa: BLE001
                pass
        return p

    def status(self) -> dict:
        return {"configured": self.enabled, "recipients": list(self.cfg.recipients) if self.enabled else [],
                "has_password": bool(os.environ.get(self.cfg.password_env)), "prefs": self.prefs()}

    def _smtp_send(self, subject: str, body: str) -> None:
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = self.cfg.sender or self.cfg.username
        msg["To"] = ", ".join(self.cfg.recipients)
        msg.set_content(body)
        pw = os.environ.get(self.cfg.password_env, "")
        with smtplib.SMTP(self.cfg.smtp_host, self.cfg.smtp_port, timeout=20) as s:
            if self.cfg.starttls:
                s.starttls()
            if self.cfg.username:
                s.login(self.cfg.username, pw)
            s.send_message(msg)

    def _compose(self, subject: str, body: str) -> tuple[str, str]:
        full = f"[Odds & Whiskers {self.label}] {subject}"
        body = (f"{body}\n\nMode: {self.label}\n"
                f"Time: {time.strftime('%a %b %d, %I:%M %p', time.localtime())} "
                f"({time.strftime('%H:%M', time.gmtime())} UTC)\n")
        return full, body

    def send(self, subject: str, body: str) -> None:
        if not self.enabled:
            return
        full, body = self._compose(subject, body)

        def run():
            try:
                self._send_fn(full, body)
            except Exception as e:  # noqa: BLE001
                logger.warning("alert email failed: %s", type(e).__name__)

        threading.Thread(target=run, daemon=True).start()

    def send_now(self, subject: str, body: str) -> None:
        """Blocking send that raises on failure (used by the dashboard's test button)."""
        if not self.enabled:
            raise RuntimeError("email alerts are not set up in config.yaml")
        full, body = self._compose(subject, body)
        self._send_fn(full, body)

    def _problem(self, subject: str, body: str) -> None:
        if self.prefs().get("problems", True):
            self.send(subject, body)

    def error(self, kind: str, msg: str) -> None:
        with self._lock:
            now = time.time()
            if now - self._last.get(kind, 0) < self.cfg.error_min_interval_s:
                return
            self._last[kind] = now
        self._problem(f"problem: {kind}", msg)

    def kill(self, reason: str) -> None:
        self._problem("Kill switch ON", f"{reason}\n\nNo new bets; waiting bids cancelled. Bets that already filled are NOT "
                                        "closed by the kill switch: they finish at their 15-minute result.")

    def daily_loss(self, pnl, limit) -> None:
        self._problem("Daily loss limit reached", f"Today's P&L {pnl} reached the limit {limit}. "
                                                  "No new bets until tomorrow (UTC); waiting bids cancelled.")

    def shutdown(self, why: str) -> None:
        self._problem("Bot stopped", why)

    def result(self, coin: str, ticker: str, won: bool, pnl, detail: str) -> None:
        p = self.prefs()
        forced = coin.upper() in {c.upper() for c in self.cfg.result_coins}
        if not (forced or (won and p.get("wins")) or (not won and p.get("losses"))):
            return
        self.send(f"{'Won' if won else 'LOST'} {coin} {pnl}", f"{ticker}\n{detail}")

    def summary(self, subject: str, body: str) -> None:
        if self.prefs().get("summary"):
            self.send(subject, body)

    def network(self, ok: bool, err: str = "") -> None:
        """Collapse an outage into one 'lost' and one 'restored' email."""
        now = time.time()
        with self._lock:
            if ok:
                self._net_errors.clear()
                if self._net_down:
                    self._net_down = False
                    restored = True
                else:
                    return
            else:
                self._net_errors = [t for t in self._net_errors if now - t < 60] + [now]
                if self._net_down or len(self._net_errors) < 3:
                    return
                self._net_down = True
                self.net_since = now
                restored = False
        if restored:
            logger.warning("network restored")
            self._problem("Network restored", "Exchange API reachable again.")
        else:
            logger.error("network lost: %s", err)
            self._problem("Network lost", f"Repeated failures reaching the exchange API: {err}")
