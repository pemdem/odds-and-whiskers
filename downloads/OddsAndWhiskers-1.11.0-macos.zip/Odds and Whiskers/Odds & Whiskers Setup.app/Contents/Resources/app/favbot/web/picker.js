// ---- Version picker (Cat Corner): a model + coins + risk level, each choice showing how the others did ----
let pickKey = null, pickCoins = null, lastPick = '';
const seOf = (w, n) => { const q = Math.min(0.995, Math.max(0.5, w / n)); return Math.sqrt((1 - q) / q) / Math.sqrt(n); };

function comb(src, coins, nKey) {               // add up one model's per-coin results for the picked coins
  let n = 0, w = 0, p = 0, st = 0;
  for (const c of coins) { const x = (src || {})[c]; if (!x) continue; n += x[nKey]; w += x.wins; p += x.pnl; st += x.staked; }
  return n && st ? {n, wins: w, pnl: p, roi: p / st, se: seOf(w, n)} : {n: 0};
}
const fresh = (g, coins) => comb(g.fresh, coins, 'bets');
const past = (g, coins) => comb(g.past, coins, 'n');
const kN = n => n >= 1000 ? (n / 1000).toFixed(1) + 'k' : String(n);
const rTxt = (r, small) => r && r.n ? `<span class="${r.roi >= 0 ? 'pos' : 'neg'}">${r.roi >= 0 ? '+' : ''}${(r.roi * 100).toFixed(1)}%</span>` +
  (small ? '' : ` <span class="mut">±${(2 * r.se * 100).toFixed(1)}</span>`) + ` <span class="mut">${kN(r.n)}</span>` : '<span class="mut">–</span>';

function verdictOf(f) {
  if (!f.n) return ['wait', 'No fake-money bets yet', 'The Litter Box hasn’t tried this on these coins yet.'];
  if (f.n < 100) return ['wait', 'Too few fake bets', `Only ${f.n} fake bets — anything can happen over that few. Needs about 100+.`];
  if (f.roi - 2 * f.se > 0) return ['pass', 'Making money on fresh markets', 'Profitable even at the low end of its luck range, with fake money. Still an estimate: fake fills can be kinder than real ones.'];
  if (f.roi + 2 * f.se < 0) return ['fail', 'Losing on fresh markets', 'Losing money even at the high end of its luck range, with fake money.'];
  return ['prom', 'Within luck', 'The result so far could be luck either way. Give it more time.'];
}

function renderPicker(s) {
  const P = s.picker, box = $('pickbody');
  if (!P || !box || !s.presets) return;
  if (pickKey === null || !P.models.find(g => g.key === pickKey)) pickKey = P.live.key || 'original';
  if (pickCoins === null) pickCoins = new Set(P.live.coins && P.live.coins.length ? P.live.coins : P.coins);
  if (clump === null) clump = s.presets.current.level || 3;
  const key = JSON.stringify([P, pickKey, [...pickCoins], clump, s.presets.current.level, s.presets.pending_limits]);
  if (key === lastPick) return;
  if (document.activeElement && document.activeElement.id === 'pkclump') return;       // mid-slide
  lastPick = key;
  const coins = P.coins.filter(c => pickCoins.has(c)), g = P.models.find(x => x.key === pickKey);
  const scored = P.models.map(m => ({m, f: fresh(m, coins), p: past(m, coins)}));
  const best = scored.filter(x => x.f.n >= 30).sort((a, b) => b.f.roi - a.f.roi)[0];
  const BADGE = {original: ['wait', 'Original', 'The strategy you started with. The fixed yardstick.'],
    recommended: ['pass', 'Recommended', 'Beat the Original on new markets by more than luck.'],
    candidate: ['open', 'Being tested', 'The learning loop is testing this on fresh markets right now.']};
  // models: their numbers are for the coins you picked
  const models = scored.map(({m, f, p}) => {
    const b = BADGE[m.kind];
    return `<button class="pk-model ${m.key === pickKey ? 'on' : ''}" data-key="${esc(m.key)}" data-tip="${esc(m.blurb || '')} Numbers are for the coins you picked.">` +
      `<span class="pk-n">${esc(m.name)}${m.is_live ? ' <span class="pill won" data-tip="This is the strategy your real bot uses now.">live</span>' : ''}` +
      `${b && b[1] !== m.name ? ` <span class="pill ${b[0]}" data-tip="${esc(b[2])}">${b[1]}</span>` : ''}` +
      `${best && best.m === m ? ' <span class="pk-star" data-tip="Best fake-money return per $ on these coins (30+ bets). Could still be luck.">★</span>' : ''}</span>` +
      `<span class="pk-d">${esc((m.describe || []).join(' · '))}</span>` +
      `<span class="pk-r"><span data-tip="Fake money on live markets since the Litter Box season began: return per $ ± luck range, then the number of bets."><i class="src">fake</i> ${rTxt(f, true)}</span>` +
      `<span data-tip="Backtrack: the same rule replayed on past prices. Waiting-at-the-bid fills there are estimates."><i class="src">past</i> ${rTxt(p, true)}</span></span></button>`;
  }).join('');
  // coins: their numbers are for the model you picked
  const chips = P.coins.map(c => {
    const f = fresh(g, [c]), p = past(g, [c]);
    return `<button class="pk-coin ${pickCoins.has(c) ? 'on' : ''}" data-coin="${c}" aria-pressed="${pickCoins.has(c)}" ` +
      `data-tip="${c} with ${esc(g.name)}: fake money on live markets, and past data. Click to add or remove it.">` +
      `<b>${c}</b><span><i class="src">fake</i> ${rTxt(f, true)}</span><span><i class="src">past</i> ${rTxt(p, true)}</span></button>`;
  }).join('');
  const f = fresh(g, coins), p = past(g, coins), v = verdictOf(f);
  const L = s.presets.levels[clump - 1], cur = s.presets.current;
  const same = g.is_live && coins.length === P.live.coins.length && coins.every(c => P.live.coins.includes(c));
  const sameLevel = clump === cur.level;
  box.innerHTML =
    `<div class="pk-grid"><div class="pk-col"><div class="pk-h" data-tip="Each model is one way of choosing bets. Pick one to see how it did on each coin.">1 · Model</div>${models}</div>` +
    `<div class="pk-col"><div class="pk-h" data-tip="Pick the coins this version bets on. Each coin shows how the model you picked did on it.">2 · Coins</div>` +
    `<div class="pk-coins">${chips}</div><div class="pk-quick">` +
      `<button data-q="all" data-tip="Bet on every coin.">All coins</button>` +
      (g.default_coins ? `<button data-q="model" data-tip="The coins this model was built for.">Its coins</button>` : '') +
      `<button data-q="fresh" data-tip="Only coins where this model is making money with fake money so far (20+ bets). Picking winners after the fact can be luck.">Up on fake money</button>` +
      `<button data-q="past" data-tip="Only coins where this model made money on past data (30+ bets). Past winners often don’t repeat.">Up on past data</button></div>` +
    `<div class="pk-h" style="margin-top:14px" data-tip="How much to risk: bet size, money at risk at once and bets open at once. It never changes which bets are taken.">3 · Risk (Clump)</div>` +
    `<input type="range" min="1" max="5" step="1" value="${clump}" id="pkclump" class="clump" aria-label="Risk level">` +
    `<div class="clumpticks">${s.presets.levels.map(l => `<span class="${l.level === cur.level ? 'cur' : ''}" data-tip="${l.level === cur.level ? 'Your bot’s level now. ' : ''}${esc(l.name)}: ${money(l.max_loss_per_position_usd)} per bet, up to ${l.max_open_positions} open at once.">${l.name}</span>`).join('')}</div>` +
    `<div class="pk-sum"><div class="pk-title">${esc(g.name)} · ${coins.length === P.coins.length ? 'all coins' : esc(coins.join(', ') || 'no coins')} · ${esc(L.name)}</div>` +
      `<div class="facts">` +
        tile('<span data-tip="Litter Box fake-money bets on live markets, these coins only. Paper fills and fees included.">Fake money, fresh markets</span>', `${rTxt(f)}`) +
        tile(`<span data-tip="Backtrack replay of past prices, these coins only. Bid fills there are estimates.">Past ${((s.backtrack || {}).results || {}).days || ''} days</span>`, `${rTxt(p)}`) +
        tile('<span data-tip="The most one bet can lose at this risk level.">Per bet</span>', money(L.max_loss_per_position_usd)) +
      `</div><div class="pk-ver"><span class="pill ${v[0]}" data-tip="${esc(v[2])}">${v[1]}</span> ` +
      `<span class="mut">Return per $ bet ± luck range · number of bets. “Fake” counts more than “past”: it happened after the idea was made.</span></div>` +
      (P.models.length < 2 ? `<div class="sub">Turn on the Litter Box to see more models here.</div>` : '') +
      `<div class="pre-act"><button class="primary" id="pkapply" ${(same && sameLevel) || !coins.length ? 'disabled' : ''} ` +
      `data-tip="Saves this version for your real bot. Strategy and coins apply after a restart; new risk limits also need your typed confirmation.">` +
      `${same && sameLevel ? 'This is your bot’s version' : 'Use this version'}</button>` +
      (s.presets.pending_limits ? `<span class="tip2" style="margin:0"><b>New limits waiting</b>Double-click <b>Confirm new limits</b> in your Odds & Whiskers folder.</span>` : '') +
      `</div></div></div></div>`;
}

$('pickbody').addEventListener('click', async e => {
  const s = window._state, P = s && s.picker; if (!P) return;
  const m = e.target.closest('.pk-model'), c = e.target.closest('.pk-coin'), q = e.target.closest('[data-q]');
  if (m) { pickKey = m.dataset.key; const g = P.models.find(x => x.key === pickKey);
    if (g && g.default_coins) pickCoins = new Set(g.default_coins); }
  else if (c) { const k = c.dataset.coin; if (pickCoins.has(k)) { if (pickCoins.size > 1) pickCoins.delete(k); } else pickCoins.add(k); }
  else if (q) {
    const g = P.models.find(x => x.key === pickKey);
    const pick = {all: () => P.coins, model: () => g.default_coins || P.coins,
      fresh: () => P.coins.filter(k => { const r = fresh(g, [k]); return r.n >= 20 && r.roi > 0; }),
      past: () => P.coins.filter(k => { const r = past(g, [k]); return r.n >= 30 && r.roi > 0; })}[q.dataset.q]();
    if (!pick.length) { alert('No coin qualifies yet for this model.'); return; }
    pickCoins = new Set(pick);
  } else if (e.target.id === 'pkapply') {
    const g = P.models.find(x => x.key === pickKey), coins = P.coins.filter(k => pickCoins.has(k));
    const cur = s.presets.current, L = s.presets.levels[clump - 1], f = fresh(g, coins);
    const body = {strategy: 'model', key: pickKey, coins};
    if (clump !== cur.level) body.level = clump;
    const proven = g.kind === 'original' || g.kind === 'recommended';
    if (!confirm(`Switch your REAL-MONEY bot to:\n\n${g.name} on ${coins.join(', ')}${body.level ? `\nRisk: ${L.name} (${money(L.max_loss_per_position_usd)} per bet)` : ''}\n\n` +
      (proven ? '' : `⚠ This version has NOT passed the fresh-market test. Fake money so far: ${f.n ? `${(f.roi * 100).toFixed(1)}% per $ over ${f.n} bets` : 'no bets'}.\n\n`) +
      `Strategy and coins take effect after you restart the bot (banner: Restart now).` +
      (body.level && s.mode === 'live' ? ' New risk limits also need your typed confirmation (Confirm new limits).' : '') + ' You can go back to the original any time.')) return;
    try { const r = await postJSON('/api/apply', body);
      alert(r.pending_limits ? 'Saved. Restart the bot to use the new strategy/coins, and double-click “Confirm new limits” in your Odds & Whiskers folder to make the new limits live.'
                             : 'Saved. Restart the bot (banner at the top) to use it.');
    } catch (err) { alert(err.message); }
  } else return;
  lastPick = ''; lastPreset = ''; load();
});
$('pickbody').addEventListener('input', e => { if (e.target.id === 'pkclump') { clump = +e.target.value; } });
$('pickbody').addEventListener('change', e => { if (e.target.id === 'pkclump') { e.target.blur(); lastPick = ''; lastPreset = ''; load(); } });
