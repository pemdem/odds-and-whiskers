"""Decimal money helpers, Kalshi and Polymarket US fee formulas and the price grid.

All money is Decimal. Floats never touch a price, a count or a balance.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_EVEN, Decimal

ZERO = Decimal("0")
ONE = Decimal("1")
CENT = Decimal("0.01")
TICK4 = Decimal("0.0001")

TAKER_RATE = Decimal("0.07")
MAKER_RATE = Decimal("0.0175")

# fee_type values from GET /series/{ticker}. Anything else: do not trade.
NO_MAKER_FEE_TYPES = {"quadratic"}
MAKER_FEE_TYPES = {"quadratic_with_maker_fees", "quadratic_with_combo_maker_fees"}
# Polymarket US (docs.polymarket.us/fees): taker fee = 0.0695 x contracts x p x (1 - p), rounded to the cent
# half-to-even. Makers get a rebate on some volume tiers; the simulation assumes none, which is the cautious side.
POLYMARKET_US = "polymarket_us"
PM_TAKER_RATE = Decimal("0.0695")
KNOWN_FEE_TYPES = NO_MAKER_FEE_TYPES | MAKER_FEE_TYPES | {POLYMARKET_US}


class UnknownFeeType(ValueError):
    pass


def d(x) -> Decimal:
    """Convert API values (strings, ints) to Decimal. Floats go through repr to avoid binary noise."""
    if isinstance(x, Decimal):
        return x
    if isinstance(x, bool):
        raise TypeError("bool is not money")
    if isinstance(x, float):
        return Decimal(repr(x))
    if x is None or x == "":
        raise ValueError("empty money value")
    return Decimal(str(x))


def d_or_zero(x) -> Decimal:
    if x is None or x == "":
        return ZERO
    return d(x)


def ceil_to_cent(x: Decimal) -> Decimal:
    return x.quantize(CENT, rounding=ROUND_CEILING)


def _check_fee_type(fee_type: str) -> None:
    if fee_type not in KNOWN_FEE_TYPES:
        raise UnknownFeeType(f"unrecognised fee_type {fee_type!r}; refusing to trade")


def taker_fee(fee_type: str, multiplier, contracts, price) -> Decimal:
    _check_fee_type(fee_type)
    p = d(price)
    if fee_type == POLYMARKET_US:
        return (PM_TAKER_RATE * d(multiplier) * d(contracts) * p * (ONE - p)).quantize(CENT, rounding=ROUND_HALF_EVEN)
    return ceil_to_cent(TAKER_RATE * d(multiplier) * d(contracts) * p * (ONE - p))


def maker_fee(fee_type: str, multiplier, contracts, price) -> Decimal:
    _check_fee_type(fee_type)
    if fee_type in NO_MAKER_FEE_TYPES or fee_type == POLYMARKET_US:
        return ZERO
    p = d(price)
    return ceil_to_cent(MAKER_RATE * d(multiplier) * d(contracts) * p * (ONE - p))


def fmt_price(p: Decimal) -> str:
    return f"{d(p).quantize(TICK4):f}"


def fmt_count(n) -> str:
    return f"{d(n).quantize(CENT):f}"


def fmt_usd(x: Decimal) -> str:
    return f"${d(x).quantize(CENT):,f}"


@dataclass(frozen=True)
class PriceRange:
    start: Decimal
    end: Decimal
    step: Decimal


@dataclass(frozen=True)
class PriceGrid:
    """The market's `price_ranges`. An off-grid price is rejected by the exchange."""

    ranges: tuple[PriceRange, ...]

    @classmethod
    def from_api(cls, raw) -> "PriceGrid":
        if not raw:
            raise ValueError("market has no price_ranges")
        return cls(tuple(PriceRange(d(r["start"]), d(r["end"]), d(r["step"])) for r in raw))

    @classmethod
    def default(cls) -> "PriceGrid":
        return cls.from_api([
            {"start": "0.0000", "end": "0.1000", "step": "0.0010"},
            {"start": "0.1000", "end": "0.9000", "step": "0.0100"},
            {"start": "0.9000", "end": "1.0000", "step": "0.0010"},
        ])

    def is_valid(self, p: Decimal) -> bool:
        p = d(p)
        if p <= ZERO or p >= ONE:
            return False
        for r in self.ranges:
            if r.start <= p <= r.end and (p - r.start) % r.step == ZERO:
                return True
        return False

    def snap_down(self, p: Decimal) -> Decimal | None:
        """Largest valid price <= p (bids are only ever rounded down)."""
        p = d(p)
        best = None
        for r in self.ranges:
            if r.start <= p <= r.end:
                n = ((p - r.start) / r.step).to_integral_value(rounding=ROUND_FLOOR)
                cand = r.start + n * r.step
                if self.is_valid(cand) and (best is None or cand > best):
                    best = cand
        return best

    def to_api(self) -> list[dict]:
        return [{"start": str(r.start), "end": str(r.end), "step": str(r.step)} for r in self.ranges]
