"""Your Kalshi key, kept securely on this computer (set up from inside the app — no files to edit).

The private key and its Key ID are encrypted with AES-256-GCM into data/vault/kalshi-<mode>.vault. The random
256-bit key that unlocks that file is kept in the operating system's own secret store — the macOS Keychain or
Windows Credential Manager — through `keyring`. So the vault file alone (a copy of the folder, a backup, a cloud
sync) reveals nothing, and nothing is ever uploaded anywhere. The app never shows the key again after saving it.

A key set up the old way (KALSHI_PRIVATE_KEY_FILE / _COMMAND in .env) always takes priority over the vault.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import time
from pathlib import Path

SERVICE = "Odds & Whiskers"
VERSION = 1


class VaultError(RuntimeError):
    pass


def _path(data_root: Path, mode: str) -> Path:
    return Path(data_root) / "vault" / f"kalshi-{mode}.vault"


def _account(data_root: Path, mode: str) -> str:
    # one entry per install (two copies on one computer don't share a key) and per mode (live / demo)
    where = hashlib.sha256(str(Path(data_root).resolve()).lower().encode()).hexdigest()[:12]
    return f"kalshi-{mode}-{where}"


def _aad(mode: str) -> bytes:
    return f"odds-whiskers-vault-v{VERSION}:{mode}".encode()


def _keyring():
    try:
        import keyring
        from keyring.backends.fail import Keyring as FailKeyring
    except ImportError as e:
        raise VaultError("the secure key store isn't installed (keyring)") from e
    if isinstance(keyring.get_keyring(), FailKeyring):
        raise VaultError("this computer has no secure key store available")
    return keyring


def check_pem(pem: bytes):
    """The parsed private key, or VaultError. Accepts the file Kalshi gives you (BEGIN/END lines included)."""
    from cryptography.hazmat.primitives import serialization
    text = pem.strip().replace(b"\r\n", b"\n")
    try:
        return serialization.load_pem_private_key(text + b"\n", password=None)
    except Exception:  # noqa: BLE001 - every parse problem means the same thing to the person
        raise VaultError("that isn't a valid private key (it should start with -----BEGIN … PRIVATE KEY-----)") from None


def save(data_root: Path, mode: str, key_id: str, pem: bytes) -> dict:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    key_id = key_id.strip()
    if not (8 <= len(key_id) <= 80) or not all(c.isalnum() or c == "-" for c in key_id):
        raise VaultError("that doesn't look like a Kalshi Key ID")
    check_pem(pem)
    kr = _keyring()
    secret, nonce = os.urandom(32), os.urandom(12)
    payload = json.dumps({"key_id": key_id, "pem": base64.b64encode(pem.strip() + b"\n").decode()}).encode()
    blob = AESGCM(secret).encrypt(nonce, payload, _aad(mode))
    rec = {"v": VERSION, "mode": mode, "nonce": base64.b64encode(nonce).decode(), "ct": base64.b64encode(blob).decode(),
           "key_tail": key_id[-4:], "saved_at": time.time()}
    p = _path(data_root, mode)
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(p.parent, 0o700)
    except OSError:
        pass
    kr.set_password(SERVICE, _account(data_root, mode), base64.b64encode(secret).decode())
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(rec), encoding="utf-8")
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    os.replace(tmp, p)
    return status(data_root, mode)


def load(data_root: Path, mode: str) -> tuple[str, bytes] | None:
    """(key_id, pem) or None when no key was saved in the app. Raises VaultError if it can't be unlocked."""
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    p = _path(data_root, mode)
    if not p.exists():
        return None
    rec = json.loads(p.read_text(encoding="utf-8"))
    secret = _keyring().get_password(SERVICE, _account(data_root, mode))
    if not secret:
        raise VaultError("the saved key's lock is missing from this computer's key store; connect your Kalshi key again")
    try:
        payload = AESGCM(base64.b64decode(secret)).decrypt(base64.b64decode(rec["nonce"]), base64.b64decode(rec["ct"]), _aad(mode))
    except Exception:  # noqa: BLE001
        raise VaultError("the saved key couldn't be unlocked; connect your Kalshi key again") from None
    d = json.loads(payload)
    return d["key_id"], base64.b64decode(d["pem"])


def status(data_root: Path, mode: str) -> dict:
    """What the app may show: whether a key is saved and the last 4 characters of its Key ID. Never the key."""
    p = _path(data_root, mode)
    if not p.exists():
        return {"stored": False}
    try:
        rec = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"stored": False}
    return {"stored": True, "key_tail": rec.get("key_tail", ""), "saved_at": rec.get("saved_at")}


def remove(data_root: Path, mode: str) -> bool:
    p = _path(data_root, mode)
    had = p.exists()
    try:
        _keyring().delete_password(SERVICE, _account(data_root, mode))
    except Exception:  # noqa: BLE001 - already gone is fine
        pass
    p.unlink(missing_ok=True)
    return had
