#!/bin/bash
cd "$(dirname "$0")"
echo 'This moves REAL money inside your own Kalshi account, into the crypto section where the bot trades.'
echo 'Nothing leaves your account. It asks how much, then asks you to type a phrase to confirm.'
echo
.venv/bin/python -m favbot move-funds --mode live
echo
read -n 1 -s -r -p "Press any key to close this window."
echo
