// ---- updates ----------------------------------------------------------------------------
$('banners').addEventListener('click', async e => {
  if (e.target.id === 'installupdate') return installUpdate(e.target);     // whatsnew.js
  if (e.target.id !== 'restartnow') return;
  e.target.disabled = true;
  try { await postJSON('/api/restart', {}); window._restarting = true; setTimeout(() => { window._restarting = false; }, 45000);
    $('banners').innerHTML = '<div class="banner warn">Restarting with the update… this window reconnects by itself.</div>';
  } catch (err) { alert(err.message); e.target.disabled = false; }
});

// ---- period pickers, collapsible trades, sticky header ---------------------------------
$('pnlseg').onclick = e => { const b = e.target.closest('button'); if (!b) return; prefs.pnl = b.dataset.p; savePrefs(); load(); };
$('rangeseg').onclick = e => { const b = e.target.closest('button'); if (!b) return; prefs.range = b.dataset.r; savePrefs(); load(); };
function applyTradesCollapsed() {}     // replaced by the – / + button every section has
addEventListener('scroll', () => $('hdr').classList.toggle('scrolled', scrollY > 8), {passive: true});

// ---- "Is it working?" scorecard --------------------------------------------------------
let lastScore = '';
function renderScore(c) {
  const key = JSON.stringify(c); if (!c || key === lastScore) return; lastScore = key;
  if (!c.ready) { $('score').innerHTML = '<div class="empty" style="height:90px;margin-top:14px">The scorecard starts after the first bet settles.</div>'; return; }
  const V = {
    early: ['…', 'Too early to tell', `A good start, but ${c.n} bets can't separate skill from luck yet.`],
    unclear: ['?', 'Not clear yet', 'Your win rate is close to break-even; the range still covers both outcomes.'],
    ahead: ['✓', 'Ahead of break-even', 'Even the low end of the luck range is above break-even. Keep watching: conditions change.'],
    behind: ['!', 'Behind break-even', 'Even the high end of the luck range is below break-even. Consider pausing and reviewing.'],
  }[c.verdict];
  const more = c.more_bets ? `If your win rate stays at ${pct(c.win_rate)}, it takes about <b>${c.more_bets.toLocaleString()}</b> more bets to be sure.` : '';
  // gauge from 70% to 100% (where these favourites live)
  const lo = 0.70, X = v => Math.max(0, Math.min(100, (v - lo) / (1 - lo) * 100));
  const po = c.picked || {}, f = po.filled_contracts || {}, u = po.unfilled_contracts || {};
  const vsRow = (lbl, g, cls) => `<span>${lbl}</span><div class="t"><i class="${cls}" style="width:${g.win_rate == null ? 0 : g.win_rate * 100}%"></i></div>` +
    `<span>${g.win_rate == null ? '–' : pct(g.win_rate)} <span class="mut">(${g.won}/${g.n})</span></span>`;
  let pickedNote = 'Not enough bids that missed yet to compare.';
  if (f.n >= 10 && u.n >= 10) pickedNote = f.win_rate + 0.03 < u.win_rate
    ? 'Filled bets are winning less often than the ones that missed: fills may be getting picked off.'
    : 'No sign of being picked off so far.';
  $('score').innerHTML =
    `<div class="verdict"><div class="vicon ${c.verdict}">${V[0]}</div><div><div class="vtitle">${V[1]}</div><div class="sub">${V[2]}</div></div></div>` +
    `<div class="gauge"><div class="track"></div>` +
      `<div class="band" style="left:${X(c.low)}%;width:${Math.max(X(c.high) - X(c.low), 1)}%"></div>` +
      `<div class="be" style="left:${X(c.breakeven)}%"></div><div class="lbl" style="left:${X(c.breakeven)}%">break-even ${pct(c.breakeven)}</div>` +
      `<div class="mark" style="left:${X(c.win_rate)}%" title="Your win rate"></div></div>` +
    `<div class="scale"><span>70%</span><span>85%</span><span>100%</span></div>` +
    `<div class="sub" style="margin-top:8px">Dot = your win rate, weighted by bet size (${pct(c.win_rate)}, ${c.wins}–${c.losses}). Shaded = the range it could really be, ` +
      `given luck (${pct(c.low)} – ${pct(c.high)}). Line = what you need to break even. ${more}</div>` +
    `<div class="facts">` +
      tile('Profit so far', money(c.net, true), c.net >= 0 ? 'pos' : 'neg') +
      tile('One loss costs about', money(c.avg_loss)) +
      tile('Profit covers', c.cushion_losses == null ? '–' : (c.cushion_losses > 0 ? `${c.cushion_losses} losses` : 'no losses yet')) +
    `</div>` +
    `<div class="sub" style="margin-top:18px;font-weight:600;color:var(--fg)">Getting picked off?</div>` +
    `<div class="vs">${vsRow('Bids that filled', f, 'f')}${vsRow('Bids that missed', u, '')}</div>` +
    `<div class="sub" style="margin-top:6px">Did the side we bid on win? If filled bids win clearly less often than missed ones, ` +
      `the bot only gets filled when the price is about to turn against it. ${pickedNote}</div>`;
}

// ---- expandable trades (open rows stay open across refreshes) --------------------------
const expanded = new Set();
function toggleTrade(row) {
  const box = row.closest('.trade'), id = +box.dataset.id;
  if (expanded.has(id)) expanded.delete(id); else expanded.add(id);
  box.classList.toggle('open', expanded.has(id)); row.setAttribute('aria-expanded', expanded.has(id));
}
$('trades').addEventListener('click', e => { const r = e.target.closest('.trade>.row'); if (r) toggleTrade(r); });
$('trades').addEventListener('keydown', e => { const r = e.target.closest('.trade>.row');
  if (r && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); toggleTrade(r); } });
function setAll(open) {
  document.querySelectorAll('#trades .trade').forEach((box, i) => {
    const id = +box.dataset.id; if (open) expanded.add(id); else expanded.delete(id);
    setTimeout(() => { box.classList.toggle('open', open); box.firstElementChild.setAttribute('aria-expanded', open); },
      Math.min(i * 30, 400));   // a quick cascade
  });
}
$('expandall').onclick = () => setAll(true);
$('collapseall').onclick = () => setAll(false);

// ---- Layout: move, resize (⅓ ½ ⅔ full), minimize, maximize, hide ---------------------------
const SIZES = ['s3', 's6', 's8', 'full'];
const SIZE_LABEL = {s3: '⅓', s6: '½', s8: '⅔', full: 'Full'};
// Screens: Cat Corner home in Classic (everything on one page) or Custom (your own pick), and Statistics.
const ALL_SECTIONS = ['sec-balance', 'sec-preset', 'sec-picker', 'sec-cats', 'sec-score', 'sec-future', 'sec-profit', 'sec-each', 'sec-now',
  'sec-trades', 'sec-backtrack', 'sec-bids', 'sec-warn'];
const mk = (rows, rest) => {
  const L = rows.map(([id, size]) => ({id, size, hidden: false, min: false}));
  for (const id of ALL_SECTIONS) if (!L.find(x => x.id === id)) L.push({id, size: rest[id] || 's6', hidden: true, min: false});
  return L;
};
const DEFAULTS = {
  layout: mk([['sec-balance', 'full'], ['sec-preset', 'full'], ['sec-picker', 'full'], ['sec-cats', 'full'], ['sec-score', 's6'], ['sec-future', 's6'], ['sec-profit', 's3'],
    ['sec-each', 's3'], ['sec-now', 's3'], ['sec-trades', 'full'], ['sec-backtrack', 'full'], ['sec-bids', 's6'], ['sec-warn', 's6']], {}),
  layoutCustom: mk([['sec-balance', 'full'], ['sec-preset', 'full'], ['sec-picker', 'full'], ['sec-cats', 'full'], ['sec-now', 's6'], ['sec-trades', 's6']], {}),
  layoutStats: mk([['sec-score', 's6'], ['sec-future', 's6'], ['sec-profit', 's6'], ['sec-each', 's6'], ['sec-backtrack', 'full'],
    ['sec-trades', 'full'], ['sec-bids', 's6'], ['sec-warn', 's6']], {'sec-balance': 'full', 'sec-cats': 'full'}),
};
function layoutKey() {
  if (prefs.tab === 'stats' && prefs.view !== 'classic') return 'layoutStats';
  return prefs.view === 'custom' ? 'layoutCustom' : 'layout';
}
const DEFAULT_LAYOUT = DEFAULTS.layout;
const normSize = s => s === 'half' ? 's6' : SIZES.includes(s) ? s : 'full';
function layoutPrefs() {
  const key = layoutKey(), defs = DEFAULTS[key];
  let L = Array.isArray(prefs[key]) ? prefs[key].filter(x => $(x.id)) : null;
  if (key === 'layout' && L && !prefs.layoutV2) L = null;     // new default arrangement for Classic (wider Cat Chat)
  if (!L || !L.length) L = defs.map(x => ({...x}));
  defs.forEach((d, i) => {                       // sections added in updates go where they belong by default
    if (L.find(x => x.id === d.id)) return;
    const prev = i > 0 ? L.findIndex(x => x.id === defs[i - 1].id) : -1;
    L.splice(prev + 1, 0, {...d});
  });
  L.forEach(x => { x.size = normSize(x.size); });
  if (prefs.tradesCollapsed) { const t = L.find(x => x.id === 'sec-trades'); if (t) t.min = true; prefs.tradesCollapsed = false; }
  return L;
}
function saveLayout(L) { prefs[layoutKey()] = L; if (layoutKey() === 'layout') prefs.layoutV2 = true; savePrefs(); }
function applyLayout() {
  const L = layoutPrefs(), box = $('layout');
  for (const x of L) {
    const sec = $(x.id); if (!sec) continue;
    box.appendChild(sec);
    SIZES.forEach(sz => sec.classList.toggle(sz, x.size === sz && sz !== 'full'));
    sec.classList.remove('half');
    sec.classList.toggle('hid', !!x.hidden);
    sec.classList.toggle('min', !!x.min);
    addSecBar(sec, x);
    addSecTools(sec, x);
  }
  lastSeries = ''; lastProj = '';
}
function updateItem(id, fn) { const L = layoutPrefs(), it = L.find(i => i.id === id); fn(it); saveLayout(L); applyLayout(); load(); }
function addSecTools(sec, x) {
  let t = sec.querySelector(':scope > .sectools');
  if (!t) {
    t = document.createElement('div'); t.className = 'sectools';
    t.innerHTML = '<button data-t="min"></button><button data-t="max" title="Maximize">⤢</button>';
    sec.prepend(t);
    t.addEventListener('click', e => {
      const what = e.target.dataset.t; if (!what) return;
      if (what === 'min') updateItem(sec.id, it => { it.min = !it.min; });
      if (what === 'max') toggleMax(sec);
    });
  }
  const b = t.querySelector('[data-t=min]');
  b.textContent = x.min ? '+' : '–'; b.title = x.min ? 'Expand' : 'Minimize';
  b.setAttribute('aria-label', b.title + ' ' + (sec.dataset.title || ''));
  t.querySelector('[data-t=max]').setAttribute('aria-label', 'Maximize ' + (sec.dataset.title || ''));
}
function toggleMax(sec) {
  const on = !sec.classList.contains('max');
  document.querySelectorAll('#layout > section.max').forEach(s => { s.classList.remove('max'); s.querySelector('[data-t=max]').textContent = '⤢'; });
  if (on) { sec.classList.remove('min'); sec.classList.add('max'); sec.querySelector('[data-t=max]').textContent = '✕'; }
  document.body.classList.toggle('has-max', on);
  lastSeries = ''; lastProj = ''; lastBt = ''; load();
}
addEventListener('keydown', e => { if (e.key === 'Escape') { const m = document.querySelector('#layout > section.max'); if (m) toggleMax(m); } });
document.addEventListener('click', e => {      // click the dimmed backdrop to close a maximized section
  if (document.body.classList.contains('has-max') && !e.target.closest('#layout > section.max') && !e.target.closest('header,.scrim')) {
    const m = document.querySelector('#layout > section.max'); if (m) toggleMax(m);
  }
});
function addSecBar(sec, x) {
  let bar = sec.querySelector(':scope > .secbar');
  if (!bar) {
    bar = document.createElement('div'); bar.className = 'secbar';
    bar.innerHTML = `<span class="grip" title="Drag to move" draggable="true">⠿</span><span class="nm"></span>` +
      `<span class="seg small">${SIZES.map(s => `<button data-sz="${s}">${SIZE_LABEL[s]}</button>`).join('')}</span><button data-act="hide"></button>`;
    sec.prepend(bar);
    bar.addEventListener('click', e => {
      if (e.target.dataset.sz) updateItem(sec.id, it => { it.size = e.target.dataset.sz; });
      if (e.target.dataset.act === 'hide') updateItem(sec.id, it => { it.hidden = !it.hidden; });
    });
    const grip = bar.querySelector('.grip');
    grip.addEventListener('dragstart', e => { sec.classList.add('dragging'); e.dataTransfer.setData('text/plain', sec.id);
      e.dataTransfer.setDragImage(sec, 30, 20); });
    grip.addEventListener('dragend', () => { sec.classList.remove('dragging'); clearDrop(); });
  }
  bar.querySelector('.nm').textContent = sec.dataset.title || sec.id;
  bar.querySelectorAll('[data-sz]').forEach(b => b.classList.toggle('on', b.dataset.sz === x.size));
  bar.querySelector('[data-act=hide]').textContent = x.hidden ? '👁 Show' : '👁 Hide';
}
function clearDrop() { document.querySelectorAll('.drop-before,.drop-after').forEach(n => n.classList.remove('drop-before', 'drop-after')); }
function dropSide(sec, e) {
  const r = sec.getBoundingClientRect(), narrow = r.width < $('layout').getBoundingClientRect().width * 0.9;
  return narrow ? (e.clientX < r.left + r.width / 2 ? 'before' : 'after') : (e.clientY < r.top + r.height / 2 ? 'before' : 'after');
}
$('layout').addEventListener('dragover', e => {
  if (!document.body.classList.contains('editing')) return;
  const sec = e.target.closest('#layout > section'); if (!sec || sec.classList.contains('dragging')) return;
  e.preventDefault(); clearDrop(); sec.classList.add('drop-' + dropSide(sec, e));
});
$('layout').addEventListener('drop', e => {
  if (!document.body.classList.contains('editing')) return;
  e.preventDefault();
  const id = e.dataTransfer.getData('text/plain'), moving = $(id), sec = e.target.closest('#layout > section');
  clearDrop(); if (!moving || !sec || sec === moving) return;
  if (dropSide(sec, e) === 'before') sec.before(moving); else sec.after(moving);
  const L = layoutPrefs(), order = [...$('layout').children].map(n => n.id);
  L.sort((a, b) => order.indexOf(a.id) - order.indexOf(b.id)); saveLayout(L); applyLayout(); load();
});
$('editlayout').onclick = () => { document.body.classList.toggle('editing'); applyLayout(); };
$('donelayout').onclick = () => { document.body.classList.remove('editing'); load(); };
$('resetlayout').onclick = () => { if (confirm('Put every section on this screen back where it started?')) { prefs[layoutKey()] = null; savePrefs(); applyLayout(); load(); } };
function renderPageSettings() {
  const L = layoutPrefs();
  $('sectoggles').innerHTML = L.map((x, i) => `<div class="pagerow" data-id="${x.id}"><span>${esc($(x.id).dataset.title || x.id)}</span>` +
    `<span class="arrows"><button data-mv="-1" ${i ? '' : 'disabled'} aria-label="Move up">↑</button><button data-mv="1" ${i < L.length - 1 ? '' : 'disabled'} aria-label="Move down">↓</button></span>` +
    `<div class="seg small">${SIZES.map(s => `<button data-sz="${s}" class="${x.size === s ? 'on' : ''}">${SIZE_LABEL[s]}</button>`).join('')}</div>` +
    `<span class="sw"><input type="checkbox" ${x.hidden ? '' : 'checked'} aria-label="Show"><span></span></span></div>`).join('') +
    `<div class="sub" style="padding:10px 0">Tip: <b>✎ Layout</b> at the top lets you drag sections around on the page. ` +
    `Every section also has <b>–</b> (minimize) and <b>⤢</b> (maximize) in its top-right corner.</div>`;
}
$('sectoggles').addEventListener('click', e => {
  const row = e.target.closest('.pagerow'); if (!row) return;
  const L = layoutPrefs(), i = L.findIndex(x => x.id === row.dataset.id);
  if (e.target.dataset.mv) { const j = i + +e.target.dataset.mv; [L[i], L[j]] = [L[j], L[i]]; }
  else if (e.target.dataset.sz) L[i].size = e.target.dataset.sz;
  else if (e.target.type === 'checkbox') L[i].hidden = !e.target.checked;
  else return;
  saveLayout(L); applyLayout(); renderPageSettings(); load();
});

// ---- Simple mode ---------------------------------------------------------------------------
$('viewseg').onclick = e => { const b = e.target.closest('button'); if (!b) return;
  prefs.view = b.dataset.view; if (prefs.view === 'classic' && prefs.tab === 'stats') prefs.tab = 'home';
  savePrefs(); applyPrefs(); load(); };
$('s-pnlseg').onclick = e => { const b = e.target.closest('button'); if (!b) return; prefs.pnl = b.dataset.p; savePrefs(); load(); };
function renderSimple(s) {
  if (prefs.view !== 'simple' || prefs.tab !== 'home') return;
  const a = s.account || {};
  if (a.equity != null) countTo($('s-equity'), +a.equity);
  const since = s.now - PERIODS[prefs.pnl === '90d' ? 'all' : prefs.pnl], inP = s.series.filter(p => (p.ts || 0) >= since);
  const pp = inP.reduce((t, p) => t + p.pnl, 0);
  $('s-pnl').innerHTML = `<span class="${pp > 0 ? 'pos' : pp < 0 ? 'neg' : 'mut'}">${money(pp, true)}</span> <span class="mut" style="font-weight:500">${PERIOD_LABEL[prefs.pnl]}</span>`;
  document.querySelectorAll('#s-pnlseg button').forEach(b => b.classList.toggle('on', b.dataset.p === prefs.pnl));
  const left = s.coins.map(c => c.secs_left).filter(v => v != null), next = left.length ? Math.min(...left) : null;
  $('s-status').innerHTML = s.killed ? '⛔ Kill switch is on' : s.paused ? '⏸ Paused' :
    (s.trading_active ? '🟢 Running' : '⚪ Exchange not trading') +
    (next != null ? (next > 300 ? ` · next bets at ${tm(s.now + next - 300)}` : ' · betting window open now') : '');
  $('s-open').innerHTML = s.open_bets.length ? s.open_bets.map(b => `<div class="row"><div class="badge">${esc(b.coin)}</div>` +
    `<div><div class="t1">${esc(b.coin)} ${b.outcome === 'UP' ? '<span class="side up">↑ Up</span>' : '<span class="side dn">↓ Down</span>'}</div>` +
    `<div class="t2">${money(b.cost)} bet · result in ${b.closes_at ? mmss(b.closes_at - s.now) : '–'}</div></div>` +
    `<div class="amt">wins ${money(b.if_win)}</div></div>`).join('') : '<div class="empty" style="height:70px">No bets in progress.</div>';
  $('s-last').innerHTML = s.trades.filter(t => t.status !== 'open').slice(0, 6).map(t => `<div class="row"><div class="badge">${esc(t.coin)}</div>` +
    `<div><div class="t1">${esc(t.coin)} ${t.outcome === 'UP' ? '↑ Up' : '↓ Down'}</div><div class="t2">${dt(t.settled_at || t.placed_at)}</div></div>` +
    `<div class="amt"><span class="${+t.pnl >= 0 ? 'pos' : 'neg'}">${money(t.pnl, true)}</span><br>` +
    `<span class="pill ${t.status}">${t.status === 'won' ? 'Won' : 'Lost'}</span></div></div>`).join('') || '<div class="empty" style="height:70px">No results yet.</div>';
  const c = s.scorecard || {};
  const V = {early: ['…', 'Too early to tell'], unclear: ['?', 'Not clear yet'], ahead: ['✓', 'Ahead of break-even'], behind: ['!', 'Behind break-even'], none: ['…', 'No bets yet']}[c.verdict || 'none'];
  $('s-verdict').innerHTML = `<div class="vicon ${c.verdict || 'none'}">${V[0]}</div><div><div class="vtitle">${V[1]}</div>` +
    `<div class="sub">${c.n ? `${c.wins}–${c.losses} · win rate ${pct(c.win_rate)} · needs ${pct(c.breakeven)} to break even` : ''}</div></div>`;
}

// ---- Cat Corner: the cats explain your stats ----------------------------------------------
let lastCorner = '';
function renderCatCorner(s) {
  const ins = s.insights || {}, sc = s.scorecard || {}, bt = (s.backtrack || {}).results, lim = s.limits || {};
  const lbs = (s.litterbox || {}).summary;
  const key = JSON.stringify([ins, sc.n, sc.net, bt && bt.generated_at, prefs.odds, lbs && Math.floor(lbs.ts / 60)]);
  if (key === lastCorner) return; lastCorner = key;
  const av = k => `<div class="av">${CATS[k].svg.replace(/id="ink"/g, 'id="ink-' + k + '"').replace(/url\(#ink\)/g, 'url(#ink-' + k + ')')}</div>`;
  const card = (k, role, body) => `<div class="ccard"><div class="who">${av(k)}<div><div class="nm">${CATS[k].name}</div>` +
    `<div class="role">${role}</div></div></div>${body}</div>`;
  const few = n => n < 20 ? ` <span class="mut">(only ${n} bets — likely luck)</span>` : '';
  // Biscuit: your best and worst
  let b1;
  if (!ins.n) b1 = '<div class="say">No settled bets yet. I’ll dig through them as they come in.</div>';
  else {
    const coins = ins.by_coin, top = coins[0], bot = coins[coins.length - 1];
    const bands = ins.by_band.slice().sort((x, y) => y.roi - x.roi);
    b1 = `<div class="say">${ins.n} bets so far, ${ins.wins} won, ${money(ins.net, true)}. Here’s what I found:</div><ul>` +
      `<li>Best coin: <b>${esc(top.key)}</b> ${money(top.pnl, true)} (${top.wins}/${top.n} won)${few(top.n)}</li>` +
      (coins.length > 1 ? `<li>Worst coin: <b>${esc(bot.key)}</b> ${money(bot.pnl, true)} (${bot.wins}/${bot.n} won)${few(bot.n)}</li>` : '') +
      `<li>Best price range: <b>${esc(bands[0].key)}</b> ${pct(bands[0].win_rate)} won${few(bands[0].n)}</li>` +
      (ins.best[0] ? `<li>Biggest win: ${esc(ins.best[0].coin)} ${ins.best[0].outcome === 'UP' ? 'Up' : 'Down'} ${money(ins.best[0].pnl, true)}</li>` : '') +
      (ins.worst[0] && ins.worst[0].pnl < 0 ? `<li>Biggest loss: ${esc(ins.worst[0].coin)} ${ins.worst[0].outcome === 'UP' ? 'Up' : 'Down'} ${money(ins.worst[0].pnl, true)}</li>` : '') +
      `<li>Win streak: ${ins.streak} now, best ${ins.best_streak}</li></ul>`;
  }
  // Le Chonk: risk coach
  const perBet = +(lim.max_loss_per_position_usd || 0), cap = +(lim.capital_cap_usd || 0);
  const winsPerLoss = ins.avg_win && ins.avg_loss ? Math.round(ins.avg_loss / ins.avg_win) : null;
  const b2 = `<div class="say">Risk is the weight on the bar. Here’s yours:</div><ul>` +
    `<li>Each bet risks up to <b>${money(perBet)}</b> to win about <b>${money(ins.avg_win || perBet * 0.075)}</b>` +
      `${ins.avg_loss ? `; your losses average <b>${money(ins.avg_loss)}</b>` : ''}.</li>` +
    (winsPerLoss ? `<li>One loss wipes out about <b>${winsPerLoss} wins</b>.</li>` : '') +
    `<li>Your profit covers <b>${sc.cushion_losses != null ? sc.cushion_losses : 0}</b> losses right now.</li></ul>` +
    `<div class="tip2"><b>Risk less, same odds</b>Smaller bets (say $1) keep the same win rate and the same % result, ` +
    `with about ${perBet ? Math.round(perBet) : 4}× smaller swings — while the scorecard collects proof. Changing it means editing ` +
    `<b>config.yaml</b> and re-running ack-live (ask Claude).</div>` +
    `<div class="tip2"><b>“Risk less, make more” only comes from a real edge</b>No setting makes the same bets safer and more profitable. ` +
    `Le Chill checks Backtrack for an edge that survives a fair test.</div>`;
  // Le Chill: Backtrack says
  let b3;
  if (!bt) b3 = '<div class="say">Haven’t run Backtrack yet. Hit <b>Run Backtrack</b> below and I’ll read the results.</div>';
  else {
    const c = bt.current.all, gap = bt.picked_off_gap, sug = bt.suggestions || [],
      prom = (bt.top || []).filter(t => t.verdict === 'promising' || t.verdict === 'better'), wf = bt.walk_forward || {};
    b3 = `<div class="say">Replayed <b>${bt.contracts.toLocaleString()}</b> real contracts from the last ${bt.days} days.</div><ul>` +
      `<li>Your settings: ${c.n.toLocaleString()} bets, ${pct(c.win_rate)} won, <b class="${c.roi >= 0 ? 'pos' : 'neg'}">${(c.roi * 100).toFixed(1)}%</b> per $ (±${(2 * c.se * 100).toFixed(1)}%).</li>` +
      (gap != null ? `<li>Getting picked off: when a bid fills, the favourite wins <b>${pct(c.win_rate)}</b>; at the asking price it wins <b>${pct(bt.taker.win_rate)}</b>. That ${(gap * 100).toFixed(1)}-point gap is bigger than the fee waiting saves.</li>` : '') +
      `</ul>` +
      (sug.length ? `<div class="tip2"><b>Suggested change (beat yours on fresh data)</b>${esc(sug[0].label)}: ${(sug[0].test.roi * 100).toFixed(1)}% vs ` +
        `${(bt.current.test.roi * 100).toFixed(1)}% on newer data it wasn’t picked from. Ask Claude to try it in simulation first.</div>`
        : `<div class="tip2"><b>No change has proven itself yet</b>${prom.length ? `Closest: “${esc(prom[0].label)}” held up on newer data ` +
          `(${(prom[0].test.roi * 100).toFixed(1)}%) but within luck. Worth testing in simulation, not with real money yet.` :
          'Every setting that looked better on older days fell apart on newer ones.'}</div>`) +
      (wf.chosen_overall && wf.chosen_overall.n ? `<div class="tip2"><b>Walk-forward check</b>Picking settings only from earlier data ` +
        `made ${roiTxt(wf.chosen_overall)} per $ vs yours ${roiTxt(wf.current_overall)}. ` +
        `${wf.verdict === 'strong' ? 'Strong evidence it beats yours — still an estimate.' : wf.verdict === 'better' ? 'It beat yours on fresh data, but its own profit is still within luck.' : 'Not a reliable edge yet.'}</div>` : '');
  }
  b3 += litterTip(s);
  $('catcorner').innerHTML = card('biscuit', 'Best &amp; worst bets', b1) + card('chonk', 'Risk coach', b2) + card('chill', 'Backtrack reader', b3);
}

// ---- Backtrack section -----------------------------------------------------------------------
let lastBt = '';
$('btdays').onclick = e => { const b = e.target.closest('button'); if (!b) return; prefs.btDays = b.dataset.d; savePrefs(); lastBt = ''; load(); };
$('btrun').onclick = async () => {
  $('btrun').disabled = true;
  try { await postJSON('/api/backtrack', {days: +prefs.btDays || 7}); } catch (err) { alert(err.message); }
  setTimeout(() => { $('btrun').disabled = false; }, 3000); load();
};
const roiTxt = s => s && s.n ? `${s.roi >= 0 ? '+' : ''}${(s.roi * 100).toFixed(1)}%` : '–';
function dvRows(rows, lab) {
  const span = Math.max(0.04, ...rows.map(r => Math.abs(r.roi || 0) + 2 * (r.se || 0)));
  const X = v => 50 + v / span * 50;
  return rows.filter(r => r.n).map(r => {
    const a = X(Math.min(0, r.roi)), b = X(Math.max(0, r.roi));
    return `<div class="dvrow"><span>${esc(lab ? lab(r.key) : r.key)}</span><div class="dv"><div class="mid"></div>` +
      `<div class="b" style="left:${a}%;width:${Math.max(.5, b - a)}%;background:var(${r.roi >= 0 ? '--pos' : '--neg'})"></div>` +
      `<div class="e" style="left:${X(r.roi - 2 * r.se)}%;width:${X(r.roi + 2 * r.se) - X(r.roi - 2 * r.se)}%"></div></div>` +
      `<span class="v">${roiTxt(r)} <span class="mut">n=${r.n}</span></span></div>`;
  }).join('');
}
function renderBacktrack(b) {
  document.querySelectorAll('#btdays button').forEach(x => x.classList.toggle('on', x.dataset.d === String(prefs.btDays || 7)));
  if (!b) return;
  const st = b.status;
  const running = st && st.state === 'running' && Date.now() / 1000 - st.ts < 300;
  $('btrun').textContent = running ? 'Running…' : 'Run Backtrack';
  $('btstatus').innerHTML = running ? `<div class="sub" style="margin-top:12px">${esc(st.message)}…</div><div class="btprog"><i style="width:${st.progress}%"></i></div>`
    : st && st.state === 'error' ? `<div class="banner" style="margin-top:12px">${esc(st.message)}</div>` : '';
  const r = b.results, key = JSON.stringify([r && r.generated_at, prefs.odds]);
  if (key === lastBt) return; lastBt = key;
  if (!r) { $('btbody').innerHTML = '<div class="empty" style="height:110px;margin-top:14px">Run Backtrack to replay the last week of real contracts (takes about a minute, read-only).</div>'; return; }
  const c = r.current;
  const verdictPill = v => ({strong: '<span class="pill pass">Strong evidence (still an estimate)</span>',
    profitable: '<span class="pill pass">Strong evidence (still an estimate)</span>',
    convincing: '<span class="pill pass">Strong evidence (still an estimate)</span>',
    better: '<span class="pill prom">Beat yours on fresh data · profit within luck</span>', promising: '<span class="pill prom">Promising, within luck</span>',
    failed: '<span class="pill fail">Didn’t hold up on fresh data</span>'})[v];
  $('btbody').innerHTML =
    `<div class="sub" style="margin-top:10px">${r.contracts.toLocaleString()} real contracts · ${new Date(r.from * 1000).toLocaleDateString()} – ${new Date(r.to * 1000).toLocaleDateString()} · run ${dt(r.generated_at)}</div>` +
    `<div class="bt-tiles">` +
      tile('Your settings', `${roiTxt(c.all)} per $`, c.all.roi >= 0 ? 'pos' : 'neg') +
      tile('Stress test: sustained crosses only', `${roiTxt(c.strict || c.clear_only)} per $`, (((c.strict || c.clear_only) || {}).roi || 0) >= 0 ? 'pos' : 'neg') +
      tile('Buying at the ask instead', `${roiTxt(r.taker)} per $`, (r.taker.roi || 0) >= 0 ? 'pos' : 'neg') +
      tile('Picked-off gap', r.picked_off_gap != null ? `${(r.picked_off_gap * 100).toFixed(1)} pts` : '–') +
    `</div>` +
    `<div class="btgrid">` +
      `<div class="btbox"><h4>By coin (return per $, ±luck)</h4>${dvRows(r.by_coin)}</div>` +
      `<div class="btbox"><h4>By price</h4>${dvRows(r.by_band)}</div>` +
      `<div class="btbox"><h4>By side</h4>${dvRows(r.by_side, k => k === 'UP' ? 'Up' : 'Down')}</div>` +
      `<div class="btbox"><h4>By time left when the bid filled</h4>${dvRows(r.by_minute)}</div>` +
    `</div>` +
    `<div class="btbox" style="margin-top:16px"><h4>Settings tested — picked on older days, judged on newer days</h4>` +
    `<table class="bttable"><tr><th>Setting</th><th>Older days</th><th>Newer days</th><th></th></tr>` +
    `<tr><td><b>Your current settings</b></td><td>${roiTxt(c.train)}</td><td>${roiTxt(c.test)}</td><td></td></tr>` +
    (r.top || []).map(t => `<tr><td>${esc(t.label)}</td><td>${roiTxt(t.train)}</td><td>${roiTxt(t.test)}</td><td>${verdictPill(t.verdict)}</td></tr>`).join('') +
    `</table></div>` +
    (r.walk_forward && r.walk_forward.folds && r.walk_forward.folds.length ? `<div class="btbox" style="margin-top:16px">` +
      `<h4>Walk-forward test — for each period, settings were picked using only the periods before it</h4>` +
      `<table class="bttable"><tr><th>Period</th><th>Setting picked from earlier data</th><th>It made</th><th>Yours made</th></tr>` +
      r.walk_forward.folds.map(x => `<tr><td>${dt(x.from).split(',')[0]} – ${dt(x.to).split(',')[0]}</td><td>${esc(x.chosen)}</td>` +
        `<td>${roiTxt(x.chosen_next)}</td><td>${roiTxt(x.current_next)}</td></tr>`).join('') +
      `<tr><td><b>All periods</b></td><td></td><td><b>${roiTxt(r.walk_forward.chosen_overall)}</b> ` +
      `<span class="mut">±${(2 * (r.walk_forward.chosen_overall.se || 0) * 100).toFixed(1)}%</span></td>` +
      `<td><b>${roiTxt(r.walk_forward.current_overall)}</b> <span class="mut">±${(2 * (r.walk_forward.current_overall.se || 0) * 100).toFixed(1)}%</span></td></tr>` +
      `</table><div class="sub" style="margin-top:6px">${verdictPill(r.walk_forward.verdict)} This is the fairest test here: nothing was judged on data it was picked from.</div></div>` : '') +
    `<p class="note"><b>Every bid fill here is uncertain.</b> The real bid waits only 20 seconds, and minute-by-minute data can’t show ` +
      `whether the price crossed it inside those 20 seconds — even when it was still crossed at the minute’s end` +
      `${c.all.sustained_share != null ? ` (${Math.round(c.all.sustained_share * 100)}% of fills)` : ''}. So waiting-at-the-bid results are estimates, ` +
      `and are never rated “strong” from this data alone; the stress test shows how much they shrink with stricter fills. ` +
      `Buying at the ask doesn’t have this problem. ` +
    `Bets are sized like the live bot ($4 → whole contracts) with taker fees rounded up per order. All figures are estimates.</p>` +
    `<p class="note">How it works: the bot’s exact rule is replayed on Kalshi’s minute-by-minute bid/ask history. A bid is assumed filled if ` +
    `the price trades through it within the next minute — an estimate, so real fills may differ. Settings are chosen on the older ${Math.round(r.train_contracts / r.contracts * 100)}% ` +
    `of contracts and judged on the newest ${Math.round(r.test_contracts / r.contracts * 100)}% — anything can look good on the data it was picked from. ` +
    `Bars show the return per dollar bet; the thin line is the range luck alone could explain.</p>`;
}
