"""Plain data types shared by providers, strategy, risk and execution."""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal

from .money import ONE, ZERO, PriceGrid, d, d_or_zero, fmt_count, fmt_price

LEGS = ("yes", "no")


def parse_ts(s: str | None) -> float | None:
    if not s:
        return None
    return datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()


def coin_of(series: str) -> str:
    c = series
    if c.startswith("KX") or c.startswith("PM"):          # Kalshi KXETH15M, Polymarket US PMETH15M
        c = c[2:]
    if c.endswith("15M"):
        c = c[:-3]
    return c


def other_leg(leg: str) -> str:
    return "no" if leg == "yes" else "yes"


@dataclass
class Book:
    """Order book: bids only, ascending, best last (as the API returns them)."""

    ticker: str
    yes_bids: list[tuple[Decimal, Decimal]]
    no_bids: list[tuple[Decimal, Decimal]]
    fetched_at: float = field(default_factory=time.time)

    @classmethod
    def from_api(cls, ticker: str, raw: dict, fetched_at: float | None = None) -> "Book":
        ob = raw.get("orderbook_fp") or {}

        def levels(key):
            out = [(d(p), d(q)) for p, q in (ob.get(key) or [])]
            out = [(p, q) for p, q in out if q > ZERO]
            out.sort(key=lambda x: x[0])
            return out

        return cls(ticker, levels("yes_dollars"), levels("no_dollars"), fetched_at or time.time())

    def bids(self, leg: str):
        return self.yes_bids if leg == "yes" else self.no_bids

    def best_bid(self, leg: str) -> Decimal | None:
        b = self.bids(leg)
        return b[-1][0] if b else None

    def best_bid_size(self, leg: str) -> Decimal:
        b = self.bids(leg)
        return b[-1][1] if b else ZERO

    def best_ask(self, leg: str) -> Decimal | None:
        """A NO bid at q is a YES ask at 1-q, and vice versa."""
        opp = self.bids(other_leg(leg))
        return ONE - opp[-1][0] if opp else None

    def ask_levels(self, leg: str) -> list[tuple[Decimal, Decimal]]:
        """Asks for `leg`, best (lowest) first."""
        return [(ONE - p, q) for p, q in reversed(self.bids(other_leg(leg)))]

    def age(self, now: float | None = None) -> float:
        return (now if now is not None else time.time()) - self.fetched_at


@dataclass
class Contract:
    ticker: str
    series: str
    coin: str
    open_ts: float
    close_ts: float
    yes_is_up: bool
    status: str
    floor_strike: Decimal | None
    exchange_index: int | None
    grid: PriceGrid
    result: str = ""

    def outcome_of(self, leg: str) -> str:
        return "UP" if (leg == "yes") == self.yes_is_up else "DOWN"

    def leg_of(self, outcome: str) -> str:
        return "yes" if (outcome == "UP") == self.yes_is_up else "no"


@dataclass(frozen=True)
class SeriesInfo:
    ticker: str
    fee_type: str
    fee_multiplier: Decimal
    exchange_index: int


@dataclass(frozen=True)
class OrderRequest:
    """A buy of `count` contracts of `leg` at `price` (price on that leg)."""

    ticker: str
    client_order_id: str
    leg: str
    price: Decimal
    count: int
    expiration_ts: int
    post_only: bool = True

    def to_payload(self) -> dict:
        """Translate to the YES-leg quoting of POST /portfolio/events/orders.

        Buy YES at q -> side "bid" at q. Buy NO at q -> side "ask" at YES price 1-q.
        """
        if self.leg == "yes":
            side, yes_price = "bid", self.price
        elif self.leg == "no":
            side, yes_price = "ask", ONE - self.price
        else:
            raise ValueError(f"bad leg {self.leg}")
        if self.count < 1:
            raise ValueError("count must be >= 1")
        return {
            "ticker": self.ticker,
            "client_order_id": self.client_order_id,
            "side": side,
            "count": fmt_count(self.count),
            "price": fmt_price(yes_price),
            "time_in_force": "good_till_canceled",
            "post_only": self.post_only,
            "expiration_time": int(self.expiration_ts),
            "cancel_order_on_pause": True,
            "self_trade_prevention_type": "taker_at_cross",
        }


@dataclass
class OrderAck:
    order_id: str
    client_order_id: str | None
    fill_count: Decimal
    remaining_count: Decimal


@dataclass
class OrderInfo:
    order_id: str
    client_order_id: str
    ticker: str
    leg: str
    price: Decimal          # price on `leg`
    status: str             # resting | canceled | executed
    fill_count: Decimal
    remaining_count: Decimal
    initial_count: Decimal
    fill_cost: Decimal
    fees: Decimal
    created_ts: float | None = None

    @classmethod
    def from_api(cls, o: dict) -> "OrderInfo":
        leg = o.get("outcome_side") or o.get("side")
        price = d(o["yes_price_dollars"] if leg == "yes" else o["no_price_dollars"])
        return cls(
            order_id=o["order_id"],
            client_order_id=o.get("client_order_id") or "",
            ticker=o["ticker"],
            leg=leg,
            price=price,
            status=o["status"],
            fill_count=d_or_zero(o.get("fill_count_fp")),
            remaining_count=d_or_zero(o.get("remaining_count_fp")),
            initial_count=d_or_zero(o.get("initial_count_fp")),
            fill_cost=d_or_zero(o.get("maker_fill_cost_dollars")) + d_or_zero(o.get("taker_fill_cost_dollars")),
            fees=d_or_zero(o.get("maker_fees_dollars")) + d_or_zero(o.get("taker_fees_dollars")),
            created_ts=parse_ts(o.get("created_time")),
        )


@dataclass
class FillInfo:
    fill_id: str
    order_id: str
    ticker: str
    leg: str
    count: Decimal
    price: Decimal
    fee: Decimal
    is_taker: bool
    ts: float | None

    @classmethod
    def from_api(cls, f: dict) -> "FillInfo":
        leg = f.get("outcome_side") or f.get("side")
        return cls(
            fill_id=f.get("fill_id") or f["trade_id"],
            order_id=f["order_id"],
            ticker=f.get("ticker") or f.get("market_ticker"),
            leg=leg,
            count=d(f["count_fp"]),
            price=d(f["yes_price_dollars"] if leg == "yes" else f["no_price_dollars"]),
            fee=d_or_zero(f.get("fee_cost")),
            is_taker=bool(f.get("is_taker")),
            ts=parse_ts(f.get("created_time")) or (float(f["ts"]) if f.get("ts") else None),
        )


@dataclass
class PositionInfo:
    ticker: str
    position: Decimal       # positive = YES, negative = NO
    exposure: Decimal

    @classmethod
    def from_api(cls, p: dict) -> "PositionInfo":
        return cls(p["ticker"], d_or_zero(p.get("position_fp")), d_or_zero(p.get("market_exposure_dollars")))


@dataclass
class BalanceInfo:
    balance: Decimal          # available cash on the trading shard
    portfolio_value: Decimal

    @classmethod
    def from_api(cls, b: dict) -> "BalanceInfo":
        bal = d(b["balance_dollars"]) if b.get("balance_dollars") else d(b.get("balance", 0)) / 100
        return cls(bal, d(b.get("portfolio_value", 0)) / 100)


@dataclass
class ExchangeStatus:
    exchange_active: bool
    trading_active: bool
    fetched_at: float
