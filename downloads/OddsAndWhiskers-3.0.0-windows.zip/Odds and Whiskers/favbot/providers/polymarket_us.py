"""Polymarket US: public market data only (https://gateway.polymarket.us, no account, no key).

Odds & Whiskers 3.0 starts Polymarket US with market browsing and fake-money testing. This client is read-only
(any non-GET request raises before it is sent), so nothing here can place an order or touch an account.

The bot's engine, strategy, risk checks and paper simulator were built around Kalshi's market records, so this
client presents Polymarket US's 15-minute "Up or Down" crypto markets in that same shape. Every market still
goes through the same checks before the strategy may use it (a 900-second window, a CF Benchmarks index with a
sixty-second average in the official rule text, open for trading). How they line up:

- one Polymarket US market per coin per 15-minute window, its book quoted on the "Up" side (long, Yes); the
  Down side is the mirror image (a Down ask at q is an Up bid at 1 - q), exactly like Kalshi's yes/no legs;
- ticker "PM{COIN}15M-{market slug}", so fees and settlement can be looked up per coin;
- settlement from GET /v1/markets/{slug}/settlement: 1 = Up won, 0 = Down won (404 until settled);
- prices in whole cents (orderPriceMinTickSize 0.01).
"""
from __future__ import annotations

import asyncio
import re
import time
from datetime import datetime, timezone
from decimal import Decimal

from ..models import Book, ExchangeStatus, SeriesInfo
from ..money import ONE, ZERO, d
from .base import ApiError, NotFound
from .kalshi import KalshiAPI, RateLimiter

GATEWAY = "https://gateway.polymarket.us/v1"
EXCHANGE = "polymarket_us"
FEE_TYPE = "polymarket_us"
# coins with a 15-minute Up or Down series on Polymarket US (checked 2026-10-17: btc, eth, sol, xrp)
# Pace: the public gateway refused requests at a sustained 1.5/s during betting windows (2026-10-17), so the ceiling
# is 1.2/s and books are cached for 4 s (the strategy accepts books up to 6 s old).
BOOK_TTL_S = 4.0
COINS = ("BTC", "ETH", "SOL", "XRP")
WINDOW_S = 900
CENT_GRID = [{"start": "0.0000", "end": "1.0000", "step": "0.0100"}]


def series_for(coin: str) -> str:
    return f"PM{coin.upper()}15M"


def coin_of_series(series: str) -> str:
    return series[2:-3] if series.startswith("PM") and series.endswith("15M") else series


def event_slug(coin: str, window_start: float) -> str:
    t = datetime.fromtimestamp(window_start, tz=timezone.utc)
    return f"{coin.lower()}-updown-15m-{t:%Y-%m-%d}-{t:%H%M}z"


def _ts(s: str | None) -> float | None:
    if not s:
        return None
    return datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()


def _iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def market_record(series: str, m: dict, now: float | None = None) -> dict:
    """A Polymarket US market in the shape the engine checks (the same fields verify_market reads)."""
    a = m.get("assetPriceTerms") or {}
    start, end = _ts(a.get("windowStart")), _ts(a.get("windowEnd"))
    now = time.time() if now is None else now
    st = m.get("status") or ""
    if st == "MARKET_STATUS_OPEN":
        status = "active"
    elif st == "MARKET_STATUS_RESOLVED":
        status = "finalized"
    elif start and now < start:
        status = "initialized"                       # created ahead of its window: not open for trading yet
    else:
        status = "closed"
    up_down = a.get("marketType") == "ASSET_PRICE_MARKET_TYPE_UP_DOWN"
    beat = (a.get("priceToBeat") or {}).get("value")
    return {
        "ticker": f"{series}-{m.get('slug', '')}",
        "slug": m.get("slug", ""),
        "market_type": "binary" if up_down and len(m.get("marketSides") or []) == 2 else (m.get("marketType") or "other"),
        "open_time": a.get("windowStart"), "close_time": a.get("windowEnd"),
        "settlement_bounds_type": "default",
        # Up (the long side, "Yes") wins when the closing average is at least the opening one
        "strike_type": "greater_or_equal" if up_down else None,
        "rules_primary": m.get("description") or "", "rules_secondary": "",
        "status": status,
        "exchange_index": None,
        "price_ranges": CENT_GRID if d(m.get("orderPriceMinTickSize") or "0.01") == Decimal("0.01") else None,
        "floor_strike": beat,
        "result": "",
        "index": a.get("indexSymbol"),
        "window": [start, end],
    }


def book_from(ticker: str, raw: dict, fetched_at: float) -> Book:
    """The Up side's bids are the yes bids. An Up offer at a is a Down bid at 1 - a."""
    md = raw.get("marketData") or {}

    def lv(rows, flip):
        out = []
        for r in rows or []:
            p, q = d((r.get("px") or {}).get("value")), d(r.get("qty") or "0")
            if q > ZERO and ZERO < p < ONE:
                out.append((ONE - p if flip else p, q))
        out.sort(key=lambda x: x[0])
        return out

    return Book(ticker, lv(md.get("bids"), False), lv(md.get("offers"), True), fetched_at)


class AdaptiveLimiter(RateLimiter):
    """Polymarket US's public gateway rate-limits by IP far below its documented 25/s. On every 429 this halves
    the pace (down to one request every 4 s) and waits; then it speeds back up slowly while all is well."""

    def __init__(self, rate_per_s: float, floor: float = 0.25):
        super().__init__(rate_per_s, burst=1.0)
        self.ceiling, self.floor = rate_per_s, floor

    async def acquire(self, cost: float = 1.0) -> None:
        now = time.monotonic()
        self.rate = min(self.ceiling, self.rate + 0.02 * max(0.0, now - self.updated))      # +0.02/s per quiet second
        await super().acquire(cost)

    def back_off(self, seconds: float) -> None:
        self.rate = max(self.floor, self.rate / 2)
        super().back_off(seconds)


class PolymarketUSAPI(KalshiAPI):
    """Read-only client for Polymarket US's public gateway, with the MarketData methods the engine uses."""

    def __init__(self, *, timeout_s: float = 10.0, requests_per_s: float = 1.2, on_network=None, base_url: str = GATEWAY):
        # The documented limit is 25 requests a second per IP, but in testing the public gateway answered "429 Too
        # Many Requests" far below that. So: one client per app (the workspace's bot, Litter Box and Markets panel
        # share it and its book cache), a slow steady pace with no bursts, and a back-off on any 429.
        super().__init__(base_url, read_only=True, timeout_s=timeout_s, requests_per_s=requests_per_s, on_network=on_network)
        self.limiter = AdaptiveLimiter(requests_per_s)
        self._events: dict[str, tuple[float, dict | None]] = {}
        self._settled: dict[str, tuple[float, dict]] = {}
        self._status: ExchangeStatus | None = None
        self.counts: dict[str, int] = {}             # requests by kind, for diagnostics and the pace check
        self._inflight: dict[str, asyncio.Future] = {}

    async def _once(self, key: str, fetch):
        """Coalesce identical lookups: when a dozen practice bots start together and all ask for the same event,
        one request goes out and they all get its answer (instead of a burst that gets the IP rate-limited)."""
        fut = self._inflight.get(key)
        if fut is not None:
            return await asyncio.shield(fut)
        fut = asyncio.get_running_loop().create_future()
        self._inflight[key] = fut
        try:
            val = await fetch()
        except BaseException as e:
            if not fut.done():
                fut.set_exception(e)
                fut.exception()                       # mark it retrieved when nobody else was waiting
            raise
        else:
            fut.set_result(val)
            return val
        finally:
            self._inflight.pop(key, None)

    async def request(self, method: str, path: str, **kw):
        kind = re.sub(r"/[^/]*\d{4}-\d\d-\d\d-\d{4}z", "/*", path)
        self.counts[kind] = self.counts.get(kind, 0) + 1
        return await super().request(method, path, **kw)

    exchange = EXCHANGE

    async def get_exchange_status(self, exchange_index: int = 0) -> ExchangeStatus:
        """Reachable = open (each market has its own state). Asked at most once a minute."""
        if self._status is None or time.time() - self._status.fetched_at > 60:
            async def fetch():
                await self.request("GET", "/markets", params={"limit": 1})
                return ExchangeStatus(True, True, time.time())
            self._status = await self._once("status", fetch)
        return self._status

    async def get_series(self, series: str) -> SeriesInfo:
        coin = coin_of_series(series)
        if coin not in COINS:
            raise NotFound(404, f"Polymarket US has no 15-minute {coin} market")
        return SeriesInfo(series, FEE_TYPE, Decimal(1), 0)

    async def _event(self, coin: str, start: float, stale_ok: bool = False) -> dict | None:
        """The event for one coin's window. With stale_ok (browsing), a copy we already have is good enough."""
        slug = event_slug(coin, start)
        hit = self._events.get(slug)
        now = time.time()
        if stale_ok and hit and hit[1] and any(m.get("status") == "MARKET_STATUS_OPEN" for m in hit[1].get("markets") or []):
            return hit[1]                    # (a copy from before the window opened would still say "not open")
        # An event changes when its window opens (status, price to beat) and is settled separately, so: the minute
        # before it opens, check every 8 s; while open, every minute; long before or after, every 5 minutes.
        # Missing ones may be created later.
        if hit and hit[1]:
            ttl = 8 if 0 < start - now <= 60 else 60 if start <= now < start + WINDOW_S else 300
        else:
            ttl = 120
        if hit and now - hit[0] < ttl:
            return hit[1]
        async def fetch():
            try:
                return (await self.request("GET", f"/events/slug/{slug}")).get("event")
            except NotFound:
                return None
        ev = await self._once("event:" + slug, fetch)
        self._events[slug] = (time.time(), ev)
        if len(self._events) > 400:
            for k in sorted(self._events, key=lambda k: self._events[k][0])[:200]:
                self._events.pop(k, None)
        return ev

    async def list_markets(self, series: str, min_close_ts: int, max_close_ts: int) -> list[dict]:
        coin = coin_of_series(series)
        if coin not in COINS:
            return []
        out = []
        first = (int(min_close_ts) // WINDOW_S) * WINDOW_S - WINDOW_S
        for start in range(first, int(max_close_ts), WINDOW_S):
            if not (min_close_ts <= start + WINDOW_S <= max_close_ts):
                continue
            ev = await self._event(coin, start)
            for m in (ev or {}).get("markets") or []:
                rec = market_record(series, m)
                if rec["open_time"] and abs((_ts(rec["open_time"]) or 0) - start) < 1:
                    out.append(rec)
        return out

    async def get_market(self, ticker: str) -> dict:
        """Status and, once settled, the result: "yes" = Up won, "no" = Down won. Only asked about closed markets
        (to settle bets), so a missing settlement simply means "not settled yet". One request, at most every
        30 s per market; a result, once known, is kept."""
        hit = self._settled.get(ticker)
        if hit and (hit[1]["result"] or time.time() - hit[0] < 30):
            return hit[1]
        slug = ticker.split("-", 1)[1]

        async def fetch():
            try:
                return (await self.request("GET", f"/markets/{slug}/settlement", retries=-2)).get("settlement")
            except NotFound:
                return None
        v = await self._once("settle:" + ticker, fetch)
        result = "yes" if v in (1, "1", 1.0) else "no" if v in (0, "0", 0.0) else ""
        out = {"ticker": ticker, "status": "finalized" if result else "closed", "result": result}
        self._settled[ticker] = (time.time(), out)
        if len(self._settled) > 500:
            for k in sorted(self._settled, key=lambda k: self._settled[k][0])[:250]:
                self._settled.pop(k, None)
        return out

    async def get_orderbook(self, ticker: str) -> Book:
        slug = ticker.split("-", 1)[1]
        # fail fast: a refused or missing book is simply asked for again on the engine's next tick, a couple of
        # seconds later, instead of holding everyone up with retries
        raw = await self.request("GET", f"/markets/{slug}/book", retries=-2)
        if not raw.get("marketData"):
            raise ApiError(404, f"no order book for {slug}")
        return book_from(ticker, raw, time.time())

    async def get_orderbooks(self, tickers: list[str]) -> dict[str, Book]:
        out = {}
        for t in tickers:
            try:
                out[t] = await self.get_orderbook(t)
            except ApiError:
                continue
        return out

    # ---- browsing (the Markets panel) ------------------------------------------------------------
    async def browse(self, now: float | None = None, book=None) -> list[dict]:
        """The current 15-minute market for every coin Polymarket US lists, with live prices from its book.
        `book` lets a shared cache supply the order books (so browsing costs few or no extra requests). The coins
        are looked up side by side, and a coin that takes too long is shown without prices instead of holding up
        the rest."""
        now = time.time() if now is None else now
        book = book or self.get_orderbook
        start = (int(now) // WINDOW_S) * WINDOW_S

        async def one(coin: str) -> dict:
            row = {"coin": coin, "series": series_for(coin), "available": False}
            try:
                ev = await self._event(coin, start, stale_ok=True)
                m = ((ev or {}).get("markets") or [None])[0]
                if m:
                    rec = market_record(series_for(coin), m, now)
                    row.update(available=True, slug=rec["slug"], status=rec["status"], index=rec["index"],
                               window=rec["window"], price_to_beat=rec["floor_strike"], rules=rec["rules_primary"],
                               title=m.get("question"))
                    if rec["status"] == "active":
                        b = await book(rec["ticker"])
                        row.update(up_bid=_s(b.best_bid("yes")), up_ask=_s(b.best_ask("yes")),
                                   down_bid=_s(b.best_bid("no")), down_ask=_s(b.best_ask("no")), book_ts=b.fetched_at)
            except Exception as e:  # noqa: BLE001 - one coin's problem shouldn't hide the others
                row["error"] = type(e).__name__
            return row

        async def capped(coin: str) -> dict:
            try:
                return await asyncio.wait_for(one(coin), 10)
            except asyncio.TimeoutError:
                return {"coin": coin, "series": series_for(coin), "available": False, "error": "busy"}

        return list(await asyncio.gather(*(capped(c) for c in COINS)))


def _s(x):
    return None if x is None else str(x)
