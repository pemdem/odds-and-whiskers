"""Edit one top-level block of config.yaml while keeping everything else (including comments) as it is."""
from __future__ import annotations

import re
import shutil
import time
from pathlib import Path

import yaml


def _block_span(text: str, key: str) -> tuple[int, int] | None:
    m = re.search(rf"(?m)^{re.escape(key)}:.*\n?", text)
    if not m:
        return None
    end = m.end()
    for line in re.finditer(r"(?m)^.*\n?", text[end:]):
        ln = line.group(0)
        if ln.strip() and not ln.startswith((" ", "\t", "#")):
            break
        if ln.startswith("#"):                 # a comment at column 0 ends the block
            break
        end += len(ln)
        if not ln:
            break
    return m.start(), end


def render(key: str, value) -> str:
    body = yaml.safe_dump({key: value}, sort_keys=False, default_flow_style=False, allow_unicode=True)
    return body if body.endswith("\n") else body + "\n"


def set_block(text: str, key: str, value) -> str:
    """Replace (or append) the top-level `key:` block. value=None removes it."""
    span = _block_span(text, key)
    new = "" if value is None else render(key, value)
    if span:
        return text[:span[0]] + new + text[span[1]:]
    if value is None:
        return text
    return text + ("" if text.endswith("\n") else "\n") + new


def update_config(path: Path, changes: dict) -> Path:
    """Apply {key: value-or-None} to config.yaml. Keeps a timestamped backup and checks the result still parses."""
    text = path.read_text(encoding="utf-8")
    backup = path.with_name(f"{path.stem}.backup-{time.strftime('%Y%m%d-%H%M%S')}{path.suffix}")
    shutil.copy2(path, backup)
    for k, v in changes.items():
        text = set_block(text, k, v)
    yaml.safe_load(text)                       # refuse to write a broken file
    path.write_text(text, encoding="utf-8")
    return backup
