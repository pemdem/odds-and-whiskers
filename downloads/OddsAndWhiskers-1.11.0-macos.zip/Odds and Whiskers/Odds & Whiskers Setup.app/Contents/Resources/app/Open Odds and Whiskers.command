#!/bin/bash
cd "$(dirname "$0")"
/bin/bash app/launch_mac.sh
