"""SQLite store: order intents, fills, settlements, contracts, flags and events.

Every order intent is written here *before* it is sent. The partial unique index
`one_live_entry` allows one live entry per contract: an entry keeps its slot while it
is pending, resting, unknown or has any fill; an entry that ends with zero fill frees it.
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from contextlib import contextmanager
from decimal import Decimal
from pathlib import Path

from .models import Contract, OrderInfo
from .money import ZERO, PriceGrid, d, d_or_zero

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS contracts(
  ticker TEXT PRIMARY KEY, series TEXT NOT NULL, coin TEXT NOT NULL,
  open_ts REAL NOT NULL, close_ts REAL NOT NULL, yes_is_up INTEGER NOT NULL,
  floor_strike TEXT, status TEXT, result TEXT DEFAULT '', grid TEXT, exchange_index INTEGER,
  updated_at REAL);
CREATE TABLE IF NOT EXISTS entries(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  mode TEXT NOT NULL, series TEXT NOT NULL, coin TEXT NOT NULL, ticker TEXT NOT NULL,
  attempt INTEGER NOT NULL,
  client_order_id TEXT NOT NULL UNIQUE, order_id TEXT,
  leg TEXT NOT NULL, outcome TEXT NOT NULL, price TEXT NOT NULL, count INTEGER NOT NULL,
  max_loss TEXT NOT NULL, expiration_ts INTEGER NOT NULL,
  state TEXT NOT NULL,            -- intent | resting | unknown | done | rejected | not_placed
  slot INTEGER,                   -- 1 while this entry holds the contract's single live slot
  filled_count TEXT NOT NULL DEFAULT '0', fill_cost TEXT NOT NULL DEFAULT '0', fees TEXT NOT NULL DEFAULT '0',
  resend_count INTEGER NOT NULL DEFAULT 0,
  created_at REAL NOT NULL, sent_at REAL, ended_at REAL, error TEXT, end_reason TEXT,
  ask_at_entry TEXT,
  settled_result TEXT, payout TEXT, pnl TEXT, settled_at REAL,
  UNIQUE(mode, ticker, attempt));
CREATE UNIQUE INDEX IF NOT EXISTS one_live_entry ON entries(mode, ticker) WHERE slot = 1;
CREATE INDEX IF NOT EXISTS entries_state ON entries(mode, state);
CREATE TABLE IF NOT EXISTS fills(
  fill_id TEXT PRIMARY KEY, entry_id INTEGER, order_id TEXT NOT NULL, ticker TEXT NOT NULL,
  leg TEXT NOT NULL, count TEXT NOT NULL, price TEXT NOT NULL, fee TEXT NOT NULL,
  is_taker INTEGER NOT NULL, ts REAL);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, level TEXT NOT NULL, kind TEXT NOT NULL,
  coin TEXT, ticker TEXT, message TEXT NOT NULL);
"""

LIVE_STATES = ("intent", "resting", "unknown")


class SlotTaken(Exception):
    """The contract already has a live entry (or the attempt number collided)."""


class Store:
    def __init__(self, path: str | Path):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path, timeout=15, isolation_level=None, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._lock = threading.RLock()
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA busy_timeout=15000")
        self.conn.executescript(SCHEMA)

    def close(self) -> None:
        self.conn.close()

    @contextmanager
    def tx(self):
        with self._lock:
            self.conn.execute("BEGIN IMMEDIATE")
            try:
                yield self.conn
            except BaseException:
                self.conn.execute("ROLLBACK")
                raise
            else:
                self.conn.execute("COMMIT")

    def _q(self, sql: str, args=()):
        with self._lock:
            return self.conn.execute(sql, args).fetchall()

    def _x(self, sql: str, args=()):
        with self._lock:
            return self.conn.execute(sql, args)

    # ---- meta / flags -------------------------------------------------------------------
    def get_meta(self, key: str, default=None):
        r = self._q("SELECT value FROM meta WHERE key=?", (key,))
        return json.loads(r[0]["value"]) if r else default

    def set_meta(self, key: str, value) -> None:
        self._x("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, json.dumps(value, default=str)))

    def del_meta(self, key: str) -> None:
        self._x("DELETE FROM meta WHERE key=?", (key,))

    def set_kill(self, reason: str) -> None:
        self.set_meta("kill", {"reason": reason, "ts": time.time()})

    def clear_kill(self) -> None:
        self.del_meta("kill")

    def kill_state(self):
        return self.get_meta("kill")

    def set_halt(self, name: str, detail: str) -> None:
        self.set_meta(f"halt:{name}", {"detail": detail, "ts": time.time()})

    def clear_halt(self, name: str | None = None) -> None:
        if name:
            self.del_meta(f"halt:{name}")
        else:
            self._x("DELETE FROM meta WHERE key LIKE 'halt:%'")

    def halts(self) -> dict:
        return {r["key"][5:]: json.loads(r["value"]) for r in self._q("SELECT key,value FROM meta WHERE key LIKE 'halt:%'")}

    # ---- contracts ----------------------------------------------------------------------
    def upsert_contract(self, c: Contract) -> None:
        self._x("""INSERT INTO contracts(ticker,series,coin,open_ts,close_ts,yes_is_up,floor_strike,status,result,grid,exchange_index,updated_at)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(ticker) DO UPDATE SET status=excluded.status, floor_strike=excluded.floor_strike,
                     yes_is_up=excluded.yes_is_up, grid=excluded.grid, updated_at=excluded.updated_at,
                     result=CASE WHEN excluded.result!='' THEN excluded.result ELSE contracts.result END""",
                (c.ticker, c.series, c.coin, c.open_ts, c.close_ts, int(c.yes_is_up),
                 str(c.floor_strike) if c.floor_strike is not None else None, c.status, c.result or "",
                 json.dumps(c.grid.to_api()), c.exchange_index, time.time()))

    def set_contract_result(self, ticker: str, status: str, result: str) -> None:
        self._x("UPDATE contracts SET status=?, result=?, updated_at=? WHERE ticker=?", (status, result, time.time(), ticker))

    def contract(self, ticker: str) -> Contract | None:
        r = self._q("SELECT * FROM contracts WHERE ticker=?", (ticker,))
        if not r:
            return None
        r = r[0]
        return Contract(r["ticker"], r["series"], r["coin"], r["open_ts"], r["close_ts"], bool(r["yes_is_up"]),
                        r["status"], d(r["floor_strike"]) if r["floor_strike"] else None, r["exchange_index"],
                        PriceGrid.from_api(json.loads(r["grid"])) if r["grid"] else PriceGrid.default(),
                        r["result"] or "")

    # ---- entries ------------------------------------------------------------------------
    def insert_intent(self, *, mode: str, series: str, coin: str, ticker: str, leg: str, outcome: str,
                      price: Decimal, count: int, max_loss: Decimal, expiration_ts: int, client_order_id: str,
                      max_attempts: int, ask: Decimal | None = None, now: float | None = None) -> int:
        now = now if now is not None else time.time()
        try:
            with self.tx() as c:
                n = c.execute("SELECT COUNT(*) FROM entries WHERE mode=? AND ticker=?", (mode, ticker)).fetchone()[0]
                if n >= max_attempts:
                    raise SlotTaken(f"bid cap {max_attempts} reached for {ticker}")
                filled = c.execute("SELECT COUNT(*) FROM entries WHERE mode=? AND ticker=? AND CAST(filled_count AS REAL) > 0",
                                   (mode, ticker)).fetchone()[0]
                if filled:
                    raise SlotTaken(f"{ticker} already has a filled entry")
                cur = c.execute(
                    """INSERT INTO entries(mode,series,coin,ticker,attempt,client_order_id,leg,outcome,price,count,max_loss,
                       expiration_ts,state,slot,created_at,ask_at_entry) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,'intent',1,?,?)""",
                    (mode, series, coin, ticker, n + 1, client_order_id, leg, outcome, str(price), int(count),
                     str(max_loss), int(expiration_ts), now, str(ask) if ask is not None else None))
                return cur.lastrowid
        except sqlite3.IntegrityError as e:
            raise SlotTaken(str(e)) from None

    def entry(self, entry_id: int) -> dict | None:
        r = self._q("SELECT * FROM entries WHERE id=?", (entry_id,))
        return dict(r[0]) if r else None

    def entry_by_coid(self, coid: str) -> dict | None:
        r = self._q("SELECT * FROM entries WHERE client_order_id=?", (coid,))
        return dict(r[0]) if r else None

    def active_entry(self, mode: str, ticker: str) -> dict | None:
        r = self._q("SELECT * FROM entries WHERE mode=? AND ticker=? AND slot=1", (mode, ticker))
        return dict(r[0]) if r else None

    def entries(self, mode: str, *, series: str | None = None, states=None, ticker: str | None = None,
                unsettled_slot: bool = False, limit: int | None = None) -> list[dict]:
        sql, args = "SELECT * FROM entries WHERE mode=?", [mode]
        if series:
            sql += " AND series=?"; args.append(series)
        if ticker:
            sql += " AND ticker=?"; args.append(ticker)
        if states:
            sql += f" AND state IN ({','.join('?' * len(states))})"; args += list(states)
        if unsettled_slot:
            sql += " AND slot=1 AND settled_result IS NULL"
        sql += " ORDER BY id DESC"
        if limit:
            sql += f" LIMIT {int(limit)}"
        return [dict(r) for r in self._q(sql, args)]

    def attempts(self, mode: str, ticker: str) -> int:
        return self._q("SELECT COUNT(*) n FROM entries WHERE mode=? AND ticker=?", (mode, ticker))[0]["n"]

    def mark_sent(self, entry_id: int, now: float | None = None) -> None:
        self._x("UPDATE entries SET sent_at=? WHERE id=?", (now or time.time(), entry_id))

    def mark_resting(self, entry_id: int, order_id: str) -> None:
        self._x("UPDATE entries SET state='resting', order_id=?, error=NULL WHERE id=? AND state IN ('intent','unknown')",
                (order_id, entry_id))

    def mark_unknown(self, entry_id: int, error: str) -> None:
        self._x("UPDATE entries SET state='unknown', error=? WHERE id=?", (error[:500], entry_id))

    def _end(self, entry_id: int, state: str, reason: str, error: str | None = None) -> None:
        with self.tx() as c:
            r = c.execute("SELECT filled_count FROM entries WHERE id=?", (entry_id,)).fetchone()
            filled = d_or_zero(r["filled_count"]) if r else ZERO
            slot = 1 if filled > ZERO else None
            c.execute("UPDATE entries SET state=?, slot=?, ended_at=?, end_reason=?, error=COALESCE(?, error) WHERE id=?",
                      (state, slot, time.time(), reason, error, entry_id))

    def mark_rejected(self, entry_id: int, error: str) -> None:
        self._end(entry_id, "rejected", "rejected", error[:500])

    def mark_not_placed(self, entry_id: int, reason: str) -> None:
        self._end(entry_id, "not_placed", reason)

    def bump_resend(self, entry_id: int) -> None:
        self._x("UPDATE entries SET resend_count=resend_count+1, sent_at=? WHERE id=?", (time.time(), entry_id))

    def apply_order(self, entry_id: int, info: OrderInfo, reason: str | None = None) -> dict:
        """Copy the exchange's view of the order onto the entry. Frees the slot if it ended unfilled."""
        with self.tx() as c:
            done = info.status != "resting"
            filled = info.fill_count
            slot = 1 if (not done or filled > ZERO) else None
            state = "done" if done else "resting"
            c.execute("""UPDATE entries SET order_id=?, state=?, slot=?, filled_count=?, fill_cost=?, fees=?,
                         ended_at=CASE WHEN ? THEN COALESCE(ended_at, ?) ELSE NULL END,
                         end_reason=CASE WHEN ? THEN COALESCE(end_reason, ?) ELSE end_reason END,
                         error=NULL WHERE id=?""",
                      (info.order_id, state, slot, str(filled), str(info.fill_cost), str(info.fees),
                       int(done), time.time(), int(done), reason or info.status, entry_id))
            return dict(c.execute("SELECT * FROM entries WHERE id=?", (entry_id,)).fetchone())

    def settle_entry(self, entry_id: int, result: str, payout: Decimal, pnl: Decimal, now: float | None = None) -> None:
        self._x("UPDATE entries SET settled_result=?, payout=?, pnl=?, settled_at=? WHERE id=? AND settled_result IS NULL",
                (result, str(payout), str(pnl), now or time.time(), entry_id))

    def unknown_count(self, mode: str) -> int:
        # 'intent' rows are only in flight for the length of one request (their worst case already counts as
        # exposure); a crash leaves them behind, and startup turns those into 'unknown'.
        return self._q("SELECT COUNT(*) n FROM entries WHERE mode=? AND state='unknown'", (mode,))[0]["n"]

    def intents_to_unknown(self, mode: str) -> int:
        """On startup an 'intent' row may have been sent before a crash: treat it as unknown."""
        cur = self._x("UPDATE entries SET state='unknown', error='found as intent at startup' WHERE mode=? AND state='intent'", (mode,))
        return cur.rowcount

    # ---- fills --------------------------------------------------------------------------
    def record_fill(self, entry_id: int | None, f) -> bool:
        cur = self._x("""INSERT OR IGNORE INTO fills(fill_id,entry_id,order_id,ticker,leg,count,price,fee,is_taker,ts)
                         VALUES(?,?,?,?,?,?,?,?,?,?)""",
                      (f.fill_id, entry_id, f.order_id, f.ticker, f.leg, str(f.count), str(f.price), str(f.fee),
                       int(f.is_taker), f.ts))
        return cur.rowcount > 0

    def fills(self, mode: str | None = None, limit: int = 200) -> list[dict]:
        if mode:
            return [dict(r) for r in self._q("""SELECT f.* FROM fills f JOIN entries e ON e.id=f.entry_id
                                                WHERE e.mode=? ORDER BY f.ts DESC LIMIT ?""", (mode, limit))]
        return [dict(r) for r in self._q("SELECT * FROM fills ORDER BY ts DESC LIMIT ?", (limit,))]

    # ---- events -------------------------------------------------------------------------
    def log_event(self, level: str, kind: str, message: str, coin: str | None = None, ticker: str | None = None) -> None:
        self._x("INSERT INTO events(ts,level,kind,coin,ticker,message) VALUES(?,?,?,?,?,?)",
                (time.time(), level, kind, coin, ticker, message[:2000]))

    def recent_events(self, limit: int = 50, levels=("warning", "error", "critical")) -> list[dict]:
        sql = f"SELECT * FROM events WHERE level IN ({','.join('?' * len(levels))}) ORDER BY id DESC LIMIT ?"
        return [dict(r) for r in self._q(sql, (*levels, limit))]
