"""Presets: the original strategy, the learning loop's recommendation, and the Clump slider's risk levels.

The Clump slider only changes measurable limits — stake per bet, total money at risk and how many bets can be
open at once. It never changes WHICH bets are taken (the price range stays the same), so a higher level does
not mean buying lower-probability bets.
"""
from __future__ import annotations

import hashlib
import json
import math
from decimal import Decimal

from .config import DEFAULT_SERIES, Config, Limits, StrategyCfg

RISK_LEVELS = [
    # level, name, stake $, total exposure % of capital, max bets open at once
    (1, "Tiny", Decimal("1"), Decimal("0.10"), 1),
    (2, "Light", Decimal("2"), Decimal("0.20"), 1),
    (3, "Steady", Decimal("4"), Decimal("0.40"), 2),
    (4, "Bold", Decimal("6"), Decimal("0.55"), 3),
    (5, "Chonky", Decimal("8"), Decimal("0.70"), 4),
]
STRATEGY_KEYS = ("entry", "side", "ask_min", "ask_max", "max_spread", "window_start_s", "window_end_s")
ORIGINAL = {k: (str(v) if isinstance(v, Decimal) else v) for k, v in StrategyCfg().model_dump().items() if k in STRATEGY_KEYS}


def limits_for_level(level: int, current: Limits) -> Limits:
    _, _, stake, exposure, positions = RISK_LEVELS[max(1, min(5, level)) - 1]
    cap = current.capital_cap_usd
    stake = min(stake, (cap * Decimal("0.4")).quantize(Decimal("0.01")))           # never more than 40% of capital per bet
    pct = Decimal(math.ceil(stake / cap * 100)) / 100
    return Limits(capital_cap_usd=cap, max_loss_per_position_usd=stake, max_loss_per_position_pct=min(Decimal(1), pct),
                  max_total_exposure_pct=exposure, daily_loss_pct=current.daily_loss_pct, max_open_positions=positions)


def level_of(lim: Limits) -> int | None:
    for lv, _, stake, exposure, positions in RISK_LEVELS:
        if lim.max_loss_per_position_usd == min(stake, (lim.capital_cap_usd * Decimal("0.4")).quantize(Decimal("0.01"))) \
                and lim.max_total_exposure_pct == exposure and lim.max_open_positions == positions:
            return lv
    return None


def strategy_dict(st: StrategyCfg) -> dict:
    return {k: (str(v) if isinstance(v, Decimal) else v) for k, v in st.model_dump().items() if k in STRATEGY_KEYS}


def fingerprint(cfg: Config, mode: str) -> str:
    lim = cfg.limits_for(mode)
    blob = json.dumps({"strategy": strategy_dict(cfg.strategy), "series": cfg.series,
                       "limits": {k: str(v) for k, v in (lim.model_dump() if lim else {}).items()}}, sort_keys=True)
    return hashlib.sha256(blob.encode()).hexdigest()[:12]


def describe(st: dict, coins: list[str] | None = None) -> list[str]:
    out = ["Buys at the asking price" if st.get("entry") == "ask" else "Waits at the bid",
           f"Favourites {float(st.get('ask_min', 0.88)) * 100:.0f}–{float(st.get('ask_max', 0.97)) * 100:.0f}¢",
           "Up and Down" if st.get("side", "both") == "both" else f"{str(st.get('side')).upper()} only"]
    ws, we = int(st.get("window_start_s", 300)), int(st.get("window_end_s", 60))
    out.append(f"last {ws // 60} min" if we == 60 else f"{ws // 60}–{we // 60} min before close")
    out.append("all coins" if not coins else ", ".join(coins))
    return out


def series_for(coins: list[str] | None) -> list[str]:
    return list(DEFAULT_SERIES) if not coins else [f"KX{c}15M" for c in coins]
