#!/bin/bash
# Odds & Whiskers background helper for macOS (the Mac twin of supervisor.ps1).
# Runs the bot and restarts it if it stops on its own. It does NOT restart when the bot was turned off from the
# app (data/<mode>/STOPPED exists) or when the bot refused to start (exit code 2, e.g. the live confirmation expired).
MODE="${1:-paper}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DATA="$ROOT/data/$MODE"
mkdir -p "$DATA"
PIDFILE="$DATA/supervisor.pid"
STOPFILE="$DATA/STOPPED"
LOG="$DATA/supervisor.log"
CONSOLE="$DATA/console.log"
PY="$ROOT/.venv/bin/python"
export PYTHONUNBUFFERED=1
export PYTHONIOENCODING=utf-8

log() { echo "$(date '+%Y-%m-%d %H:%M:%S')  $1" >> "$LOG"; }

echo $$ > "$PIDFILE"
trap 'rm -f "$PIDFILE"' EXIT
if [ -f "$CONSOLE" ] && [ "$(wc -c < "$CONSOLE")" -gt 5000000 ]; then mv -f "$CONSOLE" "$CONSOLE.old"; fi
log "supervisor started"
while true; do
    if [ -f "$STOPFILE" ]; then log "turned off from the app; not restarting"; break; fi
    log "starting bot"
    cd "$ROOT" || exit 1
    "$PY" -m favbot --config config.yaml run --mode "$MODE" >> "$CONSOLE" 2>&1
    CODE=$?
    log "bot exited (code $CODE)"
    if [ -f "$STOPFILE" ]; then log "turned off from the app; not restarting"; break; fi
    if [ "$CODE" -eq 2 ]; then
        echo "the bot refused to start; see data/$MODE/console.log" > "$STOPFILE"
        log "bot refused to start (code 2); not restarting"
        break
    fi
    if [ -f "$DATA/RESTART" ]; then
        rm -f "$DATA/RESTART"
        log "restart requested from the app (update); restarting now"
        sleep 2
        continue
    fi
    log "restarting in 30 seconds"
    sleep 30
done
