@echo off
cd /d "%~dp0"
.venv\Scripts\python.exe -m favbot report --mode live
echo.
.venv\Scripts\python.exe -m favbot status --mode live
pause
