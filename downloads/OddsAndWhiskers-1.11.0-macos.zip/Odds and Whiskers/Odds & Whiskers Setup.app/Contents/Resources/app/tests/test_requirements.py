"""requirements.txt: exactly one pinned version of each part for every supported Python (3.11-3.14)."""
from pathlib import Path

from pip._vendor.packaging.markers import Marker
from pip._vendor.packaging.requirements import Requirement

REQ = Path(__file__).resolve().parent.parent / "requirements.txt"


def resolved(py: str) -> dict:
    env = {"python_version": py, "python_full_version": py + ".0", "sys_platform": "darwin"}
    out = {}
    for line in REQ.read_text().splitlines():
        line = line.split("#")[0].strip()
        if not line:
            continue
        r = Requirement(line)
        if r.marker is None or r.marker.evaluate(env):
            assert r.name.lower() not in out, f"{r.name} listed twice for Python {py}"
            assert str(r.specifier).startswith("=="), f"{r.name} must be pinned"
            out[r.name.lower()] = str(r.specifier)
    return out


def test_every_supported_python_gets_one_pinned_set():
    sets = {py: resolved(py) for py in ("3.11", "3.12", "3.13", "3.14")}
    names = set(sets["3.12"])
    assert all(set(s) == names for s in sets.values())
    assert {"aiohttp", "cryptography", "pydantic", "pyyaml", "certifi"} <= names


def test_live_bot_python_keeps_its_versions_and_314_gets_ones_with_ready_made_packages():
    assert resolved("3.12")["aiohttp"] == "==3.11.18" and resolved("3.12")["pydantic"] == "==2.11.4"
    assert resolved("3.14")["aiohttp"] == "==3.14.5" and resolved("3.14")["pyyaml"] == "==6.0.3"
    assert Marker('python_version >= "3.14"').evaluate({"python_version": "3.14"})
