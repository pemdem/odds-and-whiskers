@echo off
cd /d "%~dp0"
title Better Bot - real money
echo This switches Better Bot from practice to REAL money, step by step. You choose the limits
echo and type the confirmation yourself. Close this window to cancel.
echo.
.venv\Scripts\python.exe -m favbot go-live
echo.
pause
