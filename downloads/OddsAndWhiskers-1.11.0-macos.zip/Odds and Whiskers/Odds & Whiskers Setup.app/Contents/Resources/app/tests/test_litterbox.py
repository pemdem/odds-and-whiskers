import json
from decimal import Decimal as D

from favbot import litterbox as lbx
from favbot.config import Config, StrategyCfg
from favbot.litterbox import _stats
from favbot.store import Store


def _settle(s, i, won, price="0.93", qty=4):
    eid = s.insert_intent(mode="paper", series="KXETH15M", coin="ETH", ticker=f"KXETH15M-{i}", leg="yes", outcome="UP",
                          price=D(price), count=qty, max_loss=D(price) * qty, expiration_ts=1, client_order_id=f"c{i}",
                          max_attempts=20)
    cost = D(price) * qty
    s._x("UPDATE entries SET filled_count=?, fill_cost=?, state='done' WHERE id=?", (str(qty), str(cost), eid))
    payout = D(qty) if won else D(0)
    s.settle_entry(eid, "yes" if won else "no", payout, payout - cost, now=1_800_000_000 + i)


def test_winning_streak_still_has_uncertainty(tmp_path):
    s = Store(tmp_path / "db.sqlite3")
    for i in range(12):
        _settle(s, i, True)
    st = _stats(s, D(100))
    assert st["bets"] == 12 and st["losses"] == 0
    assert st["se"] and st["se"] > 0.05            # ~sqrt(0.07/0.93)/sqrt(12) ~ 0.079, not 0
    assert st["roi"] - 2 * st["se"] < 0            # a 12-0 streak is not evidence of profit
    assert st["by_coin"]["ETH"]["bets"] == 12 and st["by_coin"]["ETH"]["wins"] == 12


def test_original_is_fixed_whatever_the_live_config_says():
    live = Config(strategy=StrategyCfg(entry="ask", side="down", ask_min=D("0.92")), series=["KXETH15M"])
    orig = next(m for m in lbx.MODELS if m.id == "original")
    st = lbx.model_strategy(orig)
    assert st == StrategyCfg()                                           # the original defaults, all fields
    assert st.entry == "bid" and st.side == "both" and st.ask_min == D("0.88")
    assert lbx.model_series(orig) == [f"KX{c}15M" for c in lbx.ORIGINAL_COINS]
    assert live.strategy.entry == "ask"                                  # (live settings didn't leak in)
    asker = next(m for m in lbx.MODELS if m.id == "asker")
    assert lbx.model_strategy(asker).entry == "ask" and lbx.model_strategy(asker).ask_max == D("0.97")


def test_risk_level_copies_same_strategy_and_coins_other_limits(tmp_path):
    lb = tmp_path / "litterbox"
    models = lbx.load_models(tmp_path, tmp_path)
    ids = [m.id for m in models]
    assert "original-L1" in ids and "original-L5" in ids                 # default copies (were Tiny Paws / Big Chonk)
    lbx.write_variants(lb, [{"base": "big3", "level": 5}, {"base": "big3", "level": 3}, {"base": "nope", "level": 2}])
    models = {m.id: m for m in lbx.load_models(tmp_path, tmp_path)}
    v = models["big3-L5"]
    assert "big3-L3" not in models and "nope-L2" not in models           # its own level / unknown base: skipped
    assert v.coins == models["big3"].coins and v.strategy == models["big3"].strategy and v.base == "big3"
    lim, base_lim = lbx.model_limits(v), lbx.model_limits(models["big3"])
    assert lim.max_loss_per_position_usd == D("8") and lim.max_open_positions == 4 and lim.max_total_exposure_pct == D("0.70")
    assert base_lim.max_loss_per_position_usd == D("4") and base_lim.max_open_positions == 2


def test_new_season_never_inherits_old_bets(tmp_path):
    root = tmp_path / "litterbox"
    (root / "asker").mkdir(parents=True)
    (root / "asker" / "favbot.sqlite3").write_text("old season-2 bets")      # same id as before, no season mark
    (root / "copycat").mkdir()                                               # model no longer in the line-up
    models = [m for m in lbx.MODELS if m.id in ("asker", "original")]
    moved = lbx.prepare_dirs(root, models)
    assert sorted(moved) == ["asker", "copycat"]
    assert not (root / "asker" / "favbot.sqlite3").exists()                  # starts empty
    assert (root / "asker" / "season.txt").read_text() == lbx.SEASON
    assert len(list((root / "_old").iterdir())) == 2                         # archived, not deleted
    assert lbx.prepare_dirs(root, models) == []                              # same season: kept


def test_picker_feeds_models_and_coins_into_each_other():
    from favbot import picker
    summ = {"models": [
        {"id": "original", "name": "Original", "role": "baseline", "coins": None, "strategy": {},
         "by_coin": {"ETH": {"bets": 10, "wins": 9, "pnl": -1.0, "staked": 37.0}}},
        {"id": "asker", "name": "Ask Buyer", "role": "experiment", "coins": None, "strategy": {"entry": "ask"},
         "by_coin": {"ETH": {"bets": 5, "wins": 5, "pnl": 1.0, "staked": 18.0}}},
        {"id": "solo-eth", "name": "ETH Solo", "role": "experiment", "coins": ["ETH"], "strategy": {"entry": "ask"},
         "by_coin": {"ETH": {"bets": 40, "wins": 38, "pnl": 2.0, "staked": 150.0}}},
        {"id": "asker-L5", "name": "Ask Buyer · Chonky", "base": "asker", "coins": None, "strategy": {"entry": "ask"},
         "by_coin": {"ETH": {"bets": 99, "wins": 0, "pnl": -99.0, "staked": 99.0}}},
    ]}
    bt = {"models": {"asker": {"by_coin": {"SOL": {"n": 300, "wins": 280, "pnl_usd": 5.0, "staked_usd": 1100.0}}}}}
    P = picker.build(summ, bt, {"entry": "bid"}, ["ETH", "SOL"])
    names = [g["name"] for g in P["models"]]
    assert names[0] == "Original" and "Ask Buyer" in names and "ETH Solo" not in names     # one row per strategy
    ask = picker.find(P, "asker")
    assert ask["fresh"]["ETH"]["bets"] == 40 and ask["fresh"]["ETH"]["from"] == "solo-eth"  # most bets, no double count
    assert ask["past"]["SOL"]["n"] == 300 and "solo-eth" in ask["members"]
    assert "asker-L5" not in ask["members"]                                                # risk copies aside
    assert P["live"]["key"] == "original" and P["live"]["coins"] == ["ETH", "SOL"]
    rec = picker.build(summ, bt, {"entry": "ask"}, ["ETH"], {"ready": True, "strategy": {"entry": "ask"}, "coins": ["ETH"]})
    r = picker.find(rec, "recommended")
    assert r and r["is_live"] and r["default_coins"] == ["ETH"]


def test_variants_file_is_bounded(tmp_path):
    lbx.write_variants(tmp_path, [{"base": f"m{i}", "level": 2} for i in range(30)])
    assert len(json.loads((tmp_path / "variants.json").read_text())) == lbx.MAX_VARIANTS
