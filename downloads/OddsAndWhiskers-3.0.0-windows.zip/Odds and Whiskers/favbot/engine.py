"""Loops: one Engine per coin, all inside one Bot sharing one database, account and set of limits."""
from __future__ import annotations

import asyncio
import logging
import re
import time
from decimal import Decimal
from pathlib import Path

from .config import Config, Limits
from .execution import Execution
from .logutil import log
from .models import coin_of, Book, Contract, ExchangeStatus, SeriesInfo
from .money import KNOWN_FEE_TYPES, ZERO, d, d_or_zero, maker_fee, taker_fee
from .portfolio import AccountCache, Portfolio
from .providers.base import ApiError, TransportError
from .providers.kalshi import verify_market
from .risk import RiskInputs, daily_loss_breached, equity_for_limits, evaluate
from .strategy.favourite import Decision, decide, should_keep

logger = logging.getLogger("favbot.engine")


WAKE_GAP_S = 20.0      # a one-second check that took longer than this means the computer slept (or froze)


class Bot:
    def __init__(self, cfg: Config, mode: str, store, md, trading, limits: Limits, *, alerts=None,
                 data_dir: Path | None = None, clock=time.time):
        self.cfg = cfg
        self.mode = mode
        self.store = store
        self.md = md
        self.trading = trading
        self.limits = limits
        self.alerts = alerts
        self.clock = clock
        self.data_dir = Path(data_dir) if data_dir else None
        self.marks: dict[str, Book] = {}
        self.account = AccountCache(trading, cfg.timing.account_cache_s, clock)
        self.portfolio = Portfolio(store, mode, self.account, self.marks, clock)
        self.execution = Execution(store, trading, mode, alerts=alerts, account=self.account, clock=clock)
        self.series_info: dict[str, SeriesInfo] = {}
        self.exchange_status: ExchangeStatus | None = None
        self.exchange_index: int = 2
        self.exchange = "kalshi"                    # "polymarket_us" for that workspace's practice bot
        self.paused = False
        self.recovering: str | None = None          # Cat Nap: why we're re-checking with the exchange (no new bets)
        self.last_recovery: dict | None = None
        self._recover_retry = 0.0
        self.daily_loss_day: int | None = None
        self.stop = asyncio.Event()
        self.started_at = clock()
        self._kill_seen = False
        self.engines = [Engine(self, s) for s in cfg.series]

    # ---- shared state -------------------------------------------------------------------
    def fee_lookup(self, ticker: str):
        si = self.series_info.get(ticker.split("-", 1)[0])
        if si is None:
            return ("unknown", Decimal(1))
        return (si.fee_type, si.fee_multiplier)

    def kill_file(self) -> Path | None:
        return self.data_dir / "KILL" if self.data_dir else None

    def killed(self) -> str | None:
        k = self.store.kill_state()
        kf = self.kill_file()
        if kf is not None and kf.exists():
            if not k:
                self.store.set_kill("KILL file present")
                k = self.store.kill_state()
        return k["reason"] if k else None

    def trading_active(self) -> bool | None:
        s = self.exchange_status
        if s is None or self.clock() - s.fetched_at > 60:
            return None
        return s.trading_active

    def coins_off(self) -> list[str]:
        """Coins switched off from the dashboard settings (persisted in the database)."""
        return self.store.get_meta("coins_off", []) or []

    def daily_loss_hit(self) -> bool:
        return self.daily_loss_day == int(self.clock()) // 86400

    def cancel_reason(self) -> str | None:
        """Why every resting bid must be cancelled right now (None = normal operation)."""
        k = self.killed()
        if k:
            return f"kill switch: {k}"
        if self.paused:
            return "paused"
        if self.recovering:
            return f"recovering: {self.recovering}"
        if self.daily_loss_hit():
            return "daily loss limit"
        halts = self.store.halts()
        if halts:
            return "halted: " + ", ".join(halts)
        return None

    # ---- lifecycle ----------------------------------------------------------------------
    async def startup(self) -> None:
        n = self.store.intents_to_unknown(self.mode)
        if n:
            log(logger, logging.WARNING, "intents from a previous run treated as unknown", count=n)
        await self.refresh_exchange_status()
        for e in self.engines:
            await e.refresh_series()
        shards = {si.exchange_index for si in self.series_info.values()}
        if len(shards) > 1:
            raise RuntimeError(f"configured series span several exchange shards {shards}; balances are per shard")
        if shards:
            self.exchange_index = shards.pop()
        if hasattr(self.trading, "exchange_index"):
            self.trading.exchange_index = self.exchange_index
        for e in self.engines:
            try:
                await self.execution.reconcile(e.series)
            except (ApiError, TransportError) as ex:
                log(logger, logging.WARNING, "startup reconcile failed", series=e.series, error=str(ex))
        self.store.log_event("info", "startup", f"started in {self.mode} mode")

    async def refresh_exchange_status(self) -> None:
        try:
            self.exchange_status = await self.md.get_exchange_status(self.exchange_index)
        except (ApiError, TransportError) as e:
            log(logger, logging.WARNING, "exchange status unavailable", error=str(e))

    async def status_loop(self) -> None:
        while not self.stop.is_set():
            await self.refresh_exchange_status()
            await self._sleep(self.cfg.timing.metadata_refresh_s)

    async def guard_loop(self) -> None:
        """Kill switch and daily loss limit, checked every second."""
        last_heartbeat = 0.0
        while not self.stop.is_set():
            try:
                k = self.killed()
                if k and not self._kill_seen:
                    self._kill_seen = True
                    log(logger, logging.CRITICAL, "KILL SWITCH ON: no new orders, cancelling resting bids. "
                        "Filled positions are not closed.", reason=k)
                    self.store.log_event("critical", "kill", f"kill switch on: {k}")
                    if self.alerts:
                        self.alerts.kill(k)
                elif not k:
                    self._kill_seen = False
                snap = await self.portfolio.snapshot()
                if not self.daily_loss_hit() and daily_loss_breached(self.limits, snap.equity, snap.daily_pnl):
                    self.daily_loss_day = int(self.clock()) // 86400
                    limit = -(self.limits.daily_loss_pct * equity_for_limits(self.limits, snap.equity))
                    log(logger, logging.CRITICAL, "daily loss limit reached: no new bids, cancelling resting",
                        pnl=str(snap.daily_pnl), limit=str(limit))
                    self.store.log_event("critical", "daily_loss", f"daily loss limit: P&L {snap.daily_pnl:.2f} <= {limit:.2f}")
                    if self.alerts:
                        self.alerts.daily_loss(f"{snap.daily_pnl:.2f}", f"{limit:.2f}")
                if self.clock() - last_heartbeat >= 60:
                    last_heartbeat = self.clock()
                    self._heartbeat(snap)
                    self._maybe_summary(snap)
            except (ApiError, TransportError) as e:
                log(logger, logging.WARNING, "guard loop: account read failed", error=str(e))
            except Exception:  # noqa: BLE001
                logger.exception("guard loop error")
            await self._sleep(1.0)

    def _maybe_summary(self, snap) -> None:
        """Morning summary email, once a day at the chosen local hour."""
        if not self.alerts or not self.alerts.enabled:
            return
        prefs = self.alerts.prefs()
        lt = time.localtime(self.clock())
        key = f"summary_sent:{time.strftime('%Y-%m-%d', lt)}"
        if not prefs.get("summary") or lt.tm_hour != int(prefs.get("summary_hour", 8)) or self.store.get_meta(key):
            return
        self.store.set_meta(key, True)
        since = self.clock() - 86400
        rows = self.store._q("""SELECT pnl, payout FROM entries WHERE mode=? AND settled_at>=?
                                AND CAST(filled_count AS REAL) > 0""", (self.mode, since))
        wins = sum(1 for r in rows if d_or_zero(r["payout"]) > 0)
        pnl = sum((d_or_zero(r["pnl"]) for r in rows), ZERO)
        allrows = self.store._q("""SELECT pnl, payout FROM entries WHERE mode=? AND settled_result IS NOT NULL
                                   AND CAST(filled_count AS REAL) > 0""", (self.mode,))
        aw = sum(1 for r in allrows if d_or_zero(r["payout"]) > 0)
        anet = sum((d_or_zero(r["pnl"]) for r in allrows), ZERO)
        body = (f"Last 24 hours: {len(rows)} bets, {wins} won, {len(rows) - wins} lost, P&L {pnl:+.2f}\n"
                f"All time: {aw}-{len(allrows) - aw}, P&L {anet:+.2f}\n"
                f"Balance now: ${snap.equity:.2f} (available cash ${snap.balance:.2f})\n"
                f"Open bets: {snap.open_positions}\n\n"
                "A small sample does not show an edge. Check the app's 'Is it working?' card.")
        self.alerts.summary(f"Morning summary: {pnl:+.2f} in 24h, balance ${snap.equity:.2f}", body)

    def _heartbeat(self, snap) -> None:
        log(logger, logging.INFO, "heartbeat", mode=self.mode, equity=f"{snap.equity:.2f}",
            cash=f"{snap.balance:.2f}", exposure=f"{snap.exposure:.2f}", open=snap.open_positions,
            daily_pnl=f"{snap.daily_pnl:.2f}", skew=self.md.clock_skew_s and round(self.md.clock_skew_s, 2),
            coins={e.coin: e.status.get("decision") for e in self.engines})

    async def watch_loop(self) -> None:
        """Cat Nap: notice when the computer slept (the clock jumps between two checks) or the internet came back,
        and re-check everything with the exchange before trading again. Prices are fetched fresh every tick and
        the risk check rejects any that are too old, so nothing from before the gap is ever traded on."""
        last, was_down = self.clock(), False
        while not self.stop.is_set():
            await self._sleep(1.0)
            now = self.clock()
            gap, last = now - last, now
            down = bool(self.alerts and getattr(self.alerts, "_net_down", False))
            why = None
            if gap > WAKE_GAP_S:
                why = f"the computer was asleep or busy for {int(gap)} s"
            elif was_down and not down:
                why = "the internet connection came back"
            was_down = down
            try:
                if why:
                    await self.recover(why)
                elif self.recovering and now >= self._recover_retry:
                    await self.recover(self.recovering)
            except Exception:  # noqa: BLE001 - never let the watcher die
                logger.exception("recovery check failed")

    async def recover(self, why: str) -> bool:
        """Block new bets (and cancel waiting bids via cancel_reason), forget old prices, then reconcile every
        series and re-read the balance. Trading resumes only when all of that worked."""
        first = self.recovering is None
        self.recovering = why
        if first:
            log(logger, logging.WARNING, "recovering", why=why)
            self.store.log_event("warning", "recovering", f"{why}: re-checking orders and balance with Kalshi before trading")
        self.marks.clear()
        self.account.invalidate()
        try:
            await self.refresh_exchange_status()
            for e in self.engines:
                e._next_meta = 0.0                 # fresh contract list and settlements on the next tick
                await self.execution.reconcile(e.series)
            await self.portfolio.snapshot()
        except (ApiError, TransportError) as ex:
            self._recover_retry = self.clock() + 10
            log(logger, logging.WARNING, "recovery not finished, retrying", error=str(ex))
            return False
        self.recovering = None
        self.last_recovery = {"at": self.clock(), "why": why}
        self.store.log_event("info", "recovered", f"re-checked with Kalshi after {why}; trading resumed")
        return True

    async def _sleep(self, s: float) -> None:
        try:
            await asyncio.wait_for(self.stop.wait(), timeout=s)
        except asyncio.TimeoutError:
            pass

    async def run(self, duration: float | None = None) -> None:
        await self.startup()
        tasks = [asyncio.create_task(e.run(), name=f"engine-{e.coin}") for e in self.engines]
        tasks += [asyncio.create_task(self.status_loop(), name="status"),
                  asyncio.create_task(self.guard_loop(), name="guard"),
                  asyncio.create_task(self.watch_loop(), name="watch")]
        try:
            if duration:
                await self._sleep(duration)
                self.stop.set()
            else:
                await self.stop.wait()
        finally:
            self.stop.set()
            if self.exchange != "kalshi":
                # practice workspace: stop within seconds even if a slow, rate-limited request is still waiting (fake
                # money; anything interrupted is reconciled at the next start). The real Kalshi bot always finishes
                # what it's doing first.
                _, pending = await asyncio.wait(tasks, timeout=PRACTICE_STOP_GRACE_S)
                for t in pending:
                    t.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)

    async def shutdown(self, why: str) -> None:
        """Cancel our resting bids (they would expire within 20 s anyway). Filled positions are held."""
        for e in self.store.entries(self.mode, states=("resting",)):
            try:
                await self.execution.cancel(e, "shutdown")
            except Exception as ex:  # noqa: BLE001
                log(logger, logging.WARNING, "cancel at shutdown failed", ticker=e["ticker"], error=str(ex))
        self.store.log_event("info", "shutdown", why)
        if self.alerts:
            self.alerts.shutdown(why)


PRACTICE_STOP_GRACE_S = 8.0


class Engine:
    def __init__(self, bot: Bot, series: str):
        self.bot = bot
        self.series = series
        self.coin = coin_of(series)                 # KXETH15M (Kalshi) or PMETH15M (Polymarket US) → ETH
        self.contracts: dict[str, Contract] = {}
        self.disabled: str | None = "series info not loaded"
        self.status: dict = {"coin": self.coin, "series": series, "decision": "starting"}
        self._next_meta = 0.0
        self._next_series = 0.0
        self._next_reconcile = 0.0
        self._last_logged: dict[str, str] = {}
        self._last_block: dict[str, str] = {}

    @property
    def cfg(self):
        return self.bot.cfg

    async def run(self) -> None:
        poll = self.cfg.strategy.poll_s
        while not self.bot.stop.is_set():
            t0 = time.monotonic()
            try:
                await self.tick()
                self.status.pop("error", None)
            except (ApiError, TransportError) as e:
                self.status["error"] = str(e)[:200]
                log(logger, logging.WARNING, "tick failed", coin=self.coin, error=str(e))
            except Exception as e:  # noqa: BLE001
                self.status["error"] = f"{type(e).__name__}: {e}"[:200]
                logger.exception("engine %s tick error", self.coin)
                self.bot.store.log_event("error", "engine_error", f"{type(e).__name__}: {e}", self.coin)
                if self.bot.alerts:
                    self.bot.alerts.error("engine_error", f"{self.coin}: {type(e).__name__}: {e}")
            await self.bot._sleep(max(0.05, poll - (time.monotonic() - t0)))

    async def refresh_series(self) -> None:
        try:
            si = await self.bot.md.get_series(self.series)
        except (ApiError, TransportError) as e:
            self.disabled = f"series info unavailable: {e}"
            return
        if si.fee_type not in KNOWN_FEE_TYPES:
            self.disabled = f"unrecognised fee_type {si.fee_type!r}: not trading"
            log(logger, logging.ERROR, "unknown fee type, coin disabled", series=self.series, fee_type=si.fee_type)
        else:
            self.disabled = None
        self.bot.series_info[self.series] = si
        self._next_series = self.bot.clock() + 3600

    async def refresh_contracts(self, now: float) -> None:
        raw = await self.bot.md.list_markets(self.series, int(now) - 120, int(now) + 3600)
        verified: dict[str, Contract] = {}
        for m in raw:
            c, why = verify_market(m, self.series, self.bot.exchange_index)
            if c:
                verified[c.ticker] = c
                self.bot.store.upsert_contract(c)
            else:
                t = m.get("ticker", "?")
                close = m.get("close_time")
                if self._last_logged.get("verify:" + t) != why and why not in ("strike_type not set yet",) \
                        and not why.startswith("status "):
                    self._last_logged["verify:" + t] = why
                    log(logger, logging.WARNING, "contract failed verification", ticker=t, why=why, close=close)
        self.contracts = verified

    async def tick(self) -> None:
        bot, now = self.bot, self.bot.clock()
        if now >= self._next_series:
            await self.refresh_series()
        if now >= self._next_meta:
            self._next_meta = now + self.cfg.timing.metadata_refresh_s
            await self.refresh_contracts(now)
            await self.check_settlements(now)
        if now >= self._next_reconcile:
            self._next_reconcile = now + self.cfg.timing.reconcile_s
            await bot.execution.reconcile(self.series, now)

        cancel_reason = bot.cancel_reason()
        if cancel_reason is None and self.coin in bot.coins_off():
            cancel_reason = "turned off in settings"
        targets: dict[str, Contract] = dict(self.contracts)
        for e in bot.store.entries(bot.mode, series=self.series, states=("resting", "unknown", "intent")):
            if e["ticker"] not in targets:
                c = bot.store.contract(e["ticker"])
                if c:
                    targets[c.ticker] = c
        shown = False
        for c in sorted(targets.values(), key=lambda c: c.close_ts):
            secs_left = c.close_ts - now
            if secs_left <= -60 and not bot.store.active_entry(bot.mode, c.ticker):
                continue
            await self.handle(c, now, cancel_reason)
            if not shown and secs_left > 0:
                shown = True
                self.status["contract"] = c.ticker
                self.status["secs_left"] = int(secs_left)
                self.status["floor_strike"] = str(c.floor_strike) if c.floor_strike is not None else None
        if not shown:
            self.status.update({"contract": None, "secs_left": None, "up_bid": None, "up_ask": None,
                                "down_bid": None, "down_ask": None})
            self.status["decision"] = self.disabled or "no verified contract open"

    async def handle(self, c: Contract, now: float, cancel_reason: str | None) -> None:
        bot, st = self.bot, self.cfg.strategy
        ex = bot.execution
        entry = bot.store.active_entry(bot.mode, c.ticker)
        secs_left = c.close_ts - now
        in_window = 0 < secs_left <= st.window_start_s + st.poll_s
        decision = Decision(False, f"waiting ({int(secs_left)}s left)" if secs_left > 0 else "closed", secs_left=secs_left)
        book = None
        if in_window and c.status == "active":
            book = await bot.md.get_orderbook(c.ticker)
            bot.marks[c.ticker] = book
            bot.trading.observe_book(book, bot.clock())
            decision = decide(c, book, bot.clock(), st)
        elif entry is None and secs_left > 0 and c.ticker != self.status.get("contract"):
            return
        self._show(c, book, decision, entry)

        if entry is not None:
            if entry["state"] in ("unknown", "intent"):
                wanted = cancel_reason is None and should_keep(entry["leg"], d(entry["price"]), decision)
                entry = await ex.resolve_unknown(entry, still_wanted=wanted)
            elif entry["state"] == "resting":
                entry = await ex.refresh(entry)
                if entry["state"] == "resting":
                    if cancel_reason:
                        entry = await ex.cancel(entry, cancel_reason)
                    elif not should_keep(entry["leg"], d(entry["price"]), decision):
                        entry = await ex.cancel(entry, decision.reason)
            if entry and entry.get("slot") == 1:
                if d_or_zero(entry["filled_count"]) > ZERO:
                    self.status["position"] = f"holding {entry['filled_count']} {entry['outcome']} @ {entry['price']}"
                return

        if cancel_reason or not decision.bid or self.disabled or book is None:
            if cancel_reason and decision.bid:
                self._block(c, cancel_reason)
            return
        if bot.store.attempts(bot.mode, c.ticker) >= st.max_bids_per_contract:
            self._block(c, f"bid cap {st.max_bids_per_contract} reached")
            return

        si = bot.series_info[self.series]
        snap = await bot.portfolio.snapshot()
        r = evaluate(RiskInputs(
            limits=bot.limits, equity=snap.equity, available_cash=snap.available_cash, exposure=snap.exposure,
            open_positions=snap.open_positions, daily_pnl=snap.daily_pnl, price=decision.price,
            fee_fn=(lambda q, p: taker_fee(si.fee_type, si.fee_multiplier, q, p)) if st.entry == "ask" else
                   (lambda q, p: maker_fee(si.fee_type, si.fee_multiplier, q, p)),
            killed=bool(bot.killed()), paused=bot.paused, halts=tuple(bot.store.halts()),
            unknown_orders=bot.store.unknown_count(bot.mode), trading_active=bot.trading_active(),
            clock_skew_s=bot.md.clock_skew_s, max_clock_skew_s=self.cfg.timing.max_clock_skew_s,
            book_age_s=book.age(bot.clock()), stale_book_s=self.cfg.timing.stale_book_s))
        if not r.ok:
            self._block(c, r.reason)
            return
        self._last_block.pop(c.ticker, None)
        await ex.place(c, leg=decision.leg, outcome=decision.outcome, price=decision.price, count=r.quantity,
                       max_loss=r.max_loss, expiration_ts=decision.expiration_ts,
                       max_attempts=st.max_bids_per_contract, ask=decision.ask,
                       post_only=st.entry != "ask")

    def _block(self, c: Contract, reason: str) -> None:
        self.status["blocked"] = reason
        if self._last_block.get(c.ticker) != reason:
            self._last_block[c.ticker] = reason
            log(logger, logging.INFO, "bid blocked", coin=self.coin, ticker=c.ticker, reason=reason)

    def _show(self, c: Contract, book: Book | None, decision: Decision, entry: dict | None) -> None:
        if book is None:
            self.status.update({"up_bid": None, "up_ask": None, "down_bid": None, "down_ask": None})
        else:
            up, dn = c.leg_of("UP"), c.leg_of("DOWN")
            self.status.update({
                "up_bid": _s(book.best_bid(up)), "up_ask": _s(book.best_ask(up)),
                "down_bid": _s(book.best_bid(dn)), "down_ask": _s(book.best_ask(dn)),
                "book_ts": book.fetched_at})
            key = re.sub(r"[\d.]+", "#", decision.reason) + str(decision.price)
            if self._last_logged.get(c.ticker) != key:
                self._last_logged[c.ticker] = key
                log(logger, logging.INFO, "decision", coin=self.coin, ticker=c.ticker, secs_left=int(decision.secs_left or 0),
                    decision=decision.reason, up=f"{_s(book.best_bid(up))}/{_s(book.best_ask(up))}",
                    down=f"{_s(book.best_bid(dn))}/{_s(book.best_ask(dn))}")
        self.status["decision"] = self.disabled or decision.reason
        if entry is None:
            self.status.pop("position", None)
            self.status.pop("entry", None)
            if not decision.bid:
                self.status.pop("blocked", None)
        else:
            self.status["entry"] = f"{entry['state']} {entry['outcome']} {entry['count']}@{entry['price']}"

    async def check_settlements(self, now: float) -> None:
        bot = self.bot
        rows = bot.store._q("""SELECT DISTINCT e.ticker FROM entries e JOIN contracts c ON c.ticker=e.ticker
                               WHERE e.mode=? AND e.series=? AND e.settled_result IS NULL AND c.close_ts < ?""",
                            (bot.mode, self.series, now - 5))
        for r in rows[:10]:
            t = r["ticker"]
            m = await bot.md.get_market(t)
            status, result = m.get("status"), m.get("result") or ""
            if status != "finalized" or result not in ("yes", "no"):
                continue
            bot.store.set_contract_result(t, status, result)
            await bot.trading.settle(t, result)
            bot.account.invalidate()
            for e in bot.store.entries(bot.mode, ticker=t):
                if e["settled_result"] is not None or e["state"] in ("resting", "unknown", "intent"):
                    continue
                filled = d_or_zero(e["filled_count"])
                cost = d_or_zero(e["fill_cost"]) + d_or_zero(e["fees"])
                won = e["leg"] == result
                payout = filled if won else ZERO
                pnl = payout - cost
                bot.store.settle_entry(e["id"], result, payout, pnl, now)
                if filled > ZERO:
                    msg = (f"{'WON' if won else 'LOST'} {t}: held {filled} {e['outcome']} @ {e['price']}, "
                           f"result {result.upper()}, P&L {pnl:+.2f}")
                    bot.store.log_event("info", "settlement", msg, self.coin, t)
                    log(logger, logging.INFO, "settlement", coin=self.coin, ticker=t, won=won, pnl=f"{pnl:.2f}")
                    if bot.alerts:
                        bot.alerts.result(self.coin, t, won, f"{pnl:+.2f}", msg)


def _s(x) -> str | None:
    return None if x is None else f"{x:.3f}".rstrip("0").rstrip(".") if x < 1 else str(x)
