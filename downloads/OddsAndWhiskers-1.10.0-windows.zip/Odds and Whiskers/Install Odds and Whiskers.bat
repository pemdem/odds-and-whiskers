@echo off
cd /d "%~dp0"
title Odds and Whiskers - install
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\install.ps1"
echo.
pause
