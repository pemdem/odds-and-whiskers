from decimal import Decimal as D

from favbot.config import Limits
from favbot.presets import ORIGINAL, RISK_LEVELS, level_of, limits_for_level


def cur():
    return Limits(capital_cap_usd="22", max_loss_per_position_usd="4", max_loss_per_position_pct="0.20",
                  max_total_exposure_pct="0.40", daily_loss_pct="0.20", max_open_positions=2)


def test_levels_only_change_size_exposure_positions():
    c = cur()
    for lv, *_ in RISK_LEVELS:
        L = limits_for_level(lv, c)
        assert L.capital_cap_usd == c.capital_cap_usd and L.daily_loss_pct == c.daily_loss_pct
    stakes = [limits_for_level(lv, c).max_loss_per_position_usd for lv in range(1, 6)]
    assert stakes == sorted(stakes) and stakes[-1] <= D("8.80")          # capped at 40% of $22


def test_original_strategy_unchanged_by_slider():
    assert ORIGINAL["entry"] == "bid" and ORIGINAL["ask_min"] == "0.88" and ORIGINAL["ask_max"] == "0.97"


def test_level_round_trip():
    assert level_of(limits_for_level(3, cur())) == 3
