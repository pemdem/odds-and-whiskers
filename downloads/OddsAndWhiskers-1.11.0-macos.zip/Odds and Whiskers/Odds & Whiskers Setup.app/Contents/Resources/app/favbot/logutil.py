"""Structured JSON logs with secret redaction, plus the one-process-per-data-directory lock."""
from __future__ import annotations

import json
import logging
import os
import re
import sys
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path

_SECRET_KEYS = re.compile(r"(key|secret|signature|password|token|authorization)", re.I)
_PEM = re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----", re.S)
_HDR = re.compile(r"(KALSHI-ACCESS-(?:KEY|SIGNATURE)['\"]?\s*[:=]\s*['\"]?)[^'\",\s}]+", re.I)


def redact(obj):
    if isinstance(obj, dict):
        return {k: ("<redacted>" if _SECRET_KEYS.search(str(k)) and k not in ("ticker",) else redact(v))
                for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [redact(v) for v in obj]
    if isinstance(obj, str):
        s = _PEM.sub("<redacted-pem>", obj)
        return _HDR.sub(r"\1<redacted>", s)
    return obj


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        out = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created)) + f".{int(record.msecs):03d}Z",
            "level": record.levelname,
            "logger": record.name,
            "msg": redact(record.getMessage()),
        }
        extra = getattr(record, "data", None)
        if extra:
            out["data"] = redact(extra)
        if record.exc_info:
            out["exc"] = redact(self.formatException(record.exc_info))
        return json.dumps(out, default=str)


class ConsoleFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        t = time.strftime("%H:%M:%S", time.gmtime(record.created))
        s = f"{t}Z {record.levelname:<5} {redact(record.getMessage())}"
        extra = getattr(record, "data", None)
        if extra:
            s += " " + json.dumps(redact(extra), default=str)
        if record.exc_info and record.levelno >= logging.ERROR:
            s += "\n" + redact(self.formatException(record.exc_info))
        return s


def setup_logging(data_dir: Path, level: str = "INFO", console: bool = True) -> None:
    data_dir.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(level.upper())
    fh = RotatingFileHandler(data_dir / "bot.log.jsonl", maxBytes=20_000_000, backupCount=5, encoding="utf-8")
    fh.setFormatter(JsonFormatter())
    root.addHandler(fh)
    if console:
        ch = logging.StreamHandler(sys.stdout)
        ch.setFormatter(ConsoleFormatter())
        root.addHandler(ch)
    logging.getLogger("aiohttp.access").setLevel(logging.WARNING)


def log(logger: logging.Logger, level: int, msg: str, **data) -> None:
    logger.log(level, msg, extra={"data": data} if data else None)


class ProcessLock:
    """Exclusive lock on <data_dir>/bot.lock. A second `run` on the same directory fails fast."""

    def __init__(self, data_dir: Path):
        self.path = data_dir / "bot.lock"
        self._fh = None

    def acquire(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fh = open(self.path, "a+")
        try:
            if os.name == "nt":
                import msvcrt
                fh.seek(0)
                msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            fh.close()
            raise RuntimeError(f"another favbot process is already using {self.path.parent}") from None
        fh.seek(0)
        fh.truncate()
        fh.write(str(os.getpid()))
        fh.flush()
        self._fh = fh

    def release(self) -> None:
        if not self._fh:
            return
        try:
            if os.name == "nt":
                import msvcrt
                self._fh.seek(0)
                msvcrt.locking(self._fh.fileno(), msvcrt.LK_UNLCK, 1)
        except OSError:
            pass
        self._fh.close()
        self._fh = None
