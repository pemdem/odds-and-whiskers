#!/bin/bash
# "Odds & Whiskers Setup" for macOS - the whole install with clicks only, no Terminal.
#  1. copies the app to ~/Library/Application Support/Odds and Whiskers (kept on this Mac, never synced to iCloud)
#  2. downloads its own Python 3.12 (checked against a fixed SHA-256 before it is used) - no python.org step
#  3. installs the parts the app needs, makes the "Odds & Whiskers" app (Applications + Desktop) and opens it
# Running it again repairs or updates the app; your settings, Kalshi key, limits and history are always kept.
set -u
BUNDLE_RES="$(cd "$(dirname "$0")/../Resources" && pwd)"
SRC="$BUNDLE_RES/app"
DEST="$HOME/Library/Application Support/Odds and Whiskers"
LOG="$HOME/Library/Logs/Odds and Whiskers Setup.log"
TITLE="Odds & Whiskers"
mkdir -p "$(dirname "$LOG")"
note() { echo "$(date '+%H:%M:%S') $1" >> "$LOG"; osascript -e "display notification \"$1\" with title \"$TITLE\"" >/dev/null 2>&1; }
fail() {
    echo "$(date '+%H:%M:%S') FAILED: $1" >> "$LOG"
    osascript -e "display dialog \"$1\" & return & return & \"Details: ~/Library/Logs/Odds and Whiskers Setup.log\" with title \"$TITLE\" buttons {\"OK\"} default button 1 with icon caution" >/dev/null 2>&1
    exit 1
}
ask() {  # ask "message" "No button" "Yes button" -> prints the button pressed
    osascript -e "button returned of (display dialog \"$1\" with title \"$TITLE\" buttons {\"$2\", \"$3\"} default button \"$3\" with icon note)" 2>/dev/null
}

if [ -x "$DEST/.venv/bin/python" ]; then
    MSG="Update or repair Odds & Whiskers on this Mac?\n\nYour settings, Kalshi key, limits and history are kept."
else
    MSG="Set up Odds & Whiskers on this Mac?\n\nSetup downloads its own copy of Python (about 25 MB) and installs everything else by itself. It takes 2 to 3 minutes. Nothing else on your Mac is changed."
fi
[ "$(ask "$MSG" "Cancel" "Install")" = "Install" ] || exit 0
echo "---- setup $(date)" >> "$LOG"

# 1. the app's files (code only - personal setup is never overwritten)
note "Copying the app..."
mkdir -p "$DEST" || fail "Couldn't create the app folder."
rsync -a --exclude 'config.yaml' --exclude '.env' --exclude 'data/' --exclude 'keys/' --exclude '.venv/' \
      --exclude 'versions/' --exclude 'python/' "$SRC/" "$DEST/" >> "$LOG" 2>&1 || fail "Couldn't copy the app's files."
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null
chmod +x "$DEST"/app/*.sh "$DEST"/*.command 2>/dev/null
[ -f "$DEST/config.yaml" ] || cp "$DEST/config.example.yaml" "$DEST/config.yaml"
[ -f "$DEST/.env" ] || cp "$DEST/.env.example" "$DEST/.env"
mkdir -p "$DEST/keys" "$DEST/data" && chmod 700 "$DEST/keys" "$DEST/data"

# 2. Python: our own copy, checked before use (falls back to a Python already on this Mac)
SUPPORTED='import sys; sys.exit(0 if (3, 11) <= sys.version_info[:2] <= (3, 14) else 1)'
PY="$DEST/python/bin/python3"
if ! { [ -x "$PY" ] && "$PY" -c "$SUPPORTED" 2>/dev/null; }; then
    ARCH="$(uname -m)"
    [ "$(sysctl -in sysctl.proc_translated 2>/dev/null)" = "1" ] && ARCH=arm64        # Apple silicon under Rosetta
    read -r URL SHA <<< "$(awk -v a="$ARCH" '$1 == a { print $2, $3 }' "$DEST/app/python_mac.txt")"
    PY=""
    if [ -n "${URL:-}" ]; then
        note "Downloading Python (about 25 MB)..."
        TMP="$(mktemp -d)"
        if curl -fsSL --retry 3 --connect-timeout 20 -o "$TMP/python.tar.gz" "$URL" >> "$LOG" 2>&1; then
            GOT="$(shasum -a 256 "$TMP/python.tar.gz" | awk '{ print $1 }')"
            if [ "$GOT" = "$SHA" ]; then
                rm -rf "$DEST/python" && tar -xzf "$TMP/python.tar.gz" -C "$DEST" >> "$LOG" 2>&1 && PY="$DEST/python/bin/python3"
            else
                echo "python download checksum mismatch: $GOT" >> "$LOG"
            fi
        fi
        rm -rf "$TMP"
    fi
    if [ -z "$PY" ] || ! "$PY" -c "$SUPPORTED" 2>/dev/null; then
        PY=""
        for c in python3.12 python3.13 python3.14 python3.11 /Library/Frameworks/Python.framework/Versions/3.12/bin/python3 python3; do
            if command -v "$c" >/dev/null 2>&1 && "$c" -c "$SUPPORTED" 2>/dev/null; then PY="$(command -v "$c")"; break; fi
        done
    fi
    [ -n "$PY" ] || { open "https://www.python.org/downloads/macos/"
                      fail "Python couldn't be downloaded. Check the internet connection and open Setup again, or install Python 3.12 from the page that just opened and then open Setup again."; }
fi
echo "python: $PY" >> "$LOG"

# 3. the app's own environment and its parts
if [ -x "$DEST/.venv/bin/python" ] && ! "$DEST/.venv/bin/python" -c "$SUPPORTED" 2>/dev/null; then rm -rf "$DEST/.venv"; fi
if [ ! -x "$DEST/.venv/bin/python" ]; then "$PY" -m venv "$DEST/.venv" >> "$LOG" 2>&1 || fail "Couldn't create the app's Python environment."; fi
note "Installing the parts it needs (1 to 2 minutes)..."
"$DEST/.venv/bin/python" -m pip install --disable-pip-version-check --prefer-binary -q -r "$DEST/requirements.txt" >> "$LOG" 2>&1 \
    || fail "Installing the parts failed. Check the internet connection and open Setup again."

# 4. the "Odds & Whiskers" app that opens it (made on this Mac, so macOS doesn't block it)
make_app() {  # make_app <path to .app>
    local A="$1"
    rm -rf "$A" && mkdir -p "$A/Contents/MacOS" "$A/Contents/Resources" || return 1
    cat > "$A/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>OddsAndWhiskers</string>
<key>CFBundleIdentifier</key><string>io.github.pemdem.oddsandwhiskers</string>
<key>CFBundleName</key><string>Odds &amp; Whiskers</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleIconFile</key><string>AppIcon</string>
<key>LSMinimumSystemVersion</key><string>11.0</string>
</dict></plist>
PLIST
    printf '#!/bin/bash\nexec /bin/bash "%s/app/launch_mac.sh"\n' "$DEST" > "$A/Contents/MacOS/OddsAndWhiskers"
    chmod +x "$A/Contents/MacOS/OddsAndWhiskers"
    [ -f "$BUNDLE_RES/AppIcon.icns" ] && cp "$BUNDLE_RES/AppIcon.icns" "$A/Contents/Resources/AppIcon.icns"
    touch "$A"
}
mkdir -p "$HOME/Applications"
make_app "$HOME/Applications/Odds & Whiskers.app" || fail "Couldn't create the app."
make_app "$HOME/Desktop/Odds & Whiskers.app" 2>/dev/null
# nothing Setup made should carry the "downloaded from the internet" mark
xattr -dr com.apple.quarantine "$DEST" "$HOME/Applications/Odds & Whiskers.app" "$HOME/Desktop/Odds & Whiskers.app" 2>/dev/null
echo "done" >> "$LOG"
note "All set! Opening Odds & Whiskers..."
open "$HOME/Applications/Odds & Whiskers.app"
