"""Performance report.

Includes the adverse-selection ("picked off") test: for every contract the bot bid on, did the side
it bid on go on to win, split by contracts where a bid filled versus contracts where none did?
If filled bids win clearly less often than unfilled ones, the fills are being picked off.
"""
from __future__ import annotations

from decimal import Decimal

from .alerts import LABELS
from .money import ZERO, d, d_or_zero


def build_report(store, mode: str) -> dict:
    rows = store._q("""SELECT e.*, c.result AS c_result FROM entries e LEFT JOIN contracts c ON c.ticker=e.ticker
                       WHERE e.mode=? ORDER BY e.id""", (mode,))
    entries = [dict(r) for r in rows]
    sent = [e for e in entries if e["order_id"]]
    filled = [e for e in entries if d_or_zero(e["filled_count"]) > ZERO]
    settled = [e for e in filled if e["settled_result"]]
    wins = [e for e in settled if d_or_zero(e["payout"]) > ZERO]
    net = sum((d(e["pnl"]) for e in settled), ZERO)
    fees = sum((d_or_zero(e["fees"]) for e in filled), ZERO)
    cost = sum((d_or_zero(e["fill_cost"]) for e in settled), ZERO)

    contracts: dict[str, dict] = {}
    for e in entries:
        c = contracts.setdefault(e["ticker"], {"ticker": e["ticker"], "coin": e["coin"], "bids": 0, "filled": False,
                                               "leg": e["leg"], "outcome": e["outcome"], "result": "", "won": None,
                                               "pnl": None})
        c["bids"] += 1
        if d_or_zero(e["filled_count"]) > ZERO:
            c["filled"] = True
            c["leg"], c["outcome"] = e["leg"], e["outcome"]
            c["pnl"] = e["pnl"]
        res = e["c_result"] or e["settled_result"] or ""
        if res:
            c["result"] = res
            c["won"] = c["leg"] == res

    def rate(group):
        known = [c for c in group if c["won"] is not None]
        if not known:
            return {"n": 0, "won": 0, "win_rate": None}
        w = sum(1 for c in known if c["won"])
        return {"n": len(known), "won": w, "win_rate": round(w / len(known), 4)}

    cs = list(contracts.values())
    return {
        "mode": mode, "label": LABELS[mode],
        "bids_sent": len(sent), "bids_filled": len(filled),
        "fill_rate": round(len(filled) / len(sent), 4) if sent else None,
        "settled_positions": len(settled), "wins": len(wins), "losses": len(settled) - len(wins),
        "net_pnl": str(net), "fees": str(fees), "capital_deployed": str(cost),
        "return_on_cost": str((net / cost).quantize(Decimal("0.0001"))) if cost else None,
        "picked_off_test": {"filled_contracts": rate([c for c in cs if c["filled"]]),
                            "unfilled_contracts": rate([c for c in cs if not c["filled"]])},
        "contracts": cs,
    }


def format_report(r: dict) -> str:
    def pct(x):
        return "n/a" if x is None else f"{x * 100:.1f}%"

    po = r["picked_off_test"]
    lines = [
        f"Odds & Whiskers report - {r['label']}",
        "",
        f"Bids sent          {r['bids_sent']}",
        f"Bids filled        {r['bids_filled']}   (fill rate {pct(r['fill_rate'])})",
        f"Settled positions  {r['settled_positions']}   wins {r['wins']}  losses {r['losses']}",
        f"Net P&L            ${Decimal(r['net_pnl']):.2f}   fees ${Decimal(r['fees']):.2f}   "
        f"on ${Decimal(r['capital_deployed']):.2f} deployed"
        + (f" ({float(r['return_on_cost']) * 100:+.2f}%)" if r["return_on_cost"] else ""),
        "",
        "Picked-off test (did the side we bid on win?)",
        f"  contracts where a bid FILLED:   {po['filled_contracts']['won']}/{po['filled_contracts']['n']}  {pct(po['filled_contracts']['win_rate'])}",
        f"  contracts where NO bid filled:  {po['unfilled_contracts']['won']}/{po['unfilled_contracts']['n']}  {pct(po['unfilled_contracts']['win_rate'])}",
        "  If filled bids win clearly less often than unfilled ones, fills are adversely selected.",
        "",
        "This is a small sample. It does not show that the strategy has an edge.",
        "",
        f"{'contract':<34} {'bids':>4} {'side':<5} {'filled':<6} {'result':<6} {'won':<5} {'pnl':>8}",
    ]
    for c in r["contracts"][-60:]:
        won = "" if c["won"] is None else ("yes" if c["won"] else "no")
        pnl = f"{Decimal(c['pnl']):+.2f}" if c["pnl"] else ""
        lines.append(f"{c['ticker']:<34} {c['bids']:>4} {c['outcome']:<5} {'yes' if c['filled'] else 'no':<6} "
                     f"{(c['result'] or '').upper():<6} {won:<5} {pnl:>8}")
    return "\n".join(lines)
