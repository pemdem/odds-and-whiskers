"""Litter Box: several fake-money models trading live prices side by side, to find what works.

Runs as its own process. It reads public market data only (one shared, cached, read-only client; order books
for all coins come from one batch request), and every model trades its own paper simulator with its own
database and limits — the same engine, risk checks and fill rules as the real bot. It can never place a
real order. A summary for the app is written to data/litterbox/summary.json every few seconds.

Start/stop: the app writes data/litterbox/ENABLED or data/litterbox/STOP.
"""
from __future__ import annotations

import asyncio
import json
import logging
import math
import os
import time
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path

import yaml

from .config import PROD_URL, Config, Limits, StrategyCfg
from .engine import Bot
from .logutil import ProcessLock, log, setup_logging
from .models import Book
from .money import d_or_zero
from .providers.base import ApiError, TransportError
from .providers.kalshi import KalshiAPI
from .providers.paper import PaperExchange
from .store import Store

logger = logging.getLogger("favbot.litterbox")
START_CASH = Decimal("100")


@dataclass
class Model:
    id: str
    name: str
    blurb: str
    strategy: dict = field(default_factory=dict)
    bet_usd: Decimal = Decimal("4")
    cash: Decimal = START_CASH
    coins: list[str] | None = None          # coin subset; None = all ORIGINAL_COINS
    role: str = "experiment"                # baseline | experiment | candidate
    group: str = ""                          # how the leaderboard groups models
    level: int = 3                           # Clump level (1-5) for its limits; 3 = Steady
    base: str = ""                           # for a risk-level copy: the model it copies
    limits: Limits | None = None             # explicit limits (the twin copies your real ones)
    mark: str = ""                           # extra part of the season mark: a new mark starts the model fresh


SEASON = "season-3"
ASK = {"entry": "ask"}
_COINS = ["ETH", "SOL", "XRP", "DOGE", "BNB", "ZEC", "HYPE", "NEAR"]
ORIGINAL_COINS = list(_COINS)
# The original strategy, written out in full. Litter Box models are built on THIS, never on config.yaml, so the
# Original stays the same yardstick even after you switch your real bot to something else.
ORIGINAL_STRATEGY = {"window_start_s": 300, "window_end_s": 60, "ask_min": "0.88", "ask_max": "0.97", "max_spread": "0.03",
                     "order_ttl_s": 20, "poll_s": 2.0, "max_bids_per_contract": 20, "entry": "bid", "side": "both"}
MAX_VARIANTS = 12
DEFAULT_VARIANTS = [{"base": "original", "level": 1}, {"base": "original", "level": 5}]

# Season 3: a FIXED set of experiments. It does not change while it runs (Reset starts a new season).
# Risk-level copies (the Clump slider on each card) are added on top, from variants.json.
MODELS = [
    Model("original", "Original", "Your original strategy, unchanged — the fixed yardstick for everything else.",
          {}, role="baseline", group="Baseline"),
    # entry style & timing (all coins, $4)
    Model("asker", "Ask Buyer", "Buys at the asking price instead of waiting at the bid.", dict(ASK), group="Entry & timing"),
    Model("downask", "Down Dog", "Buys at the ask, DOWN favourites only.", {**ASK, "side": "down"}, group="Entry & timing"),
    Model("early", "Early Bird", "Waits at the bid, first minute of the window only.", {"window_end_s": 240}, group="Entry & timing"),
    Model("late", "Night Owl", "Buys at the ask, only in the last 3 minutes.", {**ASK, "window_start_s": 180}, group="Entry & timing"),
    Model("high", "High Shelf", "Buys at the ask, strong favourites only (92–97¢).", {**ASK, "ask_min": "0.92"}, group="Entry & timing"),
    # bet size: now done with risk-level copies (Original · Tiny and Original · Chonky by default)
    # coin groups (buy at the ask)
    Model("big3", "Big Three", "Buys at the ask on ETH, SOL and XRP only.", dict(ASK), coins=["ETH", "SOL", "XRP"], group="Coin groups"),
    Model("smalls", "Small Fry", "Buys at the ask on DOGE, BNB, ZEC, HYPE and NEAR only.", dict(ASK),
          coins=["DOGE", "BNB", "ZEC", "HYPE", "NEAR"], group="Coin groups"),
] + [Model(f"solo-{c.lower()}", f"{c} Solo", f"Buys at the ask on {c} only.", dict(ASK), coins=[c], group="Single coins")
     for c in _COINS]


def candidate_model(root: Path) -> Model | None:
    """The learning loop's current proposal (frozen while it is being tested on fresh markets)."""
    f = root / "lab" / "candidate.json"
    if not f.exists():
        return None
    import json
    c = json.loads(f.read_text(encoding="utf-8"))
    if c.get("status") != "testing":
        return None
    return Model(f"candidate-{c['id']}", f"Candidate #{c['id']}", c.get("blurb", "Proposed from past data; now tested on new markets."),
                 c["strategy"], Decimal(str(c.get("bet_usd", 4))), coins=c.get("coins"), role="candidate", group="Candidate")


def load_models(root: Path, data_root: Path | None = None) -> list[Model]:
    """Optional litterbox.yaml next to config.yaml can replace the default lineup. The candidate slot is added."""
    f = root / "litterbox.yaml"
    models = MODELS
    if f.exists():
        raw = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        custom = [Model(m["id"], m.get("name", m["id"]), m.get("blurb", ""), m.get("strategy", {}),
                        Decimal(str(m.get("bet_usd", 4))), Decimal(str(m.get("cash", START_CASH))), m.get("coins"),
                        m.get("role", "experiment"), m.get("group", "")) for m in raw.get("models", [])]
        models = custom or MODELS
    cand = candidate_model(data_root) if data_root else None
    models = models + ([cand] if cand else [])
    return models + variant_models(models, read_variants(data_root / "litterbox") if data_root else [])


def read_variants(lb_root: Path) -> list[dict]:
    f = lb_root / "variants.json"
    if not f.exists():
        return [dict(v) for v in DEFAULT_VARIANTS]
    try:
        raw = json.loads(f.read_text(encoding="utf-8"))
    except ValueError:
        return []
    return [{"base": str(v["base"]), "level": int(v["level"])} for v in raw
            if isinstance(v, dict) and "base" in v and 1 <= int(v.get("level", 0)) <= 5][:MAX_VARIANTS]


def write_variants(lb_root: Path, variants: list[dict]) -> None:
    lb_root.mkdir(parents=True, exist_ok=True)
    tmp = lb_root / "variants.json.tmp"
    tmp.write_text(json.dumps(variants[:MAX_VARIANTS], indent=2), encoding="utf-8")
    os.replace(tmp, lb_root / "variants.json")


def variant_id(base: str, level: int) -> str:
    return f"{base}-L{level}"


def variant_models(models: list[Model], variants: list[dict]) -> list[Model]:
    """Fake-money copies of a model at another Clump level: same strategy and coins, different limits."""
    from .presets import RISK_LEVELS
    by_id, out, seen = {m.id: m for m in models}, [], set()
    for v in variants:
        b, lv = by_id.get(v["base"]), v["level"]
        if b is None or b.base or b.role == "twin" or lv == b.level or (b.id, lv) in seen:
            continue
        seen.add((b.id, lv))
        _, lname, stake, _, _ = RISK_LEVELS[lv - 1]
        out.append(Model(variant_id(b.id, lv), f"{b.name} · {lname}", f"{b.name} at the {lname} risk level, with fake money.",
                         dict(b.strategy), stake, b.cash, b.coins, "experiment", "Risk levels", lv, b.id))
    return out


def twin_model(cfg: Config) -> Model | None:
    """'Simulated you': your REAL bot's current strategy, coins and limits, with fake money (starting cash = your
    capital cap). Unlike every other model it follows config.yaml; when your settings change it starts fresh."""
    import hashlib
    from .presets import strategy_dict
    lim = cfg.live_limits or cfg.limits_for(cfg.mode)
    if lim is None:
        return None
    st = strategy_dict(cfg.strategy)
    coins = [s[2:-3] for s in cfg.series]
    mark = hashlib.sha256(json.dumps([st, coins, lim.model_dump()], sort_keys=True, default=str).encode()).hexdigest()[:10]
    return Model("twin", "Simulated you", "Your real bot's exact settings, coins and limits — with fake money.", st,
                 Decimal(lim.max_loss_per_position_usd), Decimal(lim.capital_cap_usd),
                 None if sorted(coins) == sorted(ORIGINAL_COINS) else coins, "twin", "Your twin", 3, "", lim, mark)


def model_limits(m: Model) -> Limits:
    """A model's limits come from its Clump level (stake, money at risk at once, bets open at once).
    Base models keep their own bet size at level 3. The twin uses your real limits."""
    if m.limits is not None:
        return m.limits
    from .presets import RISK_LEVELS
    _, _, stake, exposure, positions = RISK_LEVELS[max(1, min(5, m.level)) - 1]
    bet = m.bet_usd if not m.base else stake
    pct = min(Decimal("1"), Decimal(math.ceil(bet / m.cash * 100)) / 100)
    return Limits(capital_cap_usd=m.cash, max_loss_per_position_usd=bet, max_loss_per_position_pct=max(pct, Decimal("0.01")),
                  max_total_exposure_pct=exposure, daily_loss_pct="0.2", max_open_positions=positions)


def model_strategy(m: Model) -> StrategyCfg:
    """ORIGINAL_STRATEGY plus the model's own changes — never the live config."""
    s = {**ORIGINAL_STRATEGY, **m.strategy}
    return StrategyCfg(**{k: (Decimal(str(v)) if k in ("ask_min", "ask_max", "max_spread") else v) for k, v in s.items()})


def model_series(m: Model) -> list[str]:
    return [f"KX{c}15M" for c in (m.coins or ORIGINAL_COINS)]


def prepare_dirs(root: Path, models: list[Model], now: float | None = None) -> list[str]:
    """Each model's folder belongs to one season. Folders from an earlier season, or of models no longer in the
    lineup, are moved to _old/ (kept, not deleted) so no model starts with someone else's bets."""
    ids, moved = {m.id: m for m in models}, []
    want = lambda m: SEASON + (f":{m.mark}" if m.mark else "")          # noqa: E731
    stamp = time.strftime("%Y%m%d-%H%M%S", time.localtime(now or time.time()))
    for d in sorted(p for p in root.iterdir() if p.is_dir() and not p.name.startswith("_")) if root.exists() else []:
        mark = d / "season.txt"
        season = mark.read_text(encoding="utf-8").strip() if mark.exists() else ""
        if d.name not in ids or season != want(ids[d.name]):
            dest = root / "_old" / f"{season.replace(':', '-') or 'season-old'}-{d.name}-{stamp}"
            dest.parent.mkdir(parents=True, exist_ok=True)
            d.rename(dest)
            moved.append(d.name)
    for m in models:
        (root / m.id).mkdir(parents=True, exist_ok=True)
        f = root / m.id / "season.txt"
        if not f.exists() or f.read_text(encoding="utf-8").strip() != want(m):
            f.write_text(want(m), encoding="utf-8")                     # its date = when this model started
    return moved


def backtrack_params(models: list[Model]) -> dict:
    """The same settings expressed for Backtrack, so each model also gets a score on past data."""
    from .backtrack import Params
    out = {}
    for m in models:
        s = {**ORIGINAL_STRATEGY, **m.strategy}
        out[m.id] = (Params(float(s.get("ask_min", 0.88)), float(s.get("ask_max", 0.97)), float(s.get("max_spread", 0.03)),
                            int(s.get("window_start_s", 300)), s.get("side", "both"), s.get("entry", "bid"),
                            int(s.get("window_end_s", 60))), m.coins, float(m.bet_usd))
    return out


class SharedMarketData:
    """One read-only client for every model. Books for all recently requested tickers come in one batch call."""

    def __init__(self, api: KalshiAPI, book_ttl: float = 1.5):
        self.api = api
        self.book_ttl = book_ttl
        self._books: dict[str, tuple[float, Book]] = {}
        self._wanted: dict[str, float] = {}
        self._cache: dict[str, tuple[float, object]] = {}
        self._lock = asyncio.Lock()

    @property
    def clock_skew_s(self):
        return self.api.clock_skew_s

    async def _cached(self, key: str, ttl: float, fn):
        hit = self._cache.get(key)
        if hit and time.time() - hit[0] < ttl:
            return hit[1]
        val = await fn()
        self._cache[key] = (time.time(), val)
        return val

    async def get_exchange_status(self, exchange_index: int = 2):
        return await self._cached(f"status{exchange_index}", 10, lambda: self.api.get_exchange_status(exchange_index))

    async def get_series(self, series: str):
        return await self._cached("series" + series, 3600, lambda: self.api.get_series(series))

    async def list_markets(self, series: str, min_close_ts: int, max_close_ts: int):
        return await self._cached(f"m{series}{min_close_ts // 10}", 10,
                                  lambda: self.api.list_markets(series, min_close_ts, max_close_ts))

    async def get_market(self, ticker: str):
        return await self._cached("mk" + ticker, 10, lambda: self.api.get_market(ticker))

    async def get_orderbook(self, ticker: str) -> Book:
        now = time.time()
        self._wanted[ticker] = now
        hit = self._books.get(ticker)
        if hit and now - hit[0] < self.book_ttl:
            return hit[1]
        async with self._lock:
            hit = self._books.get(ticker)
            if hit and time.time() - hit[0] < self.book_ttl:
                return hit[1]
            tickers = [t for t, ts in self._wanted.items() if now - ts < 10][:100]
            j = await self.api.request("GET", "/markets/orderbooks", params={"tickers": tickers}, cost=len(tickers))
            got = time.time()
            for ob in j.get("orderbooks") or []:
                self._books[ob["ticker"]] = (got, Book.from_api(ob["ticker"], ob, got))
        if ticker not in self._books:
            raise ApiError(404, f"no order book for {ticker}")
        return self._books[ticker][1]


def replace_file(path: Path, text: str, tries: int = 8) -> None:
    """Write a file in one step. Windows refuses to replace a file someone is reading at that instant, so retry."""
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    for i in range(tries):
        try:
            os.replace(tmp, path)
            return
        except PermissionError:
            if i == tries - 1:
                raise
            time.sleep(0.05 * (i + 1))


def _since(d: Path) -> float | None:
    try:
        return (d / "season.txt").stat().st_mtime
    except OSError:
        return None


def _stats(store: Store, start_cash: Decimal) -> dict:
    rows = store._q("""SELECT settled_at, pnl, fill_cost, fees, payout, coin, outcome, price, filled_count FROM entries
                       WHERE mode='paper' AND settled_result IS NOT NULL AND CAST(filled_count AS REAL) > 0
                       ORDER BY settled_at""")
    rets, curve, bal, wins, cost_total, pnl_total = [], [], float(start_cash), 0, 0.0, 0.0
    by_coin: dict[str, dict] = {}
    for r in rows:
        cost = float(d_or_zero(r["fill_cost"]) + d_or_zero(r["fees"]))
        pnl = float(d_or_zero(r["pnl"]))
        won = d_or_zero(r["payout"]) > 0
        wins += won
        c = by_coin.setdefault(r["coin"], {"bets": 0, "wins": 0, "pnl": 0.0, "staked": 0.0})
        c["bets"] += 1
        c["wins"] += int(won)
        c["pnl"] = round(c["pnl"] + pnl, 4)
        c["staked"] = round(c["staked"] + cost, 4)
        cost_total += cost
        pnl_total += pnl
        if cost:
            rets.append(pnl / cost)
        bal += pnl
        curve.append([r["settled_at"], round(bal, 2)])
    n = len(rets)
    mean = sum(rets) / n if n else 0.0
    sample_var = sum((x - mean) ** 2 for x in rets) / max(1, n - 1) if n > 1 else 0.0
    # A winning streak has no spread yet, but every bet at price p can still lose: the return of one bet has
    # variance about (1-p)/p. Never report less uncertainty than that.
    prices = [float(r["price"]) for r in rows if r["price"]]
    model_var = sum((1 - p) / p for p in prices) / len(prices) if prices else 0.0
    sd = math.sqrt(max(sample_var, model_var))
    last = [{"coin": r["coin"], "outcome": r["outcome"], "price": r["price"], "pnl": float(d_or_zero(r["pnl"])),
             "won": d_or_zero(r["payout"]) > 0, "ts": r["settled_at"]} for r in rows[-8:]][::-1]
    return {"bets": len(rows), "wins": int(wins), "losses": len(rows) - int(wins), "pnl": round(pnl_total, 2),
            "roi": mean, "se": sd / math.sqrt(n) if n else None, "staked": round(cost_total, 2),
            "curve": curve[-300:], "last": last, "by_coin": by_coin}


async def run(cfg: Config, root: Path, models: list[Model], duration: float | None = None) -> None:
    api = KalshiAPI(PROD_URL, read_only=True, requests_per_s=2)     # small fixed share; the live bot keeps the rest
    api.limiter.capacity = 4.0
    md = SharedMarketData(api, book_ttl=3.0)
    bots: list[tuple[Model, Bot]] = []
    started = time.time()
    moved = prepare_dirs(root, models)
    if moved:
        log(logger, logging.INFO, "litter box: old folders archived", moved=moved)
    for m in models:
        # fixed settings per model: never taken from config.yaml (which follows your REAL bot)
        st, lim, series = model_strategy(m), model_limits(m), model_series(m)
        mcfg = cfg.model_copy(update={"strategy": st, "paper_limits": lim, "series": series})
        ddir = root / m.id
        store = Store(ddir / "favbot.sqlite3")
        holder = {}
        sim = PaperExchange(store, m.cash, latency_s=cfg.paper.latency_ms / 1000, depth_fraction=cfg.paper.depth_fraction,
                            fee_lookup=lambda t, h=holder: h["bot"].fee_lookup(t))
        bot = Bot(mcfg, "paper", store, md, sim, lim, data_dir=ddir)
        holder["bot"] = bot
        bots.append((m, bot))
    stop = asyncio.Event()

    def write_summary():
            out = {"ts": time.time(), "started_at": started, "pid": os.getpid(), "season": SEASON, "models": []}
            for m, bot in bots:
                snap = bot.portfolio.last
                s = _stats(bot.store, m.cash)
                out["models"].append({
                    "id": m.id, "name": m.name, "blurb": m.blurb, "bet_usd": str(m.bet_usd), "cash_start": str(m.cash),
                    "role": m.role, "group": m.group, "coins": m.coins, "level": m.level, "base": m.base,
                    "since": _since(root / m.id),
                    "limits": {"bet": str(bot.limits.max_loss_per_position_usd),
                               "exposure_pct": str(bot.limits.max_total_exposure_pct),
                               "max_open": bot.limits.max_open_positions},
                    "strategy": {**ORIGINAL_STRATEGY, **m.strategy},
                    "settings": {"entry": bot.cfg.strategy.entry, "side": bot.cfg.strategy.side,
                                 "ask_min": str(bot.cfg.strategy.ask_min), "ask_max": str(bot.cfg.strategy.ask_max),
                                 "window_start_s": bot.cfg.strategy.window_start_s, "window_end_s": bot.cfg.strategy.window_end_s},
                    "equity": float(snap.equity) if snap else float(m.cash),
                    "open": snap.open_positions if snap else 0, **s,
                    "status": [e.status.get("decision") for e in bot.engines][:1],
                })
            replace_file(root / "summary.json", json.dumps(out, default=str))

    async def summary_loop():
        # Never let one bad write end this loop: it is also what notices STOP. (On Windows the app may be reading
        # summary.json at the very moment it is replaced; that used to kill this loop silently.)
        while not stop.is_set():
            if (root / "STOP").exists() or (duration and time.time() - started > duration):
                stop.set()
                break
            try:
                write_summary()
            except Exception:  # noqa: BLE001
                logger.exception("litter box summary not written this time")
            await asyncio.sleep(5)

    async def runner(bot: Bot):
        await bot.run()

    tasks = [asyncio.create_task(runner(b)) for _, b in bots]
    sl = asyncio.create_task(summary_loop())
    try:
        await stop.wait()
    finally:
        for _, b in bots:
            b.stop.set()
        await asyncio.gather(*tasks, return_exceptions=True)
        sl.cancel()
        for _, b in bots:
            await b.shutdown("litter box stopped")
            b.store.close()
        await api.close()


def main(cfg: Config, root: Path, duration: float | None = None) -> int:
    root.mkdir(parents=True, exist_ok=True)
    setup_logging(root, cfg.log_level, console=False)
    lock = ProcessLock(root)
    try:
        lock.acquire()
    except RuntimeError as e:
        print(e)
        return 2
    try:
        if (root / "STOP").exists():
            (root / "STOP").unlink()
        models = load_models(Path(cfg.base_dir), root.parent)
        twin = twin_model(cfg)
        if twin:
            models.append(twin)
        log(logger, logging.INFO, "litter box starting", models=[m.id for m in models])
        asyncio.run(run(cfg, root, models, duration))
        return 0
    except KeyboardInterrupt:
        return 0
    finally:
        lock.release()
